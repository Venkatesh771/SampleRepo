package com.monsanto.tcc.inventorycommon.domain;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;
import org.junit.Test;

import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: mdspark
 * Date: Sep 23, 2009
 * Time: 10:52:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class InventoryBidToObservationAttributeValuesMap_UT {
    @Test
    public void testPut_MapIsEmpty_PutsNewEntry() {
        InventoryBidToObservationAttributeValuesMap map = new InventoryBidToObservationAttributeValuesMap();
        String inventoryBarcode1 = "inventoryBarcode1";
        ObservationAttributeValue observationAttributeValue1 = new ObservationAttributeValue();
        String value1 = "value1";
        observationAttributeValue1.setValue(value1);
        map.put(inventoryBarcode1, observationAttributeValue1);
        List<ObservationAttributeValue> values = map.get(inventoryBarcode1);
        assertNotNull(values);
        assertEquals(1, values.size());
        assertEquals(value1, values.get(0).getValue());
    }

    @Test
    public void testPutTwice_SameBarcode_PutsNewEntryInValueList() {
        InventoryBidToObservationAttributeValuesMap map = new InventoryBidToObservationAttributeValuesMap();
        String inventoryBarcode1 = "inventoryBarcode1";
        ObservationAttributeValue observationAttributeValue1 = new ObservationAttributeValue();
        ObservationAttributeValue observationAttributeValue2 = new ObservationAttributeValue();
        String value1 = "value1";
        String value2 = "value2";
        observationAttributeValue1.setValue(value1);
        observationAttributeValue2.setValue(value2);
        map.put(inventoryBarcode1, observationAttributeValue1);
        map.put(inventoryBarcode1, observationAttributeValue2);
        List<ObservationAttributeValue> values = map.get(inventoryBarcode1);
        assertNotNull(values);
        assertEquals(2, values.size());
        assertEquals(value1, values.get(0).getValue());
        assertEquals(value2, values.get(1).getValue());
    }

    @Test
    public void testPutTwice_DifferentBarcode_TwoSeperateLists() {
        InventoryBidToObservationAttributeValuesMap map = new InventoryBidToObservationAttributeValuesMap();
        String inventoryBarcode1 = "inventoryBarcode1";
        String inventoryBarcode2 = "inventoryBarcode2";
        ObservationAttributeValue observationAttributeValue1 = new ObservationAttributeValue();
        ObservationAttributeValue observationAttributeValue2 = new ObservationAttributeValue();
        String value1 = "value1";
        String value2 = "value2";
        observationAttributeValue1.setValue(value1);
        observationAttributeValue2.setValue(value2);
        map.put(inventoryBarcode1, observationAttributeValue1);
        map.put(inventoryBarcode2, observationAttributeValue2);
        List<ObservationAttributeValue> values1 = map.get(inventoryBarcode1);
        assertNotNull(values1);
        assertEquals(1, values1.size());
        assertEquals(value1, values1.get(0).getValue());
        List<ObservationAttributeValue> values2 = map.get(inventoryBarcode2);
        assertNotNull(values2);
        assertEquals(1, values2.size());
        assertEquals(value2, values2.get(0).getValue());
    }

    @Test
    public void testMarshall_Unmarshal_SameObject() throws Exception {
        InventoryBidToObservationAttributeValuesMap map = new InventoryBidToObservationAttributeValuesMap();
        String inventoryBarcode1 = "inventoryBarcode1";
        String inventoryBarcode2 = "inventoryBarcode2";
        ObservationAttributeValue observationAttributeValue1 = new ObservationAttributeValue();
        ObservationAttributeValue observationAttributeValue2 = new ObservationAttributeValue();
        String value1 = "value1";
        String value2 = "value2";
        observationAttributeValue1.setValue(value1);
        observationAttributeValue2.setValue(value2);
        map.put(inventoryBarcode1, observationAttributeValue1);
        map.put(inventoryBarcode2, observationAttributeValue2);

        MapAdapter adapter = new MapAdapter();

        ObservationAttributeKeyValuePairList observationAttributeKeyValuePairList = adapter.marshal(map.getMap());
        Map<String, List<ObservationAttributeValue>> listMap = adapter.unmarshal(observationAttributeKeyValuePairList);

        List<ObservationAttributeValue> values1 = map.get(inventoryBarcode1);
        assertNotNull(values1);
        assertEquals(1, values1.size());
        assertEquals(value1, values1.get(0).getValue());
        List<ObservationAttributeValue> values2 = map.get(inventoryBarcode2);
        assertNotNull(values2);
        assertEquals(1, values2.size());
        assertEquals(value2, values2.get(0).getValue());
    }
}
