/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertEquals;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RJKENN
 * @version $Revision$
 */
public class PlotRelatedDTO_UT {

  private static final Integer SUB_ROW_DISPLAY_ORDER = 3;



  @Test
  public void calculateSubRowValueReturnsNullWhenSubRowIsNull_UT(){
    PlotRelatedDTO mprd = new PlotRelatedDTO();

    assertThat(mprd.calculateMaleSubRowValue(), is(nullValue()));
  }

  @Test
  public void calculateSubRowValueReturnsSubRowValueWhenPlotTypeIs2_UT(){
    PlotRelatedDTO mprd = new PlotRelatedDTO();
    mprd.setMaleSubRowDisplayOrder(SUB_ROW_DISPLAY_ORDER);
    mprd.setMalePlotType(2);

    assertEquals(SUB_ROW_DISPLAY_ORDER.toString(), mprd.calculateMaleSubRowValue());
  }

  @Test
  public void calculateSubRowValueReturnsCorrectlyWhenPlotTypeIs3_UT() throws Exception {
    //expected:  When plot type = 3, this should return subSubDisplayOrder + character value of subDisplayOrder (1 = A, 2 = B, ..., 26 = z, 27 = AA,..., 702 = zz)
    PlotRelatedDTO mprd = new PlotRelatedDTO();
    mprd.setMalePlotType(3);
    mprd.setMaleSubRowDisplayOrder(4);
    mprd.setMaleSubSubRowDisplayOrder(5);

    assertEquals("5D", mprd.calculateMaleSubRowValue());
  }

  @Test
  public void testBoundariesOfCalculateSubRowValue_UT(){
    PlotRelatedDTO mprd = new PlotRelatedDTO();
    mprd.setMalePlotType(3);
    mprd.setMaleSubSubRowDisplayOrder(44);

    mprd.setMaleSubRowDisplayOrder(1);
    assertEquals("44A", mprd.calculateMaleSubRowValue());

    mprd.setMaleSubRowDisplayOrder(26);
    assertEquals("44Z", mprd.calculateMaleSubRowValue());

    mprd.setMaleSubRowDisplayOrder(27);
    assertEquals("44AA", mprd.calculateMaleSubRowValue());

    mprd.setMaleSubRowDisplayOrder(702);
    assertEquals("44ZZ", mprd.calculateMaleSubRowValue());

    mprd.setMaleSubRowDisplayOrder(703);
    assertEquals("44AAA", mprd.calculateMaleSubRowValue());

    mprd.setMaleSubRowDisplayOrder(0);
    assertEquals("44", mprd.calculateMaleSubRowValue());
  }
}
