package com.monsanto.tcc.inventorycommon.domain;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class Measurement_UT {

    @Test
    public void testGetId() throws Exception {
        Measurement measurement = new Measurement();

        long id = 123;
        measurement.setId(id);

        assertThat(id, is(equalTo(measurement.getId())));
    }

    @Test
    public void testGetName() throws Exception {
        Measurement measurement = new Measurement();

        String name = "SomeName";
        measurement.setName(name);

        assertThat(name, is(equalTo(measurement.getName())));
    }

    @Test
    public void testGetDescription() throws Exception {
        Measurement measurement = new Measurement();

        String description = "Some description.";
        measurement.setDescription(description);

        assertThat(description, is(equalTo(measurement.getDescription())));
    }
}
