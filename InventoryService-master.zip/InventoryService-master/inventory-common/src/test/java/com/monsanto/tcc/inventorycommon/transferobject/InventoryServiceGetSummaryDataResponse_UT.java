package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.client.breedingsamplemanagement.InventoryLotRelation;
import com.monsanto.services.domain.breeding.uom.UnitOfMeasure;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.services.domain.shipping.StorageUnit;
import com.monsanto.tcc.inventorycommon.domain.InventoryBidToObservationAttributeValuesMap;
import com.monsanto.services.domain.germplasm.*;
import com.monsanto.services.domain.breeding.*;
import com.monsanto.tcc.inventorycommon.domain.InventorySample;
import com.monsanto.tcc.inventorycommon.domain.MolecularBreedingRequest;
import com.monsanto.tcc.inventorycommon.domain.RubProj;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.assertEquals;

import java.util.Collections;
import java.util.List;

public class InventoryServiceGetSummaryDataResponse_UT {
    @Mock
    private DisplayInventoryProductName mockDisplayInventoryProductName;
    @Mock
    private GeneticMaterial mockGeneticMaterial;
    @Mock
    private Germplasm mockGermplasm;
    @Mock
    private Inventory mockInventory;
    @Mock
    private InventoryContainer mockInventoryContainer;
    @Mock
    private InventoryLotRelation mockInventoryLotRelation;
    @Mock
    private InventoryType mockInventoryType;
    @Mock
    private LineFunction mockLineFunction;
    @Mock
    private ProductDescription mockProductDescription;
    @Mock
    private ProductName mockProductName;
    @Mock
    private Program mockProgram;
    @Mock
    private ProgramRole mockProgramRole;
    @Mock
    private SharedInventory mockSharedInventory;
    @Mock
    private SharedInventorySummary mockSharedInventorySummary;
    @Mock
    private StorageUnit mockStorageUnit;
    @Mock
    private VegetativeStructure mockVegetativeStructure;
    @Mock
    private GeneticMaterialRubProj mockGeneticMaterialRubProj;
    @Mock
    private InventoryBidToObservationAttributeValuesMap mockInvBidToObservationAttributesValuesMap;
    @Mock
    private MaterialExchange mockMaterialExchange;
    @Mock
    private UnitOfMeasure mockUnitOfMeasure;
    @Mock
    private InbredGermplasm mockInbredGermplasm;
    @Mock
    private RubProj mockRubProj;
    @Mock
    private MolecularBreedingRequest mockMbr;
    @Mock
    private InventorySample mockInventorySample;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void test_GetResponseEnvelope() throws Exception {
        List<DisplayInventoryProductName> mockDisplayInventoryProductNameList = Collections
            .singletonList(mockDisplayInventoryProductName);
        List<GeneticMaterial> mockGeneticMaterialList = Collections.singletonList(mockGeneticMaterial);
        List<Germplasm> mockGermplasmList = Collections.singletonList(mockGermplasm);
        List<Inventory> mockInventoryList = Collections.singletonList(mockInventory);
        List<InventoryContainer> mockInventoryContainerList = Collections.singletonList(mockInventoryContainer);
        List<InventoryLotRelation> mockInventoryLotRelationList = Collections.singletonList(mockInventoryLotRelation);
        List<InventoryType> mockInventoryTypeList = Collections.singletonList(mockInventoryType);
        List<LineFunction> mockLineFunctionList = Collections.singletonList(mockLineFunction);
        List<ProductDescription> mockProductDescriptionList = Collections.singletonList(mockProductDescription);
        List<ProductName> mockProductNameList = Collections.singletonList(mockProductName);
        List<Program> mockProgramList = Collections.singletonList(mockProgram);
        List<ProgramRole> mockProgramRoleList = Collections.singletonList(mockProgramRole);
        List<SharedInventory> mockSharedInventoryList = Collections.singletonList(mockSharedInventory);
        List<SharedInventorySummary> mockSharedInventorySummaryList = Collections
            .singletonList(mockSharedInventorySummary);
        List<StorageUnit> mockStorageUnitList = Collections.singletonList(mockStorageUnit);
        List<VegetativeStructure> mockVegetativeStructureList = Collections.singletonList(mockVegetativeStructure);
        List<GeneticMaterialRubProj> mockGeneticMaterialRubProjList = Collections
            .singletonList(mockGeneticMaterialRubProj);
        List<MaterialExchange> mockMaterialExchangeList = Collections.singletonList(mockMaterialExchange);
        List<UnitOfMeasure> mockUnitOfMeasureList = Collections.singletonList(mockUnitOfMeasure);
        List<InbredGermplasm> mockInbredGermplasmList = Collections.singletonList(mockInbredGermplasm);
        List<RubProj> mockRubProjList = Collections.singletonList(mockRubProj);
        List<MolecularBreedingRequest> mockMbrList = Collections.singletonList(mockMbr);
        List<InventorySample> mockInventorySamples = Collections.singletonList(mockInventorySample);

        InventoryServiceGetSummaryDataResponse testObject = new InventoryServiceGetSummaryDataResponse();
        testObject.setDisplayInventoryProductNames(mockDisplayInventoryProductNameList);
        testObject.setGeneticMaterials(mockGeneticMaterialList);
        testObject.setGeneticMaterialRubProjs(mockGeneticMaterialRubProjList);
        testObject.setGermplasms(mockGermplasmList);
        testObject.setInventories(mockInventoryList);
        testObject.setInventoryContainers(mockInventoryContainerList);
        testObject.setInventoryTypes(mockInventoryTypeList);
        testObject.setLineFunctions(mockLineFunctionList);
        testObject.setProductDescriptions(mockProductDescriptionList);
        testObject.setSharedInventories(mockSharedInventoryList);
        testObject.setSharedInventorySummaries(mockSharedInventorySummaryList);
        testObject.setStorageUnits(mockStorageUnitList);
        testObject.setVegetativeStructures(mockVegetativeStructureList);
        testObject.setProductNames(mockProductNameList);
        testObject.setProgramRoles(mockProgramRoleList);
        testObject.setInventoryLotRelations(mockInventoryLotRelationList);
        testObject.setPrograms(mockProgramList);
        testObject.setInvBidToObservationAttributeValuesMap(mockInvBidToObservationAttributesValuesMap);
        testObject.setMaterialExchanges(mockMaterialExchangeList);
        testObject.setUnitOfMeasures(mockUnitOfMeasureList);
        testObject.setInbredGermplasms(mockInbredGermplasmList);
        testObject.setRubProjs(mockRubProjList);
        testObject.setMolecularBreedingRequests(mockMbrList);
        testObject.setInventorySamples(mockInventorySamples);


        ResponseEnvelope actual = testObject.getResponseEnvelope();

        assertEquals(mockDisplayInventoryProductNameList, actual.getAsList(DisplayInventoryProductName.class));
        assertEquals(mockGeneticMaterialList, actual.getAsList(GeneticMaterial.class));
        assertEquals(mockGeneticMaterialRubProjList, actual.getAsList(GeneticMaterialRubProj.class));
        assertEquals(mockGermplasmList, actual.getAsList(Germplasm.class));
        assertEquals(mockInventoryList, actual.getAsList(Inventory.class));
        assertEquals(mockInventoryContainerList, actual.getAsList(InventoryContainer.class));
        assertEquals(mockInventoryTypeList, actual.getAsList(InventoryType.class));
        assertEquals(mockLineFunctionList, actual.getAsList(LineFunction.class));
        assertEquals(mockProductDescriptionList, actual.getAsList(ProductDescription.class));
        assertEquals(mockSharedInventoryList, actual.getAsList(SharedInventory.class));
        assertEquals(mockSharedInventorySummaryList, actual.getAsList(SharedInventorySummary.class));
        assertEquals(mockStorageUnitList, actual.getAsList(StorageUnit.class));
        assertEquals(mockVegetativeStructureList, actual.getAsList(VegetativeStructure.class));
        assertEquals(mockProductNameList, actual.getAsList(ProductName.class));
        assertEquals(mockProgramRoleList, actual.getAsList(ProgramRole.class));
        assertEquals(mockInventoryLotRelationList, actual.getAsList(InventoryLotRelation.class));
        assertEquals(mockProgramList, actual.getAsList(Program.class));
        assertEquals(mockInvBidToObservationAttributesValuesMap,
            actual.getFirst(InventoryBidToObservationAttributeValuesMap.class));
        assertEquals(mockMaterialExchangeList, actual.getAsList(MaterialExchange.class));
        assertEquals(mockUnitOfMeasureList, actual.getAsList(UnitOfMeasure.class));
        assertEquals(mockInbredGermplasmList, actual.getAsList(InbredGermplasm.class));
        assertEquals(mockRubProjList, actual.getAsList(RubProj.class));
        assertEquals(mockMbrList, actual.getAsList(MolecularBreedingRequest.class));
        assertEquals(mockInventorySamples, actual.getAsList(InventorySample.class));

        assertEquals(24, actual.getAsList(Object.class).size());
    }
}
