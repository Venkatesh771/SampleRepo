/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain.email;

import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

/**
 * User: jjbens2
 * Date: Jun 3, 2010
 */

public class EmailConfiguration_UT {

    @Before
    public void setUp() {
        Map<String, String> map = new HashMap<String, String>(3);
        map.put("default.KEY", "default_key_value");
        map.put("specific.KEY", "specific_key_value");
        map.put("otherkey", "someotherkey");

        EmailConfiguration emailConfig = new EmailConfiguration();
        emailConfig.setResourceMap(map);
    }

    @Test
    public void testGetEnvironmentKey_ReturnsKeyValue() {

        String val = EmailConfiguration.getProperty("KEY", "specific");
        assertEquals("specific_key_value", val);
    }

    @Test
    public void testGetEnvironmentKey_EnvironmentMissing_ReturnsDefault() {
        String val = EmailConfiguration.getProperty("KEY", "otherspecific");
        assertEquals("default_key_value", val);
    }

    @Test
    public void testGetKey_AllKeysMissing_ReturnsNull() {

        String val = EmailConfiguration.getProperty("randomkey");
        assertNull(val);
    }
}