package com.monsanto.tcc.inventorycommon.domain;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class MaterialExchangeRequestDetail_UT {

    @Test
    public void testGetId() throws Exception {
        MaterialExchangeRequestDetail materialExchangeRequestDetail = new MaterialExchangeRequestDetail();
        long id = 123l;

        materialExchangeRequestDetail.setId(id);

        assertThat(materialExchangeRequestDetail.getId(), is(equalTo(id)));
    }

    @Test
    public void testGetMaterialExchange() throws Exception {
        MaterialExchangeRequestDetail materialExchangeRequestDetail = new MaterialExchangeRequestDetail();
        MaterialExchange materialExchange = new MaterialExchange();
        materialExchange.setId(5678l);

        materialExchangeRequestDetail.setMaterialExchange(materialExchange);

        assertThat(materialExchangeRequestDetail.getMaterialExchange(), is(equalTo(materialExchange)));
    }

    @Test
    public void testGetMaterialRequestDetail() throws Exception {
        MaterialExchangeRequestDetail materialExchangeRequestDetail = new MaterialExchangeRequestDetail();
        MaterialRequestDetail detail = new MaterialRequestDetail();
        detail.setMaterialRequestId(3567234l);

        materialExchangeRequestDetail.setMaterialRequestDetail(detail);

        assertThat(materialExchangeRequestDetail.getMaterialRequestDetail(), is(equalTo(detail)));
    }
}
