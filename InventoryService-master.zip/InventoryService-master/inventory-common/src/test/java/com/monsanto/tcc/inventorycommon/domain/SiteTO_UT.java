/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.LazyLoader;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/* NBWALD - Mar 18, 2011 */
public class SiteTO_UT
{
    @Test
    public void testEquals_CglibEnhancedSiteTO()
       throws Exception
    {
        Enhancer enhancer = new Enhancer();
        enhancer.setSuperclass(SiteTO.class);
        enhancer.setCallback(new LazyLoader() {
            @Override
            public Object loadObject() throws Exception {
                SiteTO siteTo = new SiteTO();
                siteTo.setName("MyName");
                return siteTo;
            }
        });
        SiteTO enhancedSiteTO = (SiteTO) enhancer.create();
        SiteTO normalSiteTO = new SiteTO();
        normalSiteTO.setName("MyName");

        assertThat(enhancedSiteTO.equals(normalSiteTO), is(true));
        assertThat(normalSiteTO.equals(enhancedSiteTO), is(true));

        assertThat(enhancedSiteTO.equals(new SiteTO()), is(false));
        assertThat(new SiteTO().equals(enhancedSiteTO), is(false));
    }

    @Test
    public void testHashCode_CglibEnhancedSiteTO()
       throws Exception
    {
        Enhancer enhancer = new Enhancer();
        enhancer.setSuperclass(SiteTO.class);
        enhancer.setCallback(new LazyLoader() {
            @Override
            public Object loadObject() throws Exception {
                SiteTO siteTo = new SiteTO();
                siteTo.setName("MyName");
                return siteTo;
            }
        });
        SiteTO enhancedSiteTO = (SiteTO) enhancer.create();
        SiteTO normalSiteTO = new SiteTO();
        normalSiteTO.setName("MyName");

        assertThat(normalSiteTO.hashCode() == enhancedSiteTO.hashCode(), is(true));
    }
}