package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.breeding.uom.UnitOfMeasure;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class CompositeUnitOfMeasure_UT {

    @Test
    public void testGetId() throws Exception {
        CompositeUnitOfMeasure compositeUnitOfMeasure = new CompositeUnitOfMeasure();

        long id = 123;
        compositeUnitOfMeasure.setId(id);

        assertThat(id, is(equalTo(compositeUnitOfMeasure.getId())));
    }

    @Test
    public void testGetUnitOfMeasure() throws Exception {
        CompositeUnitOfMeasure compositeUnitOfMeasure = new CompositeUnitOfMeasure();

        UnitOfMeasure unitOfMeasure = new UnitOfMeasure(123l, "Pounds");
        compositeUnitOfMeasure.setUnitOfMeasure(unitOfMeasure);

        assertThat(unitOfMeasure, is(equalTo(compositeUnitOfMeasure.getUnitOfMeasure())));
    }

    @Test
    public void testGetMeasurement() throws Exception {
        CompositeUnitOfMeasure compositeUnitOfMeasure = new CompositeUnitOfMeasure();

        Measurement measurement = new Measurement();
        measurement.setId(123l);
        compositeUnitOfMeasure.setMeasurement(measurement);

        assertThat(measurement, is(equalTo(compositeUnitOfMeasure.getMeasurement())));
    }

    @Test
    public void testGetMeasurementSystem() throws Exception {
        CompositeUnitOfMeasure compositeUnitOfMeasure = new CompositeUnitOfMeasure();

        MeasurementSystem measurementSystem = new MeasurementSystem();
        measurementSystem.setId(123l);
        compositeUnitOfMeasure.setMeasurementSystem(measurementSystem);

        assertThat(measurementSystem, is(equalTo(compositeUnitOfMeasure.getMeasurementSystem())));
    }

    @Test
    public void testGetPrecisionAllowed() throws Exception {
        CompositeUnitOfMeasure compositeUnitOfMeasure = new CompositeUnitOfMeasure();

        boolean isPrecisionAllowed = true;
        compositeUnitOfMeasure.setPrecisionAllowed(isPrecisionAllowed);

        assertThat(isPrecisionAllowed, is(equalTo(compositeUnitOfMeasure.isPrecisionAllowed())));
    }

    @Test
    public void testToString() {
        CompositeUnitOfMeasure compositeUnitOfMeasure = new CompositeUnitOfMeasure();

        UnitOfMeasure unitOfMeasure = new UnitOfMeasure(123l, "Pounds");
        compositeUnitOfMeasure.setUnitOfMeasure(unitOfMeasure);

        assertThat("Pounds", is(equalTo(compositeUnitOfMeasure.toString())));
    }
}
