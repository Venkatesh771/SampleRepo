package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.breeding.FateReason;
import org.junit.Test;

import java.util.Arrays;
import java.util.Date;

import static org.junit.Assert.assertEquals;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: 5/24/11
 * Time: 4:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class DiscardInventoryRequest_UT {

    @Test
    public void testDiscardInventoryRequest() {
        DiscardInventoryRequest inventoryRequest = new DiscardInventoryRequest();
        FatedInventory fatedInventory1 = createFatedInventory(new FateReason(new Long(10), "Dummy Fate Reason"), new Long(100), new Date(), true);
        FatedInventory fatedInventory2 = createFatedInventory(new FateReason(new Long(11), "Dummy Fate Reason"), new Long(101), new Date(), false);
        inventoryRequest.setFatedInventories(Arrays.asList(fatedInventory1, fatedInventory2));
        assertEquals(2, inventoryRequest.getAllInventoryIds().size());
        assertEquals(1, inventoryRequest.getKeepQuantityFatedInventory().size());
        assertEquals(1, inventoryRequest.getResetQuantityFatedInventory().size());
    }

    private FatedInventory createFatedInventory(FateReason fateReason, Long inventoryId, Date fateDate, boolean resetInventoryQuantity) {
        FatedInventory fatedInventory = new FatedInventory();
        fatedInventory.setFateReason(fateReason);
        fatedInventory.setInventoryId(inventoryId);
        fatedInventory.setFateDate(fateDate);
        fatedInventory.setResetInventoryQuantity(resetInventoryQuantity);
        return fatedInventory;
    }
}
