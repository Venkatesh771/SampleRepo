/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.inventory;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author mbpenbe
 * @version $Revision$
 */
public class ContactTO_UT {

    @Test
    public void testToString_firstNotNull_middleNotNull_lastNotNull() {
        ContactTO contact = new ContactTO();
        contact.setFirstName("FirstName");
        contact.setMiddleName("MiddleName");
        contact.setLastName("LastName");

        assertEquals("FirstName MiddleName LastName", contact.toString());
    }

    @Test
    public void testToString_firstNotNull_middleIsNull_lastNotNull() {
        ContactTO contact = new ContactTO();
        contact.setFirstName("FirstName");
        contact.setLastName("LastName");

        assertEquals("FirstName LastName", contact.toString());
    }

    @Test
    public void testToString_firstNotNull_middleIsEmptyString_lastNotNull() {
        ContactTO contact = new ContactTO();
        contact.setFirstName("FirstName");
        contact.setMiddleName("");
        contact.setLastName("LastName");

        assertEquals("FirstName LastName", contact.toString());
    }
}