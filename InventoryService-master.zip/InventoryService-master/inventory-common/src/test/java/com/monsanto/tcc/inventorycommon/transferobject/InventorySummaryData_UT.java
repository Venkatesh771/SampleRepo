package com.monsanto.tcc.inventorycommon.transferobject;

import org.junit.Test;

import java.util.Date;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class InventorySummaryData_UT {

    private static final Date SEED_PROCESSING_DATE = new Date();

    @Test
    public void testParseStorageUnitDisplayDNMLWithNull() {
        InventorySummaryData summaryData = new InventorySummaryData();
        summaryData.setStorageUnitDisplayDNML(null);

        assertThat(summaryData.getStorageSite(), is(equalTo(null)));
        assertThat(summaryData.getStorageSubSite(), is(equalTo(null)));
        assertThat(summaryData.getStorageSubSubSite(), is(equalTo(null)));
    }

    @Test
    public void testParseStorageUnitDisplayDNMLWithEmptyString() {
        InventorySummaryData summaryData = new InventorySummaryData();
        summaryData.setStorageUnitDisplayDNML("");

        assertThat(summaryData.getStorageSite(), is(equalTo(null)));
        assertThat(summaryData.getStorageSubSite(), is(equalTo(null)));
        assertThat(summaryData.getStorageSubSubSite(), is(equalTo(null)));
    }

    @Test
    public void testParseStorageUnitDisplayDNMLWithValidData() {
        InventorySummaryData summaryData = new InventorySummaryData();
        summaryData.setStorageUnitDisplayDNML("Monsanto\\Building F\\Room 34");

        assertThat(summaryData.getStorageSite(), is(equalTo("Monsanto")));
        assertThat(summaryData.getStorageSubSite(), is(equalTo("Building F")));
        assertThat(summaryData.getStorageSubSubSite(), is(equalTo("Room 34")));
    }

    @Test
    public void testParseStorageUnitDisplayDNMLWithPartialData() {
        InventorySummaryData summaryData = new InventorySummaryData();
        summaryData.setStorageUnitDisplayDNML("Monsanto\\Building F");

        assertThat(summaryData.getStorageSite(), is(equalTo("Monsanto")));
        assertThat(summaryData.getStorageSubSite(), is(equalTo("Building F")));
        assertThat(summaryData.getStorageSubSubSite(), is(equalTo("")));
    }

    @Test
    public void testGetterAndSetters() {
        InventorySummaryData summaryData = new InventorySummaryData();
        String rating = "1";
        summaryData.setGeneticMaterialInbredLineRating(rating);
        summaryData.setInventorySeedProcessingDate(SEED_PROCESSING_DATE);
        Date tsValue = new java.util.Date(System.currentTimeMillis());
        summaryData.setGeneticMaterialInbredLineRatingTimestamp(tsValue);
        assertThat(summaryData.getGeneticMaterialInbredLineRating(), is(equalTo(rating)));
        assertThat(summaryData.getGeneticMaterialInbredLineRatingTimestamp(), is(equalTo(tsValue)));
        summaryData.setGeneticMaterialSrcMalePlotNbr(1);
        summaryData.setGeneticMaterialSrcSelection("Test");
        summaryData.setGeneticMaterialSrcAdvNumber(1L);
        assertThat(summaryData.getGeneticMaterialSrcMalePlotNbr(), is(equalTo(1)));
        assertThat(summaryData.getGeneticMaterialSrcAdvNumber(), is(equalTo(1L)));
        assertThat(summaryData.getGeneticMaterialSrcSelection(), is(equalTo("Test")));
        assertThat(summaryData.getInventorySeedProcessingDate(), is(SEED_PROCESSING_DATE));
    }

}
