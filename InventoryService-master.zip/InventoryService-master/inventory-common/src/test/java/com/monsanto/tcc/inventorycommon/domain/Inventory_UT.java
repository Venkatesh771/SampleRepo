/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author mbpenbe
 * @version $Revision$
 */
public class Inventory_UT {

    private static final Date INVENTORY_SEED_PROCESSING_DATE = new Date();
    private Inventory inventory;
    private Inventory createInventory;

    @Before
    public void setUp() {
        inventory = new Inventory();
    }

    @Test
    public void testProductName() {
        createInventory = createInventory();
        assertEquals("Unit Test Product Name", createInventory.getProductName());
    }

    @Test
    public void testSeedProcessingDate() {
        inventory.setSeedProcessingDate(INVENTORY_SEED_PROCESSING_DATE);

        assertEquals(INVENTORY_SEED_PROCESSING_DATE, inventory.getSeedProcessingDate());
    }

    @Test
    public void testProductNameDoesNotThrowNPE() {
        assertNull(inventory.getProductName());

        GeneticMaterial gm = new GeneticMaterial();
        inventory.setGeneticMaterial(gm);
        assertNull(inventory.getProductName());

        Germplasm germplasm = new Germplasm();
        gm.setGermplasm(germplasm);
        assertNull(inventory.getProductName());

        Product product = new Product();
        ProductGermplasmXRef xref = new ProductGermplasmXRef(10L, product, germplasm);
        germplasm.setProductGermplasmXRefs(new HashSet<ProductGermplasmXRef>(Arrays.asList(xref)));
        assertNull(inventory.getProductName());

    }

    @Test
    public void testGetBrand() {
        createInventory = createInventory();
        assertEquals("Unit Test Brand", createInventory.getBrand());
    }

    @Test
    public void testGetBrandDoesNotThrowNPE() {
        assertNull(inventory.getBrand());

        GeneticMaterial gm = new GeneticMaterial();
        inventory.setGeneticMaterial(gm);
        assertNull(inventory.getBrand());

        Germplasm germplasm = new Germplasm();
        gm.setGermplasm(germplasm);
        assertNull(inventory.getBrand());

        Product product = new Product();
        ProductGermplasmXRef xref = new ProductGermplasmXRef(10L, product, germplasm);
        germplasm.setProductGermplasmXRefs(new HashSet<ProductGermplasmXRef>(Arrays.asList(xref)));
        assertNull(inventory.getBrand());

    }

    @Test
    public void testGetProductNameForTechUser() {
        createInventory = createInventory();

        DisplayInventoryProdNm displayInventoryProductName = new DisplayInventoryProdNm();
        ProductName productName = new ProductName();

        displayInventoryProductName.setInventory(createInventory);
        displayInventoryProductName.setProductName(productName);
        displayInventoryProductName.setIsVirtualInd("T");

        createInventory.setDisplayInventoryProductNameList(new HashSet<DisplayInventoryProdNm>(Arrays.asList(displayInventoryProductName)));

        productName.setActive(true);
        productName.setName("Product Name for Tech User");

        assertEquals("Product Name for Tech User", createInventory.getProductNameForTechDataUser());
    }

    @Test
    public void testGetProductNameForTechUserReturnsNullIfNoVirtualDisplayProdNmIsFound() {
        createInventory = createInventory();

        DisplayInventoryProdNm displayInventoryProductName = new DisplayInventoryProdNm();
        ProductName productName = new ProductName();

        displayInventoryProductName.setInventory(createInventory);
        displayInventoryProductName.setProductName(productName);
        displayInventoryProductName.setIsVirtualInd("F");

        createInventory.setDisplayInventoryProductNameList(new HashSet<DisplayInventoryProdNm>(Arrays.asList(displayInventoryProductName)));

        productName.setActive(true);
        productName.setName("Product Name for Tech User");

        assertNull(createInventory.getProductNameForTechDataUser());
    }

    @Test
    public void testGetProductNameForTechUserReturnsNullIfNoActiveProductNameIsFound() {
        createInventory = createInventory();

        DisplayInventoryProdNm displayInventoryProductName = new DisplayInventoryProdNm();
        ProductName productName = new ProductName();

        displayInventoryProductName.setInventory(createInventory);
        displayInventoryProductName.setProductName(productName);
        displayInventoryProductName.setIsVirtualInd("T");

        createInventory.setDisplayInventoryProductNameList(new HashSet<DisplayInventoryProdNm>(Arrays.asList(displayInventoryProductName)));

        productName.setActive(false);
        productName.setName("Product Name for Tech User");

        assertNull(createInventory.getProductNameForTechDataUser());
    }

    @Test
    public void testGetBrandNameForTechUser() {
        createInventory = createInventory();

        DisplayInventoryProdNm displayInventoryProductName = new DisplayInventoryProdNm();
        ProductName productName = new ProductName();

        displayInventoryProductName.setInventory(createInventory);
        displayInventoryProductName.setProductName(productName);
        displayInventoryProductName.setIsVirtualInd("T");

        createInventory.setDisplayInventoryProductNameList(new HashSet<DisplayInventoryProdNm>(Arrays.asList(displayInventoryProductName)));

        productName.setActive(true);
        productName.setName("Product Name for Tech User");

        Brand brand = new Brand();
        brand.setName("Test Brand Name for Tech User");
        brand.setRefActive("T");
        productName.setBrand(brand);

        assertEquals("Test Brand Name for Tech User", createInventory.getBrandNameForTechDataUser());
    }

    @Test
    public void testGetBrandNameForTechUserReturnsNullIfNoActiveProductNameIsFound() {
        createInventory = createInventory();

        DisplayInventoryProdNm displayInventoryProductName = new DisplayInventoryProdNm();
        ProductName productName = new ProductName();

        displayInventoryProductName.setInventory(createInventory);
        displayInventoryProductName.setProductName(productName);
        displayInventoryProductName.setIsVirtualInd("T");

        createInventory.setDisplayInventoryProductNameList(new HashSet<DisplayInventoryProdNm>(Arrays.asList(displayInventoryProductName)));

        productName.setActive(false);
        productName.setName("Product Name for Tech User");

        Brand brand = new Brand();
        brand.setName("Test Brand Name for Tech User");
        brand.setRefActive("T");
        productName.setBrand(brand);

        assertNull(createInventory.getBrandNameForTechDataUser());
    }

    @Test
    public void testGetBrandNameForTechUserReturnsNullIfNoActiveBrandNameIsFound() {
        createInventory = createInventory();

        DisplayInventoryProdNm displayInventoryProductName = new DisplayInventoryProdNm();
        ProductName productName = new ProductName();

        displayInventoryProductName.setInventory(createInventory);
        displayInventoryProductName.setProductName(productName);
        displayInventoryProductName.setIsVirtualInd("T");

        createInventory.setDisplayInventoryProductNameList(new HashSet<DisplayInventoryProdNm>(Arrays.asList(displayInventoryProductName)));

        productName.setActive(true);
        productName.setName("Product Name for Tech User");

        Brand brand = new Brand();
        brand.setName("Test Brand Name for Tech User");
        brand.setRefActive("F");
        productName.setBrand(brand);

        assertNull(createInventory.getBrandNameForTechDataUser());
    }

    private Inventory createInventory() {
        GeneticMaterial gm = new GeneticMaterial();
        inventory.setGeneticMaterial(gm);

        Germplasm germplasm = new Germplasm();
        gm.setGermplasm(germplasm);

        Product product = new Product();
        ProductGermplasmXRef xref = new ProductGermplasmXRef(10L, product, germplasm);
        germplasm.setProductGermplasmXRefs(new HashSet<ProductGermplasmXRef>(Arrays.asList(xref)));

        ProductName name = new ProductName();
        product.setProductNames(new HashSet<ProductName>(Arrays.asList(name)));
        name.setName("Unit Test Product Name");

        Brand brand = new Brand();
        brand.setName("Unit Test Brand");
        name.setBrand(brand);
        brand.setRefActive("F");

        return inventory;
    }

    @Test
    public void testGetStorageContainerBarcode_HandlesNullStorageContainerAndNullStorageUnit() {
        assertNull(inventory.getStorageContainerBarcode());

        InventoryContainer inventoryContainer = new InventoryContainer();
        inventory.setInventoryContainers(new HashSet<InventoryContainer>(Arrays.asList(inventoryContainer)));

        assertNull(inventory.getStorageContainerBarcode());
    }

    @Test
    public void testGetStorageContainerBarcode_ReturnsStorageUnitBarcodeIfExists() {
        InventoryContainer inventoryContainer = new InventoryContainer();
        StorageUnit storageUnit = new StorageUnit();
        storageUnit.setBarcode("STORAGEUNIT_BARCODE");

        inventory.setInventoryContainers(new HashSet<InventoryContainer>(Arrays.asList(inventoryContainer)));
        inventoryContainer.setStorageUnit(storageUnit);

        assertEquals("STORAGEUNIT_BARCODE", inventory.getStorageContainerBarcode());
    }

    @Test
    public void testGetStorageContainerBarcode_ReturnsStorageContainerBarcodeIfExists() {
        InventoryContainer inventoryContainer = new InventoryContainer();
        StorageContainer storageContainer = new StorageContainer();
        storageContainer.setBarcode("STORAGECONTAINER_BARCODE");

        inventory.setInventoryContainers(new HashSet<InventoryContainer>(Arrays.asList(inventoryContainer)));
        inventoryContainer.setStorageContainer(storageContainer);

        assertEquals("STORAGECONTAINER_BARCODE", inventory.getStorageContainerBarcode());

    }

    @Test
    public void testGetStorageContainerBarcode_ReturnsStorageContainerBarcodeByDefaultIfBothExists() {
        InventoryContainer inventoryContainer = new InventoryContainer();

        StorageUnit storageUnit = new StorageUnit();
        storageUnit.setBarcode("STORAGEUNIT_BARCODE");

        StorageContainer storageContainer = new StorageContainer();
        storageContainer.setBarcode("STORAGECONTAINER_BARCODE");

        inventory.setInventoryContainers(new HashSet<InventoryContainer>(Arrays.asList(inventoryContainer)));
        inventoryContainer.setStorageContainer(storageContainer);
        inventoryContainer.setStorageUnit(storageUnit);

        assertEquals("STORAGECONTAINER_BARCODE", inventory.getStorageContainerBarcode());
    }


    @Test
    public void testGetStorageContainerName_HandlesNullStorageContainerAndNullStorageUnit() {
        assertNull(inventory.getStorageContainerName());

        InventoryContainer inventoryContainer = new InventoryContainer();
        inventory.setInventoryContainers(new HashSet<InventoryContainer>(Arrays.asList(inventoryContainer)));

        assertNull(inventory.getStorageContainerName());
    }

    @Test
    public void testGetStorageContainerName_ReturnsStorageUnitBarcodeIfExists() {
        InventoryContainer inventoryContainer = new InventoryContainer();
        StorageUnit storageUnit = new StorageUnit();
        storageUnit.setName("STORAGEUNIT_NAME");

        inventory.setInventoryContainers(new HashSet<InventoryContainer>(Arrays.asList(inventoryContainer)));
        inventoryContainer.setStorageUnit(storageUnit);

        assertEquals("STORAGEUNIT_NAME", inventory.getStorageContainerName());
    }

    @Test
    public void testGetStorageContainerName_ReturnsStorageContainerBarcodeIfExists() {
        InventoryContainer inventoryContainer = new InventoryContainer();
        StorageContainer storageContainer = new StorageContainer();
        storageContainer.setName("STORAGECONTAINER_NAME");

        inventory.setInventoryContainers(new HashSet<InventoryContainer>(Arrays.asList(inventoryContainer)));
        inventoryContainer.setStorageContainer(storageContainer);

        assertEquals("STORAGECONTAINER_NAME", inventory.getStorageContainerName());

    }

    @Test
    public void testGetStorageContainerName_ReturnsStorageContainerBarcodeByDefaultIfBothExists() {
        inventory.setSeedProcessingDate(INVENTORY_SEED_PROCESSING_DATE);

        InventoryContainer inventoryContainer = new InventoryContainer();

        StorageUnit storageUnit = new StorageUnit();
        storageUnit.setName("STORAGEUNIT_NAME");

        StorageContainer storageContainer = new StorageContainer();
        storageContainer.setName("STORAGECONTAINER_NAME");

        inventory.setInventoryContainers(new HashSet<InventoryContainer>(Arrays.asList(inventoryContainer)));
        inventoryContainer.setStorageContainer(storageContainer);
        inventoryContainer.setStorageUnit(storageUnit);

        assertEquals("STORAGECONTAINER_NAME", inventory.getStorageContainerName());
    }

}
