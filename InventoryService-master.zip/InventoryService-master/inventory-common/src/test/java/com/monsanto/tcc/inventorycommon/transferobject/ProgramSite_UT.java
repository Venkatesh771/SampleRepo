/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.breeding.Program;
import com.monsanto.tcc.inventorycommon.domain.SiteTO;
import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

/* NBWALD - Feb 8, 2011 */
public class ProgramSite_UT
{
    @Test
    public void testToString()
       throws Exception
    {
        Program program = new Program();
        program.setProgramRefId("17");
        program.setName("LDB: KRYSTAL SCHATZ");

        SiteTO site = new SiteTO();
        site.setName("Chesterfield");

        ProgramSite programSite = new ProgramSite();
        programSite.setProgram(program);
        programSite.setSite(site);

        assertEquals("17 - LDB: KRYSTAL SCHATZ (Chesterfield)", programSite.toString());
    }

    @Test
    public void testToString_NullSite()
       throws Exception
    {
        Program program = new Program();
        program.setProgramRefId("17");
        program.setName("LDB: KRYSTAL SCHATZ");

        SiteTO site = null;

        ProgramSite programSite = new ProgramSite();
        programSite.setProgram(program);
        programSite.setSite(site);

        assertEquals("17 - LDB: KRYSTAL SCHATZ", programSite.toString());
    }

    @Test
    public void testEqualsAndHashCode()
       throws Exception
    {
        SiteTO siteA = new SiteTO();
        siteA.setSiteId(1L);
        SiteTO siteB = new SiteTO();
        siteB.setSiteId(2L);
        Program programA = new Program();
        programA.setProgramId(3L);
        Program programB = new Program();
        programB.setProgramId(4L);

        ProgramSite programSiteAA = new ProgramSite();
        programSiteAA.setProgram(programA);
        programSiteAA.setSite(siteA);

        ProgramSite programSiteAAOther = new ProgramSite();
        programSiteAAOther.setProgram(programA);
        programSiteAAOther.setSite(siteA);

        ProgramSite programSiteAB = new ProgramSite();
        programSiteAB.setProgram(programA);
        programSiteAB.setSite(siteB);

        ProgramSite programSiteBA = new ProgramSite();
        programSiteBA.setProgram(programB);
        programSiteBA.setSite(siteA);

        ProgramSite programSiteANull = new ProgramSite();
        programSiteANull.setProgram(programA);
        programSiteANull.setSite(null);


        ProgramSite programSiteNullA = new ProgramSite();
        programSiteNullA.setProgram(null);
        programSiteNullA.setSite(siteA);

        assertAreEqual(programSiteAA, programSiteAA, true);
        assertAreEqual(programSiteAA, programSiteAAOther, true);
        assertAreEqual(programSiteAA, programSiteAB, false);
        assertAreEqual(programSiteAA, programSiteBA, false);
        assertAreEqual(programSiteAA, programSiteANull, false);
        assertAreEqual(programSiteAA, programSiteNullA, false);
    }

    private void assertAreEqual(ProgramSite a, ProgramSite b, boolean equal) {
        assertThat(a.equals(b), is(equal));
        assertThat(b.equals(a), is(equal));
        if(equal) {
            assertThat(a.hashCode(), is(b.hashCode()));
        }
    }
}