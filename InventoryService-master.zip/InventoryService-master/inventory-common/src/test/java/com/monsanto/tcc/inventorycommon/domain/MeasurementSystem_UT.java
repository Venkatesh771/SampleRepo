package com.monsanto.tcc.inventorycommon.domain;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class MeasurementSystem_UT {

    @Test
    public void testGetId() throws Exception {
        MeasurementSystem measurementSystem = new MeasurementSystem();

        long id = 123;
        measurementSystem.setId(id);

        assertThat(id, is(equalTo(measurementSystem.getId())));
    }

    @Test
    public void testGetName() throws Exception {
        MeasurementSystem measurementSystem = new MeasurementSystem();

        String name = "SomeName";
        measurementSystem.setName(name);

        assertThat(name, is(equalTo(measurementSystem.getName())));
    }

    @Test
    public void testGetDescription() throws Exception {
        MeasurementSystem measurementSystem = new MeasurementSystem();

        String description = "Some description.";
        measurementSystem.setDescription(description);

        assertThat(description, is(equalTo(measurementSystem.getDescription())));
    }
}
