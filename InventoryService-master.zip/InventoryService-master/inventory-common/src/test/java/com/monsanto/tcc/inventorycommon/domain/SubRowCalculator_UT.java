/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import org.junit.Test;

import static junit.framework.Assert.assertEquals;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertThat;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rjkenn
 * @version $Revision$
 */
public class SubRowCalculator_UT {
  @Test
  public void calculateSubRowValueReturnsNullWhenNecessaryFieldsAreNull_UT(){
    assertThat(SubRowCalculator.calculateSubRowValue(null, null, null), is(nullValue()));
    assertThat(SubRowCalculator.calculateSubRowValue(2, null, null), is(nullValue()));
  }


  @Test
  public void calculateSubRowValueReturnsSubRowValueWhenPlotTypeIs2_UT(){
    assertEquals("13", SubRowCalculator.calculateSubRowValue(2, 13, 2389));
  }

  @Test
  public void calculateSubRowValueReturnsCorrectlyWhenPlotTypeIs3_UT() throws Exception {
    //expected:  When plot type = 3, this should return subSubDisplayOrder + character value of subDisplayOrder (1 = A, 2 = B, ..., 26 = z, 27 = AA,..., 702 = zz)
    assertEquals("5D", SubRowCalculator.calculateSubRowValue(3, 4, 5));
  }

  @Test
  public void boundariesOfCalculateSubRowValue_UT(){
    Integer plotType = 3;
    Integer subSubRowDisplayOrder = 44;
    Integer subRowDisplayOrder = 1;

    assertEquals("44A", SubRowCalculator.calculateSubRowValue(plotType, subRowDisplayOrder, subSubRowDisplayOrder));

    subRowDisplayOrder = 26;
    assertEquals("44Z", SubRowCalculator.calculateSubRowValue(plotType, subRowDisplayOrder, subSubRowDisplayOrder));

    subRowDisplayOrder = 27;
    assertEquals("44AA", SubRowCalculator.calculateSubRowValue(plotType, subRowDisplayOrder, subSubRowDisplayOrder));

    subRowDisplayOrder = 702;
    assertEquals("44ZZ", SubRowCalculator.calculateSubRowValue(plotType, subRowDisplayOrder, subSubRowDisplayOrder));

    subRowDisplayOrder = 703;
    assertEquals("44AAA", SubRowCalculator.calculateSubRowValue(plotType, subRowDisplayOrder, subSubRowDisplayOrder));

    subRowDisplayOrder = 0;
    assertEquals("44", SubRowCalculator.calculateSubRowValue(plotType, subRowDisplayOrder, subSubRowDisplayOrder));
  }
}