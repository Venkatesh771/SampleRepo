package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.bpm.ActivityInstance;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;

public class MaterialRequestPublishData_UT {

    @Test
    public void testGetMaterialRequestId() throws Exception {
        MaterialRequestPublishData data = new MaterialRequestPublishData();
        long id = 123l;

        data.setMaterialRequestDetailId(id);

        assertThat(data.getMaterialRequestDetailId(), is(equalTo(id)));
    }


    @Test
    public void testGetComments() throws Exception {
        MaterialRequestPublishData data = new MaterialRequestPublishData();
        String comments = "comments";

        data.setComments(comments);

        assertThat(data.getComments(), is(equalTo(comments)));
    }

    @Test
    public void testGetPublishInventoryAmounts() {
        MaterialRequestPublishData data = new MaterialRequestPublishData();
        List<InventoryAmount> inventoryAmounts = new ArrayList<InventoryAmount>();
        inventoryAmounts.add(new InventoryAmount());
        data.setPublishInventoryAmounts(inventoryAmounts);

        assertThat(data.getPublishInventoryAmounts(), is(inventoryAmounts));
    }

    @Test
    public void testGetBpmActivity() {
        ActivityInstance bpmActivityInstance = mock(ActivityInstance.class);
        MaterialRequestPublishData data = new MaterialRequestPublishData();
        data.setBpmActivityInstance(bpmActivityInstance);

        assertThat(data.getBpmActivityInstance(), is(bpmActivityInstance));
    }
}
