package com.monsanto.tcc.inventorycommon;

import org.junit.Test;
import org.springframework.beans.BeanInstantiationException;
import org.springframework.beans.BeanUtils;

import java.beans.PropertyDescriptor;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FilenameFilter;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class BeanDefinition_UT {

        private static final String[] PACKAGES = new String[]{
                "com.monsanto.tcc.inventorycommon"
        };

        private static final Class[] IGNORED_CLASSES = new Class[] {};

        @Test
        public void testBeans() throws Exception {
            List<Class> pojoClasses = getAllPojos(PACKAGES);

            for (Class pojoClass : pojoClasses) {
                if (shouldCover(pojoClass)) {
                    coverProperties(pojoClass);
                } else if (pojoClass.isEnum()) {
                    pojoClass.getEnumConstants();
                }
            }
        }

        private boolean shouldCover(Class pojoClass) {
            return classNotIgnored(pojoClass) && classModifiersSupported(pojoClass);
        }

        private boolean classNotIgnored(Class pojoClass) {
            for (Class ignoredClass : IGNORED_CLASSES) {
                if (ignoredClass.isAssignableFrom(pojoClass)) {
                    return false;
                }
            }
            return true;
        }

        private boolean classModifiersSupported(Class clazz) {
            return !(Modifier.isInterface(clazz.getModifiers())
                    || Modifier.isAbstract(clazz.getModifiers())
                    || clazz.isEnum());
        }

        private List<Class> getAllPojos(String[] packageFragmentRoot) throws ClassNotFoundException {
            List<Class> pojos = new ArrayList<Class>();
            for (String packageName : packageFragmentRoot) {
                File packageDir = getPackageFragmentRootFile(packageName);
                addClasses(packageName, packageDir, pojos);
            }
            return pojos;
        }

        private File getPackageFragmentRootFile(String packageFragmentRoot) {
            URL urlOfPackage = getClass().getClassLoader().getResource(slashPackageName(packageFragmentRoot));
            String absolutePath = getAbsolutePath(urlOfPackage);
            absolutePath = absolutePath.replace("test-classes", "classes");
            return new File(absolutePath);
        }

        private String slashPackageName(String dotPackageName) {
            return dotPackageName.replaceAll("\\.", "/");
        }

        private String getAbsolutePath(URL url) {
            if (!"file".equals(url.getProtocol())) {
                throw new RuntimeException("This doesn't work with anything but local class files.  Protocol was: " + url.getProtocol());
            }
            return url.getPath().replaceAll("\\%20", " ");
        }

        private void addClasses(String packageFragmentRoot, File filePackageFragment, List<Class> pojos) throws ClassNotFoundException {
            FilenameFilter classFileFilter = getClassFileFilter();
            File[] files = filePackageFragment.listFiles();
            for (File file : files) {
                if (classFileFilter.accept(filePackageFragment, file.getName())) {
                    pojos.add(getClass(packageFragmentRoot, file.getName()));
                } else if (file.isDirectory()) {
                    String extendedPackage = packageFragmentRoot + "." + file.getName();
                    addClasses(extendedPackage, file, pojos);
                }
            }
        }

        private FilenameFilter getClassFileFilter() {
            return new FilenameFilter() {
                public boolean accept(File dir, String name) {
                    return name.endsWith(".class");
                }
            };
        }

        private Class getClass(String packageName, String fileName) throws ClassNotFoundException {
            String className = packageName + "." + fileName.substring(0, fileName.indexOf(".class"));
            return getClass().getClassLoader().loadClass(className);
        }

        @SuppressWarnings({"ObjectEqualsNull"})
        private void coverProperties(Class clazz) {
            PropertyDescriptor[] descriptors = BeanUtils.getPropertyDescriptors(clazz);
            Object object;
            try {
                object = BeanUtils.instantiateClass(clazz);
            } catch (BeanInstantiationException ignored) {
                return;
            }
            object.equals(object);
            object.equals(null);
            object.equals("");
            try {
                object.equals(BeanUtils.instantiateClass(clazz));
            } catch (Exception ignored) {
            }
            try {
                object.toString();
            } catch (Exception ignored) {
            }
            extensivelyTestOverloadedObjectMethods(clazz, descriptors, object);
            for (PropertyDescriptor descriptor : descriptors) {
                coverProperty(object, descriptor);
            }
        }

        private void extensivelyTestOverloadedObjectMethods(Class clazz, PropertyDescriptor[] descriptors, Object object) {
            Object object2 = BeanUtils.instantiateClass(clazz);
            try {
                object2.hashCode();
            } catch (Exception ignored) {
            }
            populateObjects(object, object2, descriptors);
            for (Field field : object.getClass().getDeclaredFields()) {
                try {
                    changeOutValueForFieldAndRunOverloadedMethods(descriptors, object, object2, field);
                } catch (Exception e) {/* do nothing */}
            }
        }

        private void changeOutValueForFieldAndRunOverloadedMethods(PropertyDescriptor[] descriptors, Object object1, Object object2, Field field) throws IllegalAccessException, InvocationTargetException {
            Method writeMethod = getWriteMethod(descriptors, field);
            Method readMethod = getReadMethod(descriptors, field);
            Object oldValue = readMethod.invoke(object2);
            testOverloadedMethods(object1, object2);
            if (field.getType().isPrimitive()) {
                setPrimativeValue(object1, field, writeMethod, false);
            } else {
                Object newValue = getNonPrimativeValue(field);
                writeMethod.invoke(object2, newValue);
            }
            testOverloadedMethods(object1, object2);
            if (!field.getType().isPrimitive()) {
                Object nullValue = null;
                writeMethod.invoke(object2, nullValue);
                testOverloadedMethods(object1, object2);
                testOverloadedMethods(object2, object1);
                writeMethod.invoke(object1, nullValue);
                testOverloadedMethods(object1, object2);
            }
            if (field.getType().isPrimitive()) {
                setPrimativeValue(object1, field, writeMethod, true);
            } else {
                writeMethod.invoke(object1, oldValue);
                writeMethod.invoke(object2, oldValue);
            }
        }

        private void testOverloadedMethods(Object object1, Object object2) {
            object1.equals(object2);
            object2.toString();
            object2.hashCode();
        }

        private Method getWriteMethod(PropertyDescriptor[] descriptors, Field field) {
            for (PropertyDescriptor propertyDescriptor : descriptors) {
                if (propertyDescriptor.getName().equals(field.getName())) {
                    return propertyDescriptor.getWriteMethod();
                }
            }
            return null;
        }

        private Method getReadMethod(PropertyDescriptor[] descriptors, Field field) {
            for (PropertyDescriptor propertyDescriptor : descriptors) {
                if (propertyDescriptor.getName().equals(field.getName())) {
                    return propertyDescriptor.getReadMethod();
                }
            }
            return null;
        }

        private void populateObjects(Object object1, Object object2, PropertyDescriptor[] descriptors) {
            for (Field field : object1.getClass().getDeclaredFields()) {
                if (!field.getType().getName().equals("com.intellij.rt.coverage.data.ClassData") && !Modifier.isFinal(field.getModifiers())) {
                    if (field.getType().isPrimitive()) {
                        Method method = getWriteMethod(descriptors, field);
                        setPrimativeValue(object1, field, method, true);
                        setPrimativeValue(object2, field, method, true);
                    } else {
                        try {
                            Object value = getNonPrimativeValue(field);
                            Method method = getWriteMethod(descriptors, field);
                            if (method != null) {
                                method.invoke(object1, value);
                                method.invoke(object2, value);
                            }
                        } catch (NullPointerException e) {
                            e.printStackTrace();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }

        @SuppressWarnings({"UnnecessaryBoxing"})
        private Object getNonPrimativeValue(Field field) {
            Object value = null;
            if (field.getType().isInterface()) {
                if (field.getType().getSimpleName().equals("List")) {
                    value = new ArrayList();
                } else if (field.getType().getSimpleName().equals("Map")) {
                    value = new HashMap();
                } else if (field.getType().getSimpleName().equals("Set")) {
                    value = new HashSet();
                }
            } else if (field.getType().isEnum()) {
                value = field.getType().getEnumConstants()[0];
            } else if (field.getType().getSuperclass().equals(Number.class) || field.getType().equals(Boolean.class) || field.getType().equals(Number.class)) {
                if (field.getType().equals(Boolean.class)) {
                    value = Boolean.FALSE;
                } else if (field.getType().equals(Integer.class)) {
                    value = new Integer(9);
                } else if (field.getType().equals(Long.class)) {
                    value = new Long(9);
                } else if (field.getType().equals(Double.class)) {
                    value = new Double(9);
                } else if (field.getType().equals(Float.class)) {
                    value = new Float(9);
                } else if (field.getType().equals(Byte.class)) {
                    value = new Byte("a");
                } else if (field.getType().equals(Short.class)) {
                    value = new Short("a");
                } else {
                    value = new Integer(9);
                }
            } else if (Modifier.isAbstract(field.getType().getModifiers())) {
                if (field.getType().equals(OutputStream.class)) {
                    value = new ByteArrayOutputStream();
                }
            } else if (!field.getType().getName().equals("com.intellij.rt.coverage.data.ClassData")) {
                value = BeanUtils.instantiateClass(field.getType());
            }
            return value;
        }

        private void setPrimativeValue(Object object, Field field, Method method, boolean useDefault) {
            if (method == null) return;
            try {
                if (field.getType().equals(boolean.class)) {
                    method.invoke(object, useDefault);
                } else if (field.getType().equals(int.class)) {
                    method.invoke(object, useDefault ? 5 : 9);
                } else if (field.getType().equals(long.class)) {
                    method.invoke(object, useDefault ? 6L : 10L);
                } else if (field.getType().equals(double.class)) {
                    method.invoke(object, useDefault ? 7D : 11D);
                } else if (field.getType().equals(float.class)) {
                    method.invoke(object, useDefault ? 8F : 12F);
                } else if (field.getType().equals(byte.class)) {
                    byte b = 1;
                    method.invoke(object, useDefault ? b : 2);
                } else if (field.getType().equals(char.class)) {
                    method.invoke(object, useDefault ? 'a' : 'b');
                } else if (field.getType().equals(short.class)) {
                    short s = 'a';
                    method.invoke(object, useDefault ? s : 'b');
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private void coverProperty(Object object, PropertyDescriptor descriptor) {
            Object result = null;
            try {
                result = descriptor.getReadMethod().invoke(object);
            } catch (Exception e) {/* do nothing */}
            try {
                descriptor.getWriteMethod().invoke(object, result);
            } catch (Exception e) {/* do nothing */}
        }

}
