package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.domain.MaterialSource;

import java.util.List;

/**
 * Created by IntelliJ IDEA. User: sssing5 Date: Jul 21, 2009 Time: 5:32:16 PM
 */
public class GetSourcesResponse {
    private List<MaterialSource> materialSources;

    public List<MaterialSource> getMaterialSources() {
        return materialSources;
    }

    public void setMaterialSources(List<MaterialSource> materialSources) {
        this.materialSources = materialSources;
    }
}
