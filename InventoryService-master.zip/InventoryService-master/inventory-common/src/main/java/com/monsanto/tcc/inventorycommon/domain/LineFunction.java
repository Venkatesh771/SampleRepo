/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "Line_Function")
public class LineFunction {
    private Long lineFunctionId;
    private String name;
    private boolean refActive;
    private String lineFunctionRefId;
    private Long listOrder;

    public LineFunction() {
    }

    public LineFunction(Long lineFunctionId, String name, boolean refActive, String lineFunctionRefId, Long listOrder) {
        this.lineFunctionId = lineFunctionId;
        this.name = name;
        this.refActive = refActive;
        this.lineFunctionRefId = lineFunctionRefId;
        this.listOrder = listOrder;
    }

    public Long getLineFunctionId() {
        return lineFunctionId;
    }

    public void setLineFunctionId(Long lineFunctionId) {
        this.lineFunctionId = lineFunctionId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public String getLineFunctionRefId() {
        return lineFunctionRefId;
    }

    public void setLineFunctionRefId(String lineFunctionRefId) {
        this.lineFunctionRefId = lineFunctionRefId;
    }

    public Long getListOrder() {
        return listOrder;
    }

    public void setListOrder(Long listOrder) {
        this.listOrder = listOrder;
    }
}