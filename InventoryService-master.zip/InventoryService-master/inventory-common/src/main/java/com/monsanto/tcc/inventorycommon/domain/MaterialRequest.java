package com.monsanto.tcc.inventorycommon.domain;

import java.util.Date;
import java.util.Set;

import com.monsanto.services.domain.breeding.Program;
import com.monsanto.services.domain.protocol.MidasUser;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 24, 2009
 * Time: 10:45:22 AM
 */
public class MaterialRequest {
    private Long materialRequestId;
    private Program requestorProgram;
    private Program providerProgram;
    private Date requestedDate;
    private String comments;
    private String requestingUserIdTxt;
    private Long requestUniqueIdNumber;
    private Set<MaterialRequestDetail> details;
    private MidasUser requestingUser;

    public Long getMaterialRequestId() {
        return materialRequestId;
    }

    public void setMaterialRequestId(Long materialRequestId) {
        this.materialRequestId = materialRequestId;
        // populate into children
        if( details != null ) {
            for( MaterialRequestDetail detail : details ) {
                detail.setMaterialRequestId(materialRequestId);
            }
        }
    }

    public String getRequestingUserIdTxt() {
        return requestingUserIdTxt;
    }

    public void setRequestingUserIdTxt(String requestingUserIdTxt) {
        this.requestingUserIdTxt = requestingUserIdTxt;
    }

    public Program getRequestorProgram() {
        return requestorProgram;
    }

    public void setRequestorProgram(Program requestorProgram) {
        this.requestorProgram = requestorProgram;
    }

    public Program getProviderProgram() {
        return providerProgram;
    }

    public void setProviderProgram(Program providerProgram) {
        this.providerProgram = providerProgram;
    }

    public Date getRequestedDate() {
        return requestedDate;
    }

    public void setRequestedDate(Date requestedDate) {
        this.requestedDate = requestedDate;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Set<MaterialRequestDetail> getDetails() {
        return details;
    }

    public void setDetails(Set<MaterialRequestDetail> details) {
        this.details = details;
    }

    public Long getRequestUniqueIdNumber() {
        return requestUniqueIdNumber;
    }

    public void setRequestUniqueIdNumber(Long requestUniqueIdNumber) {
        this.requestUniqueIdNumber = requestUniqueIdNumber;
    }

    public MidasUser getRequestingUser() {
        return requestingUser;
    }

    public void setRequestingUser(MidasUser requestingUser) {
        this.requestingUser = requestingUser;
    }
}
