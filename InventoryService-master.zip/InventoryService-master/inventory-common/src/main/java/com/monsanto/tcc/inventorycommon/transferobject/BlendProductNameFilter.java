/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by Dan Schnettgoecke with IntelliJ IDEA.
 * Created on Sep 16, 2010 @ 10:32:18 AM.
 */

public class BlendProductNameFilter {

    private Long cropId;
    private String productFilter;

    public BlendProductNameFilter() {
    }

    public BlendProductNameFilter(Long cropId, String productFilter) {
        this.cropId = cropId;
        this.productFilter = productFilter;
    }

    public String getProductFilter() {
        return productFilter;
    }

    public void setProductFilter(String productFilter) {
        this.productFilter = productFilter;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }
}