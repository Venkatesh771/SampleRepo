package com.monsanto.tcc.inventorycommon.service;

import com.monsanto.tcc.inventorycommon.transferobject.AssayType;

import javax.jws.WebService;
import java.util.List;

/**
 * Filename:    $RCSfile: $
 * Last Change: $Author: daguar $
 * Date: $Date: Sep 11, 2009 4:47:46 PM $
 */
@WebService
public interface QualityEventCalculatorService {

    public Integer calculateQualityEvents(
            Long r0GrowoutWorkflowId,
            Double expectedOriginQuantity,
            String expectedUnitOfMeasure, List<AssayType> matchingAssays ) throws Exception;

    
}
