package com.monsanto.tcc.inventorycommon.service;

import com.monsanto.services.domain.breeding.Program;
import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.tcc.inventorycommon.exception.QueryTimedOutException;
import com.monsanto.tcc.inventorycommon.transferobject.*;

import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: RRPATN
 * Date: Jan 26, 2010
 * Time: 10:58:30 AM
 */
@WebService
public interface EventPresenceManagementService {
    public TestedMaterialResponse getTestedMaterials(Long cropId) throws Exception;

    public CrossSegregateAssayResult getAssayResultsForCrossSegregateIndividual(Long crossSegregateIndividualStatusId) throws Exception;

    public RemoveEventResponse removeEvent(RemoveEventRequest removeEventRequest) throws Exception;

    public Collection<CrossSegMaterialTO> getRegulatedMaterials(Filter[] filters, List<Program> selectedPrograms) throws QueryTimedOutException;

    public void deregulateMaterials(Collection<Long> germplasmEventConstructIds);

    public List<InventoryEventInfo> getInventoryEventInfo(@WebParam(name = "inventoryIds") List<Long> inventoryIds) throws Exception;
}
