package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.common.Entity;

/**
 * User: DCENGL
 */
public class TermsOfUseSummaryData implements Entity {

    private Long geneticMaterialId;
    private String hasRestriction;
    private Integer touCount;

    public Long getGeneticMaterialId() {
        return geneticMaterialId;
    }

    public void setGeneticMaterialId(Long geneticMaterialId) {
        this.geneticMaterialId = geneticMaterialId;
    }

    public String getHasRestriction() {
        return hasRestriction;
    }

    public void setHasRestriction(String hasRestriction) {
        this.hasRestriction = hasRestriction;
    }

    public Integer getTouCount() {
        return touCount;
    }

    public void setTouCount(Integer touCount) {
        this.touCount = touCount;
    }

    @Override
    public Object getID() {
        return getGeneticMaterialId();
    }
}
