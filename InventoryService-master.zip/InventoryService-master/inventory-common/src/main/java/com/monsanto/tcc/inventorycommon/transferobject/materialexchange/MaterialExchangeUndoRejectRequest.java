package com.monsanto.tcc.inventorycommon.transferobject.materialexchange;

import java.util.List;

public class MaterialExchangeUndoRejectRequest {

    private List<Long> inventoryIds;
    private boolean autoAcceptRequested;

    public List<Long> getInventoryIds() {
        return inventoryIds;
    }

    public void setInventoryIds(List<Long> inventoryIds) {
        this.inventoryIds = inventoryIds;
    }

    public boolean isAutoAcceptRequested() {
        return autoAcceptRequested;
    }

    public void setAutoAcceptRequested(boolean autoAcceptRequested) {
        this.autoAcceptRequested = autoAcceptRequested;
    }
}