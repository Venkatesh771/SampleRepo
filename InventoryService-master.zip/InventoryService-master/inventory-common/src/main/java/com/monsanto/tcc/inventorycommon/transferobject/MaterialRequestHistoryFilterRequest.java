package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Jun 3, 2010
 * Time: 11:34:52 AM
 * To change this template use File | Settings | File Templates.
 */
public class MaterialRequestHistoryFilterRequest {
    private String currentUserTxt;

    public MaterialRequestHistoryFilterRequest() {
    }

    public MaterialRequestHistoryFilterRequest(String currentUserTxt) {
        this.currentUserTxt = currentUserTxt;
    }

    public String getCurrentUserTxt() {
        return currentUserTxt;
    }

    public void setCurrentUserTxt(String currentUserTxt) {
        this.currentUserTxt = currentUserTxt;
    }
}
