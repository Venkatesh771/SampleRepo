package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.breeding.GermplasmOwnershipSummary;
import com.monsanto.services.domain.breeding.InventoryType;
import com.monsanto.services.domain.breeding.UserAssignedProgram;
import com.monsanto.services.domain.germplasm.InventoryPurpose;
import com.monsanto.services.domain.germplasm.ProductDescription;
import com.monsanto.tcc.inventorycommon.domain.GeneticMaterial;
import com.monsanto.tcc.inventorycommon.domain.Germplasm;
import com.monsanto.tcc.inventorycommon.domain.Inventory;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.ContactTO;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings({"UnusedDeclaration"})
public class PublishRequest {

    private List<Inventory> inventoryList;
    private List<MaterialExchangeInfoContact> materialExchangeInfoContacts;
    private List<ProgramSite> programSites;
    private List<GermplasmOwnershipSummary> ownershipSummaryList;
    private UserAssignedProgram userAssignedProgram;
    private List<InventoryType> inventoryTypeList;
    private List<InventoryPurpose> inventoryPurposeList;
    private List<GeneticMaterial> geneticMaterialList;
    private List<Germplasm> germplasmList;
    private List<ProductDescription> productDescriptionList;
    private boolean fateParentInventory;
    private boolean publishAllSeedQuantity;
    private ContactTO shipFromContact;

    public PublishRequest() {
        this.inventoryList = new ArrayList<Inventory>();
        this.materialExchangeInfoContacts = new ArrayList<MaterialExchangeInfoContact>();
        this.programSites = new ArrayList<ProgramSite>();
        this.ownershipSummaryList = new ArrayList<GermplasmOwnershipSummary>();
        this.userAssignedProgram = null;
        this.inventoryTypeList = new ArrayList<InventoryType>();
        this.inventoryPurposeList = new ArrayList<InventoryPurpose>();
        this.geneticMaterialList = new ArrayList<GeneticMaterial>();
        this.germplasmList = new ArrayList<Germplasm>();
        this.productDescriptionList = new ArrayList<ProductDescription>();
    }

    public List<Inventory> getInventoryList() {
        return inventoryList;
    }

    public void setInventoryList(List<Inventory> inventoryList) {
        this.inventoryList = inventoryList;
    }

    public List<MaterialExchangeInfoContact> getMaterialExchangeInfoContacts() {
        return materialExchangeInfoContacts;
    }

    public void setMaterialExchangeInfoContacts(List<MaterialExchangeInfoContact> materialExchangeInfoContacts) {
        this.materialExchangeInfoContacts = materialExchangeInfoContacts;
    }

    public List<ProgramSite> getProgramSites() {
        return programSites;
    }

    public void setProgramSites(List<ProgramSite> programSites) {
        this.programSites = programSites;
    }

    public List<GermplasmOwnershipSummary> getOwnershipSummaryList() {
        return ownershipSummaryList;
    }

    public void setOwnershipSummaryList(List<GermplasmOwnershipSummary> ownershipSummaryList) {
        this.ownershipSummaryList = ownershipSummaryList;
    }

    public UserAssignedProgram getUserAssignedProgram() {
        return userAssignedProgram;
    }

    public void setUserAssignedProgram(UserAssignedProgram userAssignedProgram) {
        this.userAssignedProgram = userAssignedProgram;
    }

    public List<InventoryType> getInventoryTypeList() {
        return inventoryTypeList;
    }

    public void setInventoryTypeList(List<InventoryType> inventoryTypeList) {
        this.inventoryTypeList = inventoryTypeList;
    }

    public List<InventoryPurpose> getInventoryPurposeList() {
        return inventoryPurposeList;
    }

    public void setInventoryPurposeList(List<InventoryPurpose> inventoryPurposeList) {
        this.inventoryPurposeList = inventoryPurposeList;
    }

    public List<GeneticMaterial> getGeneticMaterialList() {
        return geneticMaterialList;
    }

    public void setGeneticMaterialList(List<GeneticMaterial> geneticMaterialList) {
        this.geneticMaterialList = geneticMaterialList;
    }

    public List<Germplasm> getGermplasmList() {
        return germplasmList;
    }

    public void setGermplasmList(List<Germplasm> germplasmList) {
        this.germplasmList = germplasmList;
    }

    public List<ProductDescription> getProductDescriptionList() {
        return productDescriptionList;
    }

    public void setProductDescriptionList(List<ProductDescription> productDescriptionList) {
        this.productDescriptionList = productDescriptionList;
    }

    public boolean isFateParentInventory() {
        return fateParentInventory;
    }

    public void setFateParentInventory(boolean fateParentInventory) {
        this.fateParentInventory = fateParentInventory;
    }

    public boolean isPublishAllSeedQuantity() {
        return publishAllSeedQuantity;
    }

    public void setPublishAllSeedQuantity(boolean publishAllSeedQuantity) {
        this.publishAllSeedQuantity = publishAllSeedQuantity;
    }

    public ContactTO getShipFromContact() {
        return shipFromContact;
    }

    public void setShipFromContact(ContactTO shipFromContact) {
        this.shipFromContact = shipFromContact;
    }
}
