/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.germplasm.MaterialExchange;
import com.monsanto.services.domain.protocol.MidasUser;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.ContactTO;

import java.util.Date;

/* NBWALD - Feb 3, 2011 */
public class MaterialExchangeInfo {
    private Long materialExchangeInfoId;
    private MaterialExchange materialExchange;
    private SiteTO receiverSite;
    private SiteTO senderSite;
    private Boolean createShipment;
    private Boolean transferOwnership;
    private Date modifiedDate;
    private MidasUser publishedUser;
    private ContactTO toContact;

    public ContactTO getToContact() {
        return toContact;
    }

    public void setToContact(ContactTO toContact) {
        this.toContact = toContact;
    }

    public Long getMaterialExchangeInfoId() {
        return materialExchangeInfoId;
    }

    public void setMaterialExchangeInfoId(Long materialExchangeInfoId) {
        this.materialExchangeInfoId = materialExchangeInfoId;
    }

    public MaterialExchange getMaterialExchange() {
        return materialExchange;
    }

    public void setMaterialExchange(MaterialExchange materialExchange) {
        this.materialExchange = materialExchange;
    }

    public SiteTO getReceiverSite() {
        return receiverSite;
    }

    public void setReceiverSite(SiteTO receiverSite) {
        this.receiverSite = receiverSite;
    }

    public SiteTO getSenderSite() {
        return senderSite;
    }

    public void setSenderSite(SiteTO senderSite) {
        this.senderSite = senderSite;
    }

    public Boolean isCreateShipment() {
        return createShipment;
    }

    public void setCreateShipment(Boolean createShipment) {
        this.createShipment = createShipment;
    }

    public Boolean isTransferOwnership() {
        return transferOwnership;
    }

    public void setTransferOwnership(Boolean transferOwnership) {
        this.transferOwnership = transferOwnership;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public MidasUser getPublishedUser() {
        return publishedUser;
    }

    public void setPublishedUser(MidasUser publishedUser) {
        this.publishedUser = publishedUser;
    }
}