package com.monsanto.tcc.inventorycommon.transferobject.materialexchange;

public class RejectedInventory {
    private long inventoryId;
    private Long rejectionReasonId;

    public long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Long getRejectionReasonId() {
        return rejectionReasonId;
    }

    public void setRejectionReasonId(Long rejectionReasonId) {
        this.rejectionReasonId = rejectionReasonId;
    }
}
