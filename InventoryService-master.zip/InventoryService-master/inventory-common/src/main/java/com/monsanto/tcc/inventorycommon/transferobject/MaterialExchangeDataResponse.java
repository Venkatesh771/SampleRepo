package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.germplasm.ProductDescription;
import com.monsanto.tcc.inventorycommon.domain.Inventory;

import java.util.List;

@SuppressWarnings({"UnusedDeclaration"})
public class MaterialExchangeDataResponse {

    private List<Inventory> inventoryList;
    private List<ProductDescription> productDescriptionList;

    public List<Inventory> getInventoryList() {
        return inventoryList;
    }

    public void setInventoryList(List<Inventory> inventoryList) {
        this.inventoryList = inventoryList;
    }

    public List<ProductDescription> getProductDescriptionList() {
        return productDescriptionList;
    }

    public void setProductDescriptionList(List<ProductDescription> productDescriptionList) {
        this.productDescriptionList = productDescriptionList;
    }
}
