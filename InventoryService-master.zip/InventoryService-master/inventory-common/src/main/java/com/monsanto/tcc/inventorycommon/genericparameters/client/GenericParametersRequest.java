package com.monsanto.tcc.inventorycommon.genericparameters.client;

import java.util.Date;

/**
 * User: Mark D. Sparks
 * Date: 8/26/11
 * Time: 2:09 PM
 */
public class GenericParametersRequest {
    Long number1;
    Long number2;
    String text1;
    String text2;
    Date date1;
    Date date2;

    public Long getNumber1() {
        return number1;
    }

    public void setNumber1(Long number1) {
        this.number1 = number1;
    }

    public Long getNumber2() {
        return number2;
    }

    public void setNumber2(Long number2) {
        this.number2 = number2;
    }

    public String getText1() {
        return text1;
    }

    public void setText1(String text1) {
        this.text1 = text1;
    }

    public String getText2() {
        return text2;
    }

    public void setText2(String text2) {
        this.text2 = text2;
    }

    public Date getDate1() {
        return date1;
    }

    public void setDate1(Date date1) {
        this.date1 = date1;
    }

    public Date getDate2() {
        return date2;
    }

    public void setDate2(Date date2) {
        this.date2 = date2;
    }
}
