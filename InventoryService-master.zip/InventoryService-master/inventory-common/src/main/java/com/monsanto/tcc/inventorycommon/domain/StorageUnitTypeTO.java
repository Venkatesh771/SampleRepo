package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.tcc.inventorycommon.transferobject.StorageType;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 8, 2010
 * Time: 2:18:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class StorageUnitTypeTO {

    private String name;
    private Long storageTypeId;
    private String description;
    private StorageType type;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getStorageTypeId() {
        return storageTypeId;
    }

    public void setStorageTypeId(Long storageTypeId) {
        this.storageTypeId = storageTypeId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public StorageType getType() {
        return type;
    }

    public void setType(StorageType type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return name;
    }
}
