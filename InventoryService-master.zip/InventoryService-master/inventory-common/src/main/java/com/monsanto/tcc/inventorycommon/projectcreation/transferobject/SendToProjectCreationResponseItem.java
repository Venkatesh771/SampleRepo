package com.monsanto.tcc.inventorycommon.projectcreation.transferobject;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: MDSPARK
 * Date: Oct 12, 2009
 * Time: 1:32:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class SendToProjectCreationResponseItem {
    private String inventoryBarcode;
    private boolean valid = true;
    private List<String> errorMessages = new ArrayList<String>();
    private List<String> warningMessages = new ArrayList<String>();

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public List<String> getErrorMessages() {
        return errorMessages;
    }

    public void setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
    }

    public List<String> getWarningMessages() {
        return warningMessages;
    }

    public void setWarningMessages(List<String> warningMessages) {
        this.warningMessages = warningMessages;
    }

    public String getInventoryBarcode() {
        return inventoryBarcode;
    }

    public void setInventoryBarcode(String inventoryBarcode) {
        this.inventoryBarcode = inventoryBarcode;
    }
}
