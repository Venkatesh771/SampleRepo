package com.monsanto.tcc.inventorycommon.domain;

import java.sql.Date;

public class StorageLocationType {

    private Long storageLocationTypeId;
    private String name;
    private String description;
    private Date inactiveDttm;

    public Long getStorageLocationTypeId() {
        return storageLocationTypeId;
    }

    public void setStorageLocationTypeId(Long storageLocationTypeId) {
        this.storageLocationTypeId = storageLocationTypeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }
}
