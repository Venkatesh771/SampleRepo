package com.monsanto.tcc.inventorycommon.domain;

public class ShipmentToInventoryIdRelation {

    private Long shipmentId;
    private Long inventoryId;

    public ShipmentToInventoryIdRelation() { }
    
    public ShipmentToInventoryIdRelation(Long shipmentId, Long inventoryId) {
        this.shipmentId = shipmentId;
        this.inventoryId = inventoryId;
    }
    
    public Long getShipmentId() {
        return shipmentId;
    }
    public void setShipmentId(Long shipmentId) {
        this.shipmentId = shipmentId;
    }
    public Long getInventoryId() {
        return inventoryId;
    }
    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }
    
    
}
