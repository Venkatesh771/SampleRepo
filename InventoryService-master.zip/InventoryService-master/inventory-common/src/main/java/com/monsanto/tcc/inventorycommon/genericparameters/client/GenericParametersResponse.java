package com.monsanto.tcc.inventorycommon.genericparameters.client;

/**
 * User: Mark D. Sparks
 * Date: 8/26/11
 * Time: 2:11 PM
 */
public class GenericParametersResponse {
    private Long sessionId;

    public Long getSessionId() {
        return sessionId;
    }

    public void setSessionId(Long sessionId) {
        this.sessionId = sessionId;
    }
}
