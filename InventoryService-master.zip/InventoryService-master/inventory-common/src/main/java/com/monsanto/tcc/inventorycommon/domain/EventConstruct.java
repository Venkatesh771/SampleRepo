package com.monsanto.tcc.inventorycommon.domain;

import javax.xml.bind.annotation.XmlType;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: RRPATN
 * Date: Jan 26, 2010
 * Time: 11:38:14 AM
 * To change this template use File | Settings | File Templates.
 */
@XmlType(name = "Inventory_EventConstruct")
public class EventConstruct {

    private Long eventConstructId;
    private String name;
    private Boolean refActive;
    private Long cropId;
    private String virgoCasperNo;
    private String constructName;
    private String eventName;
    private Long regulatoryNameId;

    private Set<GermplasmEventConstruct> germplasmEventConstructList;

    public EventConstruct() {

    }

    public Long getEventConstructId() {
        return eventConstructId;
    }

    public void setEventConstructId(Long eventConstructId) {
        this.eventConstructId = eventConstructId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getRefActive() {
        return refActive;
    }

    public void setRefActive(Boolean refActive) {
        this.refActive = refActive;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public String getVirgoCasperNo() {
        return virgoCasperNo;
    }

    public void setVirgoCasperNo(String virgoCasperNo) {
        this.virgoCasperNo = virgoCasperNo;
    }

    public String getConstructName() {
        return constructName;
    }

    public void setConstructName(String constructName) {
        this.constructName = constructName;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public Long getRegulatoryNameId() {
        return regulatoryNameId;
    }

    public void setRegulatoryNameId(Long regulatoryNameId) {
        this.regulatoryNameId = regulatoryNameId;
    }

    public Set<GermplasmEventConstruct> getGermplasmEventConstructList() {
        return germplasmEventConstructList;
    }

    public void setGermplasmEventConstructList(Set<GermplasmEventConstruct> germplasmEventConstructList) {
        this.germplasmEventConstructList = germplasmEventConstructList;
    }
}
