package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.breeding.City;
import com.monsanto.services.domain.shipping.StorageUnit;
import com.monsanto.services.domain.shipping.contact.Address;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 26, 2010
 * Time: 7:56:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class StorageUnitsResponse {

    Collection<StorageUnit> storageUnits;
    Collection<City> cities;
    Collection<Address> addresses;

    public Collection<StorageUnit> getStorageUnits() {
        return storageUnits;
    }

    public void setStorageUnits(Collection<StorageUnit> storageUnits) {
        this.storageUnits = storageUnits;
    }

    public Collection<City> getCities() {
        return cities;
    }

    public void setCities(Collection<City> cities) {
        this.cities = cities;
    }

    public Collection<Address> getAddresses() {
        return addresses;
    }

    public void setAddresses(Collection<Address> addresses) {
        this.addresses = addresses;
    }
}
