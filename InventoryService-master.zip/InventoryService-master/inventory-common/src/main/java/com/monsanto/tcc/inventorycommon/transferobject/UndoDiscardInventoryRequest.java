/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;

import java.util.List;


public class UndoDiscardInventoryRequest {
    private List<Long> inventoryIds;
    private StorageUnitTO storageUnit;
    private Double inventoryQuantity;

    public List<Long> getInventoryIds() {
        return inventoryIds;
    }

    public void setInventoryIds(List<Long> inventoryIds) {
        this.inventoryIds = inventoryIds;
    }

    public StorageUnitTO getStorageUnit() {
        return storageUnit;
    }

    public void setStorageUnit(StorageUnitTO storageUnit) {
        this.storageUnit = storageUnit;
    }

    public Double getInventoryQuantity() {
        return inventoryQuantity;
    }

    public void setInventoryQuantity(Double inventoryQuantity) {
        this.inventoryQuantity = inventoryQuantity;
    }
}
