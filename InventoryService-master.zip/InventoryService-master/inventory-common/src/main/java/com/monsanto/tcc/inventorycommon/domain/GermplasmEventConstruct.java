package com.monsanto.tcc.inventorycommon.domain;

import javax.xml.bind.annotation.XmlType;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Feb 8, 2010
 * Time: 3:55:23 PM
 * To change this template use File | Settings | File Templates.
 */
@XmlType(name = "Inventory_GermplasmEventConstruct")
public class GermplasmEventConstruct {
    private Long germplasmEventConstructId;
    private EventConstruct eventConstruct;
    private Germplasm germplasm;
    private Date eventConstructAbsenceDate;
    private Date eventConstructDeregulatedDttm;

    public Long getGermplasmEventConstructId() {
        return germplasmEventConstructId;
    }

    public void setGermplasmEventConstructId(Long germplasmEventConstructId) {
        this.germplasmEventConstructId = germplasmEventConstructId;
    }

    public Germplasm getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(Germplasm germplasm) {
        this.germplasm = germplasm;
    }

    public Date getEventConstructAbsenceDate() {
        return eventConstructAbsenceDate;
    }

    public void setEventConstructAbsenceDate(Date eventConstructAbsenceDate) {
        this.eventConstructAbsenceDate = eventConstructAbsenceDate;
    }

    public EventConstruct getEventConstruct() {
        return eventConstruct;
    }

    public void setEventConstruct(EventConstruct eventConstruct) {
        this.eventConstruct = eventConstruct;
    }

    public Date getEventConstructDeregulatedDttm() {
        return eventConstructDeregulatedDttm;
    }

    public void setEventConstructDeregulatedDttm(Date eventConstructDeregulatedDttm) {
        this.eventConstructDeregulatedDttm = eventConstructDeregulatedDttm;
    }
}
