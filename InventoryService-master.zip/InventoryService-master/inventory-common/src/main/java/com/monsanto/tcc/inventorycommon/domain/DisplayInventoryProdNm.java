package com.monsanto.tcc.inventorycommon.domain;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 18, 2009
 * Time: 3:59:18 PM
 */
public class DisplayInventoryProdNm {
    private Long displayInventoryProdNmId;
    private String isVirtualInd;
    private ProductName productName;
    private Inventory inventory;
    private Date inactiveDttm;

    public Long getDisplayInventoryProdNmId() {
        return displayInventoryProdNmId;
    }

    public void setDisplayInventoryProdNmId(Long displayInventoryProdNmId) {
        this.displayInventoryProdNmId = displayInventoryProdNmId;
    }

    public String getIsVirtualInd() {
        return isVirtualInd;
    }

    public void setIsVirtualInd(String virtualInd) {
        isVirtualInd = virtualInd;
    }

    public ProductName getProductName() {
        return productName;
    }

    public void setProductName(ProductName productName) {
        this.productName = productName;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }
}
