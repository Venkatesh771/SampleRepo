/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.suinventory;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;

public class SUMoveRequest {
    private StorageUnitTO movedStorageUnitTO;
    private StorageUnitTO toStorageUnitTO;

    public StorageUnitTO getMovedStorageUnitTO() {
        return movedStorageUnitTO;
    }

    public void setMovedStorageUnitTO(StorageUnitTO movedStorageUnitTO) {
        this.movedStorageUnitTO = movedStorageUnitTO;
    }

    public StorageUnitTO getToStorageUnitTO() {
        return toStorageUnitTO;
    }

    public void setToStorageUnitTO(StorageUnitTO toStorageUnitTO) {
        this.toStorageUnitTO = toStorageUnitTO;
    }
}