package com.monsanto.tcc.inventorycommon.projectcreation.client;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: MDSPARK
 * Date: Oct 23, 2009
 * Time: 4:37:07 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProjectCreationStartUpRequest {
    List<Long> inventoryIds = new ArrayList<Long>();

    public List<Long> getInventoryIds() {
        return inventoryIds;
    }

    public void setInventoryIds(List<Long> inventoryIds) {
        this.inventoryIds = inventoryIds;
    }
}
