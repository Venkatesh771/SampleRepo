/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

public class MidasRole {
    private Long midasRoleId;
    private String name;
    private String midasRoleRefId;
    private String midasRoleTypeId;
    private boolean active;
    private Long listOrder;

    public MidasRole() {
    }

    public MidasRole(Long midasRoleId, String name) {
        this.midasRoleId = midasRoleId;
        this.name = name;
    }

    public Object getID() {
        return midasRoleId;
    }

    public Long getMidasRoleId() {
        return midasRoleId;
    }

    public void setMidasRoleId(Long midasRoleId) {
        this.midasRoleId = midasRoleId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMidasRoleRefId() {
        return midasRoleRefId;
    }

    public void setMidasRoleRefId(String midasRoleRefId) {
        this.midasRoleRefId = midasRoleRefId;
    }

    public String getMidasRoleTypeId() {
        return midasRoleTypeId;
    }

    public void setMidasRoleTypeId(String midasRoleTypeId) {
        this.midasRoleTypeId = midasRoleTypeId;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Long getListOrder() {
        return listOrder;
    }

    public void setListOrder(Long listOrder) {
        this.listOrder = listOrder;
    }
}