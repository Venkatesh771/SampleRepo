package com.monsanto.tcc.inventorycommon.transferobject.serviceinterfaceobject;

import java.util.ArrayList;
import java.util.List;


public class DestroyInventoryResponse {

    private boolean success;
    private List<Long> destroyedInventoryIds;
    private String resultMessage;

    public DestroyInventoryResponse() {
        this.destroyedInventoryIds = new ArrayList<Long>();
    }
    
    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public List<Long> getDestroyedInventoryIds() {
        return destroyedInventoryIds;
    }

    public void setDestroyedInventoryIds(List<Long> destroyedInventoryIds) {
        this.destroyedInventoryIds = destroyedInventoryIds;
    }

    public String getResultMessage() {
        return resultMessage;
    }

    public void setResultMessage(String resultMessage) {
        this.resultMessage = resultMessage;
    }
}
