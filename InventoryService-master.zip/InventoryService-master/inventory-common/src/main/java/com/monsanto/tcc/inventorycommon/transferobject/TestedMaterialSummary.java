package com.monsanto.tcc.inventorycommon.transferobject;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 23, 2010
 * Time: 3:00:45 PM
 */
public class TestedMaterialSummary implements Serializable {

    private Long crossSegregateIndividualStatusId;

    private String barcode;
    private String constructDisplay;
    private String eventDisplay;
    private String constructAbsent;
    private String eventAbsent;
    private String germplasmOwner;
    private String inventoryOwner;
    private String lineCode;
    private String origin;
    private String pedigree;
    private String source;
    private String generation;

    public Long getCrossSegregateIndividualStatusId() {
        return crossSegregateIndividualStatusId;
    }

    public void setCrossSegregateIndividualStatusId(Long crossSegregateIndividualStatusId) {
        this.crossSegregateIndividualStatusId = crossSegregateIndividualStatusId;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getConstructDisplay() {
        return constructDisplay;
    }

    public void setConstructDisplay(String constructDisplay) {
        this.constructDisplay = constructDisplay;
    }

    public String getEventDisplay() {
        return eventDisplay;
    }

    public void setEventDisplay(String eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    public String getConstructAbsent() {
        return constructAbsent;
    }

    public void setConstructAbsent(String constructAbsent) {
        this.constructAbsent = constructAbsent;
    }

    public String getEventAbsent() {
        return eventAbsent;
    }

    public void setEventAbsent(String eventAbsent) {
        this.eventAbsent = eventAbsent;
    }

    public String getGermplasmOwner() {
        return germplasmOwner;
    }

    public void setGermplasmOwner(String germplasmOwner) {
        this.germplasmOwner = germplasmOwner;
    }

    public String getInventoryOwner() {
        return inventoryOwner;
    }

    public void setInventoryOwner(String inventoryOwner) {
        this.inventoryOwner = inventoryOwner;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getPedigree() {
        return pedigree;
    }

    public void setPedigree(String pedigree) {
        this.pedigree = pedigree;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getGeneration() {
        return generation;
    }

    public void setGeneration(String generation) {
        this.generation = generation;
    }
}
