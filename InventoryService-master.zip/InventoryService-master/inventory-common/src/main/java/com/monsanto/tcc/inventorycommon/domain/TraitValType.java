package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: mdspark
 * Date: Sep 23, 2009
 * Time: 12:11:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class TraitValType {
    private Long traitValTypeId;
    private String name;
    private String refActive;
    private String traitValTypeRefId;
    private Integer listOrder;

    public Long getTraitValTypeId() {
        return traitValTypeId;
    }

    public void setTraitValTypeId(Long traitValTypeId) {
        this.traitValTypeId = traitValTypeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public String getTraitValTypeRefId() {
        return traitValTypeRefId;
    }

    public void setTraitValTypeRefId(String traitValTypeRefId) {
        this.traitValTypeRefId = traitValTypeRefId;
    }

    public Integer getListOrder() {
        return listOrder;
    }

    public void setListOrder(Integer listOrder) {
        this.listOrder = listOrder;
    }
}
