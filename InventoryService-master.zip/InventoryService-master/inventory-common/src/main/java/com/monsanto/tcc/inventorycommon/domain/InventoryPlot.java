/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.common.AbstractEntity;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "SU_InventoryPlot")
public class InventoryPlot extends AbstractEntity {
    private Long inventoryPlotId;
    private Long inventoryId;
    private Long plotId;

    private Plot plotByPlotId;
    private Inventory inventoryByInventoryId;

    public Long getInventoryPlotId() {
        return inventoryPlotId;
    }

    public void setInventoryPlotId(Long inventoryPlotId) {
        this.inventoryPlotId = inventoryPlotId;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Long getPlotId() {
        return plotId;
    }

    public void setPlotId(Long plotId) {
        this.plotId = plotId;
    }

    public Plot getPlotByPlotId() {
        return plotByPlotId;
    }

    public void setPlotByPlotId(Plot plotByPlotId) {
        this.plotByPlotId = plotByPlotId;
    }

    public Inventory getInventoryByInventoryId() {
        return inventoryByInventoryId;
    }

    public void setInventoryByInventoryId(Inventory inventoryByInventoryId) {
        this.inventoryByInventoryId = inventoryByInventoryId;
    }

    public InventoryPlot() {

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InventoryPlot that = (InventoryPlot) o;

        if (!inventoryPlotId.equals(that.inventoryPlotId)) {
            return false;
        }

        return true;
    }


    public Object getID() {
        return getInventoryPlotId();
    }
}