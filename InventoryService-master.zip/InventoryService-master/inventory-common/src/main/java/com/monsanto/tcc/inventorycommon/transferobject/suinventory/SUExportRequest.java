/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.suinventory;

import com.monsanto.tcc.inventorycommon.transferobject.StorageType;

/* nbwald - Dec 17, 2010 */
public class SUExportRequest {
    private long storageUnitId;
    private StorageType storageType;

    public long getStorageUnitId() {
        return storageUnitId;
    }

    public void setStorageUnitId(long storageUnitId) {
        this.storageUnitId = storageUnitId;
    }

    public StorageType getStorageType() {
        return storageType;
    }

    public void setStorageType(StorageType storageType) {
        this.storageType = storageType;
    }
}