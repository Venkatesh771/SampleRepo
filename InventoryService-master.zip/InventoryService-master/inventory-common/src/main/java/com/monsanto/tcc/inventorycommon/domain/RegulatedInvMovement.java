/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import java.sql.Date;

public class RegulatedInvMovement {
    private Long regulatedInvMovementId;

    public Long getRegulatedInvMovementId() {
        return regulatedInvMovementId;
    }

    public void setRegulatedInvMovementId(Long regulatedInvMovementId) {
        this.regulatedInvMovementId = regulatedInvMovementId;
    }

    private String monsantoId;

    public String getMonsantoId() {
        return monsantoId;
    }

    public void setMonsantoId(String monsantoId) {
        this.monsantoId = monsantoId;
    }

    private String fieldTrialBarcode;

    public String getFieldTrialBarcode() {
        return fieldTrialBarcode;
    }

    public void setFieldTrialBarcode(String fieldTrialBarcode) {
        this.fieldTrialBarcode = fieldTrialBarcode;
    }

    private Long agencyRequestLocationId;

    public Long getAgencyRequestLocationId() {
        return agencyRequestLocationId;
    }

    public void setAgencyRequestLocationId(Long agencyRequestLocationId) {
        this.agencyRequestLocationId = agencyRequestLocationId;
    }

    private Long regRlsMvmntRsnId;

    public Long getRegRlsMvmntRsnId() {
        return regRlsMvmntRsnId;
    }

    public void setRegRlsMvmntRsnId(Long regRlsMvmntRsnId) {
        this.regRlsMvmntRsnId = regRlsMvmntRsnId;
    }

    private String isUserOverriden;

    public String getIsUserOverriden() {
        return isUserOverriden;
    }

    public void setIsUserOverriden(String userOverriden) {
        isUserOverriden = userOverriden;
    }

    private Date inactiveDttm;

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }

    private Long inventoryContainerId;

    public Long getInventoryContainerId() {
        return inventoryContainerId;
    }

    public void setInventoryContainerId(Long inventoryContainerId) {
        this.inventoryContainerId = inventoryContainerId;
    }

    private Date dateCreated;

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    private Date dateModified;

    public Date getDateModified() {
        return dateModified;
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified;
    }

    private Long agencyId;

    public Long getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(Long agencyId) {
        this.agencyId = agencyId;
    }

    private String isHarvestedInd;

    public String getIsHarvestedInd() {
        return isHarvestedInd;
    }

    public void setIsHarvestedInd(String harvestedInd) {
        isHarvestedInd = harvestedInd;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RegulatedInvMovement that = (RegulatedInvMovement) o;

        if (agencyId != null ? !agencyId.equals(that.agencyId) : that.agencyId != null) {
            return false;
        }
        if (agencyRequestLocationId != null ? !agencyRequestLocationId.equals(that.agencyRequestLocationId) : that.agencyRequestLocationId != null) {
            return false;
        }
        if (dateCreated != null ? !dateCreated.equals(that.dateCreated) : that.dateCreated != null) {
            return false;
        }
        if (dateModified != null ? !dateModified.equals(that.dateModified) : that.dateModified != null) {
            return false;
        }
        if (fieldTrialBarcode != null ? !fieldTrialBarcode.equals(that.fieldTrialBarcode) : that.fieldTrialBarcode != null) {
            return false;
        }
        if (inactiveDttm != null ? !inactiveDttm.equals(that.inactiveDttm) : that.inactiveDttm != null) {
            return false;
        }
        if (inventoryContainerId != null ? !inventoryContainerId.equals(that.inventoryContainerId) : that.inventoryContainerId != null) {
            return false;
        }
        if (isHarvestedInd != null ? !isHarvestedInd.equals(that.isHarvestedInd) : that.isHarvestedInd != null) {
            return false;
        }
        if (isUserOverriden != null ? !isUserOverriden.equals(that.isUserOverriden) : that.isUserOverriden != null) {
            return false;
        }
        if (monsantoId != null ? !monsantoId.equals(that.monsantoId) : that.monsantoId != null) {
            return false;
        }
        if (regRlsMvmntRsnId != null ? !regRlsMvmntRsnId.equals(that.regRlsMvmntRsnId) : that.regRlsMvmntRsnId != null) {
            return false;
        }
        if (regulatedInvMovementId != null ? !regulatedInvMovementId.equals(that.regulatedInvMovementId) : that.regulatedInvMovementId != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = regulatedInvMovementId != null ? regulatedInvMovementId.hashCode() : 0;
        result = 31 * result + (monsantoId != null ? monsantoId.hashCode() : 0);
        result = 31 * result + (fieldTrialBarcode != null ? fieldTrialBarcode.hashCode() : 0);
        result = 31 * result + (agencyRequestLocationId != null ? agencyRequestLocationId.hashCode() : 0);
        result = 31 * result + (regRlsMvmntRsnId != null ? regRlsMvmntRsnId.hashCode() : 0);
        result = 31 * result + (isUserOverriden != null ? isUserOverriden.hashCode() : 0);
        result = 31 * result + (inactiveDttm != null ? inactiveDttm.hashCode() : 0);
        result = 31 * result + (inventoryContainerId != null ? inventoryContainerId.hashCode() : 0);
        result = 31 * result + (dateCreated != null ? dateCreated.hashCode() : 0);
        result = 31 * result + (dateModified != null ? dateModified.hashCode() : 0);
        result = 31 * result + (agencyId != null ? agencyId.hashCode() : 0);
        result = 31 * result + (isHarvestedInd != null ? isHarvestedInd.hashCode() : 0);
        return result;
    }
}