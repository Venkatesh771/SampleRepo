package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jul 1, 2009
 * Time: 4:29:27 PM
 */
public class MaterialSource {
    private String pedigree;
    private String source;
    private Double amount;
    private Double klb;
    private String supplier;
    private String treatment;
    private String suLocation;
    private String suDescription;
    private String suName;
    private Inventory inventory;

    public String getPedigree() {
        return pedigree;
    }

    public void setPedigree(String pedigree) {
        this.pedigree = pedigree;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Double getKlb() {
        return klb;
    }

    public void setKlb(Double klb) {
        this.klb = klb;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    public String getSuLocation() {
        return suLocation;
    }

    public void setSuLocation(String suLocation) {
        this.suLocation = suLocation;
    }

    public String getSuDescription() {
        return suDescription;
    }

    public void setSuDescription(String suDescription) {
        this.suDescription = suDescription;
    }

    public String getSuName() {
        return suName;
    }

    public void setSuName(String suName) {
        this.suName = suName;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
}
