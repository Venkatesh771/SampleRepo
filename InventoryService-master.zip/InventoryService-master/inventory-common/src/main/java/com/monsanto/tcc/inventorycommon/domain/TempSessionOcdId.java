package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: MDSPARK
 * Date: Oct 4, 2009
 * Time: 10:34:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class TempSessionOcdId implements java.io.Serializable {

    private Long requestId;
    private Long number1;
    private Long number2;
    private String text1;
    private String text2;
    private Long sortOrder;
    private static final int RESULT_INIT = 17;
    private static final int RESULT_MULTIPLIER = 37;

    public TempSessionOcdId() {
    }

    public TempSessionOcdId(Long id, Long sort) {
        this.requestId = id;
        this.sortOrder = sort;
    }

    public TempSessionOcdId(Long id, Long num1,
                            Long num2, String t1, String t2, Long sort) {
        this.requestId = id;
        this.number1 = num1;
        this.number2 = num2;
        this.text1 = t1;
        this.text2 = t2;
        this.sortOrder = sort;
    }

    public Long getRequestId() {
        return this.requestId;
    }

    public void setRequestId(Long id) {
        this.requestId = id;
    }

    public Long getNumber1() {
        return number1;
    }

    public void setNumber1(Long num) {
        this.number1 = num;
    }

    public Long getNumber2() {
        return number2;
    }

    public void setNumber2(Long num) {
        this.number2 = num;
    }

    public String getText1() {
        return this.text1;
    }

    public void setText1(String s) {
        this.text1 = s;
    }

    public String getText2() {
        return this.text2;
    }

    public void setText2(String s) {
        this.text2 = s;
    }

    public Long getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Long sort) {
        this.sortOrder = sort;
    }

    public boolean equals(Object other) {
        if ((this == other)) {
            return true;
        }
        if ((other == null)) {
            return false;
        }
        if (!(other instanceof TempSessionOcdId)) {
            return false;
        }
        TempSessionOcdId castOther = (TempSessionOcdId) other;

        return ((this.getRequestId() != null &&
                 castOther.getRequestId() != null &&
                 this.getRequestId().equals(castOther.getRequestId())))
                &&
                ((this.getNumber1() != null &&
                  castOther.getNumber1() != null &&
                  this.getNumber1().equals(castOther.getNumber1())))
                &&
                ((this.getNumber2() != null &&
                  castOther.getNumber2() != null &&
                  this.getNumber2().equals(castOther.getNumber2())))
                &&
                ((this.getText1() != null &&
                  castOther.getText1() != null &&
                  this.getText1().equals(castOther.getText1())))
                &&
                ((this.getText2() != null &&
                  castOther.getText2() != null &&
                  this.getText2().equals(castOther.getText2())))
                &&
                ((this.getSortOrder() != null &&
                  castOther.getSortOrder() != null &&
                  this.getSortOrder().equals(castOther.getSortOrder())));
    }

    public int hashCode() {
        int result = RESULT_INIT;

        result = RESULT_MULTIPLIER * result
                + (getRequestId() == null ? 0 : this.getRequestId().hashCode());
        result = RESULT_MULTIPLIER * result
                + (getNumber1() == null ? 0 : this.getNumber1().hashCode());
        result = RESULT_MULTIPLIER * result
                + (getNumber2() == null ? 0 : this.getNumber2().hashCode());
        result = RESULT_MULTIPLIER * result
                + (getText1() == null ? 0 : this.getText1().hashCode());
        result = RESULT_MULTIPLIER * result
                + (getText2() == null ? 0 : this.getText2().hashCode());
        result = RESULT_MULTIPLIER * result
                + (getSortOrder() == null ? 0 : this.getSortOrder().hashCode());
        return result;
    }
}
