/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.service.email;

import com.monsanto.tcc.inventorycommon.domain.email.EmailMessage;

/**
 * Created by IntelliJ IDEA.
 * User: emgoode
 * Date: Mar 4, 2010
 * Time: 2:27:03 PM
 * To change this template use File | Settings | File Templates.
 */
public interface EmailSystemBroker {
    void sendEmailMessages(EmailMessage... emailMessageList);
}