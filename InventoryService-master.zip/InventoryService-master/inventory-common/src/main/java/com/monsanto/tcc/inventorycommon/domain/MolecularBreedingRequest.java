package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.common.Entity;

public class MolecularBreedingRequest implements Entity {
    private Long molecularBreedingRequestId;
    private String molecularBreedingRequestNbr;

    public Long getMolecularBreedingRequestId() {
        return molecularBreedingRequestId;
    }

    public void setMolecularBreedingRequestId(Long molecularBreedingRequestId) {
        this.molecularBreedingRequestId = molecularBreedingRequestId;
    }

    public String getMolecularBreedingRequestNbr() {
        return molecularBreedingRequestNbr;
    }

    public void setMolecularBreedingRequestNbr(String molecularBreedingRequestNbr) {
        this.molecularBreedingRequestNbr = molecularBreedingRequestNbr;
    }

    @Override
    public Object getID() {
        return molecularBreedingRequestId;
    }
}