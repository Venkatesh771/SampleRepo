/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.breeding.Program;

import java.util.Date;

public class ProgramSiteXRef {
    private Long id;
    private SiteTO site;
    private Program program;
    private Date inactiveDttm;
    private Date modifiedDttm;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public SiteTO getSite() {
        return site;
    }

    public void setSite(SiteTO site) {
        this.site = site;
    }

    public Program getProgram() {
        return program;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }

    public Date getModifiedDttm() {
        return modifiedDttm;
    }

    public void setModifiedDttm(Date modifiedDttm) {
        this.modifiedDttm = modifiedDttm;
    }
}