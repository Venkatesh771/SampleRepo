package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.common.Entity;

public class RubProj implements Entity {
    private Long rubProjId;
    private String rubKey;
    private Long origBrProgId;
    private Long recomBrProgId;
    private String projectType;

    public Long getRubProjId() {
        return rubProjId;
    }

    public void setRubProjId(Long rubProjId) {
        this.rubProjId = rubProjId;
    }

    public String getRubKey() {
        return rubKey;
    }

    public void setRubKey(String rubKey) {
        this.rubKey = rubKey;
    }

    public Long getOrigBrProgId() {
        return origBrProgId;
    }

    public void setOrigBrProgId(Long origBrProgId) {
        this.origBrProgId = origBrProgId;
    }

    public Long getRecomBrProgId() {
        return recomBrProgId;
    }

    public void setRecomBrProgId(Long recomBrProgId) {
        this.recomBrProgId = recomBrProgId;
    }

    public String getProjectType() {
        return projectType;
    }

    public void setProjectType(String projectType) {
        this.projectType = projectType;
    }

    @Override
    public Object getID() {
        return getRubProjId();
    }
}
