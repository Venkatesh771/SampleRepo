package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.services.domain.germplasm.VegetativeStructure;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vvalav
 * Date: May 4, 2009
 * Time: 3:39:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class InventoryServiceGetVegStructuresResponse {

    public List<VegetativeStructure> vegetativeStructure;

    public CompositeObject getComposite() {
        return getResponseEnvelope();
    }

    public ResponseEnvelope getResponseEnvelope() {
        ResponseEnvelope responseEnvelope = new ResponseEnvelope();
        add(responseEnvelope, getVegStructure());
        return responseEnvelope;
    }

    private void add(ResponseEnvelope responseEnvelope, Collection collection) {
        if (null != collection) {
            responseEnvelope.addAll(collection);
        }
    }

    public List<VegetativeStructure> getVegStructure() {
        return vegetativeStructure;
    }

    public void setVegetativeStructure(List<VegetativeStructure> vegetativeStructure) {
        this.vegetativeStructure = vegetativeStructure;
    }
}
