package com.monsanto.tcc.inventorycommon.projectcreation.service;

import com.monsanto.tcc.inventorycommon.projectcreation.transferobject.SendToProjectCreationRequest;
import com.monsanto.tcc.inventorycommon.projectcreation.transferobject.SendToProjectCreationResponse;

import javax.jws.WebService;

/**
 * Created by IntelliJ IDEA. User: MDSPARK Date: Oct 12, 2009 Time: 1:23:35 PM To change this template use File | Settings | File Templates.
 */
@WebService
public interface ProjectCreationService {
    public SendToProjectCreationResponse sendToProjectCreation(SendToProjectCreationRequest request);
}
