package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.domain.RejectionReason;

import java.util.Collection;

public class MaterialExchangeReferenceDataResponse {
    Collection<RejectionReason> rejectionReasons;

    public Collection<RejectionReason> getRejectionReasons() {
        return rejectionReasons;
    }

    public void setRejectionReasons(Collection<RejectionReason> rejectionReasons) {
        this.rejectionReasons = rejectionReasons;
    }

}
