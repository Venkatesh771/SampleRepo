/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.domain.RejectionReason;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.UnitOfMeasureTO;

import java.util.List;

/**
 * User: jjbens2
 * Date: May 20, 2010
 */
public class MaterialRequestsToProcessResponse {

    private List<MaterialRequestToProcessTO> requests;
    private List<RejectionReason> allRejectionReasons;
    private List<UnitOfMeasureTO> allUoms;

    public List<MaterialRequestToProcessTO> getRequests() {
        return requests;
    }

    public void setRequests(List<MaterialRequestToProcessTO> requests) {
        this.requests = requests;
    }

    public List<RejectionReason> getAllRejectionReasons() {
        return allRejectionReasons;
    }

    public void setAllRejectionReasons(List<RejectionReason> allRejectionReasons) {
        this.allRejectionReasons = allRejectionReasons;
    }

    public List<UnitOfMeasureTO> getAllUoms() {
        return allUoms;
    }

    public void setAllUoms(List<UnitOfMeasureTO> allUoms) {
        this.allUoms = allUoms;
    }
}
