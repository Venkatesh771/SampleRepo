package com.monsanto.tcc.inventorycommon.transferobject.serviceinterfaceobject;

import com.monsanto.tcc.inventorycommon.transferobject.inventory.InventoryTO;

import java.util.List;

public class InventoryToBeDestroyedPageResponse {

    private List<InventoryTO> inventories;

    public List<InventoryTO> getInventories() {
        return inventories;
    }

    public void setInventories(List<InventoryTO> inventories) {
        this.inventories = inventories;
    }
}
