package com.monsanto.tcc.inventorycommon.service.tou;

import javax.xml.bind.annotation.XmlType;
import java.util.List;

/**
 * User: DCENGL
 */
@XmlType(name = "Inventory_GetTermsOfUseResponse")
public class GetTermsOfUseResponse {

    private GeneticMaterialDetails geneticMaterialDetails;
    private List<TermsOfUse> termsOfUses;

    public GeneticMaterialDetails getGeneticMaterialDetails() {
        return geneticMaterialDetails;
    }

    public void setGeneticMaterialDetails(GeneticMaterialDetails geneticMaterialDetails) {
        this.geneticMaterialDetails = geneticMaterialDetails;
    }

    public List<TermsOfUse> getTermsOfUses() {
        return termsOfUses;
    }

    public void setTermsOfUses(List<TermsOfUse> termsOfUses) {
        this.termsOfUses = termsOfUses;
    }
}
