package com.monsanto.tcc.inventorycommon.transferobject.subinventory;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: May 25, 2010
 * Time: 2:14:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class SubInventoryDto {
    private Long parentId;
    private Double seedQuantity;
    private String seedQuantityUOM;
    private Long noOfSubInventories;

    public SubInventoryDto() {
    }

    public SubInventoryDto(Long parentId, Double seedQuantity, String seedQuantityUOM) {
        this.parentId = parentId;
        this.seedQuantity = seedQuantity;
        this.seedQuantityUOM = seedQuantityUOM;
    }

    public SubInventoryDto(Long parentId, Double seedQuantity, String seedQuantityUOM, Long noOfSubInventories) {
        this.parentId = parentId;
        this.seedQuantity = seedQuantity;
        this.seedQuantityUOM = seedQuantityUOM;
        this.noOfSubInventories = noOfSubInventories;
    }


    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public Double getSeedQuantity() {
        return seedQuantity;
    }

    public void setSeedQuantity(Double seedQuantity) {
        this.seedQuantity = seedQuantity;
    }

    public String getSeedQuantityUOM() {
        return seedQuantityUOM;
    }

    public void setSeedQuantityUOM(String seedQuantityUOM) {
        this.seedQuantityUOM = seedQuantityUOM;
    }

    public Long getNoOfSubInventories() {
        return noOfSubInventories;
    }

    public void setNoOfSubInventories(Long noOfSubInventories) {
        this.noOfSubInventories = noOfSubInventories;
    }
}
