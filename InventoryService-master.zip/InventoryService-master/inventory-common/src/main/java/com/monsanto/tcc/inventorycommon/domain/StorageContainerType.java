package com.monsanto.tcc.inventorycommon.domain;

import java.sql.Date;

public class StorageContainerType {

    private Long storageContainerTypeId;
    private String name;
    private String description;
    private Date inactiveDttm;

    public Long getStorageContainerTypeId() {
        return storageContainerTypeId;
    }

    public void setStorageContainerTypeId(Long storageContainerTypeId) {
        this.storageContainerTypeId = storageContainerTypeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }

}
