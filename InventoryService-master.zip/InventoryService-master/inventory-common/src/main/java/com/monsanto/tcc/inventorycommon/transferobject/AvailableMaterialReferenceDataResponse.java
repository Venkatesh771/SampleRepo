/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.transferobject.inventory.ContactTO;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.RequestReasonTO;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.UnitOfMeasureTO;

import java.util.List;

public class AvailableMaterialReferenceDataResponse {
    private List<ContactTO> contacts;
    private List<RequestReasonTO> requestReasons;
    private List<UnitOfMeasureTO> unitsOfMeasure;
    private List<ProgramSiteTransferObject> programSiteTOs;

    public List<ContactTO> getContacts() {
        return contacts;
    }

    public void setContacts(List<ContactTO> contacts) {
        this.contacts = contacts;
    }

    public List<RequestReasonTO> getRequestReasons() {
        return requestReasons;
    }

    public void setRequestReasons(List<RequestReasonTO> requestReasons) {
        this.requestReasons = requestReasons;
    }

    public List<UnitOfMeasureTO> getUnitsOfMeasure() {
        return unitsOfMeasure;
    }

    public void setUnitsOfMeasure(List<UnitOfMeasureTO> unitsOfMeasure) {
        this.unitsOfMeasure = unitsOfMeasure;
    }

    public List<ProgramSiteTransferObject> getProgramSiteTOs() {
        return programSiteTOs;
    }

    public void setProgramSiteTOs(List<ProgramSiteTransferObject> programSiteTOs) {
        this.programSiteTOs = programSiteTOs;
    }
}
