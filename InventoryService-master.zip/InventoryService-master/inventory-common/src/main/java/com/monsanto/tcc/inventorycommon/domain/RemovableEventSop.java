package com.monsanto.tcc.inventorycommon.domain;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: jdvoll
 * Date: Jan 13, 2011
 * Time: 2:34:23 PM
 */
public class RemovableEventSop implements Serializable {

    private Long removableEventSopId;
    private String firstGenerationAssayCheck;
    private String secondGenerationAssayCheck;
    private String sopIdentifier;

    public long getRemovableEventSopId() {
        return removableEventSopId;
    }

    public void setRemovableEventSopId(long removableEventSopId) {
        this.removableEventSopId = removableEventSopId;
    }

    public String getFirstGenerationAssayCheck() {
        return firstGenerationAssayCheck;
    }

    public void setFirstGenerationAssayCheck(String firstGenerationAssayCheck) {
        this.firstGenerationAssayCheck = firstGenerationAssayCheck;
    }

    public String getSecondGenerationAssayCheck() {
        return secondGenerationAssayCheck;
    }

    public void setSecondGenerationAssayCheck(String secondGenerationAssayCheck) {
        this.secondGenerationAssayCheck = secondGenerationAssayCheck;
    }

    public String getSopIdentifier() {
        return sopIdentifier;
    }

    public void setSopIdentifier(String sopIdentifier) {
        this.sopIdentifier = sopIdentifier;
    }
}
