package com.monsanto.tcc.inventorycommon.transferobject.subinventory;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Sep 7, 2010
 * Time: 8:15:52 AM
 * To change this template use File | Settings | File Templates.
 */
public class ImportSubInventoryResponse {

    Collection<ImportSubInventoryResponseItem> importSubInventoryResponseItems;

    public Collection<ImportSubInventoryResponseItem> getImportSubInventoryResponseItems() {
        return importSubInventoryResponseItems;
    }

    public void setImportSubInventoryResponseItems(Collection<ImportSubInventoryResponseItem> importSubInventoryResponseItems) {
        this.importSubInventoryResponseItems = importSubInventoryResponseItems;
    }

}
