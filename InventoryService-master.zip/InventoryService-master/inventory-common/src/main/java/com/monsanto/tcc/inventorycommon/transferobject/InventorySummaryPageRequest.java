package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.common.filter.Filter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: May 13, 2010
 * Time: 9:52:02 AM
 * To change this template use File | Settings | File Templates.
 */
public class InventorySummaryPageRequest {
    private List<Filter> filters = new ArrayList<Filter>();

    public InventorySummaryPageRequest() {
    }

    public InventorySummaryPageRequest(List<Filter> filters) {
        this.filters = filters;
    }

    public List<Filter> getFilters() {
        return filters;
    }

    public void setFilters(List<Filter> filters) {
        this.filters = filters;
    }
}
