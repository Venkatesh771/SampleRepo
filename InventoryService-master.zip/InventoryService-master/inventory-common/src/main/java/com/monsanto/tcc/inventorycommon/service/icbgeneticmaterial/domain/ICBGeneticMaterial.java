package com.monsanto.tcc.inventorycommon.service.icbgeneticmaterial.domain;

import com.monsanto.services.domain.germplasm.ProductDescription;

/**
 * Created by IntelliJ IDEA.
 * User: KKTIWA
 * Date: 6/6/12
 * Time: 7:55 PM
 */

public class ICBGeneticMaterial {

    private Long germplasmId;
    private String origin;
    private String lineCode;
    private String pedigree;
    private Long lineTypeId;
    private Long ownerProgramId;
    private String transgenic;
    private Long lineFunctionId;
    private Long cropId;
    private String event;
    private String construct;
    private Long geneticMaterialId;
    private String source;
    private String generation;
    private String lineage;
    private String lineTypeName;
    private String lineTypeRefId;
    private String lineFunctionName;
    private Long programId;
    private String programRefId;
    private String programName;
    private ProductDescription productDescription;

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getProgramRefId() {
        return programRefId;
    }

    public void setProgramRefId(String programRefId) {
        this.programRefId = programRefId;
    }

    public Long getGermplasmId() {
        return germplasmId;
    }

    public void setGermplasmId(Long germplasmId) {
        this.germplasmId = germplasmId;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getPedigree() {
        return pedigree;
    }

    public void setPedigree(String pedigree) {
        this.pedigree = pedigree;
    }

    public Long getLineTypeId() {
        return lineTypeId;
    }

    public void setLineTypeId(Long lineTypeId) {
        this.lineTypeId = lineTypeId;
    }

    public Long getOwnerProgramId() {
        return ownerProgramId;
    }

    public void setOwnerProgramId(Long ownerProgramId) {
        this.ownerProgramId = ownerProgramId;
    }

    public String getTransgenic() {
        return transgenic;
    }

    public void setTransgenic(String transgenic) {
        this.transgenic = transgenic;
    }

    public Boolean isTransgenic() {
        return "T".equals(transgenic);
    }

    public Long getLineFunctionId() {
        return lineFunctionId;
    }

    public void setLineFunctionId(Long lineFunctionId) {
        this.lineFunctionId = lineFunctionId;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getConstruct() {
        return construct;
    }

    public void setConstruct(String construct) {
        this.construct = construct;
    }

    public Long getGeneticMaterialId() {
        return geneticMaterialId;
    }

    public void setGeneticMaterialId(Long geneticMaterialId) {
        this.geneticMaterialId = geneticMaterialId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getGeneration() {
        return generation;
    }

    public void setGeneration(String generation) {
        this.generation = generation;
    }

    public String getLineage() {
        return lineage;
    }

    public void setLineage(String lineage) {
        this.lineage = lineage;
    }

    public String getLineTypeName() {
        return lineTypeName;
    }

    public void setLineTypeName(String lineTypeName) {
        this.lineTypeName = lineTypeName;
    }

    public String getLineTypeRefId() {
        return lineTypeRefId;
    }

    public void setLineTypeRefId(String lineTypeRefId) {
        this.lineTypeRefId = lineTypeRefId;
    }

    public String getLineFunctionName() {
        return lineFunctionName;
    }

    public void setLineFunctionName(String lineFunctionName) {
        this.lineFunctionName = lineFunctionName;
    }

    public Long getProgramId() {
        return programId;
    }

    public void setProgramId(Long programId) {
        this.programId = programId;
    }

    public ProductDescription getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(ProductDescription productDescription) {
        this.productDescription = productDescription;
    }
}