package com.monsanto.tcc.inventorycommon.domain;

import java.util.Date;

public class AlternateRequestSourcePreference {

    private Long materialRequestDetailSourcePreferenceOrderId;
    private String alternateRequestedBarcode;
    private Long preferenceOrder;
    private Date inactiveDateTime;
    private MaterialRequestDetail materialRequestDetail;

    public AlternateRequestSourcePreference() {
    }

    public AlternateRequestSourcePreference(String barcode) {
        this.alternateRequestedBarcode = barcode;
    }

    public Long getMaterialRequestDetailSourcePreferenceOrderId() {
        return materialRequestDetailSourcePreferenceOrderId;
    }

    public void setMaterialRequestDetailSourcePreferenceOrderId(
        Long materialRequestDetailSourcePreferenceOrderId) {
        this.materialRequestDetailSourcePreferenceOrderId = materialRequestDetailSourcePreferenceOrderId;
    }

    public String getAlternateRequestedBarcode() {
        return alternateRequestedBarcode;
    }

    public void setAlternateRequestedBarcode(String alternateRequestedBarcode) {
        this.alternateRequestedBarcode = alternateRequestedBarcode;
    }

    public Long getPreferenceOrder() {
        return preferenceOrder;
    }

    public void setPreferenceOrder(Long preferenceOrder) {
        this.preferenceOrder = preferenceOrder;
    }

    public Date getInactiveDateTime() {
        return inactiveDateTime;
    }

    public void setInactiveDateTime(Date inactiveDateTime) {
        this.inactiveDateTime = inactiveDateTime;
    }

    public MaterialRequestDetail getMaterialRequestDetail() {
        return materialRequestDetail;
    }

    public void setMaterialRequestDetail(MaterialRequestDetail materialRequestDetail) {
        this.materialRequestDetail = materialRequestDetail;
    }

}
