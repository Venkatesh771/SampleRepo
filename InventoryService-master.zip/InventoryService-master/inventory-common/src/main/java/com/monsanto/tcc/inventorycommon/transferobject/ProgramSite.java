/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.breeding.Program;
import com.monsanto.tcc.inventorycommon.domain.SiteTO;

/* NBWALD - Feb 3, 2011 */
public class ProgramSite {
    private Program program;
    private SiteTO site;

    public Program getProgram() {
        return program;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public SiteTO getSite() {
        return site;
    }

    public void setSite(SiteTO site) {
        this.site = site;
    }

    @Override
    public String toString() {
        String programText = program.getProgramRefId() + " - " + program.getName();
        return site == null ?
            programText :
            programText + " (" + site.getName() + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ProgramSite that = (ProgramSite) o;

        if (program != null ? !program.equals(that.program) : that.program != null) {
            return false;
        }
        if (site != null ? !site.equals(that.site) : that.site != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = program != null ? program.hashCode() : 0;
        result = 31 * result + (site != null ? site.hashCode() : 0);
        return result;
    }
}