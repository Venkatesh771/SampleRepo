package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.observation.ObservationClassification;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: RRPATN
 * Date: Mar 24, 2010
 * Time: 10:16:55 AM
 * To change this template use File | Settings | File Templates.
 */
public class ObsvDisplay {
    private Long obsvDisplayId;
    private String name;
    private ObservationClassification obsvClassification;
    private String ownerType;
    private Boolean deleted;
    private Date dateLogicallyDeleted;
    private Long midasUserId;

    public ObsvDisplay() {
    }

    public Long getObsvDisplayId() {
        return obsvDisplayId;
    }

    public void setObsvDisplayId(Long obsvDisplayId) {
        this.obsvDisplayId = obsvDisplayId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ObservationClassification getObsvClassification() {
        return obsvClassification;
    }

    public void setObsvClassification(ObservationClassification obsvClassification) {
        this.obsvClassification = obsvClassification;
    }

    public String getOwnerType() {
        return ownerType;
    }

    public void setOwnerType(String ownerType) {
        this.ownerType = ownerType;
    }

    public Boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public Date getDateLogicallyDeleted() {
        return dateLogicallyDeleted;
    }

    public void setDateLogicallyDeleted(Date dateLogicallyDeleted) {
        this.dateLogicallyDeleted = dateLogicallyDeleted;
    }

    public Long getMidasUserId() {
        return midasUserId;
    }

    public void setMidasUserId(Long midasUserId) {
        this.midasUserId = midasUserId;
    }
}
