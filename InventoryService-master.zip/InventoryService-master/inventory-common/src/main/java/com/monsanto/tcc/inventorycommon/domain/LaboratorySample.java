package com.monsanto.tcc.inventorycommon.domain;


/**
 * Created by IntelliJ IDEA.
 * User: mdspark
 * Date: Sep 23, 2009
 * Time: 11:08:34 AM
 * To change this template use File | Settings | File Templates.
 */
public class LaboratorySample {
    private Long laboratorySampleId;
    private LaboratoryRequest laboratoryRequest;
    private String sampleNumber;

    public Long getLaboratorySampleId() {
        return laboratorySampleId;
    }

    public void setLaboratorySampleId(Long laboratorySampleId) {
        this.laboratorySampleId = laboratorySampleId;
    }

    public LaboratoryRequest getLaboratoryRequest() {
        return laboratoryRequest;
    }

    public void setLaboratoryRequest(LaboratoryRequest laboratoryRequest) {
        this.laboratoryRequest = laboratoryRequest;
    }

    public String getSampleNumber() {
        return sampleNumber;
    }

    public void setSampleNumber(String sampleNumber) {
        this.sampleNumber = sampleNumber;
    }
}
