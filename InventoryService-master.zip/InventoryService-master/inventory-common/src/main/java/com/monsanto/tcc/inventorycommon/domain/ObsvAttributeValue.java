package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.breeding.uom.UnitOfMeasure;
import com.monsanto.services.domain.breeding.observation.ObsvAttributeValList;

/**
 * Created by IntelliJ IDEA.
 * User: mdspark
 * Date: Sep 23, 2009
 * Time: 10:48:31 AM
 * To change this template use File | Settings | File Templates.
 */
public class ObsvAttributeValue {
    private Long ObsvAttributeValueId;
    private ObsvAttribute obsvAttribute;
    private Observation observation;
    private String strValue;
    private Double numValue;
    private UnitOfMeasure uom;
    private ObsvAttributeValList obsvAttributeValList;
    private String deactivate;
    private String isDeleted;

    public Long getObsvAttributeValueId() {
        return ObsvAttributeValueId;
    }

    public void setObsvAttributeValueId(Long obsvAttributeValueId) {
        ObsvAttributeValueId = obsvAttributeValueId;
    }

    public ObsvAttribute getObsvAttribute() {
        return obsvAttribute;
    }

    public void setObsvAttribute(ObsvAttribute obsvAttribute) {
        this.obsvAttribute = obsvAttribute;
    }

    public Observation getObservation() {
        return observation;
    }

    public void setObservation(Observation observation) {
        this.observation = observation;
    }

    public String getStrValue() {
        return strValue;
    }

    public void setStrValue(String strValue) {
        this.strValue = strValue;
    }

    public Double getNumValue() {
        return numValue;
    }

    public void setNumValue(Double numValue) {
        this.numValue = numValue;
    }

    public UnitOfMeasure getUom() {
        return uom;
    }

    public void setUom(UnitOfMeasure uom) {
        this.uom = uom;
    }

    public ObsvAttributeValList getObsvAttributeValList() {
        return obsvAttributeValList;
    }

    public void setObsvAttributeValList(ObsvAttributeValList obsvAttributeValList) {
        this.obsvAttributeValList = obsvAttributeValList;
    }

    public String getDeactivate() {
        return deactivate;
    }

    public void setDeactivate(String deactivate) {
        this.deactivate = deactivate;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String deleted) {
        isDeleted = deleted;
    }

    public String getDeleted() {
        return isDeleted;
    }

    public void setDeleted(String deleted) {
        isDeleted = deleted;
    }
}
