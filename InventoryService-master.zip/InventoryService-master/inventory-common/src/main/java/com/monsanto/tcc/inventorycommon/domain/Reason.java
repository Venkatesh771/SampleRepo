/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.common.AbstractEntity;

import java.util.Date;

/**
 * User: jjbens2
 * Date: May 25, 2010
 */
public abstract class Reason extends AbstractEntity {

    private Long reasonId;
    private String description;
    private String name;
    private Date inactiveDttm;

    public Reason() {
    }

    public Reason(Long id, String description, String name) {

        this.setReasonId(id);
        this.setDescription(description);
        this.setName(name);
    }

    public Reason(Long id, String description, String name, Date inactiveDttm) {

        this.setReasonId(id);
        this.setDescription(description);
        this.setName(name);
        this.setInactiveDttm(inactiveDttm);
    }

    public Object getID() {
        return reasonId;
    }

    public Long getReasonId() {
        return reasonId;
    }

    public void setReasonId(Long reasonId) {
        this.reasonId = reasonId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }
}
