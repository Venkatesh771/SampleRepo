/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import java.util.HashSet;
import java.util.Set;

public class Product {
    private Long id;
    private boolean active;
    private String denomination;
    private Long cropId;

    private Set<ProductName> productNames = new HashSet<ProductName>();

    public Product() {
    }

    public Product(Long id, boolean active, String denomination, Long cropId) {
        this.id = id;
        this.active = active;
        this.denomination = denomination;
        this.cropId = cropId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getDenomination() {
        return denomination;
    }

    public void setDenomination(String denomination) {
        this.denomination = denomination;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public Set<ProductName> getProductNames() {
        return productNames;
    }

    public void setProductNames(Set<ProductName> productNames) {
        this.productNames = productNames;
    }

    public ProductName getFirstProductName() {
        if ((null != productNames) &&
            (0 != productNames.size())) {
            return productNames.iterator().next();
        }
        return null;
    }
}