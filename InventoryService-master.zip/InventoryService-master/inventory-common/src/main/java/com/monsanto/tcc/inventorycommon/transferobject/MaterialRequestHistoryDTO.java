package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.protocol.MidasUser;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.AddressTO;

import java.util.Date;

public class MaterialRequestHistoryDTO {
    private MidasUser requesterUser;
    private Date dateNeeded;
    private String requestorProgramRefId;
    private Date requestedDate;
    private Double desiredQuantity;
    private Double minimumQuantity;
    private Long requestUniqueIdNumber;
    private String requestingUserIdTxt;
    private String requestUom;
    private String requestReason;
    private String requestStatus;
    private String requestedInventoryBarcode;
    private String requestedPedigree;
    private String requestedGeneticMaterialSourceStr;
    private String agencyApprovalNumber;
    private String shipFromSite;
    private String alternateSelectionRequested;
    private String alternateSelectionProcessed;
    private String rejectionReason;
    private String rejectionComment;
    private String requesterComments;
    private String processorComments;
    private String shipToProgram;
    private String shipToSite;
    private AddressTO shipToAddress;
    private String shipmentNumber;
    private String invBID;
    private Double sentQuantity;
    private String sentQuantityUom;

    public MaterialRequestHistoryDTO() {
    }

    public MidasUser getRequesterUser() {
        return requesterUser;
    }

    public void setRequesterUser(MidasUser requesterUser) {
        this.requesterUser = requesterUser;
    }

    public Date getDateNeeded() {
        return dateNeeded;
    }

    public void setDateNeeded(Date dateNeeded) {
        this.dateNeeded = dateNeeded;
    }

    public String getRequestorProgramRefId() {
        return requestorProgramRefId;
    }

    public void setRequestorProgramRefId(String requestorProgramRefId) {
        this.requestorProgramRefId = requestorProgramRefId;
    }

    public Date getRequestedDate() {
        return requestedDate;
    }

    public void setRequestedDate(Date requestedDate) {
        this.requestedDate = requestedDate;
    }

    public Double getDesiredQuantity() {
        return desiredQuantity;
    }

    public void setDesiredQuantity(Double desiredQuantity) {
        this.desiredQuantity = desiredQuantity;
    }

    public Double getMinimumQuantity() {
        return minimumQuantity;
    }

    public void setMinimumQuantity(Double minimumQuantity) {
        this.minimumQuantity = minimumQuantity;
    }

    public Long getRequestUniqueIdNumber() {
        return requestUniqueIdNumber;
    }

    public void setRequestUniqueIdNumber(Long requestUniqueIdNumber) {
        this.requestUniqueIdNumber = requestUniqueIdNumber;
    }

    public String getRequestingUserIdTxt() {
        return requestingUserIdTxt;
    }

    public void setRequestingUserIdTxt(String requestingUserIdTxt) {
        this.requestingUserIdTxt = requestingUserIdTxt;
    }

    public String getRequestUom() {
        return requestUom;
    }

    public void setRequestUom(String requestUom) {
        this.requestUom = requestUom;
    }

    public String getRequestReason() {
        return requestReason;
    }

    public void setRequestReason(String requestReason) {
        this.requestReason = requestReason;
    }

    public String getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }

    public String getRequestedInventoryBarcode() {
        return requestedInventoryBarcode;
    }

    public void setRequestedInventoryBarcode(String requestedInventoryBarcode) {
        this.requestedInventoryBarcode = requestedInventoryBarcode;
    }

    public String getRequestedPedigree() {
        return requestedPedigree;
    }

    public void setRequestedPedigree(String requestedPedigree) {
        this.requestedPedigree = requestedPedigree;
    }

    public String getRequestedGeneticMaterialSourceStr() {
        return requestedGeneticMaterialSourceStr;
    }

    public void setRequestedGeneticMaterialSourceStr(String requestedGeneticMaterialSourceStr) {
        this.requestedGeneticMaterialSourceStr = requestedGeneticMaterialSourceStr;
    }

    public String getAgencyApprovalNumber() {
        return agencyApprovalNumber;
    }

    public void setAgencyApprovalNumber(String agencyApprovalNumber) {
        this.agencyApprovalNumber = agencyApprovalNumber;
    }

    public String getShipFromSite() {
        return shipFromSite;
    }

    public void setShipFromSite(String shipFromSite) {
        this.shipFromSite = shipFromSite;
    }

    public String getAlternateSelectionRequested() {
        return alternateSelectionRequested;
    }

    public void setAlternateSelectionRequested(String alternateSelectionRequested) {
        this.alternateSelectionRequested = alternateSelectionRequested;
    }

    public String getAlternateSelectionProcessed() {
        return alternateSelectionProcessed;
    }

    public void setAlternateSelectionProcessed(String alternateSelectionProcessed) {
        this.alternateSelectionProcessed = alternateSelectionProcessed;
    }

    public String getRejectionReason() {
        return rejectionReason;
    }

    public void setRejectionReason(String rejectionReason) {
        this.rejectionReason = rejectionReason;
    }

    public String getRejectionComment() {
        return rejectionComment;
    }

    public void setRejectionComment(String rejectionComment) {
        this.rejectionComment = rejectionComment;
    }

    public String getProcessorComments() {
        return processorComments;
    }

    public void setProcessorComments(String processorComments) {
        this.processorComments = processorComments;
    }

    public String getRequesterComments() {
        return requesterComments;
    }

    public void setRequesterComments(String requesterComments) {
        this.requesterComments = requesterComments;
    }

    public String getShipToProgram() {
        return shipToProgram;
    }

    public void setShipToProgram(String shipToProgram) {
        this.shipToProgram = shipToProgram;
    }

    public String getShipToSite() {
        return shipToSite;
    }

    public void setShipToSite(String shipToSite) {
        this.shipToSite = shipToSite;
    }

    public AddressTO getShipToAddress() {
        return shipToAddress;
    }

    public void setShipToAddress(AddressTO shipToAddress) {
        this.shipToAddress = shipToAddress;
    }

    public String getInvBID() {
        return invBID;
    }

    public void setInvBID(String invBID) {
        this.invBID = invBID;
    }

    public Double getSentQuantity() {
        return sentQuantity;
    }

    public void setSentQuantity(Double sentQuantity) {
        this.sentQuantity = sentQuantity;
    }

    public String getSentQuantityUom() {
        return sentQuantityUom;
    }

    public void setSentQuantityUom(String sentQuantityUom) {
        this.sentQuantityUom = sentQuantityUom;
    }

    public String getShipmentNumber() {
        return shipmentNumber;
    }

    public void setShipmentNumber(String shipmentNumber) {
        this.shipmentNumber = shipmentNumber;
    }
}
