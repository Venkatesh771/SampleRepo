package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Jun 10, 2010
 * Time: 9:51:57 AM
 * To change this template use File | Settings | File Templates.
 */
public class StorageUnitSearchRequest {
    private String barcode;

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }
}
