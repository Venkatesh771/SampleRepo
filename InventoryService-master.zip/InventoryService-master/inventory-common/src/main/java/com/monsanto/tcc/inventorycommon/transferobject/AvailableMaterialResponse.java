package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.transferobject.inventory.ContactTO;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.InventoryTO;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.RequestReasonTO;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.UnitOfMeasureTO;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: May 6, 2009
 * Time: 3:54:07 PM
 */
public class AvailableMaterialResponse {
    private List<InventoryTO> inventories;
    private List<UnitOfMeasureTO> unitsOfMeasure;
    private List<RequestReasonTO> requestReasons;
    private List<ContactTO> externalContacts;

    public AvailableMaterialResponse() {
    }

    public AvailableMaterialResponse(List<InventoryTO> inventories, List<UnitOfMeasureTO> unitsOfMeasure,
                                     List<RequestReasonTO> requestReasons, List<ContactTO> externalContacts) {
        this.inventories = inventories;
        this.unitsOfMeasure = unitsOfMeasure;
        this.requestReasons = requestReasons;
        this.externalContacts = externalContacts;
    }

    public List<InventoryTO> getInventories() {
        return inventories;
    }

    public void setInventories(List<InventoryTO> inventories) {
        this.inventories = inventories;
    }

    public List<UnitOfMeasureTO> getUnitsOfMeasure() {
        return unitsOfMeasure;
    }

    public void setUnitsOfMeasure(List<UnitOfMeasureTO> unitsOfMeasure) {
        this.unitsOfMeasure = unitsOfMeasure;
    }

    public List<RequestReasonTO> getRequestReasons() {
        return requestReasons;
    }

    public void setRequestReasons(List<RequestReasonTO> requestReasons) {
        this.requestReasons = requestReasons;
    }

    public List<ContactTO> getExternalContacts() {
        return externalContacts;
    }

    public void setExternalContacts(List<ContactTO> externalContacts) {
        this.externalContacts = externalContacts;
    }
}
