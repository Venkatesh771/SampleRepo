package com.monsanto.tcc.inventorycommon.domain;

import javax.xml.bind.annotation.XmlType;

import java.util.Date;

@XmlType(name = "Inventory_InventoryContainer")
public class InventoryContainer {

    private Long inventoryContainerId;
    private Long inventoryId;
    private StorageContainer storageContainer;
    private StorageUnit storageUnit;
    private Long materialExchangeId;
    private String modifiedByUserId;
    private Date modifiedDate;

    public Long getInventoryContainerId() {
        return inventoryContainerId;
    }

    public void setInventoryContainerId(Long inventoryContainerId) {
        this.inventoryContainerId = inventoryContainerId;
    }

    public StorageContainer getStorageContainer() {
        return storageContainer;
    }

    public void setStorageContainer(StorageContainer storageContainer) {
        this.storageContainer = storageContainer;
    }

    /**
     * @deprecated StorageUnit has been replaced with StorageContainer.
     */
    @Deprecated
    public StorageUnit getStorageUnit() {
        return storageUnit;
    }

    /**
     * @deprecated StorageUnit has been replaced with StorageContainer.
     */
    @Deprecated
    public void setStorageUnit(StorageUnit storageUnit) {
        this.storageUnit = storageUnit;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public String getStorageContainerBarcode() {
        String barcode = null;
        if (null != storageContainer) {
            barcode = storageContainer.getBarcode();
        } else if (null != storageUnit) {
            barcode = storageUnit.getBarcode();
        }
        return barcode;
    }

    public String getStorageContainerName() {
        String name = null;
        if (null != storageContainer) {
            name = storageContainer.getName();
        } else if (null != storageUnit) {
            name = storageUnit.getName();
        }
        return name;
    }

    public Long getMaterialExchangeId() {
        return materialExchangeId;
    }

    public void setMaterialExchangeId(Long materialExchangeId) {
        this.materialExchangeId = materialExchangeId;
    }

    public String getModifiedByUserId() {
        return modifiedByUserId;
}

    public void setModifiedByUserId(String modifiedByUserId) {
        this.modifiedByUserId = modifiedByUserId;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
}
