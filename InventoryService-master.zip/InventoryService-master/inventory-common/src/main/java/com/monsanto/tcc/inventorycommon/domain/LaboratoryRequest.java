package com.monsanto.tcc.inventorycommon.domain;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: mdspark
 * Date: Sep 23, 2009
 * Time: 11:10:15 AM
 * To change this template use File | Settings | File Templates.
 */
public class LaboratoryRequest {
    private Long laboratoryRequestId;
    private Laboratory laboratory;
    private String requestId;
    private Date requestDate;

    public Long getLaboratoryRequestId() {
        return laboratoryRequestId;
    }

    public void setLaboratoryRequestId(Long laboratoryRequestId) {
        this.laboratoryRequestId = laboratoryRequestId;
    }

    public Laboratory getLaboratory() {
        return laboratory;
    }

    public void setLaboratory(Laboratory laboratory) {
        this.laboratory = laboratory;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }
}
