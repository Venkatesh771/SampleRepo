/*
 Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.service;

import com.monsanto.tcc.inventorycommon.transferobject.CommercialLinkageRequest;
import com.monsanto.tcc.inventorycommon.transferobject.CommercialLinkageResponse;
import com.monsanto.tcc.inventorycommon.transferobject.PreCommercialLinkageResponse;
import com.monsanto.tcc.inventorycommon.transferobject.ProductNameCollapseRequest;
import com.monsanto.tcc.inventorycommon.transferobject.ProductNameCollapseResponse;

import javax.jws.WebService;
import java.util.List;

@WebService
public interface InventoryProductNameLinkageService {
    List<PreCommercialLinkageResponse> updatePreCommercialInventoryProductNameLinkage(List<String> productPublicKeys);

    List<CommercialLinkageResponse> updateCommercialInventoryProductNameLinkage(List<CommercialLinkageRequest> commercialLinkageReqeusts);

    List<ProductNameCollapseResponse> processProductNameCollapse(List<ProductNameCollapseRequest> collapseRequests);
}