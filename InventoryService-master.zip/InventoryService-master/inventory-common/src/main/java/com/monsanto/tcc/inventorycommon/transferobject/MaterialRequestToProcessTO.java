/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.monsanto.services.domain.protocol.MidasUser;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.ProgramTO;

/**
 * User: jjbens2
 * Date: May 19, 2010
 */
public class MaterialRequestToProcessTO {

    private Long materialRequestId;
    private ProgramTO providerProgram;
    private ProgramTO requestorProgram;
    private String comments;
    private Date requestedDate;
    private String requestingUserIdTxt;
    private Long requestUniqueIdNumber;
    private List<MaterialRequestDetailToProcessTO> details;
    private MidasUser requestingUser;


    public String getRequestName() {
        String requestUnitIdNumber = (null != getRequestUniqueIdNumber()) ? getRequestUniqueIdNumber().toString() : null;
        return (null != requestUnitIdNumber) ?
                StringUtils.defaultString(getRequestingUserIdTxt()) + "-" + requestUnitIdNumber : ""; 
    }

    public Long getMaterialRequestId() {
        return materialRequestId;
    }

    public void setMaterialRequestId(Long materialRequestId) {
        this.materialRequestId = materialRequestId;
    }

    public ProgramTO getProviderProgram() {
        return providerProgram;
    }

    public void setProviderProgram(ProgramTO providerProgram) {
        this.providerProgram = providerProgram;
    }

    public ProgramTO getRequestorProgram() {
        return requestorProgram;
    }

    public void setRequestorProgram(ProgramTO requestorProgram) {
        this.requestorProgram = requestorProgram;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Date getRequestedDate() {
        return requestedDate;
    }

    public void setRequestedDate(Date requestedDate) {
        this.requestedDate = requestedDate;
    }

    public String getRequestingUserIdTxt() {
        return requestingUserIdTxt;
    }

    public void setRequestingUserIdTxt(String requestingUserIdTxt) {
        this.requestingUserIdTxt = requestingUserIdTxt;
    }

    public Long getRequestUniqueIdNumber() {
        return requestUniqueIdNumber;
    }

    public void setRequestUniqueIdNumber(Long requestUniqueIdNumber) {
        this.requestUniqueIdNumber = requestUniqueIdNumber;
    }

    public List<MaterialRequestDetailToProcessTO> getDetails() {
        return details;
    }

    public void setDetails(List<MaterialRequestDetailToProcessTO> details) {
        this.details = details;
    }

    public MidasUser getRequestingUser() {
        return requestingUser;
    }

    public void setRequestingUser(MidasUser requestingUser) {
        this.requestingUser = requestingUser;
    }
    
    
}
