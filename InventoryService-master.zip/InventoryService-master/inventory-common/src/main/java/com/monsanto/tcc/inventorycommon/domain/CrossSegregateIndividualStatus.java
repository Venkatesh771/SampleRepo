package com.monsanto.tcc.inventorycommon.domain;

import java.util.Arrays;
import java.util.Date;
import java.util.List;


/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 24, 2010
 * Time: 10:40:36 AM
 */
public class CrossSegregateIndividualStatus {

    private Long crossSegregateIndividualStatusId;
    private Long inventoryId;
    private Long plotId;
    private Long eventConstructId;
    private Date eventConstructAbsenceDate;
    private Date insertedDttm;
    private Date autoEventConstructRemovalDate;
    private Long removableEventListId;
    private String removedById;

    private EventConstruct eventConstructByEventConstructId;
    private Inventory inventoryByInventoryId;
    private Plot plotByPlotId;

    public Long getCrossSegregateIndividualStatusId() {
        return crossSegregateIndividualStatusId;
    }

    public void setCrossSegregateIndividualStatusId(Long crossSegregateIndividualStatusId) {
        this.crossSegregateIndividualStatusId = crossSegregateIndividualStatusId;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Long getPlotId() {
        return plotId;
    }

    public void setPlotId(Long plotId) {
        this.plotId = plotId;
    }

    public Long getEventConstructId() {
        return eventConstructId;
    }

    public void setEventConstructId(Long eventConstructId) {
        this.eventConstructId = eventConstructId;
    }

    public Date getEventConstructAbsenceDate() {
        return eventConstructAbsenceDate;
    }

    public void setEventConstructAbsenceDate(Date eventConstructAbsenceDate) {
        this.eventConstructAbsenceDate = eventConstructAbsenceDate;
    }

    public Date getInsertedDttm() {
        return insertedDttm;
    }

    public void setInsertedDttm(Date insertedDttm) {
        this.insertedDttm = insertedDttm;
    }

    public Date getAutoEventConstructRemovalDate() {
        return autoEventConstructRemovalDate;
    }

    public void setAutoEventConstructRemovalDate(Date autoEventConstructRemovalDate) {
        this.autoEventConstructRemovalDate = autoEventConstructRemovalDate;
    }

    public Long getRemovableEventListId() {
        return removableEventListId;
    }

    public void setRemovableEventListId(Long removableEventListId) {
        this.removableEventListId = removableEventListId;
    }

    public String getRemovedById() {
        return removedById;
    }

    public void setRemovedById(String removedById) {
        this.removedById = removedById;
    }

    public EventConstruct getEventConstructByEventConstructId() {
        return eventConstructByEventConstructId;
    }

    public void setEventConstructByEventConstructId(EventConstruct eventConstructByEventConstructId) {
        this.eventConstructByEventConstructId = eventConstructByEventConstructId;
    }

    public Inventory getInventoryByInventoryId() {
        return inventoryByInventoryId;
    }

    public void setInventoryByInventoryId(Inventory inventoryByInventoryId) {
        this.inventoryByInventoryId = inventoryByInventoryId;
    }

    public Plot getPlotByPlotId() {
        return plotByPlotId;
    }

    public void setPlotByPlotId(Plot plotByPlotId) {
        this.plotByPlotId = plotByPlotId;
    }

    private List<?> identityValues() {
        return Arrays.asList(crossSegregateIndividualStatusId);
    }

    @Override
    public boolean equals(Object object) {
        return object == this || (object instanceof CrossSegregateIndividualStatus && equalsImpl((CrossSegregateIndividualStatus) object));
    }

    private boolean equalsImpl(CrossSegregateIndividualStatus crossSegregateIndividualStatus) {
        return identityValues().equals(crossSegregateIndividualStatus.identityValues());
    }

    @Override
    public int hashCode() {
        return identityValues().hashCode();
    }
}
