package com.monsanto.tcc.inventorycommon.projectcreation.client;

/**
 * Created by IntelliJ IDEA.
 * User: MDSPARK
 * Date: Oct 23, 2009
 * Time: 4:38:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class StartProjectCreationServiceClientException extends RuntimeException {
    public StartProjectCreationServiceClientException(String message, Throwable cause) {
        super(message, cause);
    }
}
