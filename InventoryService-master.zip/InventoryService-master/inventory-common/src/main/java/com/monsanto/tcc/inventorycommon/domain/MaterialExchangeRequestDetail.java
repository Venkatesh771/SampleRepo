package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.shipping.Shipment;

public class MaterialExchangeRequestDetail {

    private Long id;
    private MaterialExchange materialExchange;
    private MaterialRequestDetail materialRequestDetail;
    private Shipment shipment;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public MaterialExchange getMaterialExchange() {
        return materialExchange;
    }

    public void setMaterialExchange(MaterialExchange materialExchange) {
        this.materialExchange = materialExchange;
    }

    public MaterialRequestDetail getMaterialRequestDetail() {
        return materialRequestDetail;
    }

    public void setMaterialRequestDetail(MaterialRequestDetail materialRequestDetail) {
        this.materialRequestDetail = materialRequestDetail;
    }

    public Shipment getShipment() {
        return shipment;
    }

    public void setShipment(Shipment shipment) {
        this.shipment = shipment;
    }
}
