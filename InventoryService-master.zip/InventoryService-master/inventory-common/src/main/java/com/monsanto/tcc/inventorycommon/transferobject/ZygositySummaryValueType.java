package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by IntelliJ IDEA.
 * User: RRPATN
 * Date: Mar 25, 2010
 * Time: 1:20:07 PM
 * To change this template use File | Settings | File Templates.
 */
public enum ZygositySummaryValueType {
    TECH,
    SUBST,
    VALUET,
    VALUE,
    UNIT,
    N_POS,
    N_NEG,
    N_HETERO,
    N_NEGHOM,
    N_POSHOM,
    DEFAULT;

    public static ZygositySummaryValueType fromStrValue(String strValue) {
        try {
            return ZygositySummaryValueType.valueOf(strValue);
        } catch (IllegalArgumentException iae) {

        }
        return null;
    }

}
