package com.monsanto.tcc.inventorycommon.projectcreation.client;

/**
 * Created by IntelliJ IDEA. User: MDSPARK Date: Oct 23, 2009 Time: 4:37:17 PM To change this template use File | Settings | File Templates.
 */
public class ProjectCreationStartUpResponse {
    private String username;
    private Boolean rubiconFlow = false;
    private String rubiconKey;
    private String cropName;
    private String sessionId;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Boolean isRubiconFlow() {
        return rubiconFlow;
    }

    public void setRubiconFlow(Boolean rubiconFlow) {
        this.rubiconFlow = rubiconFlow;
    }

    public String getRubiconKey() {
        return rubiconKey;
    }

    public void setRubiconKey(String rubiconKey) {
        this.rubiconKey = rubiconKey;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ProjectCreationStartUpResponse)) {
            return false;
        }

        ProjectCreationStartUpResponse that = (ProjectCreationStartUpResponse) o;

        if (rubiconFlow != that.rubiconFlow) {
            return false;
        }
        if (cropName != null ? !cropName.equals(that.cropName) : that.cropName != null) {
            return false;
        }
        if (rubiconKey != null ? !rubiconKey.equals(that.rubiconKey) : that.rubiconKey != null) {
            return false;
        }
        if (sessionId != null ? !sessionId.equals(that.sessionId) : that.sessionId != null) {
            return false;
        }
        if (username != null ? !username.equals(that.username) : that.username != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = username != null ? username.hashCode() : 0;
        result = 31 * result + (rubiconFlow ? 1 : 0);
        result = 31 * result + (rubiconKey != null ? rubiconKey.hashCode() : 0);
        result = 31 * result + (cropName != null ? cropName.hashCode() : 0);
        result = 31 * result + (sessionId != null ? sessionId.hashCode() : 0);
        return result;
    }
}
