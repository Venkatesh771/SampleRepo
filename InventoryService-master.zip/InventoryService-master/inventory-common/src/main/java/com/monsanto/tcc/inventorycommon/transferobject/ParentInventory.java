package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.common.AbstractEntity;

public class ParentInventory extends AbstractEntity {      //GC after inventory filter is hibernate enabled
    private Long parentInventoryId;
    private Long inventoryId;
    private Long parentalInventoryId;
    private String parentalInventoryBarcode;

    public ParentInventory() {
    }

    public ParentInventory(Long parentInventoryId, Long inventoryId, Long parentalInventoryId, String parentalInventoryBarcode) {
        this.parentInventoryId = parentInventoryId;
        this.inventoryId = inventoryId;
        this.parentalInventoryId = parentalInventoryId;
        this.parentalInventoryBarcode = parentalInventoryBarcode;
    }

    public Long getParentInventoryId() {
        return parentInventoryId;
    }

    public void setParentInventoryId(Long parentInventoryId) {
        this.parentInventoryId = parentInventoryId;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Long getParentalInventoryId() {
        return parentalInventoryId;
    }

    public void setParentalInventoryId(Long parentalInventoryId) {
        this.parentalInventoryId = parentalInventoryId;
    }

    public String getParentalInventoryBarcode() {
        return parentalInventoryBarcode;
    }

    public void setParentalInventoryBarcode(String parentalInventoryBarcode) {
        this.parentalInventoryBarcode = parentalInventoryBarcode;
    }

    @Override
    public Object getID() {
        return getParentInventoryId();
    }
}
