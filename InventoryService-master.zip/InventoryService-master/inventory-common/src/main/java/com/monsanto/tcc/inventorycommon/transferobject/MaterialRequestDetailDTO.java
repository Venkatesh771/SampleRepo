package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jjbens2
 * Date: May 12, 2010
 * Time: 3:57:56 PM
 */
public class MaterialRequestDetailDTO {

    private Long materialRequestId;
    private Long materialRequestDetailId;
    private String barcode;
    private Long requestReasonId;
    private String comments;
    private Long uomID;
    private Date dateNeeded;
    private String agencyPermitNotificationTxt;
    private Long shipToContactId;
    private String shipToProgramRefId; // This is used primarily for logging performance
    private Long shipToProgramId;
    private Long shipToSiteId;
    private Double desiredQuantity;
    private Double minimumQuantity;
    private Long shipToAddressId;
    private List<AlternateRequestSourcePreferenceTO> alternateRequestSources;

    private String materialRequestStatusName = "Requested";


    public Long getMaterialRequestId() {
        return materialRequestId;
    }

    public void setMaterialRequestId(Long materialRequestId) {
        this.materialRequestId = materialRequestId;
    }

    public Long getMaterialRequestDetailId() {
        return materialRequestDetailId;
    }

    public void setMaterialRequestDetailId(Long materialRequestDetailId) {
        this.materialRequestDetailId = materialRequestDetailId;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Long getRequestReasonId() {
        return requestReasonId;
    }

    public void setRequestReasonId(Long requestReasonId) {
        this.requestReasonId = requestReasonId;
    }

    public Long getUomID() {
        return uomID;
    }

    public void setUomID(Long uomID) {
        this.uomID = uomID;
    }

    public Date getDateNeeded() {
        return dateNeeded;
    }

    public void setDateNeeded(Date dateNeeded) {
        this.dateNeeded = dateNeeded;
    }

    public String getAgencyPermitNotificationTxt() {
        return agencyPermitNotificationTxt;
    }

    public void setAgencyPermitNotificationTxt(String agencyPermitNotificationTxt) {
        this.agencyPermitNotificationTxt = agencyPermitNotificationTxt;
    }

    public Long getShipToContactId() {
        return shipToContactId;
    }

    public void setShipToContactId(Long shipToContactId) {
        this.shipToContactId = shipToContactId;
    }

    public Long getShipToProgramId() {
        return shipToProgramId;
    }

    public void setShipToProgramId(Long shipToProgramId) {
        this.shipToProgramId = shipToProgramId;
    }

    public Double getDesiredQuantity() {
        return desiredQuantity;
    }

    public void setDesiredQuantity(Double desiredQuantity) {
        this.desiredQuantity = desiredQuantity;
    }

    public Double getMinimumQuantity() {
        return minimumQuantity;
    }

    public void setMinimumQuantity(Double minimumQuantity) {
        this.minimumQuantity = minimumQuantity;
    }

    public String getMaterialRequestStatusName() {
        return materialRequestStatusName;
    }

    public void setMaterialRequestStatusName(String materialRequestStatusName) {
        this.materialRequestStatusName = materialRequestStatusName;
    }

    public Long getShipToAddressId() {
        return shipToAddressId;
    }

    public void setShipToAddressId(Long shipToAddressId) {
        this.shipToAddressId = shipToAddressId;
    }

    public String getShipToProgramRefId() {
        return shipToProgramRefId;
    }

    public void setShipToProgramRefId(String shipToProgramRefId) {
        this.shipToProgramRefId = shipToProgramRefId;
    }

    public List<AlternateRequestSourcePreferenceTO> getAlternateRequestSources() {
        return alternateRequestSources;
    }

    public void setAlternateRequestSources(
            List<AlternateRequestSourcePreferenceTO> alternateRequestSources) {
        this.alternateRequestSources = alternateRequestSources;
    }

    public Long getShipToSiteId() {
        return shipToSiteId;
    }

    public void setShipToSiteId(Long shipToSiteId) {
        this.shipToSiteId = shipToSiteId;
    }
}
