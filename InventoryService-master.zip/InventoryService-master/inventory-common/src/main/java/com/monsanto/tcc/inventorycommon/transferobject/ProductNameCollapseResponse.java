package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: May 18, 2010
 * Time: 1:06:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductNameCollapseResponse {
    private List<String> responses = new ArrayList<String>();
    private String productNamePubKey;

    public ProductNameCollapseResponse() {
    }

    public ProductNameCollapseResponse(String productNamePubKey) {
        this.productNamePubKey = productNamePubKey;
    }

    public ProductNameCollapseResponse(List<String> responses, String productNamePubKey) {
        this.responses = responses;
        this.productNamePubKey = productNamePubKey;
    }

    public void addErrorMessage(String errorMessage) {
        if (errorMessage != null) {
            getResponses().add(errorMessage);
        }
    }

    public boolean isErrorResponse() {
        return !getResponses().isEmpty();
    }

    public List<String> getResponses() {
        return responses;
    }

    public void setResponses(List<String> responses) {
        this.responses = responses;
    }

    public String getProductNamePubKey() {
        return productNamePubKey;
    }

    public void setProductNamePubKey(String productNamePubKey) {
        this.productNamePubKey = productNamePubKey;
    }
}
