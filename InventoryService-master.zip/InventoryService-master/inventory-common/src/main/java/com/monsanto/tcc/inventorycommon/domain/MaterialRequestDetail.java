package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.bpm.ActivityInstance;
import com.monsanto.services.domain.breeding.Program;
import com.monsanto.services.domain.breeding.uom.UnitOfMeasure;
import com.monsanto.tcc.inventorycommon.transferobject.ProgramSiteTransferObject;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.AddressTO;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.ContactTO;

import java.util.Date;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: jjbens2
 * Date: May 11, 2010
 * Time: 8:24:28 AM
 */
public class MaterialRequestDetail {

    private Long materialRequestId;
    private Long materialRequestDetailId;
    private Inventory requestedInventory;
    private Set<AlternateInventory> alternateInventories;
    private RequestReason requestReason;
    private UnitOfMeasure requestUom;
    private MaterialRequestStatus requestStatus;
    private Double desiredQuantity;
    private Double minimumQuantity;
    private Date dateNeeded;
    private String comments;
    private Program shipToProgram;
    private Long shipToSiteId;
    private Long shipToContactId;
    private String agencyPermitNotification;
    private Long shipToAddressId;
    private Long rejectionReasonId;
    private RejectionReason rejectionReason;
    private String rejectionComment;
    private Set<AlternateRequestSourcePreference> alternateRequestSources;
    private Set<MaterialExchangeRequestDetail> materialExchangeRequestDetails;

    // members for Conversion to TO's only
    private ActivityInstance activityInstance;
    private ContactTO shipToContact;
    private AddressTO shipToAddress;
    private ProgramSiteTransferObject shipToSite;


    public Germplasm getGermplasm() {
        return getRequestedInventory().getGeneticMaterial().getGermplasm();
    }

    public String getRequestedMaterialBarcode() {
        return getRequestedInventory().getBarcode();
    }

    public Inventory getRequestedInventory() {
        return requestedInventory;
    }

    public void setRequestedInventory(Inventory requestedInventory) {
        this.requestedInventory = requestedInventory;
    }

    public Set<AlternateInventory> getAlternateInventories() {
        return alternateInventories;
    }

    public void setAlternateInventories(Set<AlternateInventory> alternateInventories) {
        this.alternateInventories = alternateInventories;
    }

    public Date getDateNeeded() {
        return dateNeeded;
    }

    public void setDateNeeded(Date dateNeeded) {
        this.dateNeeded = dateNeeded;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Program getShipToProgram() {
        return shipToProgram;
    }

    public void setShipToProgram(Program shipToProgram) {
        this.shipToProgram = shipToProgram;
    }

    public Long getShipToContactId() {
        return shipToContactId;
    }

    public void setShipToContactId(Long shipToContactId) {
        this.shipToContactId = shipToContactId;
    }

    public String getAgencyPermitNotification() {
        return agencyPermitNotification;
    }

    public void setAgencyPermitNotification(String agencyPermitNotification) {
        this.agencyPermitNotification = agencyPermitNotification;
    }

    public Long getMaterialRequestId() {
        return materialRequestId;
    }

    public void setMaterialRequestId(Long materialRequestId) {
        this.materialRequestId = materialRequestId;
    }

    public Long getMaterialRequestDetailId() {
        return materialRequestDetailId;
    }

    public void setMaterialRequestDetailId(Long materialRequestDetailId) {
        this.materialRequestDetailId = materialRequestDetailId;
        updateChildrenWithParentInfo(); // may not be strictly needed here. Placed here to keep hibernate/dozer bi-directionally happy.
    }

    public Double getDesiredQuantity() {
        return desiredQuantity;
    }

    public void setDesiredQuantity(Double desiredQuantity) {
        this.desiredQuantity = desiredQuantity;
    }

    public Double getMinimumQuantity() {
        return minimumQuantity;
    }

    public void setMinimumQuantity(Double minimumQuantity) {
        this.minimumQuantity = minimumQuantity;
    }

    public RequestReason getRequestReason() {
        return requestReason;
    }

    public void setRequestReason(RequestReason requestReason) {
        this.requestReason = requestReason;
    }

    public UnitOfMeasure getRequestUom() {
        return requestUom;
    }

    public void setRequestUom(UnitOfMeasure requestUom) {
        this.requestUom = requestUom;
    }

    public MaterialRequestStatus getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(MaterialRequestStatus requestStatus) {
        this.requestStatus = requestStatus;
    }

    public ActivityInstance getActivityInstance() {
        return activityInstance;
    }

    public void setActivityInstance(ActivityInstance activityInstance) {
        this.activityInstance = activityInstance;
    }

    public Long getShipToAddressId() {
        return shipToAddressId;
    }

    public void setShipToAddressId(Long shipToAddressId) {
        this.shipToAddressId = shipToAddressId;
    }

    public Long getRejectionReasonId() {
        return rejectionReasonId;
    }

    public void setRejectionReasonId(Long rejectionReasonId) {
        this.rejectionReasonId = rejectionReasonId;
    }

    public RejectionReason getRejectionReason() {
        return rejectionReason;
    }

    public void setRejectionReason(RejectionReason rejectionReason) {
        this.rejectionReason = rejectionReason;
    }

    public String getRejectionComment() {
        return rejectionComment;
    }

    public void setRejectionComment(String rejectionComment) {
        this.rejectionComment = rejectionComment;
    }

    public ContactTO getShipToContact() {
        return shipToContact;
    }

    public void setShipToContact(ContactTO shipToContact) {
        this.shipToContact = shipToContact;
    }

    public AddressTO getShipToAddress() {
        return shipToAddress;
    }

    public void setShipToAddress(AddressTO shipToAddress) {
        this.shipToAddress = shipToAddress;
    }

    public Set<MaterialExchangeRequestDetail> getMaterialExchangeRequestDetails() {
        return materialExchangeRequestDetails;
    }

    public void setMaterialExchangeRequestDetails(Set<MaterialExchangeRequestDetail> materialExchangeRequestDetails) {
        this.materialExchangeRequestDetails = materialExchangeRequestDetails;
    }

    public Set<AlternateRequestSourcePreference> getAlternateRequestSources() {
        return alternateRequestSources;
    }

    public void setAlternateRequestSources(Set<AlternateRequestSourcePreference> alternateRequestSources) {
        this.alternateRequestSources = alternateRequestSources;
        updateChildrenWithParentInfo();
    }

    public Long getShipToSiteId() {
        return shipToSiteId;
    }

    public void setShipToSiteId(Long shipToSiteId) {
        this.shipToSiteId = shipToSiteId;
    }

    public ProgramSiteTransferObject getShipToSite() {
        return shipToSite;
    }

    public void setShipToSite(ProgramSiteTransferObject shipToSite) {
        this.shipToSite = shipToSite;
    }

    private void updateChildrenWithParentInfo() {
        if (this.alternateRequestSources != null) {
            for (AlternateRequestSourcePreference pref : this.alternateRequestSources) {
                pref.setMaterialRequestDetail(this);
            }
        }
    }
}
