/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

public class InventoryProgramAccount {

    private Long inventoryId;
    private Long accountId;
    private String barcode;

    public InventoryProgramAccount() {
    }

    public InventoryProgramAccount(Long inventoryId, Long accountId, String barcode) {
        this.inventoryId = inventoryId;
        this.accountId = accountId;
        this.barcode = barcode;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }
}