package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.breeding.uom.UnitOfMeasure;

import java.util.Set;

public class UnitOfMeasureGroup {

    private Long id;
    private String name;
    private String refId;
    private boolean active;
    private Set<UnitOfMeasure> unitOfMeasures;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Set<UnitOfMeasure> getUnitOfMeasures() {
        return unitOfMeasures;
    }

    public void setUnitOfMeasures(Set<UnitOfMeasure> unitOfMeasures) {
        this.unitOfMeasures = unitOfMeasures;
    }

}