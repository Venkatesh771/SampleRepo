package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: RRPATN
 * Date: Mar 24, 2010
 * Time: 10:20:46 AM
 * To change this template use File | Settings | File Templates.
 */
public class AggregateFunction {
    private Long aggregateFunctionId;
    private String name;
    private String aggregateType;
    private String aggregateFunctionRefId;
    private Long listOrder;
    private Boolean refActive;
    private Boolean isResultAlwaysNumeric;

    public AggregateFunction() {
    }

    public Long getAggregateFunctionId() {
        return aggregateFunctionId;
    }

    public void setAggregateFunctionId(Long aggregateFunctionId) {
        this.aggregateFunctionId = aggregateFunctionId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAggregateType() {
        return aggregateType;
    }

    public void setAggregateType(String aggregateType) {
        this.aggregateType = aggregateType;
    }

    public String getAggregateFunctionRefId() {
        return aggregateFunctionRefId;
    }

    public void setAggregateFunctionRefId(String aggregateFunctionRefId) {
        this.aggregateFunctionRefId = aggregateFunctionRefId;
    }

    public Long getListOrder() {
        return listOrder;
    }

    public void setListOrder(Long listOrder) {
        this.listOrder = listOrder;
    }

    public Boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(Boolean refActive) {
        this.refActive = refActive;
    }

    public Boolean isResultAlwaysNumeric() {
        return isResultAlwaysNumeric;
    }

    public void setResultAlwaysNumeric(Boolean resultAlwaysNumeric) {
        isResultAlwaysNumeric = resultAlwaysNumeric;
    }
}
