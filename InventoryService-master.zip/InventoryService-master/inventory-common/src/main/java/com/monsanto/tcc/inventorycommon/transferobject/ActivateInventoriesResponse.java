package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Apr 6, 2010
 * Time: 3:27:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class ActivateInventoriesResponse {
    private ResponseMessage responseMessage;

    public ResponseMessage getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(ResponseMessage responseMessage) {
        this.responseMessage = responseMessage;
    }
}
