package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 17, 2009
 * Time: 9:51:15 AM
 */
public class ProductName {
    private Long productNameId;
    private Long productId;
    private String name;
    private Long countryId;
    private String isStageActive;
    private String preferredName;
    private Long productStageId;
    private boolean active;

    private Brand brand;

    public Long getProductNameId() {
        return productNameId;
    }

    public void setProductNameId(Long productNameId) {
        this.productNameId = productNameId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getCountryId() {
        return countryId;
    }

    public void setCountryId(Long countryId) {
        this.countryId = countryId;
    }

    public String getIsStageActive() {
        return isStageActive;
    }

    public void setIsStageActive(String stageActive) {
        isStageActive = stageActive;
    }

    public String getPreferredName() {
        return preferredName;
    }

    public void setPreferredName(String preferredName) {
        this.preferredName = preferredName;
    }

    public Long getProductStageId() {
        return productStageId;
    }

    public void setProductStageId(Long productStageId) {
        this.productStageId = productStageId;
    }

    public String getStageActive() {
        return isStageActive;
    }

    public void setStageActive(String stageActive) {
        isStageActive = stageActive;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Brand getBrand() {
        return brand;
    }

    public void setBrand(Brand brand) {
        this.brand = brand;
    }
}
