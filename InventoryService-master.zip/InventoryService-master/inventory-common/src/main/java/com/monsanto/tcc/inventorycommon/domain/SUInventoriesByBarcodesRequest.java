/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import java.util.Collection;

/* nbwald - Oct 12, 2010 */
public class SUInventoriesByBarcodesRequest {
    private Collection<String> storageContainerBarcodes;

    public Collection<String> getStorageContainerBarcodes() {
        return storageContainerBarcodes;
    }

    public void setStorageContainerBarcodes(Collection<String> storageContainerBarcodes) {
        this.storageContainerBarcodes = storageContainerBarcodes;
    }
}