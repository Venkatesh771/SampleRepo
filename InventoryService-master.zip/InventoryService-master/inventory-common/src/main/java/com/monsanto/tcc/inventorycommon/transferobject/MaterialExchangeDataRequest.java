package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Aug 12, 2009
 * Time: 10:07:54 PM
 */
public class MaterialExchangeDataRequest {
    private List<Long> inventoryIds;
    private Long progId;

    public List<Long> getInventoryIds() {
        return inventoryIds;
    }

    public void setInventoryIds(List<Long> inventoryIds) {
        this.inventoryIds = inventoryIds;
    }

    public Long getProgId() {
        return progId;
    }

    public void setProgId(Long progId) {
        this.progId = progId;
    }
}
