package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;

import javax.xml.bind.annotation.XmlType;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: May 19, 2010
 * Time: 4:09:43 PM
 * To change this template use File | Settings | File Templates.
 */
@XmlType(name = "Inventory_AssignInventoriesToStorageContainerRequest")
public class AssignInventoriesToStorageContainerRequest {

    Collection<Long> inventoryIds;
    StorageUnitTO storageUnitTo;

    public Collection<Long> getInventoryIds() {
        return inventoryIds;
    }

    public void setInventoryIds(Collection<Long> inventoryIds) {
        this.inventoryIds = inventoryIds;
    }

    public StorageUnitTO getStorageUnitTo() {
        return storageUnitTo;
    }

    public void setStorageUnitTo(StorageUnitTO storageUnitTo) {
        this.storageUnitTo = storageUnitTo;
    }
}
