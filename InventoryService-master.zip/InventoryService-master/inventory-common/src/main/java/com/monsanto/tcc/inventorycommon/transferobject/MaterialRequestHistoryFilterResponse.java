package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Jun 3, 2010
 * Time: 11:34:52 AM
 * To change this template use File | Settings | File Templates.
 */
public class MaterialRequestHistoryFilterResponse {
    private String currentUserName;


    public MaterialRequestHistoryFilterResponse() {
    }

    public MaterialRequestHistoryFilterResponse(String currentUserName) {
        this.currentUserName = currentUserName;
    }

    public String getCurrentUserName() {
        return currentUserName;
    }

    public void setCurrentUserName(String currentUserName) {
        this.currentUserName = currentUserName;
    }
}