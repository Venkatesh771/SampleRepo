package com.monsanto.tcc.inventorycommon.transferobject.subinventory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Jun 1, 2010
 * Time: 5:09:07 PM
 * To change this template use File | Settings | File Templates.
 */
public class SubInventoryParentGroupDto {
    private Long parentId;
    private List<SubInventoryDto> subInventories = new ArrayList<SubInventoryDto>();

    public SubInventoryParentGroupDto() {
    }

    public SubInventoryParentGroupDto(Long parentId) {
        this.parentId = parentId;
    }

    public SubInventoryParentGroupDto(Long parentId, List<SubInventoryDto> subInventories) {
        this.parentId = parentId;
        this.subInventories = subInventories;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public List<SubInventoryDto> getSubInventories() {
        return subInventories;
    }

    public void setSubInventories(List<SubInventoryDto> subInventories) {
        this.subInventories = subInventories;
    }
}
