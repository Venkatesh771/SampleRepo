package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.protocol.MidasUser;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Mar 17, 2010
 * Time: 2:03:28 PM
 */
public class MidasMessage {
    private String isUnpublishable;

    public String getIsUnpublishable() {
        return isUnpublishable;
    }

    public void setIsUnpublishable(String unpublishable) {
        isUnpublishable = unpublishable;
    }

    private Date sentDatetime;

    public Date getSentDatetime() {
        return sentDatetime;
    }

    public void setSentDatetime(Date sentDatetime) {
        this.sentDatetime = sentDatetime;
    }

    private String isTransgenic;

    public String getIsTransgenic() {
        return isTransgenic;
    }

    public void setIsTransgenic(String transgenic) {
        isTransgenic = transgenic;
    }

    private String className;

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    private Long objectId;

    public Long getObjectId() {
        return objectId;
    }

    public void setObjectId(Long objectId) {
        this.objectId = objectId;
    }

    private String displayText;

    public String getDisplayText() {
        return displayText;
    }

    public void setDisplayText(String displayText) {
        this.displayText = displayText;
    }

    private Long midasMessageId;

    public Long getMidasMessageId() {
        return midasMessageId;
    }

    public void setMidasMessageId(Long midasMessageId) {
        this.midasMessageId = midasMessageId;
    }

    private Long origBrProgId;

    public Long getOrigBrProgId() {
        return origBrProgId;
    }

    public void setOrigBrProgId(Long origBrProgId) {
        this.origBrProgId = origBrProgId;
    }

    private Long sentMidasUserId;

    public Long getSentMidasUserId() {
        return sentMidasUserId;
    }

    public void setSentMidasUserId(Long sentMidasUserId) {
        this.sentMidasUserId = sentMidasUserId;
    }

    private String messageComments;

    public String getMessageComments() {
        return messageComments;
    }

    public void setMessageComments(String messageComments) {
        this.messageComments = messageComments;
    }

    private MidasUser publishedMidasUser;

    public MidasUser getPublishedMidasUser() {
        return publishedMidasUser;
    }

    public void setPublishedMidasUser(MidasUser publishedMidasUserId) {
        this.publishedMidasUser = publishedMidasUserId;
    }

    private Date publishedDatetime;

    public Date getPublishedDatetime() {
        return publishedDatetime;
    }

    public void setPublishedDatetime(Date publishedDatetime) {
        this.publishedDatetime = publishedDatetime;
    }

    private Long origMessageSourceId;

    public Long getOrigMessageSourceId() {
        return origMessageSourceId;
    }

    public void setOrigMessageSourceId(Long origMessageSourceId) {
        this.origMessageSourceId = origMessageSourceId;
    }

    private String origMessageSourceKey;

    public String getOrigMessageSourceKey() {
        return origMessageSourceKey;
    }

    public void setOrigMessageSourceKey(String origMessageSourceKey) {
        this.origMessageSourceKey = origMessageSourceKey;
    }

}
