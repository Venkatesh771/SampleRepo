package com.monsanto.tcc.inventorycommon.domain;

import java.sql.Date;
import java.util.Collection;

public class StorageLocationCatalog {

    private Long storageLocationCatalogId;
    private Long storageLocationId;
    private String name;
    private String description;
    private String barcode;
    private Long positionIndex;
    private Date inactiveDttm;
    private Collection<StorageContainerLocation> storageContainerLocationsByStorageLocationCatalogId;
    private StorageLocation storageLocation;

    public StorageLocation getStorageLocation() {
        return storageLocation;
    }

    public void setStorageLocation(StorageLocation storageLocation) {
        this.storageLocation = storageLocation;
    }

    public Long getStorageLocationCatalogId() {
        return storageLocationCatalogId;
    }

    public void setStorageLocationCatalogId(Long storageLocationCatalogId) {
        this.storageLocationCatalogId = storageLocationCatalogId;
    }

    public Long getStorageLocationId() {
        return storageLocationId;
    }

    public void setStorageLocationId(Long storageLocationId) {
        this.storageLocationId = storageLocationId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Long getPositionIndex() {
        return positionIndex;
    }

    public void setPositionIndex(Long positionIndex) {
        this.positionIndex = positionIndex;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }

    public Collection<StorageContainerLocation> getStorageContainerLocationsByStorageLocationCatalogId() {
        return storageContainerLocationsByStorageLocationCatalogId;
    }

    public void setStorageContainerLocationsByStorageLocationCatalogId(Collection<StorageContainerLocation> storageContainerLocationsByStorageLocationCatalogId) {
        this.storageContainerLocationsByStorageLocationCatalogId = storageContainerLocationsByStorageLocationCatalogId;
    }

}
