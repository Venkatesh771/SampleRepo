package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.breeding.Program;

import java.sql.Date;

/**
 * Created by IntelliJ IDEA.
 * User: MDSPARK
 * Date: Oct 14, 2009
 * Time: 4:13:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class PedFixRequest {
    private Long pedFixRequestId;
    private PedFixAction pedFixAction;
    private Long requestorUserId;
    private String requestorReason;
    private Long authorityUserId;
    private String authorityComments;
    private GeneticMaterial geneticMaterial;
    private String proposedSourceStr;
    private String proposedLineCode;
    private String proposedLineage;
    private String proposedGeneration;
    private Program proposedOwnerProgram;
    private String proposedOrigin;
    private Long proposedLineTypeId;
    private Program program;
    private Date pedFixRequestDttm;
    private String originalSourceStr;
    private String originalLineCode;
    private String originalLineage;
    private String originalOrigin;
    private String originalGeneration;
    private Long originalLineTypeId;
    private Long proposedLineFunctionId;
    private Long originalLineFunctionId;

    public Long getPedFixRequestId() {
        return pedFixRequestId;
    }

    public void setPedFixRequestId(Long pedFixRequestId) {
        this.pedFixRequestId = pedFixRequestId;
    }

    public PedFixAction getPedFixAction() {
        return pedFixAction;
    }

    public void setPedFixAction(PedFixAction pedFixAction) {
        this.pedFixAction = pedFixAction;
    }

    public Long getRequestorUserId() {
        return requestorUserId;
    }

    public void setRequestorUserId(Long requestorUserId) {
        this.requestorUserId = requestorUserId;
    }

    public String getRequestorReason() {
        return requestorReason;
    }

    public void setRequestorReason(String requestorReason) {
        this.requestorReason = requestorReason;
    }

    public Long getAuthorityUserId() {
        return authorityUserId;
    }

    public void setAuthorityUserId(Long authorityUserId) {
        this.authorityUserId = authorityUserId;
    }

    public String getAuthorityComments() {
        return authorityComments;
    }

    public void setAuthorityComments(String authorityComments) {
        this.authorityComments = authorityComments;
    }

    public GeneticMaterial getGeneticMaterial() {
        return geneticMaterial;
    }

    public void setGeneticMaterial(GeneticMaterial geneticMaterial) {
        this.geneticMaterial = geneticMaterial;
    }

    public String getProposedSourceStr() {
        return proposedSourceStr;
    }

    public void setProposedSourceStr(String proposedSourceStr) {
        this.proposedSourceStr = proposedSourceStr;
    }

    public String getProposedLineCode() {
        return proposedLineCode;
    }

    public void setProposedLineCode(String proposedLineCode) {
        this.proposedLineCode = proposedLineCode;
    }

    public String getProposedLineage() {
        return proposedLineage;
    }

    public void setProposedLineage(String proposedLineage) {
        this.proposedLineage = proposedLineage;
    }

    public String getProposedGeneration() {
        return proposedGeneration;
    }

    public void setProposedGeneration(String proposedGeneration) {
        this.proposedGeneration = proposedGeneration;
    }

    public Program getProposedOwnerProgram() {
        return proposedOwnerProgram;
    }

    public void setProposedOwnerProgram(Program proposedOwnerProgram) {
        this.proposedOwnerProgram = proposedOwnerProgram;
    }

    public String getProposedOrigin() {
        return proposedOrigin;
    }

    public void setProposedOrigin(String proposedOrigin) {
        this.proposedOrigin = proposedOrigin;
    }

    public Long getProposedLineTypeId() {
        return proposedLineTypeId;
    }

    public void setProposedLineTypeId(Long proposedLineTypeId) {
        this.proposedLineTypeId = proposedLineTypeId;
    }

    public Program getProgram() {
        return program;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public Date getPedFixRequestDttm() {
        return pedFixRequestDttm;
    }

    public void setPedFixRequestDttm(Date pedFixRequestDttm) {
        this.pedFixRequestDttm = pedFixRequestDttm;
    }

    public String getOriginalSourceStr() {
        return originalSourceStr;
    }

    public void setOriginalSourceStr(String originalSourceStr) {
        this.originalSourceStr = originalSourceStr;
    }

    public String getOriginalLineCode() {
        return originalLineCode;
    }

    public void setOriginalLineCode(String originalLineCode) {
        this.originalLineCode = originalLineCode;
    }

    public String getOriginalLineage() {
        return originalLineage;
    }

    public void setOriginalLineage(String originalLineage) {
        this.originalLineage = originalLineage;
    }

    public String getOriginalOrigin() {
        return originalOrigin;
    }

    public void setOriginalOrigin(String originalOrigin) {
        this.originalOrigin = originalOrigin;
    }

    public String getOriginalGeneration() {
        return originalGeneration;
    }

    public void setOriginalGeneration(String originalGeneration) {
        this.originalGeneration = originalGeneration;
    }

    public Long getOriginalLineTypeId() {
        return originalLineTypeId;
    }

    public void setOriginalLineTypeId(Long originalLineTypeId) {
        this.originalLineTypeId = originalLineTypeId;
    }

    public Long getProposedLineFunctionId() {
        return proposedLineFunctionId;
    }

    public void setProposedLineFunctionId(Long proposedLineFunctionId) {
        this.proposedLineFunctionId = proposedLineFunctionId;
    }

    public Long getOriginalLineFunctionId() {
        return originalLineFunctionId;
    }

    public void setOriginalLineFunctionId(Long originalLineFunctionId) {
        this.originalLineFunctionId = originalLineFunctionId;
    }
}
