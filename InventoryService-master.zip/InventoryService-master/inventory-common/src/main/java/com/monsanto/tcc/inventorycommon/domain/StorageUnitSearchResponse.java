package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.tcc.inventorycommon.transferobject.ResponseMessage;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Jun 10, 2010
 * Time: 9:52:33 AM
 * To change this template use File | Settings | File Templates.
 */
public class StorageUnitSearchResponse {

    private String storageUnitPath;
    private ResponseMessage responseMessage;

    public String getStorageUnitPath() {
        return storageUnitPath;
    }

    public void setStorageUnitPath(String storageUnitPath) {
        this.storageUnitPath = storageUnitPath;
    }

    public ResponseMessage getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(ResponseMessage responseMessage) {
        this.responseMessage = responseMessage;
    }
}
