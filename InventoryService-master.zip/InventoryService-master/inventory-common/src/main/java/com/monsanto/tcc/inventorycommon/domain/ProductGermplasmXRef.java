/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

public class ProductGermplasmXRef {
    private Long id;
    private Product product;
    private Germplasm germplasm;

    public ProductGermplasmXRef() {
    }

    public ProductGermplasmXRef(Long id, Product product, Germplasm germplasm) {
        this.id = id;
        this.product = product;
        this.germplasm = germplasm;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Germplasm getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(Germplasm germplasm) {
        this.germplasm = germplasm;
    }
}