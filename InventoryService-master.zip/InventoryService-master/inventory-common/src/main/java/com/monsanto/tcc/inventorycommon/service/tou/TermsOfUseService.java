package com.monsanto.tcc.inventorycommon.service.tou;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 * User: DCENGL
 */
@WebService(name = "TermsOfUseService")
public interface TermsOfUseService {

    @WebMethod
    GetTermsOfUseResponse getTermsOfUse(@WebParam Long geneticMaterialId);

    @WebMethod
    void save(@WebParam(name = "termsOfUseId") Long termsOfUseId, @WebParam(name = "geneticMaterialId") Long geneticMaterialId, @WebParam(name = "terms") String terms, @WebParam(name = "restricted") Boolean restricted);

}
