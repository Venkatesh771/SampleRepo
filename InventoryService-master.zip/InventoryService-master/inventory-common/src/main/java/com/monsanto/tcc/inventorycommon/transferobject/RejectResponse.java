package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 26, 2009
 * Time: 10:02:14 AM
 */
public class RejectResponse {
    private Boolean result;
    private String responseDetail;

    public RejectResponse() {
    }

    public RejectResponse(Boolean result, String responseDetail) {
        this.result = result;
        this.responseDetail = responseDetail;
    }

    public Boolean getResult() {
        return result;
    }

    public void setResult(Boolean result) {
        this.result = result;
    }

    public String getResponseDetail() {
        return responseDetail;
    }

    public void setResponseDetail(String responseDetail) {
        this.responseDetail = responseDetail;
    }
}
