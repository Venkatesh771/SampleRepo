package com.monsanto.tcc.inventorycommon.transferobject.inventory;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: dysona
 * Date: May 27, 2011
 * Time: 10:15:42 AM
 */
public class SeedProductInventory implements Serializable {

    private Long inventoryId;
    private String barcode;
    private String productName;
    private String brandName;
    private String countryName;
    private String commercialTrait;
    private Double relativeMaturity;
    private String mctName;
    private String mctCode;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCommercialTrait() {
        return commercialTrait;
    }

    public void setCommercialTrait(String commercialTrait) {
        this.commercialTrait = commercialTrait;
    }

    public Double getRelativeMaturity() {
        return relativeMaturity;
    }

    public void setRelativeMaturity(Double relativeMaturity) {
        this.relativeMaturity = relativeMaturity;
    }

    public String getMctName() {
        return mctName;
    }

    public void setMctName(String mctName) {
        this.mctName = mctName;
    }

    public String getMctCode() {
        return mctCode;
    }

    public void setMctCode(String mctCode) {
        this.mctCode = mctCode;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }
}
