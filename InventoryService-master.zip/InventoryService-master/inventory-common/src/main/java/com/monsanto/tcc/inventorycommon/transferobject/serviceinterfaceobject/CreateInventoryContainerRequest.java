package com.monsanto.tcc.inventorycommon.transferobject.serviceinterfaceobject;

import java.util.Collection;

public class CreateInventoryContainerRequest {

    private long inventoryId;
    private Long destinationStorageContainerId;
    private Collection<Long> parentInventoryIds;

    public long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Long getDestinationStorageContainer() {
        return destinationStorageContainerId;
    }

    public void setDestinationStorageContainer(Long destinationStorageContainerId) {
        this.destinationStorageContainerId = destinationStorageContainerId;
    }

    public Collection<Long> getParentInventoryIds() {
        return parentInventoryIds;
    }

    public void setParentInventoryIds(Collection<Long> parentInventoryIds) {
        this.parentInventoryIds = parentInventoryIds;
    }
}
