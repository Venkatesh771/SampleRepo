package com.monsanto.tcc.inventorycommon.exception;

/**
 * Created by IntelliJ IDEA.
 * User: SSSING5
 * Date: Jun 20, 2009
 * Time: 12:38:01 PM
 */
public class QueryResultsException extends Exception {
    public QueryResultsException(String message) {
        super(message);
    }

    public QueryResultsException(String message, Throwable cause) {
        super(message, cause);
    }
}
