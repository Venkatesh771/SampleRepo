/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.inventory;

import com.monsanto.tcc.inventorycommon.domain.User;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class GermplasmTO {

    private Long germplasmId;
    private String lineType;
    private String lineFunction;
    private String origin;
    private String lineCode;
    private String pedigreeName;
    private String oldPedigree;
    private String eventDisplay;
    private String constructDisplay;
    private String transformationGenotype;
    private String regulatoryNameDisplay;
    private Date creationDate;
    private String restriction;
    private String cytoplasmDonor;
    private Double holdensRefIndex;
    private String remRefNumber;
    private InbredGermplasmTO inbredGermplasm;
    private List<GermplasmEventConstructTO> germplasmEventConstructs = new ArrayList<GermplasmEventConstructTO>();
    private String crossName;
    private User crossContactUser;
    private Long brProgId;
    private String brProgRefId;
    private ProgramTO crossOwnerProgram;

    public GermplasmTO() {
    }

    public Long getGermplasmId() {
        return germplasmId;
    }

    public void setGermplasmId(Long germplasmId) {
        this.germplasmId = germplasmId;
    }

    public String getLineType() {
        return lineType;
    }

    public void setLineType(String lineType) {
        this.lineType = lineType;
    }

    public String getLineFunction() {
        return lineFunction;
    }

    public void setLineFunction(String lineFunction) {
        this.lineFunction = lineFunction;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getPedigreeName() {
        return pedigreeName;
    }

    public void setPedigreeName(String pedigreeName) {
        this.pedigreeName = pedigreeName;
    }

    public String getOldPedigree() {
        return oldPedigree;
    }

    public void setOldPedigree(String oldPedigree) {
        this.oldPedigree = oldPedigree;
    }

    public String getConstructDisplay() {
        return constructDisplay;
    }

    public void setConstructDisplay(String constructDisplay) {
        this.constructDisplay = constructDisplay;
    }

    public String getTransformationGenotype() {
        return transformationGenotype;
    }

    public void setTransformationGenotype(String transformationGenotype) {
        this.transformationGenotype = transformationGenotype;
    }

    public String getRegulatoryNameDisplay() {
        return regulatoryNameDisplay;
    }

    public void setRegulatoryNameDisplay(String regulatoryNameDisplay) {
        this.regulatoryNameDisplay = regulatoryNameDisplay;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getRestriction() {
        return restriction;
    }

    public void setRestriction(String restriction) {
        this.restriction = restriction;
    }

    public String getCytoplasmDonor() {
        return cytoplasmDonor;
    }

    public void setCytoplasmDonor(String cytoplasmDonor) {
        this.cytoplasmDonor = cytoplasmDonor;
    }

    public Double getHoldensRefIndex() {
        return holdensRefIndex;
    }

    public void setHoldensRefIndex(Double holdensRefIndex) {
        this.holdensRefIndex = holdensRefIndex;
    }

    public String getRemRefNumber() {
        return remRefNumber;
    }

    public void setRemRefNumber(String remRefNumber) {
        this.remRefNumber = remRefNumber;
    }

    public String getEventDisplay() {
        return eventDisplay;
    }

    public void setEventDisplay(String eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    public InbredGermplasmTO getInbredGermplasm() {
        return inbredGermplasm;
    }

    public void setInbredGermplasm(InbredGermplasmTO inbredGermplasm) {
        this.inbredGermplasm = inbredGermplasm;
    }

    public List<GermplasmEventConstructTO> getGermplasmEventConstructs() {
        return germplasmEventConstructs;
    }

    public void setGermplasmEventConstructs(List<GermplasmEventConstructTO> germplasmEventConstructs) {
        this.germplasmEventConstructs = germplasmEventConstructs;
    }

    public String getCrossName() {
        return crossName;
    }

    public void setCrossName(String crossName) {
        this.crossName = crossName;
    }

    public User getCrossContactUser() {
        return crossContactUser;
    }

    public void setCrossContactUser(User crossContactUser) {
        this.crossContactUser = crossContactUser;
    }

    public ProgramTO getCrossOwnerProgram() {
        return crossOwnerProgram;
    }

    public void setCrossOwnerProgram(ProgramTO crossOwnerProgram) {
        this.crossOwnerProgram = crossOwnerProgram;
    }

    public Long getBrProgId() {
        return brProgId;
    }

    public void setBrProgId(Long brProgId) {
        this.brProgId = brProgId;
    }

    public String getBrProgRefId() {
        return brProgRefId;
    }

    public void setBrProgRefId(String brProgRefId) {
        this.brProgRefId = brProgRefId;
    }
}
