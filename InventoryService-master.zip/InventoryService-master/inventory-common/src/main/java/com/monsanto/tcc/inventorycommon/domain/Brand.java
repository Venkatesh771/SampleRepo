package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 15, 2009
 * Time: 10:13:40 AM
 */
public class Brand {
    private Long brandId;
    private String name;
    private String refActive;
    private Company company;

    public Long getBrandId() {
        return brandId;
    }

    public void setBrandId(Long brandId) {
        this.brandId = brandId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }
}
