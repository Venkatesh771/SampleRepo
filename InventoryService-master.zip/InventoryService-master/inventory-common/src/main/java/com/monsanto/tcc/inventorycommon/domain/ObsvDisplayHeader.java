package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: RRPATN
 * Date: Mar 24, 2010
 * Time: 10:05:09 AM
 * To change this template use File | Settings | File Templates.
 */
public class ObsvDisplayHeader {
    private Long obsvDisplayHeaderId;
    private ObsvDisplay obsvDisplay;
    private ObsvAttribute obsvAttribute;
    private Long displayOrder;

    public ObsvDisplayHeader() {
    }

    public Long getObsvDisplayHeaderId() {
        return obsvDisplayHeaderId;
    }

    public void setObsvDisplayHeaderId(Long obsvDisplayHeaderId) {
        this.obsvDisplayHeaderId = obsvDisplayHeaderId;
    }

    public ObsvDisplay getObsvDisplay() {
        return obsvDisplay;
    }

    public void setObsvDisplay(ObsvDisplay obsvDisplay) {
        this.obsvDisplay = obsvDisplay;
    }

    public ObsvAttribute getObsvAttribute() {
        return obsvAttribute;
    }

    public void setObsvAttribute(ObsvAttribute obsvAttribute) {
        this.obsvAttribute = obsvAttribute;
    }

    public Long getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(Long displayOrder) {
        this.displayOrder = displayOrder;
    }
}
