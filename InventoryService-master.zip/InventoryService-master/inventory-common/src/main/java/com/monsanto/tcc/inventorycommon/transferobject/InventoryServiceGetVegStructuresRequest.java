package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.services.domain.common.CompositeObject;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: vvalav
 * Date: May 4, 2009
 * Time: 3:39:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class InventoryServiceGetVegStructuresRequest {
    private Filter[] filter;

    public InventoryServiceGetVegStructuresRequest() {

    }

    public Filter[] getFilter() {
        return filter;
    }

    public List<Filter> getListOfFilters() {
        List filterList = new ArrayList();
        for(int i=0;i<filter.length;i++) {
            filterList.add(filter[i]);
        }
        return filterList;
    }

    public void setFilter(Filter[] filter) {
        this.filter = filter;
    }

     public CompositeObject getCompositeObject() {
        CompositeObject compositeObject = new CompositeObject();
        compositeObject.addAll(getListOfFilters());
        return compositeObject;
    }
}
