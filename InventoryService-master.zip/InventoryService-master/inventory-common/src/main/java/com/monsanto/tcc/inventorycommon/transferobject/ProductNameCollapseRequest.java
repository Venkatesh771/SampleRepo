package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: May 13, 2010
 * Time: 3:53:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductNameCollapseRequest {
    private String newProductNamePubKey;
    private String oldProductNamePubKey;
    private boolean techDevRestricted;
    private ProductNameCollapseType collapseType;

    public ProductNameCollapseRequest() {
    }

    public ProductNameCollapseRequest(String newProductNamePubKey, String oldProductNamePubKey, boolean techDevRestricted, ProductNameCollapseType collapseType) {
        this.newProductNamePubKey = newProductNamePubKey;
        this.oldProductNamePubKey = oldProductNamePubKey;
        this.techDevRestricted = techDevRestricted;
        this.collapseType = collapseType;
    }

    public String getNewProductNamePubKey() {
        return newProductNamePubKey;
    }

    public void setNewProductNamePubKey(String newProductNamePubKey) {
        this.newProductNamePubKey = newProductNamePubKey;
    }

    public String getOldProductNamePubKey() {
        return oldProductNamePubKey;
    }

    public void setOldProductNamePubKey(String oldProductNamePubKey) {
        this.oldProductNamePubKey = oldProductNamePubKey;
    }

    public boolean isTechDevRestricted() {
        return techDevRestricted;
    }

    public void setTechDevRestricted(boolean techDevRestricted) {
        this.techDevRestricted = techDevRestricted;
    }

    public ProductNameCollapseType getCollapseType() {
        return collapseType;
    }

    public void setCollapseType(ProductNameCollapseType collapseType) {
        this.collapseType = collapseType;
    }
}
