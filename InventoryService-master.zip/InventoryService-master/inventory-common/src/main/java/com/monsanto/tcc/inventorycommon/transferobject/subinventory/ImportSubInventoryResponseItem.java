package com.monsanto.tcc.inventorycommon.transferobject.subinventory;

import com.monsanto.tcc.inventorycommon.transferobject.ResponseMessage;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.InventoryTO;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Sep 7, 2010
 * Time: 8:17:26 AM
 * To change this template use File | Settings | File Templates.
 */
public class ImportSubInventoryResponseItem {
    private String inventoryBarcode;
    private Collection<ResponseMessage> validationMessages;
    private InventoryTO inventory;


    public String getInventoryBarcode() {
        return inventoryBarcode;
    }

    public void setInventoryBarcode(String inventoryBarcode) {
        this.inventoryBarcode = inventoryBarcode;
    }

    public Collection<ResponseMessage> getValidationMessages() {
        return validationMessages;
    }

    public void setValidationMessages(Collection<ResponseMessage> validationMessages) {
        this.validationMessages = validationMessages;
    }

    public InventoryTO getInventory() {
        return inventory;
    }

    public void setInventory(InventoryTO inventory) {
        this.inventory = inventory;
    }
}
