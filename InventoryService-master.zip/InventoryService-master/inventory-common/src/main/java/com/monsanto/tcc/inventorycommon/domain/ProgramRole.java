/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.breeding.Program;

public class ProgramRole {
    private Long id;
    private Program program;
    private MidasRole midasRole;
    private boolean active;

    public ProgramRole() {

    }

    public ProgramRole(Long id, Program program, MidasRole midasRole, boolean active) {
        this.id = id;
        this.program = program;
        this.midasRole = midasRole;
        this.active = active;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Program getProgram() {
        return program;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public MidasRole getMidasRole() {
        return midasRole;
    }

    public void setMidasRole(MidasRole midasRole) {
        this.midasRole = midasRole;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}