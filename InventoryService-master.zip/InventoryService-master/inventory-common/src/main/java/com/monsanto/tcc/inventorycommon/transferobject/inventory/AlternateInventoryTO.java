package com.monsanto.tcc.inventorycommon.transferobject.inventory;

/**
 * Created by IntelliJ IDEA.
 * User: vkdasy
 * Date: Sep 2, 2010
 * Time: 12:52:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class AlternateInventoryTO {
    private Long materialRequestDetailSrcPrefOrderId;
    private InventoryTO inventoryTO;
    private Long prefOrder;
    private Long materialRequestDetailId;

    public Long getMaterialRequestDetailSrcPrefOrderId() {
        return materialRequestDetailSrcPrefOrderId;
    }

    public void setMaterialRequestDetailSrcPrefOrderId(Long materialRequestDetailSrcPrefOrderId) {
        this.materialRequestDetailSrcPrefOrderId = materialRequestDetailSrcPrefOrderId;
    }

    public InventoryTO getInventoryTO() {
        return inventoryTO;
    }

    public void setInventoryTO(InventoryTO inventoryTO) {
        this.inventoryTO = inventoryTO;
    }

    public Long getPrefOrder() {
        return prefOrder;
    }

    public void setPrefOrder(Long prefOrder) {
        this.prefOrder = prefOrder;
    }

    public Long getMaterialRequestDetailId() {
        return materialRequestDetailId;
    }

    public void setMaterialRequestDetailId(Long materialRequestDetailId) {
        this.materialRequestDetailId = materialRequestDetailId;
    }
}
