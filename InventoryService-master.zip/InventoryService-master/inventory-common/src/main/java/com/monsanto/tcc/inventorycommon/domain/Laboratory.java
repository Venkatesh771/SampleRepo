package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: mdspark
 * Date: Sep 23, 2009
 * Time: 11:11:32 AM
 * To change this template use File | Settings | File Templates.
 */
public class Laboratory {
    private Long laboratoryId;
    private String name;
    private String laboratoryRefId;
    private String refActive;

    public Long getLaboratoryId() {
        return laboratoryId;
    }

    public void setLaboratoryId(Long laboratoryId) {
        this.laboratoryId = laboratoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLaboratoryRefId() {
        return laboratoryRefId;
    }

    public void setLaboratoryRefId(String laboratoryRefId) {
        this.laboratoryRefId = laboratoryRefId;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }
}
