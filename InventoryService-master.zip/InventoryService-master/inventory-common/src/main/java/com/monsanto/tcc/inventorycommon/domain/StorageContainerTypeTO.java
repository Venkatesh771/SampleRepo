package com.monsanto.tcc.inventorycommon.domain;

import java.util.Date;


/**
 * Created by IntelliJ IDEA. User: SSNALL Date: Mar 3, 2010 Time: 11:01:35 AM To change this template use File | Settings | File Templates.
 */
public class StorageContainerTypeTO {
    private Long storageContainerTypeId;
    private String name;
    private String description;
    private Date inactiveDttm;

    public Long getStorageContainerTypeId() {
        return storageContainerTypeId;
    }

    public void setStorageContainerTypeId(Long storageContainerTypeId) {
        this.storageContainerTypeId = storageContainerTypeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        StorageContainerTypeTO that = (StorageContainerTypeTO) o;

        if (name != null ? !name.equals(that.name) : that.name != null) {
            return false;
        }
        if (storageContainerTypeId != null ? !storageContainerTypeId.equals(that.storageContainerTypeId) : that.storageContainerTypeId != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = storageContainerTypeId != null ? storageContainerTypeId.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }
}

