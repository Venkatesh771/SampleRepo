package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.breeding.Program;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 18, 2009
 * Time: 9:55:37 AM
 */
public class CropProgPref {
    private Long cropProgPrefId;
    private Long cropId;
    private Program program;
    private Long cropProgramPrefTypeId;
    private Date inactiveDttm;

    public Long getCropProgPrefId() {
        return cropProgPrefId;
    }

    public void setCropProgPrefId(Long cropProgPrefId) {
        this.cropProgPrefId = cropProgPrefId;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public Program getProgram() {
        return program;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public Long getCropProgramPrefTypeId() {
        return cropProgramPrefTypeId;
    }

    public void setCropProgramPrefTypeId(Long cropProgramPrefTypeId) {
        this.cropProgramPrefTypeId = cropProgramPrefTypeId;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }
}
