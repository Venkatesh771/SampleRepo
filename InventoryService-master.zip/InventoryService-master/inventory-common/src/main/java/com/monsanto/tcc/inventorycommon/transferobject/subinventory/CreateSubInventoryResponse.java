package com.monsanto.tcc.inventorycommon.transferobject.subinventory;

import com.monsanto.services.domain.breeding.Program;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: May 25, 2010
 * Time: 2:31:59 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateSubInventoryResponse {
    private List<String> subInventoryBarcodes = new ArrayList<String>();
    private List<Program> subInventoryOwners = new ArrayList<Program>();

    public CreateSubInventoryResponse() {
    }

    public CreateSubInventoryResponse(List<String> subInventoryBarcodes) {
        this.subInventoryBarcodes = subInventoryBarcodes;
    }

    public CreateSubInventoryResponse(List<String> subInventoryBarcodes, List<Program> subInventoryOwners) {
        this.subInventoryBarcodes = subInventoryBarcodes;
        this.subInventoryOwners = subInventoryOwners;
    }

    public List<String> getSubInventoryBarcodes() {
        return subInventoryBarcodes;
    }

    public void setSubInventoryBarcodes(List<String> subInventoryBarcodes) {
        this.subInventoryBarcodes = subInventoryBarcodes;
    }

    public List<Program> getSubInventoryOwners() {
        return subInventoryOwners;
    }

    public void setSubInventoryOwners(List<Program> subInventoryOwners) {
        this.subInventoryOwners = subInventoryOwners;
    }
}
