package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: SSSING5
 * Date: Aug 21, 2009
 * Time: 5:17:08 PM
 */
public class MaterialRequestHistoryResponse {
    private Collection<MaterialRequestHistoryDTO> requestHistory = new ArrayList<MaterialRequestHistoryDTO>();

    public MaterialRequestHistoryResponse() {
    }

    public MaterialRequestHistoryResponse(Collection<MaterialRequestHistoryDTO> requestHistory) {
        this.requestHistory = requestHistory;
    }

    public Collection<MaterialRequestHistoryDTO> getRequestHistory() {
        return requestHistory;
    }

    public void setRequestHistory(Collection<MaterialRequestHistoryDTO> requestHistory) {
        this.requestHistory = requestHistory;
    }
}
