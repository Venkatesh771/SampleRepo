/*
 Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

public class CommercialLinkageRequest {
    String productNamePublicKey;
    Boolean tdRestricted;

    public String getProductNamePublicKey() {
        return productNamePublicKey;
    }

    public void setProductNamePublicKey(String productNamePublicKey) {
        this.productNamePublicKey = productNamePublicKey;
    }

    public Boolean isTdRestricted() {
        return tdRestricted;
    }

    public void setTdRestricted(Boolean tdRestricted) {
        this.tdRestricted = tdRestricted;
    }
}