package com.monsanto.tcc.inventorycommon.domain;

import java.util.Date;


/**
 * Created by IntelliJ IDEA. User: SSNALL Date: Mar 3, 2010 Time: 10:40:41 AM
 */
public class SiteTO {
    private String name;
    private Long siteId;
    private String description;
    private Long addressId;
    private Date inactiveDttm;

    public Long getSiteId() {
        return siteId;
    }

    public void setSiteId(Long siteId) {
        this.siteId = siteId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getAddressId() {
        return addressId;
    }

    public void setAddressId(Long addressId) {
        this.addressId = addressId;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || !(o instanceof SiteTO)) {
            return false;
        }

        SiteTO siteTO = (SiteTO) o;

        if (getAddressId() != null ? !getAddressId().equals(siteTO.getAddressId()) : siteTO.getAddressId() != null) {
            return false;
        }
        if (getDescription() != null ? !getDescription().equals(siteTO.getDescription()) : siteTO.getDescription() != null) {
            return false;
        }
        if (getInactiveDttm() != null ? !getInactiveDttm().equals(siteTO.getInactiveDttm()) : siteTO.getInactiveDttm() != null) {
            return false;
        }
        if (getName() != null ? !getName().equals(siteTO.getName()) : siteTO.getName() != null) {
            return false;
        }
        if (getSiteId() != null ? !getSiteId().equals(siteTO.getSiteId()) : siteTO.getSiteId() != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = siteId != null ? siteId.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (addressId != null ? addressId.hashCode() : 0);
        result = 31 * result + (inactiveDttm != null ? inactiveDttm.hashCode() : 0);
        return result;
    }

}
