package com.monsanto.tcc.inventorycommon.transferobject.serviceinterfaceobject;

import java.util.List;

public class DestroyInventoryRequest {

    private List<DestroyInventoryRequestItem> lineItems;

    public List<DestroyInventoryRequestItem> getLineItems() {
        return lineItems;
    }

    public void setLineItems(List<DestroyInventoryRequestItem> lineItems) {
        this.lineItems = lineItems;
    }
}
