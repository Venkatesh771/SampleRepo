package com.monsanto.tcc.inventorycommon.service;

import com.monsanto.services.domain.breeding.PlantingWeek;
import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.tcc.inventorycommon.transferobject.SubmitToNewCycleReferenceData;
import com.monsanto.tcc.inventorycommon.transferobject.SubmitToNewCycleTestSetInfo;

import javax.jws.WebService;
import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Jul 15, 2009
 * Time: 12:55:28 PM
 */
@WebService
public interface SubmitInventoryToNewCycleService {
    public SubmitToNewCycleReferenceData getReferenceData(Long programId, String role) throws Exception;

    public Collection<PlantingWeek> getPlantingWeeks(Long programId, Long seasonId) throws Exception;

    public List<SubmitToNewCycleTestSetInfo> searchTestSet(List<Filter> filters) throws Exception;

    public List<SubmitToNewCycleTestSetInfo> searchTestSetNoFieldPlantings(List<Filter> filters) throws Exception;
}
