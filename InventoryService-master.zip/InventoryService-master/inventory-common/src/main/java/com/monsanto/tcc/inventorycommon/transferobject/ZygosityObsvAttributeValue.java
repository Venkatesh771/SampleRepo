package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by IntelliJ IDEA.
 * User: RRPATN
 * Date: Mar 25, 2010
 * Time: 9:48:30 AM
 */
public class ZygosityObsvAttributeValue {
    private String obsvAttributeName;
    private String obsvAttributeValue;
    private Long observationAttributeValueId;
    private Long observationAttributeId;
    private Long uomId;
    private Long observationAttributeValueListId;
    private Double numValue;
    private String strValue;
    private int attributeListOrder;

    public ZygosityObsvAttributeValue() {
    }

    public ZygosityObsvAttributeValue(String obsvAttributeName, String obsvAttributeValue, int attributeListOrder) {
        this.obsvAttributeName = obsvAttributeName;
        this.obsvAttributeValue = obsvAttributeValue;
        this.attributeListOrder = attributeListOrder;
    }

    public String getObsvAttributeName() {
        return obsvAttributeName;
    }

    public void setObsvAttributeName(String obsvAttributeName) {
        this.obsvAttributeName = obsvAttributeName;
    }

    public String getObsvAttributeValue() {
        return obsvAttributeValue;
    }

    public void setObsvAttributeValue(String obsvAttributeValue) {
        this.obsvAttributeValue = obsvAttributeValue;
    }

    public int getAttributeListOrder() {
        return attributeListOrder;
    }

    public void setAttributeListOrder(int attributeListOrder) {
        this.attributeListOrder = attributeListOrder;
    }

    public Double getNumValue() {
        return numValue;
    }

    public void setNumValue(Double numValue) {
        this.numValue = numValue;
    }

    public String getStrValue() {
        return strValue;
    }

    public void setStrValue(String strValue) {
        this.strValue = strValue;
    }

    public Long getObservationAttributeValueId() {
        return observationAttributeValueId;
    }

    public void setObservationAttributeValueId(Long observationAttributeValueId) {
        this.observationAttributeValueId = observationAttributeValueId;
    }

    public Long getObservationAttributeId() {
        return observationAttributeId;
    }

    public void setObservationAttributeId(Long observationAttributeId) {
        this.observationAttributeId = observationAttributeId;
    }

    public Long getUomId() {
        return uomId;
    }

    public void setUomId(Long uomId) {
        this.uomId = uomId;
    }

    public Long getObservationAttributeValueListId() {
        return observationAttributeValueListId;
    }

    public void setObservationAttributeValueListId(Long observationAttributeValueListId) {
        this.observationAttributeValueListId = observationAttributeValueListId;
    }
}
