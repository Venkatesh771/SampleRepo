package com.monsanto.tcc.inventorycommon.service;

import com.monsanto.tcc.inventorycommon.transferobject.serviceinterfaceobject.CreateInventoryContainerRequest;

import javax.jws.WebService;
import java.util.Collection;

@WebService
public interface CreateInventoryContainerService {

    void create(Collection<CreateInventoryContainerRequest> requests) throws Exception;

    long createAndCopyTreatments(long inventoryId, long targetStorageContainerId, long sourceInventoryContainerId) throws Exception;

    long createInPendingStorageContainer(long inventoryId) throws Exception;

    long createInPendingStorageContainerAndCopyTreatments(long inventoryId, long sourceInventoryContainerId) throws Exception;
}