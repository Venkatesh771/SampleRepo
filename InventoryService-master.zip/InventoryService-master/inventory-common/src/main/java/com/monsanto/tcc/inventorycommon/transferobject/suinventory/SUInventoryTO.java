/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.suinventory;

import com.monsanto.services.domain.breeding.FateReason;

import java.util.Date;

public class SUInventoryTO {

    private java.lang.Long id;
    private SUGeneticMaterialTO geneticMaterial;
    private SUProgramTO program;
    private String fateReasonName;
    private String inventoryType;
    private SUStorageUnitTO storageUnit;
    private String quantityUom;
    private String cropName;
    private String asort1;
    private String asort2;
    private String asort3;
    private String asort4;
    private String asort5;
    private Double nsort1;
    private Double nsort2;
    private Double nsort3;
    private String barcode; //aka inv_bid
    private Boolean archivedMaterial;
    private Date fateReasonDate;
    private String goiTxt;
    private String inventoryComments;
    private Double quantity;
    private String seedTreatment;
    private String storageContainerBarcode;
    private String storageContainerName;
    private String storageContainerLocation;
    private String currentLocation;
    private String modifiedUserName;
    private Date modifiedDate;
    private FateReason fateReason;
    private String parentInventoryBID;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public SUGeneticMaterialTO getGeneticMaterial() {
        return geneticMaterial;
    }

    public void setGeneticMaterial(SUGeneticMaterialTO geneticMaterial) {
        this.geneticMaterial = geneticMaterial;
    }

    public SUProgramTO getProgram() {
        return program;
    }

    public void setProgram(SUProgramTO program) {
        this.program = program;
    }

    public String getFateReasonName() {
        return this.fateReasonName;
    }

    public void setFateReasonName(String fateReasonName) {
        this.fateReasonName = fateReasonName;
    }

    public String getInventoryType() {
        return this.inventoryType;
    }

    public void setInventoryType(String inventoryType) {
        this.inventoryType = inventoryType;
    }

    public SUStorageUnitTO getStorageUnit() {
        return storageUnit;
    }

    public String getQuantityUom() {
        return quantityUom;
    }

    public void setQuantityUom(String quantityUom) {
        this.quantityUom = quantityUom;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public void setStorageUnit(SUStorageUnitTO storageUnit) {
        this.storageUnit = storageUnit;
    }

    public Double getNsort1() {
        return nsort1;
    }

    public void setNsort1(Double nsort1) {
        this.nsort1 = nsort1;
    }

    public Double getNsort2() {
        return nsort2;
    }

    public void setNsort2(Double nsort2) {
        this.nsort2 = nsort2;
    }

    public Double getNsort3() {
        return nsort3;
    }

    public void setNsort3(Double nsort3) {
        this.nsort3 = nsort3;
    }

    public String getAsort1() {
        return asort1;
    }

    public void setAsort1(String asort1) {
        this.asort1 = asort1;
    }

    public String getAsort2() {
        return asort2;
    }

    public void setAsort2(String asort2) {
        this.asort2 = asort2;
    }

    public String getAsort3() {
        return asort3;
    }

    public void setAsort3(String asort3) {
        this.asort3 = asort3;
    }

    public String getAsort4() {
        return asort4;
    }

    public void setAsort4(String asort4) {
        this.asort4 = asort4;
    }

    public String getAsort5() {
        return asort5;
    }

    public void setAsort5(String asort5) {
        this.asort5 = asort5;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Boolean isArchivedMaterial() {
        return archivedMaterial;
    }

    public void setArchivedMaterial(Boolean archivedMaterial) {
        this.archivedMaterial = archivedMaterial;
    }

    public Date getFateReasonDate() {
        return fateReasonDate;
    }

    public void setFateReasonDate(Date fateReasonDate) {
        this.fateReasonDate = fateReasonDate;
    }

    public String getGoiTxt() {
        return goiTxt;
    }

    public void setGoiTxt(String goiTxt) {
        this.goiTxt = goiTxt;
    }

    public String getInventoryComments() {
        return inventoryComments;
    }

    public void setInventoryComments(String invComments) {
        this.inventoryComments = invComments;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public String getSeedTreatment() {
        return seedTreatment;
    }

    public void setSeedTreatment(String seedTreatment) {
        this.seedTreatment = seedTreatment;
    }

    public String getStorageContainerBarcode() {
        return storageContainerBarcode;
    }

    public void setStorageContainerBarcode(String storageContainerBarcode) {
        this.storageContainerBarcode = storageContainerBarcode;
    }

    public String getStorageContainerName() {
        return storageContainerName;
    }

    public void setStorageContainerName(String storageContainerName) {
        this.storageContainerName = storageContainerName;
    }

    public String getStorageContainerLocation() {
        return storageContainerLocation;
    }

    public void setStorageContainerLocation(String storageContainerLocation) {
        this.storageContainerLocation = storageContainerLocation;
    }

    public String getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(String currentLocation) {
        this.currentLocation = currentLocation;
    }

    public FateReason getFateReason() {
        return fateReason;
    }

    public void setFateReason(FateReason fateReason) {
        this.fateReason = fateReason;
    }

    public String getModifiedUserName() {
        return modifiedUserName;
    }

    public void setModifiedUserName(String modifiedUserName) {
        this.modifiedUserName = modifiedUserName;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getParentInventoryBID() {
        return parentInventoryBID;
    }

    public void setParentInventoryBID(String parentInventoryBID) {
        this.parentInventoryBID = parentInventoryBID;
    }
}