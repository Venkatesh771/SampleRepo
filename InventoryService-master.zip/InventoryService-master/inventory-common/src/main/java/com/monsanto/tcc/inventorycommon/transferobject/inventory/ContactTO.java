package com.monsanto.tcc.inventorycommon.transferobject.inventory;

import org.apache.commons.lang.StringUtils;

import static org.springframework.util.StringUtils.hasText;

public class ContactTO {
    private String contactID;
    private String firstName;
    private String middleName;
    private String lastName;
    private String companyName;
    private AddressTO address;
    private String phone;
    private String cell;
    private String fax;
    private String pager;
    private String jobTitle;
    private String email;
    private String[] contactTypes;
    private Long businessAccountID;
    private Long programID;

    public String getContactID() {
        return contactID;
    }

    public void setContactID(String contactID) {
        this.contactID = contactID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public AddressTO getAddress() {
        return address;
    }

    public void setAddress(AddressTO address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCell() {
        return cell;
    }

    public void setCell(String cell) {
        this.cell = cell;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getPager() {
        return pager;
    }

    public void setPager(String pager) {
        this.pager = pager;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String[] getContactTypes() {
        return contactTypes;
    }

    public void setContactTypes(String[] contactTypes) {
        this.contactTypes = contactTypes;
    }

    public Long getBusinessAccountID() {
        return businessAccountID;
    }

    public void setBusinessAccountID(Long businessAccountID) {
        this.businessAccountID = businessAccountID;
    }

    public Long getProgramID() {
        return programID;
    }

    public void setProgramID(Long programID) {
        this.programID = programID;
    }

    @Override
    public String toString() {
        if (middleName != null && hasText(middleName)) {
            return StringUtils.defaultString(firstName) + " " +
                    StringUtils.defaultString(middleName) + " " +
                    StringUtils.defaultString(lastName);
        }
        return StringUtils.defaultString(firstName) + " " +
                StringUtils.defaultString(lastName);
    }
}
