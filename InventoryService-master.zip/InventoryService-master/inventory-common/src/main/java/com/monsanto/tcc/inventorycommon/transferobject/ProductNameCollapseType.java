package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: May 13, 2010
 * Time: 2:47:31 PM
 * To change this template use File | Settings | File Templates.
 */
public enum ProductNameCollapseType {

    /**
     * |-> GM1-> I1-> DIPN1-> PN1-> P1->|
     * |-> GM2-> I2-> DIPN2-> PN2-> P2->|
     */

    /**
     *
     */
    COMPLETE_CLEAN_COLLAPSE,

    /**
     * Wrong Product name is logically deleted(ref_active='F') and Correct Product is made
     * to point to Two germplasms. In this case the Display Inventory Product Name of
     * the inventory pointing to the old product name is updated to point to the new
     * product name. No Changes are made to the Inventory -> Genetic Material relations.
     * Dirty because: the two products are retained after the collapse for the same product name.
     * Complete because:
     */
    COMPLETE_DIRTY_COLLAPSE,

    /**
     * Product Name pointing to the wrong product is made to point to the right product.
     * Need to point the Inventory that belongs to the wrong product to point to the Genetic Material
     * of the Product to which the product name is made to point.
     */
    PARTIAL_CLEAN_COLLAPSE,

    /**
     * Wrong Product name and Product are deleted. Lexicon repoints the product name to the correct product. Inventory
     * Service is supposed to repoint the inventory currently pointing to the worong Products GM to the correct
     * products Genetic Material. In case more than one Genetic Materials exist then the first mirage only
     * Genetic Material is used.
     */
    PARTIAL_DIRTY_COLLAPSE

    }
