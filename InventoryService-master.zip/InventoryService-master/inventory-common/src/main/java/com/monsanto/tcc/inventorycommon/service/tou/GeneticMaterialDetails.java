package com.monsanto.tcc.inventorycommon.service.tou;

/**
 * User: DCENGL
 */
public class GeneticMaterialDetails {

    private Long geneticMaterialId;
    private String source;
    private String pedigree;

    public Long getGeneticMaterialId() {
        return geneticMaterialId;
    }

    public void setGeneticMaterialId(Long geneticMaterialId) {
        this.geneticMaterialId = geneticMaterialId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getPedigree() {
        return pedigree;
    }

    public void setPedigree(String pedigree) {
        this.pedigree = pedigree;
    }
}
