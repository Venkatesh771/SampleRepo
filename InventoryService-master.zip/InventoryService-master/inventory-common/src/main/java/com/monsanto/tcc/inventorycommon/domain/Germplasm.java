package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.breeding.Program;

import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import java.lang.String;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 15, 2009
 * Time: 12:34:01 PM
 */
@XmlType(name = "Inventory_Germplasm")
public class Germplasm {

    private Long germplasmId;
    private Long brProgId;
    private String brProgRefId;
    private LineType lineType;
    private LineFunction lineFunction;
    private Long genusSpeciesId;
    private String origin;
    private String lineCode;
    private String pedigreeName;
    private String isTransgenic;
    private Long cropId;
    private String remRefNumber;
    private String eventDisplay;
    private Long virgoId;
    private String oldPedigree;
    private String marisDbOrTemplate;
    private Long marisPedIdOrTemplateId;
    private Double holdensRefIndex;
    private String constructDisplay;
    private String cytoplasmDonor;
    private char isDeleted;
    private String isFinishedOrFinishedChild;
    private Date codeYear;
    private String transformationGenotype;
    private String regulatoryNameDisplay;
    private Date creationDate;
    private String restriction;
    private String pollinationInstruction;
    private String crossName;
    private User crossContactUser ;
    private Program crossOwnerProgram;

    @XmlTransient
    private Set<ProductGermplasmXRef> productGermplasmXRefs = new HashSet<ProductGermplasmXRef>();

    @XmlTransient
    private Collection<GermplasmEventConstruct> germplasmEventConstructs = new HashSet<GermplasmEventConstruct>();

    @XmlTransient
    private InbredGermplasm inbredGermplasm;

    public Object getID() {
        return getGermplasmId();
    }

    public Long getGermplasmId() {
        return this.germplasmId;
    }

    public void setGermplasmId(Long germplasmId) {
        this.germplasmId = germplasmId;
    }

    public Long getBrProgId() {
        return brProgId;
    }

    public void setBrProgId(Long brProgId) {
        this.brProgId = brProgId;
    }

    public LineType getLineType() {
        return lineType;
    }

    public void setLineType(LineType lineType) {
        this.lineType = lineType;
    }

    public LineFunction getLineFunction() {
        return lineFunction;
    }

    public void setLineFunction(LineFunction lineFunction) {
        this.lineFunction = lineFunction;
    }

    public Long getGenusSpeciesId() {
        return genusSpeciesId;
    }

    public void setGenusSpeciesId(Long genusSpeciesId) {
        this.genusSpeciesId = genusSpeciesId;
    }

    public String getOrigin() {
        return this.origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getLineCode() {
        return this.lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getPedigreeName() {
        return this.pedigreeName;
    }

    public void setPedigreeName(String pedigreeName) {
        this.pedigreeName = pedigreeName;
    }

    public String getIsTransgenic() {
        return this.isTransgenic;
    }

    public void setIsTransgenic(String isTransgenic) {
        this.isTransgenic = isTransgenic;
    }

    public Long getCropId() {
        return this.cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public String getRemRefNumber() {
        return this.remRefNumber;
    }

    public void setRemRefNumber(String remRefNumber) {
        this.remRefNumber = remRefNumber;
    }

    public String getEventDisplay() {
        return this.eventDisplay;
    }

    public void setEventDisplay(String eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    public Long getVirgoId() {
        return this.virgoId;
    }

    public void setVirgoId(Long virgoId) {
        this.virgoId = virgoId;
    }

    public String getOldPedigree() {
        return this.oldPedigree;
    }

    public void setOldPedigree(String oldPedigree) {
        this.oldPedigree = oldPedigree;
    }

    public String getMarisDbOrTemplate() {
        return this.marisDbOrTemplate;
    }

    public void setMarisDbOrTemplate(String marisDbOrTemplate) {
        this.marisDbOrTemplate = marisDbOrTemplate;
    }

    public Long getMarisPedIdOrTemplateId() {
        return this.marisPedIdOrTemplateId;
    }

    public void setMarisPedIdOrTemplateId(Long marisPedIdOrTemplateId) {
        this.marisPedIdOrTemplateId = marisPedIdOrTemplateId;
    }

    public Double getHoldensRefIndex() {
        return this.holdensRefIndex;
    }

    public void setHoldensRefIndex(Double holdensRefIndex) {
        this.holdensRefIndex = holdensRefIndex;
    }

    public String getConstructDisplay() {
        return this.constructDisplay;
    }

    public void setConstructDisplay(String constructDisplay) {
        this.constructDisplay = constructDisplay;
    }

    public String getCytoplasmDonor() {
        return this.cytoplasmDonor;
    }

    public void setCytoplasmDonor(String cytoplasmDonor) {
        this.cytoplasmDonor = cytoplasmDonor;
    }

    public char getIsDeleted() {
        return this.isDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getIsFinishedOrFinishedChild() {
        return this.isFinishedOrFinishedChild;
    }

    public void setIsFinishedOrFinishedChild(String isFinishedOrFinishedChild) {
        this.isFinishedOrFinishedChild = isFinishedOrFinishedChild;
    }

    public Date getCodeYear() {
        return this.codeYear;
    }

    public void setCodeYear(Date codeYear) {
        this.codeYear = codeYear;
    }

    public String getTransformationGenotype() {
        return this.transformationGenotype;
    }

    public void setTransformationGenotype(String transformationGenotype) {
        this.transformationGenotype = transformationGenotype;
    }

    public String getRegulatoryNameDisplay() {
        return this.regulatoryNameDisplay;
    }

    public void setRegulatoryNameDisplay(String regulatoryNameDisplay) {
        this.regulatoryNameDisplay = regulatoryNameDisplay;
    }

    public Date getCreationDate() {
        return this.creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getRestriction() {
        return restriction;
    }

    public void setRestriction(String restriction) {
        this.restriction = restriction;
    }

    public String getPollinationInstruction() {
        return pollinationInstruction;
    }

    public void setPollinationInstruction(String pollinationInstruction) {
        this.pollinationInstruction = pollinationInstruction;
    }

    @XmlTransient
    public Collection<GermplasmEventConstruct> getGermplasmEventConstructs() {
        return germplasmEventConstructs;
    }

    public void setGermplasmEventConstructs(Collection<GermplasmEventConstruct> germplasmEventConstructs) {
        this.germplasmEventConstructs = germplasmEventConstructs;
    }

    @XmlTransient
    public Set<ProductGermplasmXRef> getProductGermplasmXRefs() {
        return productGermplasmXRefs;
    }

    public void setProductGermplasmXRefs(Set<ProductGermplasmXRef> productGermplasmXRefs) {
        this.productGermplasmXRefs = productGermplasmXRefs;
    }

    /** We're implementing this method to give us back the first item in the list,
     * which should be the only one in the list in most cases.
     * @return First Germplasm Product Cross-Reference record.
     */
    public ProductGermplasmXRef getFirstGermplasmXRef()  {
        if ((null != productGermplasmXRefs) && (0 != productGermplasmXRefs.size()))  {
            return productGermplasmXRefs.iterator().next();
        }
        return null;
    }

    @XmlTransient
    public InbredGermplasm getInbredGermplasm() {
        return inbredGermplasm;
    }

    public void setInbredGermplasm(InbredGermplasm inbredGermplasm) {
        this.inbredGermplasm = inbredGermplasm;
    }

    public String getCrossName() {
        return crossName;
    }

    public void setCrossName(String crossName) {
        this.crossName = crossName;
    }

    public User getCrossContactUser() {
        return crossContactUser;
    }

    public void setCrossContactUser(User crossContactUser) {
        this.crossContactUser = crossContactUser;
    }

    public Program getCrossOwnerProgram() {
        return crossOwnerProgram;
    }

    public void setCrossOwnerProgram(Program crossOwnerProgram) {
        this.crossOwnerProgram = crossOwnerProgram;
    }

    public String getBrProgRefId() {
        return brProgRefId;
    }

    public void setBrProgRefId(String brProgRefId) {
        this.brProgRefId = brProgRefId;
    }
}
