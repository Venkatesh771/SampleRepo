package com.monsanto.tcc.inventorycommon.domain;

public class TestedInventoryEntity {

    private Inventory inventory;
    private EventConstruct eventConstruct;
    private long id;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public EventConstruct getEventConstruct() {
        return eventConstruct;
    }

    public void setEventConstruct(EventConstruct eventConstruct) {
        this.eventConstruct = eventConstruct;
    }
}
