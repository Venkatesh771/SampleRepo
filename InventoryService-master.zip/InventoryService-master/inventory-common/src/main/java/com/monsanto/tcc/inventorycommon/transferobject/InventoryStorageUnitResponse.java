package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 28, 2010
 * Time: 6:45:25 AM
 * To change this template use File | Settings | File Templates.
 */
public class InventoryStorageUnitResponse {
    ResponseMessage responseMessage;

    public ResponseMessage getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(ResponseMessage responseMessage) {
        this.responseMessage = responseMessage;
    }
}
