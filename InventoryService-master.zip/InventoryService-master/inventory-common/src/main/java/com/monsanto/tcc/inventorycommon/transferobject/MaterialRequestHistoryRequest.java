package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.common.filter.Filter;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Jun 2, 2010
 * Time: 3:02:55 PM
 * To change this template use File | Settings | File Templates.
 */
public class MaterialRequestHistoryRequest {
    public static final String REQUESTED_DATE_FILTER_NAME = "requested_date";
    public static final String REQUEST_STATUS_FILTER_NAME = "request_status";
    public static final String REQuESTOR_PROG_ID_FILTER_NAME = "requestor_programId";

    private Collection<Filter> filters = new ArrayList<Filter>();

    public MaterialRequestHistoryRequest() {
    }

    public MaterialRequestHistoryRequest(Collection<Filter> filters) {
        this.filters = filters;
    }

    public Collection<Filter> getFilters() {
        return filters;
    }

    public void setFilters(Collection<Filter> filters) {
        this.filters = filters;
    }
}
