package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: MDSPARK
 * Date: Oct 14, 2009
 * Time: 4:13:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class PedFixAction {
    private Long pedFixActionId;
    private String name;
    private String refActive;
    private String pedFixActionRefId;

    public Long getPedFixActionId() {
        return pedFixActionId;
    }

    public void setPedFixActionId(Long pedFixActionId) {
        this.pedFixActionId = pedFixActionId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public String getPedFixActionRefId() {
        return pedFixActionRefId;
    }

    public void setPedFixActionRefId(String pedFixActionRefId) {
        this.pedFixActionRefId = pedFixActionRefId;
    }
}
