/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

public class InbredGermplasm {

    private Long inbredGermplasmId;
    private Germplasm germplasm;
    private Long inbredBaseId;
    private String inbredBaseName;
    private String baseSuffixTxt;

    public InbredGermplasm() {
    }

    public InbredGermplasm(Long inbredGermplasmId,
                           Long inbredBaseId,
                           Germplasm germplasm,
                           String inbredBaseName,
                           String baseSuffixTxt) {
        this.inbredGermplasmId = inbredGermplasmId;
        this.inbredBaseId = inbredBaseId;
        this.germplasm = germplasm;
        this.inbredBaseName = inbredBaseName;
        this.baseSuffixTxt = baseSuffixTxt;
    }

    public Long getInbredGermplasmId() {
        return inbredGermplasmId;
    }

    public void setInbredGermplasmId(Long inbredGermplasmId) {
        this.inbredGermplasmId = inbredGermplasmId;
    }

    public Long getInbredBaseId() {
        return inbredBaseId;
    }

    public void setInbredBaseId(Long inbredBaseId) {
        this.inbredBaseId = inbredBaseId;
    }

    public Germplasm getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(Germplasm germplasm) {
        this.germplasm = germplasm;
    }

    public String getInbredBaseName() {
        return inbredBaseName;
    }

    public void setInbredBaseName(String inbredBaseName) {
        this.inbredBaseName = inbredBaseName;
    }

    public String getBaseSuffixTxt() {
        return baseSuffixTxt;
    }

    public void setBaseSuffixTxt(String baseSuffixTxt) {
        this.baseSuffixTxt = baseSuffixTxt;
    }
}