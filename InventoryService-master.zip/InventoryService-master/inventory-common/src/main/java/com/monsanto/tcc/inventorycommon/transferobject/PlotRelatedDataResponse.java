/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.ArrayList;
import java.util.List;

public class PlotRelatedDataResponse {
    private List<PlotRelatedData> response;

    public List<PlotRelatedData> getResponse() {
        return response;
    }

    public void setResponse(List<PlotRelatedData> response) {
        this.response = response;
    }

    public PlotRelatedDataResponse() {
        response = new ArrayList<PlotRelatedData>();
    }
}