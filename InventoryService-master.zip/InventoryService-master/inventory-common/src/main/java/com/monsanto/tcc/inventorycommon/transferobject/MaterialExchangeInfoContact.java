/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.domain.MaterialExchangeInfo;

/* NBWALD - Feb 24, 2011 */
public class MaterialExchangeInfoContact {
    private MaterialExchangeInfo materialExchangeInfo;
    private Long contactId;


    public MaterialExchangeInfo getMaterialExchangeInfo() {
        return materialExchangeInfo;
    }

    public void setMaterialExchangeInfo(MaterialExchangeInfo materialExchangeInfo) {
        this.materialExchangeInfo = materialExchangeInfo;
    }

    public Long getContactId() {
        return contactId;
    }

    public void setContactId(Long contactId) {
        this.contactId = contactId;
    }
}