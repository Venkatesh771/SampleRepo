package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.common.AbstractEntity;

public class DefaultEntityRelation extends AbstractEntity {
    private Long entityId;
    private Long relationId;

    public DefaultEntityRelation() {
        this(null, null);
    }

    public DefaultEntityRelation(Long entityId, Long relationId) {
        this.entityId = entityId;
        this.relationId = relationId;
    }

    public Object getID() {
        return getRelationId() + "-" + getEntityId();
    }

    public Long getEntityId() {
        return entityId;
    }

    public void setEntityId(Long entityId) {
        this.entityId = entityId;
    }

    public Long getRelationId() {
        return relationId;
    }

    public void setRelationId(Long relationId) {
        this.relationId = relationId;
    }
}