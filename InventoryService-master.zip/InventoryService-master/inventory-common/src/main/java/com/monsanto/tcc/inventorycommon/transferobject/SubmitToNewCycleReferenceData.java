package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.breeding.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Jul 15, 2009
 * Time: 1:12:32 PM
 * To change this template use File | Settings | File Templates.
 */
public class SubmitToNewCycleReferenceData {
    private List<Protocol> protocols;
    private List<Pollination> pollinationMethods;
    private List<Location> locations;
    private List<Program> growers;
    private List<YTRegulated> regulations;
    private List<Season> seasons;
    private List<PlantingWeek> plantingWeeks;

    public SubmitToNewCycleReferenceData() {
        seasons = new ArrayList<Season>();
        protocols = new ArrayList<Protocol>();
        locations = new ArrayList<Location>();
        growers = new ArrayList<Program>();
        pollinationMethods = new ArrayList<Pollination>();
        regulations = new ArrayList<YTRegulated>();
        plantingWeeks = new ArrayList<PlantingWeek>();
    }

    public List<Season> getSeasons() {
        return seasons;
    }

    public void setSeasons(List<Season> seasons) {
        this.seasons = seasons;
    }

    public List<Protocol> getProtocols() {
        return protocols;
    }

    public void setProtocols(List<Protocol> protocols) {
        this.protocols = protocols;
    }

    public List<Location> getLocations() {
        return locations;
    }

    public void setLocations(List<Location> locations) {
        this.locations = locations;
    }

    public List<Program> getGrowers() {
        return growers;
    }

    public void setGrowers(List<Program> growers) {
        this.growers = growers;
    }

    public List<Pollination> getPollinationMethods() {
        return pollinationMethods;
    }

    public void setPollinationMethods(List<Pollination> pollinationMethods) {
        this.pollinationMethods = pollinationMethods;
    }

    public List<YTRegulated> getRegulations() {
        return regulations;
    }

    public void setRegulations(List<YTRegulated> regulations) {
        this.regulations = regulations;
    }

    public List<PlantingWeek> getPlantingWeeks() {
        return plantingWeeks;
    }

    public void setPlantingWeeks(List<PlantingWeek> plantingWeeks) {
        this.plantingWeeks = plantingWeeks;
    }
}
