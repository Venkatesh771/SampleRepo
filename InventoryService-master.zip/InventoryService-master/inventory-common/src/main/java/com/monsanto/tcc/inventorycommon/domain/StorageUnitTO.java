package com.monsanto.tcc.inventorycommon.domain;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 6, 2010
 * Time: 1:44:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class StorageUnitTO {
    private Long id;
    private String name;
    private String description;
    private StorageUnitTypeTO storageUnitType;
    private String barcode;
    private Long parentStorageUnitId;
    private Collection<StorageUnitTO> childStorageUnits;
    private StorageUnitTypeTO parentStorageUnitType;
    private Boolean containsChild;
    private Boolean hasInventory;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Long getParentStorageUnitId() {
        return parentStorageUnitId;
    }

    public void setParentStorageUnitId(Long parentStorageUnitId) {
        this.parentStorageUnitId = parentStorageUnitId;
    }

    public Collection<StorageUnitTO> getChildStorageUnits() {
        return childStorageUnits;
    }

    public void setChildStorageUnits(Collection<StorageUnitTO> childStorageUnits) {
        this.childStorageUnits = childStorageUnits;
    }

    public StorageUnitTypeTO getStorageUnitType() {
        return storageUnitType;
    }

    public void setStorageUnitType(StorageUnitTypeTO storageUnitType) {
        this.storageUnitType = storageUnitType;
    }

    public StorageUnitTypeTO getParentStorageUnitType() {
        return parentStorageUnitType;
    }

    public void setParentStorageUnitType(StorageUnitTypeTO parentStorageUnitType) {
        this.parentStorageUnitType = parentStorageUnitType;
    }

    public Boolean getContainsChild() {
        return containsChild;
    }

    public void setContainsChild(Boolean containsChild) {
        this.containsChild = containsChild;
    }

    public Boolean getHasInventory() {
        return hasInventory;
    }

    public void setHasInventory(Boolean hasInventory) {
        this.hasInventory = hasInventory;
    }
}


