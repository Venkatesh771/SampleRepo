package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.observation.ObservationClassification;

import java.util.Date;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: mdspark
 * Date: Sep 23, 2009
 * Time: 10:49:26 AM
 * To change this template use File | Settings | File Templates.
 */
public class Observation {
    private Long observationId;
    private ObservationClassification observationClassification;
    private Inventory inventory;
    private Plot plot;
    private Date insertGmtTimestamp;
    private String insertUser;
    private Date updateGmtTimestamp;
    private String updateUser;
    private String deactivate;
    private LaboratorySample laboratorySample;
    private String isDeleted;
    private Set<ObsvAttributeValue> obsvAttributeValues;

    public Long getObservationId() {
        return observationId;
    }

    public void setObservationId(Long observationId) {
        this.observationId = observationId;
    }

    public ObservationClassification getObservationClassification() {
        return observationClassification;
    }

    public void setObservationClassification(ObservationClassification observationClassification) {
        this.observationClassification = observationClassification;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public Plot getPlot() {
        return plot;
    }

    public void setPlot(Plot plot) {
        this.plot = plot;
    }

    public Date getInsertGmtTimestamp() {
        return insertGmtTimestamp;
    }

    public void setInsertGmtTimestamp(Date insertGmtTimestamp) {
        this.insertGmtTimestamp = insertGmtTimestamp;
    }

    public String getInsertUser() {
        return insertUser;
    }

    public void setInsertUser(String insertUser) {
        this.insertUser = insertUser;
    }

    public Date getUpdateGmtTimestamp() {
        return updateGmtTimestamp;
    }

    public void setUpdateGmtTimestamp(Date updateGmtTimestamp) {
        this.updateGmtTimestamp = updateGmtTimestamp;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public String getDeactivate() {
        return deactivate;
    }

    public void setDeactivate(String deactivate) {
        this.deactivate = deactivate;
    }

    public LaboratorySample getLaboratorySample() {
        return laboratorySample;
    }

    public void setLaboratorySample(LaboratorySample laboratorySample) {
        this.laboratorySample = laboratorySample;
    }

    public String getDeleted() {
        return isDeleted;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setDeleted(String deleted) {
        isDeleted = deleted;
    }

    public void setIsDeleted(String deleted) {
        isDeleted = deleted;
    }

    public Set<ObsvAttributeValue> getObsvAttributeValues() {
        return obsvAttributeValues;
    }

    public void setObsvAttributeValues(Set<ObsvAttributeValue> obsvAttributeValues) {
        this.obsvAttributeValues = obsvAttributeValues;
    }
}
