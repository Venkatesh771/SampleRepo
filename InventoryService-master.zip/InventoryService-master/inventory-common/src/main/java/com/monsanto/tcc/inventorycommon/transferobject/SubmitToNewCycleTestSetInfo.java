package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.breeding.*;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Jul 15, 2009
 * Time: 2:53:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class SubmitToNewCycleTestSetInfo {
    private TestSet testSet;
    private Season season;
    private Protocol protocol;
    private Location location;
    private Program grower;
    private Long noOfEntries;
    private YTRegulated ytRegulated;
    private Pollination pollination;
    private PlantingWeek plantingWeek;
    private Rep brRep;

    public SubmitToNewCycleTestSetInfo() {

    }

    public TestSet getTestSet() {
        return testSet;
    }

    public void setTestSet(TestSet testSet) {
        this.testSet = testSet;
    }

    public Season getSeason() {
        return season;
    }

    public void setSeason(Season season) {
        this.season = season;
    }

    public Protocol getProtocol() {
        return protocol;
    }

    public void setProtocol(Protocol protocol) {
        this.protocol = protocol;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Program getGrower() {
        return grower;
    }

    public void setGrower(Program grower) {
        this.grower = grower;
    }

    public Long getNoOfEntries() {
        return noOfEntries;
    }

    public void setNoOfEntries(Long noOfEntries) {
        this.noOfEntries = noOfEntries;
    }

    public YTRegulated getYtRegulated() {
        return ytRegulated;
    }

    public void setYtRegulated(YTRegulated ytRegulated) {
        this.ytRegulated = ytRegulated;
    }

    public Pollination getPollination() {
        return pollination;
    }

    public void setPollination(Pollination pollination) {
        this.pollination = pollination;
    }

    public PlantingWeek getPlantingWeek() {
        return plantingWeek;
    }

    public void setPlantingWeek(PlantingWeek plantingWeek) {
        this.plantingWeek = plantingWeek;
    }

    public Rep getBrRep() {
        return brRep;
    }

    public void setBrRep(Rep brRep) {
        this.brRep = brRep;
    }
}
