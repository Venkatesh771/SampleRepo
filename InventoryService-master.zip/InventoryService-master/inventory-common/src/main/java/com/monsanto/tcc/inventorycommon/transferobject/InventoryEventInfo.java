/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

public class InventoryEventInfo {

    private Long inventoryId;
    private String allEventNames;
    private String removedEventNames;
    private String toBeRemovedEventNames;
    private String allConstructNames;
    private String removedConstructNames;
    private String toBeRemovedConstructNames;

    public InventoryEventInfo() {
    }

    public InventoryEventInfo(Long inventoryId, String allEventNames, String removedEventNames,
                              String toBeRemovedEventNames,
                              String allConstructNames, String removedConstructNames,
                              String toBeRemovedConstructNames) {
        this.inventoryId = inventoryId;
        this.allEventNames = allEventNames;
        this.removedEventNames = removedEventNames;
        this.toBeRemovedEventNames = toBeRemovedEventNames;
        this.allConstructNames = allConstructNames;
        this.removedConstructNames = removedConstructNames;
        this.toBeRemovedConstructNames = toBeRemovedConstructNames;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public String getAllEventNames() {
        return allEventNames;
    }

    public void setAllEventNames(String allEventNames) {
        this.allEventNames = allEventNames;
    }

    public String getRemovedEventNames() {
        return removedEventNames;
    }

    public void setRemovedEventNames(String removedEventNames) {
        this.removedEventNames = removedEventNames;
    }

    public String getToBeRemovedEventNames() {
        return toBeRemovedEventNames;
    }

    public void setToBeRemovedEventNames(String toBeRemovedEventNames) {
        this.toBeRemovedEventNames = toBeRemovedEventNames;
    }

    public String getAllConstructNames() {
        return allConstructNames;
    }

    public void setAllConstructNames(String allConstructNames) {
        this.allConstructNames = allConstructNames;
    }

    public String getRemovedConstructNames() {
        return removedConstructNames;
    }

    public void setRemovedConstructNames(String removedConstructNames) {
        this.removedConstructNames = removedConstructNames;
    }

    public String getToBeRemovedConstructNames() {
        return toBeRemovedConstructNames;
    }

    public void setToBeRemovedConstructNames(String toBeRemovedConstructNames) {
        this.toBeRemovedConstructNames = toBeRemovedConstructNames;
    }
}