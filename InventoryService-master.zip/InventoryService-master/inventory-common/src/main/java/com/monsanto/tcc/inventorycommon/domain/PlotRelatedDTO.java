/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

public class PlotRelatedDTO implements com.monsanto.services.domain.common.Entity {
    private Long inventoryId;
    private Long malePlotId;
    private Long femalePlotId;
    private Integer femaleAbsoluteColumn;
    private Integer femaleAbsoluteRange;
    private Integer femaleSubRowDisplayOrder;
    private Integer femaleSubSubRowDisplayOrder;
    private Integer femalePlotType;
    private String maleLineFunctionName;
    private String malePedigree;
    private String maleBarcode;
    private String maleSeasonName;
    private String maleBrFieldName;
    private Integer maleSubRowDisplayOrder;
    private Integer maleSubSubRowDisplayOrder;
    private Integer malePlotType;
    private String maleBufferProgramRefId;
    private Long malePlotInventoryId;
    private String maleNonBufferProgramRefId;
    private String operationName;

    public String getOperationName() {
        return operationName;
    }

    public void setOperationName(String operationName) {
        this.operationName = operationName;
    }

    public Integer getFemalePlotType() {
        return femalePlotType;
    }

    public void setFemalePlotType(Integer femalePlotType) {
        this.femalePlotType = femalePlotType;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Integer getFemaleSubRowDisplayOrder() {
        return femaleSubRowDisplayOrder;
    }

    public void setFemaleSubRowDisplayOrder(Integer femaleSubRowDisplayOrder) {
        this.femaleSubRowDisplayOrder = femaleSubRowDisplayOrder;
    }

    public Integer getFemaleSubSubRowDisplayOrder() {
        return femaleSubSubRowDisplayOrder;
    }

    public void setFemaleSubSubRowDisplayOrder(Integer femaleSubSubRowDisplayOrder) {
        this.femaleSubSubRowDisplayOrder = femaleSubSubRowDisplayOrder;
    }

    public Long getFemalePlotId() {
        return femalePlotId;
    }

    public void setFemalePlotId(Long femalePlotId) {
        this.femalePlotId = femalePlotId;
    }

    public Integer getFemaleAbsoluteColumn() {
        return femaleAbsoluteColumn;
    }

    public void setFemaleAbsoluteColumn(Integer femaleAbsoluteColumn) {
        this.femaleAbsoluteColumn = femaleAbsoluteColumn;
    }

    public Integer getFemaleAbsoluteRange() {
        return femaleAbsoluteRange;
    }

    public void setFemaleAbsoluteRange(Integer femaleAbsoluteRange) {
        this.femaleAbsoluteRange = femaleAbsoluteRange;
    }

    public String getBrProg() {
        return isBufferPlot() ? getMaleBufferProgramRefId() : getMaleNonBufferProgramRefId();
    }

    public String getMaleNonBufferProgramRefId() {
        return maleNonBufferProgramRefId;
    }

    public void setMaleNonBufferProgramRefId(String maleNonBufferProgramRefId) {
        this.maleNonBufferProgramRefId = maleNonBufferProgramRefId;
    }

    public Long getMalePlotInventoryId() {
        return malePlotInventoryId;
    }

    public void setMalePlotInventoryId(Long malePlotInventoryId) {
        this.malePlotInventoryId = malePlotInventoryId;
    }

    public String getMaleBufferProgramRefId() {
        return maleBufferProgramRefId;
    }

    public void setMaleBufferProgramRefId(String maleBufferProgramRefId) {
        this.maleBufferProgramRefId = maleBufferProgramRefId;
    }

    public boolean isBufferPlot() {
        return null == this.getMalePlotInventoryId();
    }


    public Integer getMaleSubSubRowDisplayOrder() {
        return maleSubSubRowDisplayOrder;
    }

    public void setMaleSubSubRowDisplayOrder(Integer maleSubSubRowDisplayOrder) {
        this.maleSubSubRowDisplayOrder = maleSubSubRowDisplayOrder;
    }

    public Integer getMalePlotType() {
        return malePlotType;
    }

    public void setMalePlotType(Integer malePlotType) {
        this.malePlotType = malePlotType;
    }

    public Integer getMaleSubRowDisplayOrder() {
        return maleSubRowDisplayOrder;
    }

    public void setMaleSubRowDisplayOrder(Integer maleSubRowDisplayOrder) {
        this.maleSubRowDisplayOrder = maleSubRowDisplayOrder;
    }

    public String getMaleBrFieldName() {
        return maleBrFieldName;
    }

    public void setMaleBrFieldName(String maleBrFieldName) {
        this.maleBrFieldName = maleBrFieldName;
    }

    public Long getMalePlotId() {
        return malePlotId;
    }

    public void setMalePlotId(Long plotId) {
        this.malePlotId = plotId;
    }

    public String getMaleLineFunctionName() {
        return maleLineFunctionName;
    }

    public void setMaleLineFunctionName(String maleLineFunctionName) {
        this.maleLineFunctionName = maleLineFunctionName;
    }

    public String getMalePedigree() {
        return malePedigree;
    }

    public void setMalePedigree(String malePedigree) {
        this.malePedigree = malePedigree;
    }

    public String getMaleBarcode() {
        return maleBarcode;
    }

    public void setMaleBarcode(String maleBarcode) {
        this.maleBarcode = maleBarcode;
    }

    public String getMaleSeasonName() {
        return maleSeasonName;
    }

    public void setMaleSeasonName(String maleSeasonName) {
        this.maleSeasonName = maleSeasonName;
    }

    public String calculateMaleSubRowValue() {
        return SubRowCalculator.calculateSubRowValue(getMalePlotType(), getMaleSubRowDisplayOrder(), getMaleSubSubRowDisplayOrder());
    }

    public String calculateFemaleSubRowValue() {
        return SubRowCalculator.calculateSubRowValue(getFemalePlotType(), getFemaleSubRowDisplayOrder(), getFemaleSubSubRowDisplayOrder());
    }

    public PlotRelatedDTO() {

    }

    public Object getID() {
        return getMalePlotId();
    }

    @Override
    public String toString() {
        return "PlotId: " + getMalePlotId() + "\n" +
            "Line Function: " + getMaleLineFunctionName() + "\n" +
            "Pedigree: " + getMalePedigree() + "\n" +
            "Plot bid" + getMaleBarcode() + "\n" +
            "Season Name: " + getMaleSeasonName() + "\n" +
            "Br Field Name: " + getMaleBrFieldName() + "\n";
    }
}
