package com.monsanto.tcc.inventorycommon.transferobject.subinventory;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Sep 7, 2010
 * Time: 8:15:35 AM
 * To change this template use File | Settings | File Templates.
 */
public class ImportSubInventoryRequest {
    private Collection<String> inventoryBarcodes;
    private Collection<String> programRefIds;

    public Collection<String> getInventoryBarcodes() {
        return inventoryBarcodes;
    }

    public void setInventoryBarcodes(Collection<String> inventoryBarcodes) {
        this.inventoryBarcodes = inventoryBarcodes;
    }

    public Collection<String> getProgramRefIds() {
        return programRefIds;
    }

    public void setProgramRefIds(Collection<String> programRefIds) {
        this.programRefIds = programRefIds;
    }
}
