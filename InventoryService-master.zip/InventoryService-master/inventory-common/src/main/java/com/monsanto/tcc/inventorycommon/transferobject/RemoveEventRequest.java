package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.domain.CrossSegregateIndividualStatus;

import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Feb 17, 2010
 * Time: 3:13:06 PM
 */
@XmlType(name = "Inventory_RemoveEventRequest")
public class RemoveEventRequest {

    private CrossSegregateIndividualStatus crossSegregateIndividualStatus;
    private String removedById;
    private boolean autoRemoveEvent = false;
    private Collection<EventAssayResult> eventAssayResults = new ArrayList<EventAssayResult>();

    public CrossSegregateIndividualStatus getCrossSegregateIndividualStatus() {
        return crossSegregateIndividualStatus;
    }

    public void setCrossSegregateIndividualStatus(CrossSegregateIndividualStatus crossSegregateIndividualStatus) {
        this.crossSegregateIndividualStatus = crossSegregateIndividualStatus;
    }

    public String getRemovedById() {
        return removedById;
    }

    public void setRemovedById(String removedById) {
        this.removedById = removedById;
    }

    public boolean isAutoRemoveEvent() {
        return autoRemoveEvent;
    }

    public void setAutoRemoveEvent(boolean autoRemoveEvent) {
        this.autoRemoveEvent = autoRemoveEvent;
    }

    public Collection<EventAssayResult> getEventAssayResults() {
        return eventAssayResults;
    }

    public void setEventAssayResults(Collection<EventAssayResult> eventAssayResults) {
        this.eventAssayResults = eventAssayResults;
    }
}
