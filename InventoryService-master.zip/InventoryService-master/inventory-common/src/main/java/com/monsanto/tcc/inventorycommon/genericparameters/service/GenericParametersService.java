package com.monsanto.tcc.inventorycommon.genericparameters.service;

import com.monsanto.tcc.inventorycommon.genericparameters.client.GenericParametersRequest;
import com.monsanto.tcc.inventorycommon.genericparameters.client.GenericParametersResponse;

import javax.jws.WebService;
import java.util.List;

/**
 * User: Mark D. Sparks
 * Date: 8/26/11
 * Time: 2:09 PM
 */
@WebService
public interface GenericParametersService {
    public GenericParametersResponse createGenericParameters(List<GenericParametersRequest> genericParametersRequestList);
}
