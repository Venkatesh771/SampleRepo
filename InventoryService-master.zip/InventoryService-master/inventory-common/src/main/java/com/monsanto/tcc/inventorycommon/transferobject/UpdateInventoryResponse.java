package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.Date;

/**
 * Created by Dan Schnettgoecke with IntelliJ IDEA.
 * Created on 5/31/11 at 8:37 AM.
 */

public class UpdateInventoryResponse {

    private String modifiedUserName;
    private Date modifiedDate;

    public String getModifiedUserName() {
        return modifiedUserName;
    }

    public void setModifiedUserName(String modifiedUserName) {
        this.modifiedUserName = modifiedUserName;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
}