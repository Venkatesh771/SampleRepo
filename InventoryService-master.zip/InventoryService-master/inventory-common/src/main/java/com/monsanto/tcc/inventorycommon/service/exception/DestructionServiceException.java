package com.monsanto.tcc.inventorycommon.service.exception;

public class DestructionServiceException extends Exception {

    private static final long serialVersionUID = 1L;

    public DestructionServiceException(String message) {
        super(message);
    }

    public DestructionServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
