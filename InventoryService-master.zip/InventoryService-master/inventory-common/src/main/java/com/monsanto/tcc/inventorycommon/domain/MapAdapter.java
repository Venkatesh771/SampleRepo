package com.monsanto.tcc.inventorycommon.domain;


import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MapAdapter extends XmlAdapter<ObservationAttributeKeyValuePairList, Map<String, List<ObservationAttributeValue>>> {
    @Override
    public Map<String, List<ObservationAttributeValue>> unmarshal(ObservationAttributeKeyValuePairList observationAttributeKeyValuePairList) throws
        Exception {
        List<ObservationAttributeKeyValuePair> entry = observationAttributeKeyValuePairList.getKeyValuePair();
        Map<String, List<ObservationAttributeValue>> map = new HashMap<String, List<ObservationAttributeValue>>();
        for (ObservationAttributeKeyValuePair observationAttributeKeyValuePair : entry) {
            map.put(observationAttributeKeyValuePair.getObservationAttributeValueKey(),
                observationAttributeKeyValuePair.getObservationAttributeValueValue());
        }
        return map;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    @Override
    public ObservationAttributeKeyValuePairList marshal(Map<String, List<ObservationAttributeValue>> map) throws Exception {
        Set<String> keySet = map.keySet();
        List<ObservationAttributeKeyValuePair> entry = new ArrayList();
        for (String key : keySet) {
            ObservationAttributeKeyValuePair observationAttributeKeyValuePair = new ObservationAttributeKeyValuePair();
            observationAttributeKeyValuePair.setObservationAttributeValueKey(key);
            observationAttributeKeyValuePair.setObservationAttributeValueValue(map.get(key));
            entry.add(observationAttributeKeyValuePair);
        }
        ObservationAttributeKeyValuePairList observationAttributeKeyValuePairList = new ObservationAttributeKeyValuePairList();
        observationAttributeKeyValuePairList.setKeyValuePair(entry);
        return observationAttributeKeyValuePairList;
    }
}
