package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: MDSPARK
 * Date: Sep 28, 2009
 * Time: 10:05:40 AM
 * To change this template use File | Settings | File Templates.
 */
public class ObservationAttributeValue {
    private Object value;
    private String inventoryBarcode;
    private String obsvAttributeRefId;

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public String getInventoryBarcode() {
        return inventoryBarcode;
    }

    public void setInventoryBarcode(String inventoryBarcode) {
        this.inventoryBarcode = inventoryBarcode;
    }

    public String getObsvAttributeRefId() {
        return obsvAttributeRefId;
    }

    public void setObsvAttributeRefId(String obsvAttributeRefId) {
        this.obsvAttributeRefId = obsvAttributeRefId;
    }
}
