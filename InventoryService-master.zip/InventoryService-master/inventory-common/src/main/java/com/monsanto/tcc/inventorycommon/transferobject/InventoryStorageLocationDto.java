package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Jun 7, 2010
 * Time: 2:25:47 PM
 * To change this template use File | Settings | File Templates.
 */
public class InventoryStorageLocationDto {
    private Long inventoryId;
    private String storageLocationBarcode;
    private String storageLocationName;
    private String storageUnitDisplayDnml;

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public String getStorageLocationBarcode() {
        return storageLocationBarcode;
    }

    public void setStorageLocationBarcode(String storageLocationBarcode) {
        this.storageLocationBarcode = storageLocationBarcode;
    }

    public String getStorageUnitDisplayDnml() {
        return storageUnitDisplayDnml;
    }

    public void setStorageUnitDisplayDnml(String storageUnitDisplayDnml) {
        this.storageUnitDisplayDnml = storageUnitDisplayDnml;
    }

    public String getStorageLocationName() {
        return storageLocationName;
    }

    public void setStorageLocationName(String storageLocationName) {
        this.storageLocationName = storageLocationName;
    }
}
