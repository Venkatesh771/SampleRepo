package com.monsanto.tcc.inventorycommon.domain;

import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sssing5 Date: Oct 20, 2009 Time: 6:54:04 PM
 */
public class Plot extends com.monsanto.services.domain.common.AbstractEntity {
    private Long plotId;
    private Long testSetEntryId;
    private Long fateReasonId;
    private Long ytDecisionId;
    private Long projectId;
    private Long inventoryId;
    private Decision plotDecision;
    private Long brFieldId;
    private Long operationId;
    private Long repId;
    private Integer absoluteRange;
    private Integer absoluteColumn;
    private String comments;
    private Integer range;
    private String columnNumber;
    private Integer seedsPlanted;
    private Long length;
    private Long width;
    private Integer harvestedRows;
    private Integer plantedRows;
    private Integer plotNumber;
    private String includeBulk;
    private Long treatWithAgentId;
    private Long objType;
    private Integer numberOfSelections;
    private Integer startingSelectionNumber;
    private Integer plotType;
    private Integer displayOrder;
    private Long parentPlotId;
    private Integer parentalDisplayOrder;
    private Long masterPlotId;
    private Long harvestTypeId;
    private String harvestingDirection;
    private Long selectionMethodId;
    private Long relativeLocSeqNumber;
    private String plotDeactivated;
    private Integer subrowsToCreate;
    private Integer startingSubrowNumber;
    private Long rubProjId;
    private Boolean rubApproved;
    private String barcode;
    private Integer rubSampleNumber;
    private Double harvestPlotLength;
    private Long harvestPlotWidth;
    private Integer seedsPerPacket;
    private Long tagColorId;
    private Date fateReasonDate;
    private String extBid;
    private String virgoId;
    private Integer packetsPerPlot;
    private Date backOrderDate;
    private Integer parentDisplayOrder;
    private Date readyForTransformationDate;
    private Long readyForTransformationUsrid;
    private Long plotContainerTypeId;
    private Date rootedToSoilDate;
    private Date creationDate;
    private String treatment;
    private String goiTxt;
    private Date plantingDate;
    private Inventory inventory;


    public Long getPlotId() {
        return plotId;
    }

    public void setPlotId(Long plotId) {
        this.plotId = plotId;
    }

    public Long getTestSetEntryId() {
        return testSetEntryId;
    }

    public void setTestSetEntryId(Long testSetEntryId) {
        this.testSetEntryId = testSetEntryId;
    }

    public Long getFateReasonId() {
        return fateReasonId;
    }

    public void setFateReasonId(Long fateReasonId) {
        this.fateReasonId = fateReasonId;
    }

    public Long getYtDecisionId() {
        return ytDecisionId;
    }

    public void setYtDecisionId(Long ytDecisionId) {
        this.ytDecisionId = ytDecisionId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Decision getPlotDecision() {
        return plotDecision;
    }

    public void setPlotDecision(Decision plotDecision) {
        this.plotDecision = plotDecision;
    }

    public Long getBrFieldId() {
        return brFieldId;
    }

    public void setBrFieldId(Long brFieldId) {
        this.brFieldId = brFieldId;
    }

    public Long getOperationId() {
        return operationId;
    }

    public void setOperationId(Long operationId) {
        this.operationId = operationId;
    }

    public Long getRepId() {
        return repId;
    }

    public void setRepId(Long repId) {
        this.repId = repId;
    }


    public Integer getParentalDisplayOrder() {
        return parentalDisplayOrder;
    }

    public void setParentalDisplayOrder(Integer parentalDisplayOrder) {
        this.parentalDisplayOrder = parentalDisplayOrder;
    }

    public Integer getAbsoluteRange() {
        return absoluteRange;
    }

    public void setAbsoluteRange(Integer absoluteRange) {
        this.absoluteRange = absoluteRange;
    }

    public Integer getAbsoluteColumn() {
        return absoluteColumn;
    }

    public void setAbsoluteColumn(Integer absoluteColumn) {
        this.absoluteColumn = absoluteColumn;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Integer getRange() {
        return range;
    }

    public void setRange(Integer range) {
        this.range = range;
    }

    public String getColumnNumber() {
        return columnNumber;
    }

    public void setColumnNumber(String columnNumber) {
        this.columnNumber = columnNumber;
    }

    public Integer getSeedsPlanted() {
        return seedsPlanted;
    }

    public void setSeedsPlanted(Integer seedsPlanted) {
        this.seedsPlanted = seedsPlanted;
    }

    public Long getLength() {
        return length;
    }

    public void setLength(Long length) {
        this.length = length;
    }

    public Long getWidth() {
        return width;
    }

    public void setWidth(Long width) {
        this.width = width;
    }

    public Integer getHarvestedRows() {
        return harvestedRows;
    }

    public void setHarvestedRows(Integer harvestedRows) {
        this.harvestedRows = harvestedRows;
    }

    public Integer getPlantedRows() {
        return plantedRows;
    }

    public void setPlantedRows(Integer plantedRows) {
        this.plantedRows = plantedRows;
    }

    public Integer getPlotNumber() {
        return plotNumber;
    }

    public void setPlotNumber(Integer plotNumber) {
        this.plotNumber = plotNumber;
    }

    public String getIncludeBulk() {
        return includeBulk;
    }

    public void setIncludeBulk(String includeBulk) {
        this.includeBulk = includeBulk;
    }

    public Long getTreatWithAgentId() {
        return treatWithAgentId;
    }

    public void setTreatWithAgentId(Long treatWithAgentId) {
        this.treatWithAgentId = treatWithAgentId;
    }

    public Long getObjType() {
        return objType;
    }

    public void setObjType(Long objType) {
        this.objType = objType;
    }

    public Integer getNumberOfSelections() {
        return numberOfSelections;
    }

    public void setNumberOfSelections(Integer numberOfSelections) {
        this.numberOfSelections = numberOfSelections;
    }

    public Integer getStartingSelectionNumber() {
        return startingSelectionNumber;
    }

    public void setStartingSelectionNumber(Integer startingSelectionNumber) {
        this.startingSelectionNumber = startingSelectionNumber;
    }

    public Integer getPlotType() {
        return plotType;
    }

    public void setPlotType(Integer plotType) {
        this.plotType = plotType;
    }

    public Integer getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(Integer displayOrder) {
        this.displayOrder = displayOrder;
    }

    public Long getParentPlotId() {
        return parentPlotId;
    }

    public void setParentPlotId(Long parentPlotId) {
        this.parentPlotId = parentPlotId;
    }

    public Long getMasterPlotId() {
        return masterPlotId;
    }

    public void setMasterPlotId(Long masterPlotId) {
        this.masterPlotId = masterPlotId;
    }

    public Long getHarvestTypeId() {
        return harvestTypeId;
    }

    public void setHarvestTypeId(Long harvestTypeId) {
        this.harvestTypeId = harvestTypeId;
    }

    public String getHarvestingDirection() {
        return harvestingDirection;
    }

    public void setHarvestingDirection(String harvestingDirection) {
        this.harvestingDirection = harvestingDirection;
    }

    public Long getSelectionMethodId() {
        return selectionMethodId;
    }

    public void setSelectionMethodId(Long selectionMethodId) {
        this.selectionMethodId = selectionMethodId;
    }

    public Long getRelativeLocSeqNumber() {
        return relativeLocSeqNumber;
    }

    public void setRelativeLocSeqNumber(Long relativeLocSeqNumber) {
        this.relativeLocSeqNumber = relativeLocSeqNumber;
    }

    public String getPlotDeactivated() {
        return plotDeactivated;
    }

    public void setPlotDeactivated(String plotDeactivated) {
        this.plotDeactivated = plotDeactivated;
    }

    public Integer getSubrowsToCreate() {
        return subrowsToCreate;
    }

    public void setSubrowsToCreate(Integer subrowsToCreate) {
        this.subrowsToCreate = subrowsToCreate;
    }

    public Integer getStartingSubrowNumber() {
        return startingSubrowNumber;
    }

    public void setStartingSubrowNumber(Integer startingSubrowNumber) {
        this.startingSubrowNumber = startingSubrowNumber;
    }

    public Long getRubProjId() {
        return rubProjId;
    }

    public void setRubProjId(Long rubProjId) {
        this.rubProjId = rubProjId;
    }

    public Boolean getRubApproved() {
        return rubApproved;
    }

    public void setRubApproved(Boolean rubApproved) {
        this.rubApproved = rubApproved;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Integer getRubSampleNumber() {
        return rubSampleNumber;
    }

    public void setRubSampleNumber(Integer rubSampleNumber) {
        this.rubSampleNumber = rubSampleNumber;
    }

    public Double getHarvestPlotLength() {
        return harvestPlotLength;
    }

    public void setHarvestPlotLength(Double harvestPlotLength) {
        this.harvestPlotLength = harvestPlotLength;
    }

    public Long getHarvestPlotWidth() {
        return harvestPlotWidth;
    }

    public void setHarvestPlotWidth(Long harvestPlotWidth) {
        this.harvestPlotWidth = harvestPlotWidth;
    }

    public Integer getSeedsPerPacket() {
        return seedsPerPacket;
    }

    public void setSeedsPerPacket(Integer seedsPerPacket) {
        this.seedsPerPacket = seedsPerPacket;
    }

    public Long getTagColorId() {
        return tagColorId;
    }

    public void setTagColorId(Long tagColorId) {
        this.tagColorId = tagColorId;
    }

    public Date getFateReasonDate() {
        return fateReasonDate;
    }

    public void setFateReasonDate(Date fateReasonDate) {
        this.fateReasonDate = fateReasonDate;
    }

    public String getExtBid() {
        return extBid;
    }

    public void setExtBid(String extBid) {
        this.extBid = extBid;
    }

    public String getVirgoId() {
        return virgoId;
    }

    public void setVirgoId(String virgoId) {
        this.virgoId = virgoId;
    }

    public Integer getPacketsPerPlot() {
        return packetsPerPlot;
    }

    public void setPacketsPerPlot(Integer packetsPerPlot) {
        this.packetsPerPlot = packetsPerPlot;
    }

    public Date getBackOrderDate() {
        return backOrderDate;
    }

    public void setBackOrderDate(Date backOrderDate) {
        this.backOrderDate = backOrderDate;
    }

    public Integer getParentDisplayOrder() {
        return parentDisplayOrder;
    }

    public void setParentDisplayOrder(Integer parentDisplayOrder) {
        this.parentDisplayOrder = parentDisplayOrder;
    }

    public Date getReadyForTransformationDate() {
        return readyForTransformationDate;
    }

    public void setReadyForTransformationDate(Date readyForTransformationDate) {
        this.readyForTransformationDate = readyForTransformationDate;
    }

    public Long getReadyForTransformationUsrid() {
        return readyForTransformationUsrid;
    }

    public void setReadyForTransformationUsrid(Long readyForTransformationUsrid) {
        this.readyForTransformationUsrid = readyForTransformationUsrid;
    }

    public Long getPlotContainerTypeId() {
        return plotContainerTypeId;
    }

    public void setPlotContainerTypeId(Long plotContainerTypeId) {
        this.plotContainerTypeId = plotContainerTypeId;
    }

    public Date getRootedToSoilDate() {
        return rootedToSoilDate;
    }

    public void setRootedToSoilDate(Date rootedToSoilDate) {
        this.rootedToSoilDate = rootedToSoilDate;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    public String getGoiTxt() {
        return goiTxt;
    }

    public void setGoiTxt(String goiTxt) {
        this.goiTxt = goiTxt;
    }

    public Date getPlantingDate() {
        return plantingDate;
    }

    public void setPlantingDate(Date plantingDate) {
        this.plantingDate = plantingDate;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public String calculateSubRowValue() {
        return SubRowCalculator.calculateSubRowValue(getPlotType(), getDisplayOrder(), getParentalDisplayOrder());
    }

    public Plot() {

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Plot plot = (Plot) o;

        if (plotId != null ? !plotId.equals(plot.plotId) : plot.plotId != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return plotId != null ? plotId.hashCode() : 0;
    }

    public Object getID() {
        return getPlotId();
    }
}
