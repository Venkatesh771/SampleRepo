/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.transferobject.inventory.GermplasmEventConstructTO;

import java.util.Collection;
import java.util.Date;

/**
 * Created by Dan Schnettgoecke with IntelliJ IDEA.
 * Created on Oct 19, 2010 @ 3:02:40 PM.
 */

public class CrossSegMaterialTO {

    private String inventoryComments;
    private String asort1;
    private String asort2;
    private String asort3;
    private String asort4;
    private String asort5;
    private Double nsort1;
    private Double nsort2;
    private Double nsort3;
    private Double nsort4;
    private Double nsort5;
    private String inventoryType;
    private String inventoryStatus;
    private String barcode;
    private String inventoryOwnerName;
    private String preview;
    private Date fateReasonDate;
    private String fateReason;
    private String virgoId;
    private String seedTreatment;
    private String goiTxt;
    private String parentBarcode;
    private Double quantity;
    private String quantityUom;
    private String productName;
    private String constructDisplay;
    private String eventDisplay;
    private String lineCode;
    private String origin;
    private String pedigree;
    private String source;
    private String lineType;
    private String lineFunction;
    private String germplasmOwner;
    private String generation;
    private String lineage;
    private String srcCrop;
    private String srcGrowProg;
    private String srcLoc;
    private String srcOrigCountry;
    private String srcOrigProg;
    private String srcMalePlotBid;
    private String srcSet;
    private String srcPlotBid;
    private String srcProtocolName;
    private String transformationGenotype;
    private String oldPedigree;
    private Integer srcHarvMonth;
    private Integer srcHarvYear;
    private Integer srcPlantMonth;
    private Integer srcPlantYear;
    private Long inbredBaseId;
    private String inbredBaseName;
    private String storageUnitBid;
    private String storageUnitLocation;
    private String storageUnitName;

    private Collection<GermplasmEventConstructTO> germplasmEventConstructs;

    public Long getInbredBaseId() {
        return inbredBaseId;
    }

    public void setInbredBaseId(Long inbredBaseId) {
        this.inbredBaseId = inbredBaseId;
    }

    public String getInbredBaseName() {
        return inbredBaseName;
    }

    public void setInbredBaseName(String inbredBaseName) {
        this.inbredBaseName = inbredBaseName;
    }

    public String getInventoryComments() {
        return inventoryComments;
    }

    public void setInventoryComments(String inventoryComments) {
        this.inventoryComments = inventoryComments;
    }

    public String getAsort1() {
        return asort1;
    }

    public void setAsort1(String asort1) {
        this.asort1 = asort1;
    }

    public String getAsort2() {
        return asort2;
    }

    public void setAsort2(String asort2) {
        this.asort2 = asort2;
    }

    public String getAsort3() {
        return asort3;
    }

    public void setAsort3(String asort3) {
        this.asort3 = asort3;
    }

    public String getAsort4() {
        return asort4;
    }

    public void setAsort4(String asort4) {
        this.asort4 = asort4;
    }

    public String getAsort5() {
        return asort5;
    }

    public void setAsort5(String asort5) {
        this.asort5 = asort5;
    }

    public Double getNsort1() {
        return nsort1;
    }

    public void setNsort1(Double nsort1) {
        this.nsort1 = nsort1;
    }

    public Double getNsort2() {
        return nsort2;
    }

    public void setNsort2(Double nsort2) {
        this.nsort2 = nsort2;
    }

    public Double getNsort3() {
        return nsort3;
    }

    public void setNsort3(Double nsort3) {
        this.nsort3 = nsort3;
    }

    public Double getNsort4() {
        return nsort4;
    }

    public void setNsort4(Double nsort4) {
        this.nsort4 = nsort4;
    }

    public Double getNsort5() {
        return nsort5;
    }

    public void setNsort5(Double nsort5) {
        this.nsort5 = nsort5;
    }

    public String getInventoryType() {
        return inventoryType;
    }

    public void setInventoryType(String inventoryType) {
        this.inventoryType = inventoryType;
    }

    public String getInventoryStatus() {
        return inventoryStatus;
    }

    public void setInventoryStatus(String inventoryStatus) {
        this.inventoryStatus = inventoryStatus;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getInventoryOwnerName() {
        return inventoryOwnerName;
    }

    public void setInventoryOwnerName(String inventoryOwnerName) {
        this.inventoryOwnerName = inventoryOwnerName;
    }

    public String getPreview() {
        return preview;
    }

    public void setPreview(String preview) {
        this.preview = preview;
    }

    public Date getFateReasonDate() {
        return fateReasonDate;
    }

    public void setFateReasonDate(Date fateReasonDate) {
        this.fateReasonDate = fateReasonDate;
    }

    public String getFateReason() {
        return fateReason;
    }

    public void setFateReason(String fateReason) {
        this.fateReason = fateReason;
    }

    public String getVirgoId() {
        return virgoId;
    }

    public void setVirgoId(String virgoId) {
        this.virgoId = virgoId;
    }

    public String getSeedTreatment() {
        return seedTreatment;
    }

    public void setSeedTreatment(String seedTreatment) {
        this.seedTreatment = seedTreatment;
    }

    public String getGoiTxt() {
        return goiTxt;
    }

    public void setGoiTxt(String goiTxt) {
        this.goiTxt = goiTxt;
    }

    public String getParentBarcode() {
        return parentBarcode;
    }

    public void setParentBarcode(String parentBarcode) {
        this.parentBarcode = parentBarcode;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public String getQuantityUom() {
        return quantityUom;
    }

    public void setQuantityUom(String quantityUom) {
        this.quantityUom = quantityUom;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getConstructDisplay() {
        return constructDisplay;
    }

    public void setConstructDisplay(String constructDisplay) {
        this.constructDisplay = constructDisplay;
    }

    public String getEventDisplay() {
        return eventDisplay;
    }

    public void setEventDisplay(String eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getPedigree() {
        return pedigree;
    }

    public void setPedigree(String pedigree) {
        this.pedigree = pedigree;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getLineType() {
        return lineType;
    }

    public void setLineType(String lineType) {
        this.lineType = lineType;
    }

    public String getLineFunction() {
        return lineFunction;
    }

    public void setLineFunction(String lineFunction) {
        this.lineFunction = lineFunction;
    }

    public String getGeneration() {
        return generation;
    }

    public void setGeneration(String generation) {
        this.generation = generation;
    }

    public String getLineage() {
        return lineage;
    }

    public void setLineage(String lineage) {
        this.lineage = lineage;
    }

    public String getSrcCrop() {
        return srcCrop;
    }

    public void setSrcCrop(String srcCrop) {
        this.srcCrop = srcCrop;
    }

    public String getSrcGrowProg() {
        return srcGrowProg;
    }

    public void setSrcGrowProg(String srcGrowProg) {
        this.srcGrowProg = srcGrowProg;
    }

    public Integer getSrcHarvMonth() {
        return srcHarvMonth;
    }

    public void setSrcHarvMonth(Integer srcHarvMonth) {
        this.srcHarvMonth = srcHarvMonth;
    }

    public Integer getSrcHarvYear() {
        return srcHarvYear;
    }

    public void setSrcHarvYear(Integer srcHarvYear) {
        this.srcHarvYear = srcHarvYear;
    }

    public String getSrcLoc() {
        return srcLoc;
    }

    public void setSrcLoc(String srcLoc) {
        this.srcLoc = srcLoc;
    }

    public String getSrcOrigCountry() {
        return srcOrigCountry;
    }

    public void setSrcOrigCountry(String srcOrigCountry) {
        this.srcOrigCountry = srcOrigCountry;
    }

    public String getSrcOrigProg() {
        return srcOrigProg;
    }

    public void setSrcOrigProg(String srcOrigProg) {
        this.srcOrigProg = srcOrigProg;
    }

    public Integer getSrcPlantMonth() {
        return srcPlantMonth;
    }

    public void setSrcPlantMonth(Integer srcPlantMonth) {
        this.srcPlantMonth = srcPlantMonth;
    }

    public Integer getSrcPlantYear() {
        return srcPlantYear;
    }

    public void setSrcPlantYear(Integer srcPlantYear) {
        this.srcPlantYear = srcPlantYear;
    }

    public String getSrcMalePlotBid() {
        return srcMalePlotBid;
    }

    public void setSrcMalePlotBid(String srcMalePlotBid) {
        this.srcMalePlotBid = srcMalePlotBid;
    }

    public String getSrcSet() {
        return srcSet;
    }

    public void setSrcSet(String srcSet) {
        this.srcSet = srcSet;
    }

    public String getSrcPlotBid() {
        return srcPlotBid;
    }

    public void setSrcPlotBid(String srcPlotBid) {
        this.srcPlotBid = srcPlotBid;
    }

    public String getSrcProtocolName() {
        return srcProtocolName;
    }

    public void setSrcProtocolName(String srcProtocolName) {
        this.srcProtocolName = srcProtocolName;
    }

    public String getTransformationGenotype() {
        return transformationGenotype;
    }

    public void setTransformationGenotype(String transformationGenotype) {
        this.transformationGenotype = transformationGenotype;
    }

    public String getOldPedigree() {
        return oldPedigree;
    }

    public void setOldPedigree(String oldPedigree) {
        this.oldPedigree = oldPedigree;
    }

    public Collection<GermplasmEventConstructTO> getGermplasmEventConstructs() {
        return germplasmEventConstructs;
    }

    public void setGermplasmEventConstructs(Collection<GermplasmEventConstructTO> germplasmEventConstructs) {
        this.germplasmEventConstructs = germplasmEventConstructs;
    }

    public String getGermplasmOwner() {
        return germplasmOwner;
    }

    public void setGermplasmOwner(String germplasmOwner) {
        this.germplasmOwner = germplasmOwner;
    }

    public String getStorageUnitBid() {
        return storageUnitBid;
    }

    public void setStorageUnitBid(String storageUnitBid) {
        this.storageUnitBid = storageUnitBid;
    }

    public String getStorageUnitLocation() {
        return storageUnitLocation;
    }

    public void setStorageUnitLocation(String storageUnitLocation) {
        this.storageUnitLocation = storageUnitLocation;
    }

    public String getStorageUnitName() {
        return storageUnitName;
    }

    public void setStorageUnitName(String storageUnitName) {
        this.storageUnitName = storageUnitName;
    }
}
