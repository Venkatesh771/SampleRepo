/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.ArrayList;
import java.util.List;

/* nbwald - Dec 7, 2010 */
public class InactiveInventoryResponse {
    private List<InactiveInventory> inactiveInventory = new ArrayList<InactiveInventory>();

    public List<InactiveInventory> getInactiveInventory() {
        return inactiveInventory;
    }

    public void setInactiveInventory(List<InactiveInventory> inactiveInventory) {
        this.inactiveInventory = inactiveInventory;
    }
}