package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.common.AbstractEntity;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: May 6, 2009
 * Time: 4:27:08 PM
 */
public class AvailableMaterial extends AbstractEntity {
    private String prog;
    private String pedigree;
    private String source;
    private String lcode;
    private String prod;
    private String ltype;
    private Double qty;
    private String uom;
    private Long inventoryId;

    public String getProg() {
        return prog;
    }

    public void setProg(String prog) {
        this.prog = prog;
    }

    public String getPedigree() {
        return pedigree;
    }

    public void setPedigree(String pedigree) {
        this.pedigree = pedigree;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getLcode() {
        return lcode;
    }

    public void setLcode(String lcode) {
        this.lcode = lcode;
    }

    public String getProd() {
        return prod;
    }

    public void setProd(String prod) {
        this.prod = prod;
    }

    public String getLtype() {
        return ltype;
    }

    public void setLtype(String ltype) {
        this.ltype = ltype;
    }

    public Double getQty() {
        return qty;
    }

    public void setQty(Double qty) {
        this.qty = qty;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Object getID() {
        return inventoryId;
    }
}