/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

public class PlotRelatedData {
    private Long inventoryId;
    private String maleLineFunctionName;
    private String maleFieldName;
    private String malePedigree;
    private String malePlotBid;
    private String maleSeasonName;
    private String maleSubRowNumber;
    private String malePlotType;
    private String maleProject;
    private String femaleAbsoluteColumn;
    private String femaleAbsoluteRange;
    private String subRowNumber;
    private String operation;


    public String getMalePlotBid() {
        return malePlotBid;
    }

    public void setMalePlotBid(String malePlotBid) {
        this.malePlotBid = malePlotBid;
    }

    public String getMaleSubRowNumber() {
        return maleSubRowNumber;
    }

    public void setMaleSubRowNumber(String maleSubRowNumber) {
        this.maleSubRowNumber = maleSubRowNumber;
    }

    public String getMaleProject() {
        return maleProject;
    }

    public void setMaleProject(String maleProject) {
        this.maleProject = maleProject;
    }

    public String getSubRowNumber() {
        return subRowNumber;
    }

    public void setSubRowNumber(String subRowNumber) {
        this.subRowNumber = subRowNumber;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public String getMaleLineFunctionName() {
        return maleLineFunctionName;
    }

    public void setMaleLineFunctionName(String maleLineFunctionName) {
        this.maleLineFunctionName = maleLineFunctionName;
    }

    public String getMaleFieldName() {
        return maleFieldName;
    }

    public void setMaleFieldName(String maleFieldName) {
        this.maleFieldName = maleFieldName;
    }

    public String getMalePedigree() {
        return malePedigree;
    }

    public void setMalePedigree(String malePedigree) {
        this.malePedigree = malePedigree;
    }

    public String getMaleSeasonName() {
        return maleSeasonName;
    }

    public void setMaleSeasonName(String maleSeasonName) {
        this.maleSeasonName = maleSeasonName;
    }

    public String getMalePlotType() {
        return malePlotType;
    }

    public void setMalePlotType(String malePlotType) {
        this.malePlotType = malePlotType;
    }

    public String getFemaleAbsoluteColumn() {
        return femaleAbsoluteColumn;
    }

    public void setFemaleAbsoluteColumn(String femaleAbsoluteColumn) {
        this.femaleAbsoluteColumn = femaleAbsoluteColumn;
    }

    public String getFemaleAbsoluteRange() {
        return femaleAbsoluteRange;
    }

    public void setFemaleAbsoluteRange(String femaleAbsoluteRange) {
        this.femaleAbsoluteRange = femaleAbsoluteRange;
    }
}