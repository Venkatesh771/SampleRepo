package com.monsanto.tcc.inventorycommon.transferobject.materialexchange;

import com.monsanto.tcc.inventorycommon.transferobject.ResponseMessage;

import java.util.Date;

/**
 * Created by Dan Schnettgoecke with IntelliJ IDEA.
 * Created on 6/1/11 at 4:18 PM.
 */

public class MaterialExchangeResponse {

    private ResponseMessage responseMessage;
    private String modifiedUserName;
    private Date modifiedDate;

    public MaterialExchangeResponse() {
    }

    public MaterialExchangeResponse(String modifiedUserName, Date modifiedDate) {
        this.modifiedUserName = modifiedUserName;
        this.modifiedDate = modifiedDate;
    }

    public ResponseMessage getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(ResponseMessage responseMessage) {
        this.responseMessage = responseMessage;
    }

    public String getModifiedUserName() {
        return modifiedUserName;
    }

    public void setModifiedUserName(String modifiedUserName) {
        this.modifiedUserName = modifiedUserName;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
}