package com.monsanto.tcc.inventorycommon.projectcreation.client;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MDSPARK
 * Date: Oct 23, 2009
 * Time: 4:37:38 PM
 * To change this template use File | Settings | File Templates.
 */
public interface StartProjectCreationServiceClient {
    public ProjectCreationStartUpResponse startProjectCreation(List<Long> inventoryIds) throws StartProjectCreationServiceClientException;
}
