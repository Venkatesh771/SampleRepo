package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by Dan Schnettgoecke with IntelliJ IDEA.
 * Created on Dec 15, 2010 at 9:55:10 AM.
 */

public class ObservationAttributeValueSnapshot {

    private Long observationAttributeValueSnapshotId;
    private Long crossSegregateIndividualStatusId;
    private Long observationAttributeValueId;
    private Long observationAttributeId;
    private Long observationId;
    private String strValue;
    private Double numValue;
    private Long uomId;
    private Long observationAttributeValueListId;
    private String deactivate;
    private String deleted;
    private Long laboratoryId;
    private String requestId;
    private Long plotId;
    private Long inventoryId;
    private Long observationClassificationId;
    private String sampleNumber;

    public Long getObservationAttributeValueSnapshotId() {
        return observationAttributeValueSnapshotId;
    }

    public void setObservationAttributeValueSnapshotId(Long observationAttributeValueSnapshotId) {
        this.observationAttributeValueSnapshotId = observationAttributeValueSnapshotId;
    }

    public Long getCrossSegregateIndividualStatusId() {
        return crossSegregateIndividualStatusId;
    }

    public void setCrossSegregateIndividualStatusId(Long crossSegregateIndividualStatusId) {
        this.crossSegregateIndividualStatusId = crossSegregateIndividualStatusId;
    }

    public Long getObservationAttributeValueId() {
        return observationAttributeValueId;
    }

    public void setObservationAttributeValueId(Long observationAttributeValueId) {
        this.observationAttributeValueId = observationAttributeValueId;
    }

    public Long getObservationAttributeId() {
        return observationAttributeId;
    }

    public void setObservationAttributeId(Long observationAttributeId) {
        this.observationAttributeId = observationAttributeId;
    }

    public Long getObservationId() {
        return observationId;
    }

    public void setObservationId(Long observationId) {
        this.observationId = observationId;
    }

    public String getStrValue() {
        return strValue;
    }

    public void setStrValue(String strValue) {
        this.strValue = strValue;
    }

    public Double getNumValue() {
        return numValue;
    }

    public void setNumValue(Double numValue) {
        this.numValue = numValue;
    }

    public Long getUomId() {
        return uomId;
    }

    public void setUomId(Long uomId) {
        this.uomId = uomId;
    }

    public Long getObservationAttributeValueListId() {
        return observationAttributeValueListId;
    }

    public void setObservationAttributeValueListId(Long observationAttributeValueListId) {
        this.observationAttributeValueListId = observationAttributeValueListId;
    }

    public String getDeactivate() {
        return deactivate;
    }

    public void setDeactivate(String deactivate) {
        this.deactivate = deactivate;
    }

    public String getDeleted() {
        return deleted;
    }

    public void setDeleted(String deleted) {
        this.deleted = deleted;
    }

    public Long getLaboratoryId() {
        return laboratoryId;
    }

    public void setLaboratoryId(Long laboratoryId) {
        this.laboratoryId = laboratoryId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getSampleNumber() {
        return sampleNumber;
    }

    public void setSampleNumber(String sampleNumber) {
        this.sampleNumber = sampleNumber;
    }

    public Long getObservationClassificationId() {
        return observationClassificationId;
    }

    public void setObservationClassificationId(Long observationClassificationId) {
        this.observationClassificationId = observationClassificationId;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Long getPlotId() {
        return plotId;
    }

    public void setPlotId(Long plotId) {
        this.plotId = plotId;
    }
}