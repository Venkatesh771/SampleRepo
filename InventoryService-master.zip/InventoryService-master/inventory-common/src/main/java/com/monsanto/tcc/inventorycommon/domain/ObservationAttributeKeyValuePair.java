package com.monsanto.tcc.inventorycommon.domain;

import java.util.List;

/**
 * Created by IntelliJ IDEA. User: MDSPARK Date: Sep 28, 2009 Time: 9:54:01 AM To change this template use File | Settings | File Templates.
 */
class ObservationAttributeKeyValuePair {
    private String observationAttributeValueKey;

    private List<ObservationAttributeValue> observationAttributeValueValue;

    public String getObservationAttributeValueKey() {
        return observationAttributeValueKey;
    }

    public void setObservationAttributeValueKey(String observationAttributeValueKey) {
        this.observationAttributeValueKey = observationAttributeValueKey;
    }

    public List<ObservationAttributeValue> getObservationAttributeValueValue() {
        return observationAttributeValueValue;
    }

    public void setObservationAttributeValueValue(List<ObservationAttributeValue> observationAttributeValueValue) {
        this.observationAttributeValueValue = observationAttributeValueValue;
    }
}
