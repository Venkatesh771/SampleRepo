package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: May 24, 2010
 * Time: 1:25:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductNameXRef {
    private String lexiconProductNamePubKey;
    private ProductName productName;
    private Long mirageProductId;

    public ProductNameXRef() {
    }

    public ProductNameXRef(String lexiconProductNamePubKey, ProductName productName, Long mirageProductId) {
        this.lexiconProductNamePubKey = lexiconProductNamePubKey;
        this.productName = productName;
        this.mirageProductId = mirageProductId;
    }

    public String getLexiconProductNamePubKey() {
        return lexiconProductNamePubKey;
    }

    public void setLexiconProductNamePubKey(String lexiconProductNamePubKey) {
        this.lexiconProductNamePubKey = lexiconProductNamePubKey;
    }

    public ProductName getProductName() {
        return productName;
    }

    public void setProductName(ProductName productName) {
        this.productName = productName;
    }

    public Long getMirageProductId() {
        return mirageProductId;
    }

    public void setMirageProductId(Long mirageProductId) {
        this.mirageProductId = mirageProductId;
    }
}
