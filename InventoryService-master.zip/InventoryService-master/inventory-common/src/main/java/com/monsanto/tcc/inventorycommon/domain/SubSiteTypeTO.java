package com.monsanto.tcc.inventorycommon.domain;

public class SubSiteTypeTO {
    private Long subSiteTypeId;
    private String name;
    private String subSiteTypeRefId;
    private Long listOrder;
    private String refActive;

    public Long getSubSiteTypeId() {
        return subSiteTypeId;
    }

    public void setSubSiteTypeId(Long subSiteTypeId) {
        this.subSiteTypeId = subSiteTypeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubSiteTypeRefId() {
        return subSiteTypeRefId;
    }

    public void setSubSiteTypeRefId(String subSiteTypeRefId) {
        this.subSiteTypeRefId = subSiteTypeRefId;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public Long getListOrder() {
        return listOrder;
    }

    public void setListOrder(Long listOrder) {
        this.listOrder = listOrder;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SubSiteTypeTO that = (SubSiteTypeTO) o;

        if (name != null ? !name.equals(that.name) : that.name != null) {
            return false;
        }
        if (subSiteTypeId != null ? !subSiteTypeId.equals(that.subSiteTypeId) : that.subSiteTypeId != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = subSiteTypeId != null ? subSiteTypeId.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }
}
