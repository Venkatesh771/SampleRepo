package com.monsanto.tcc.inventorycommon.transferobject;

public enum StorageType {
    STORAGE_LOCATION,
    STORAGE_CONTAINER,
    SITE,
    SUB_SITE,
    SUB_SUB_SITE,
    DISCARD_STORAGE_CONTAINER,
    DISCARD_STORAGE_LOCATION;
}
