/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import org.apache.commons.lang.StringUtils;

public class ProgramSiteTransferObject {
    private Long siteId;
    private String siteName;
    private String brProgRefId;

    public Long getSiteId() {
        return siteId;
    }

    public void setSiteId(Long siteId) {
        this.siteId = siteId;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getBrProgRefId() {
        return brProgRefId;
    }

    public void setBrProgRefId(String brProgRefId) {
        this.brProgRefId = brProgRefId;
    }

    @Override
    public String toString() {
        return StringUtils.defaultString(siteName);

    }
}