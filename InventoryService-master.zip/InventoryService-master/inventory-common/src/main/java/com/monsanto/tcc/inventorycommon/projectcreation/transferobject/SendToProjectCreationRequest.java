package com.monsanto.tcc.inventorycommon.projectcreation.transferobject;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: MDSPARK
 * Date: Oct 15, 2009
 * Time: 8:51:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class SendToProjectCreationRequest {
    private List<String> inventoryBarcodes = new ArrayList<String>();
    private boolean validateOnly;

    public List<String> getInventoryBarcodes() {
        return inventoryBarcodes;
    }

    public void setInventoryBarcodes(List<String> inventoryBarcodes) {
        this.inventoryBarcodes = inventoryBarcodes;
    }

    public boolean isValidateOnly() {
        return validateOnly;
    }

    public void setValidateOnly(boolean validateOnly) {
        this.validateOnly = validateOnly;
    }
}
