package com.monsanto.tcc.inventorycommon.service.tou;

import java.util.Date;

/**
 * User: DCENGL
 */
public class TermsOfUse {

    private Long id;
    private String terms;
    private boolean restricted;
    private GeneticMaterialDetails originGeneticMaterialDetails;
    private String modifiedBy;
    private Date modifiedDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTerms() {
        return terms;
    }

    public void setTerms(String terms) {
        this.terms = terms;
    }

    public boolean isRestricted() {
        return restricted;
    }

    public void setRestricted(boolean restricted) {
        this.restricted = restricted;
    }

    public GeneticMaterialDetails getOriginGeneticMaterialDetails() {
        return originGeneticMaterialDetails;
    }

    public void setOriginGeneticMaterialDetails(GeneticMaterialDetails originGeneticMaterialDetails) {
        this.originGeneticMaterialDetails = originGeneticMaterialDetails;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
}
