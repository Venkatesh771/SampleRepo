/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.service;


import com.monsanto.tcc.inventorycommon.domain.BlendComponentRole;
import com.monsanto.tcc.inventorycommon.transferobject.BlendProductNameFilter;
import com.monsanto.tcc.inventorycommon.transferobject.BlendProductNameTransferObject;
import com.monsanto.tcc.inventorycommon.transferobject.BlendSummary;
import com.monsanto.tcc.inventorycommon.transferobject.PreCommercialProductResponse;

import javax.jws.WebService;
import java.util.List;

@WebService
public interface BlendProductService {
    List<BlendProductNameTransferObject> getPreCommercialProducts(BlendProductNameFilter filter);

    List<BlendProductNameTransferObject> getAllPreCommercialProducts();

    PreCommercialProductResponse getPreCommercialProductDetailsByProductName(BlendProductNameTransferObject productNameTransferObject);

    List<BlendComponentRole> getAllBlendComponentRoles();

    BlendSummary retrieveBlendedSummaryFromInventoryBarcode(String inventoryBarcode);
}