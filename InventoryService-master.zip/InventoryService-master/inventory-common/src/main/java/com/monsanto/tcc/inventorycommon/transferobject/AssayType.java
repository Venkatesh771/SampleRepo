package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Filename:    $RCSfile: $ Last Change: $Author: daguar $ Date: $Date: Sep 11, 2009 5:05:24 PM $
 */
public class AssayType {

    private String attributeRefId;
    private String attributeValue;

    public AssayType() {
    }

    public AssayType(String attributeRefId, String attributeValue) {
        this.attributeRefId = attributeRefId;
        this.attributeValue = attributeValue;
    }

    public String getAttributeRefId() {
        return attributeRefId;
    }

    public void setAttributeRefId(String attributeRefId) {
        this.attributeRefId = attributeRefId;
    }

    public String getAttributeValue() {
        return attributeValue;
    }

    public void setAttributeValue(String attributeValue) {
        this.attributeValue = attributeValue;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AssayType assayType = (AssayType) o;

        return attributeRefId.equals(assayType.attributeRefId) && attributeValue.equals(assayType.attributeValue);

    }

    @Override
    public int hashCode() {
        int result = attributeRefId.hashCode();
        result = 31 * result + attributeValue.hashCode();
        return result;
    }
}
