/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

public class SubRowCalculator {
    public static String calculateSubRowValue(Integer plotType, Integer subRowDisplayOrder, Integer subSubRowDisplayOrder) {
        String subRowValue = null;
        if (plotType != null) {
            if ((plotType == 2) && (subRowDisplayOrder != null)) {
                subRowValue = subRowDisplayOrder.toString();
            } else if ((plotType == 3) && (subSubRowDisplayOrder != null)) {
                subRowValue = subSubRowDisplayOrder.toString() + convertIntegerToString(subRowDisplayOrder);
            }
        }
        return subRowValue;
    }

    private static String convertIntegerToString(Integer toBeConverted) {
        int charactersInAlphabet = 26;
        int asciiValueOfFirstLetter = 64;

        StringBuilder sb = new StringBuilder();
        while (toBeConverted >= 1) {
            int intValueOfNextChar = toBeConverted % charactersInAlphabet;
            sb.append(intValueOfNextChar == 0 ? "Z" : (char) (intValueOfNextChar + asciiValueOfFirstLetter));
            toBeConverted = (toBeConverted - 1) / charactersInAlphabet;
        }
        return sb.reverse().toString();
    }

}
