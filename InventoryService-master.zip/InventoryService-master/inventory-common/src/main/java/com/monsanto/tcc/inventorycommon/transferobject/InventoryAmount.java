package com.monsanto.tcc.inventorycommon.transferobject;

public class InventoryAmount {
    private String barcode;
    private double quantity;
    private long quantityUOM;

    public InventoryAmount() {
    }

    public InventoryAmount(String barcode, double quantity, long quantityUOM) {
        this.barcode = barcode;
        this.quantity = quantity;
        this.quantityUOM = quantityUOM;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public long getQuantityUOM() {
        return quantityUOM;
    }

    public void setQuantityUOM(long quantityUOM) {
        this.quantityUOM = quantityUOM;
    }
}
