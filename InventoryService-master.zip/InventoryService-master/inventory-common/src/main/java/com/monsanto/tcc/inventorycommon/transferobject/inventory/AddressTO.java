/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.inventory;

public class AddressTO {

    private String addressId;
    private String addressType;
    private String line1;
    private String line2;
    private String line3;
    private String city;
    private String county;
    private String state;
    private String country;
    private String postalCode;

    public AddressTO() {
    }

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getLine1() {
        return line1;
    }

    public void setLine1(String line1) {
        this.line1 = line1;
    }

    public String getLine2() {
        return line2;
    }

    public void setLine2(String line2) {
        this.line2 = line2;
    }

    public String getLine3() {
        return line3;
    }

    public void setLine3(String line3) {
        this.line3 = line3;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String toString() {
        StringBuffer address = new StringBuffer();
        if (null != line1) {
            address.append(line1).append(" ");

        }
        if (null != line2) {
            address.append(line2).append(" ");
        }
        if (null != line3) {
            address.append(line3).append(" ");
        }
        if (null != city) {
            address.append(city).append(", ");
        }
        if (null != state) {
            address.append(state).append(" ");
        }
        if (null != postalCode) {
            address.append(postalCode);
        }
        return address.toString().trim();
    }
}