package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.ProgramTO;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: May 6, 2009
 * Time: 3:52:43 PM
 */
public class AvailableMaterialRequest {
    private Filter[] filters;
    private ProgramTO[] programs;

    public Filter[] getFilters() {
        return filters;
    }

    public void setFilters(Filter filters[]) {
        this.filters = filters;
    }

    public ProgramTO[] getPrograms() {
        return programs;
    }

    public void setPrograms(ProgramTO[] programs) {
        this.programs = programs;
    }
}
