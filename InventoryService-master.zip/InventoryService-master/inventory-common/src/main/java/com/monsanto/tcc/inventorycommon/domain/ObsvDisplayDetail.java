package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: RRPATN
 * Date: Mar 24, 2010
 * Time: 10:04:35 AM
 * To change this template use File | Settings | File Templates.
 */
public class ObsvDisplayDetail {
    private Long obsvDisplayDetailId;
    private ObsvDisplay obsvDisplay;
    private ObsvAttribute obsvAttribute;
    private AggregateFunction aggregateFunction;
    private Long displayOrder;

    public ObsvDisplayDetail() {
    }

    public Long getObsvDisplayDetailId() {
        return obsvDisplayDetailId;
    }

    public void setObsvDisplayDetailId(Long obsvDisplayDetailId) {
        this.obsvDisplayDetailId = obsvDisplayDetailId;
    }

    public ObsvDisplay getObsvDisplay() {
        return obsvDisplay;
    }

    public void setObsvDisplay(ObsvDisplay obsvDisplay) {
        this.obsvDisplay = obsvDisplay;
    }

    public ObsvAttribute getObsvAttribute() {
        return obsvAttribute;
    }

    public void setObsvAttribute(ObsvAttribute obsvAttribute) {
        this.obsvAttribute = obsvAttribute;
    }

    public AggregateFunction getAggregateFunction() {
        return aggregateFunction;
    }

    public void setAggregateFunction(AggregateFunction aggregateFunction) {
        this.aggregateFunction = aggregateFunction;
    }

    public Long getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(Long displayOrder) {
        this.displayOrder = displayOrder;
    }
}
