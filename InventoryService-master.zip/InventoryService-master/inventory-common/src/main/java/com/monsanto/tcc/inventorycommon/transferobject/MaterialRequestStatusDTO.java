package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Jun 3, 2010
 * Time: 11:42:38 AM
 * To change this template use File | Settings | File Templates.
 */
public class MaterialRequestStatusDTO {
    private String name;
    private String description;
    private Date inactiveDttm;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }
}