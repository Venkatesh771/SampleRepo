package com.monsanto.tcc.inventorycommon.domain;

public class ShipmentContainer {
    private Long id;
    private Long shipmentId;
    private Long storageContainerId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getShipmentId() {
        return shipmentId;
    }

    public void setShipmentId(Long shipmentId) {
        this.shipmentId = shipmentId;
    }

    public Long getStorageContainerId() {
        return storageContainerId;
    }

    public void setStorageContainerId(Long storageContainerId) {
        this.storageContainerId = storageContainerId;
    }
}
