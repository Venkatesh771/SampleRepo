package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: MDSPARK
 * Date: Oct 4, 2009
 * Time: 10:33:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class TempSessionOcd {

    private TempSessionOcdId id;

    public TempSessionOcd() {
    }

    public TempSessionOcd(TempSessionOcdId x) {
        this.id = x;
    }

    public TempSessionOcdId getId() {
        return this.id;
    }

    public void setId(TempSessionOcdId x) {
        this.id = x;
    }

}
