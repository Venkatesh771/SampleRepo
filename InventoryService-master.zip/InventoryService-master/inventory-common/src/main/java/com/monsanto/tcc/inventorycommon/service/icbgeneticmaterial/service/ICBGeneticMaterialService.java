package com.monsanto.tcc.inventorycommon.service.icbgeneticmaterial.service;


import com.monsanto.tcc.inventorycommon.service.icbgeneticmaterial.domain.ICBGeneticMaterial;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: KKTIWA
 * Date: 7/27/12
 * Time: 3:53 PM
 */
@WebService
public interface ICBGeneticMaterialService {

  @WebMethod(operationName = "getICBGeneticMaterial")
  Collection<ICBGeneticMaterial> getICBGeneticMaterial(@WebParam(name = "fieldId") Long fieldId, @WebParam(name = "programId") Long programId);
}