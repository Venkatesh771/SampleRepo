/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.transferobject.inventory.ProgramTO;

import java.util.List;

public class AvailableMaterialReferenceDataRequest {
    private List<ProgramTO> programList;

    public List<ProgramTO> getProgramList() {
        return programList;
    }

    public void setProgramList(List<ProgramTO> programList) {
        this.programList = programList;
    }
}
