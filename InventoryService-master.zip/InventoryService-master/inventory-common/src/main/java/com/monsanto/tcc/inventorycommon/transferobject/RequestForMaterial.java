package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: May 6, 2009
 * Time: 3:54:56 PM
 */
public class RequestForMaterial {
    private List<MaterialRequestDTO> requestDTO;

    public List<MaterialRequestDTO> getRequestData() {
        return requestDTO;
    }

    public void setRequestData(List<MaterialRequestDTO> requestDTO) {
        this.requestDTO = requestDTO;
    }
}
