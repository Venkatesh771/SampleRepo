package com.monsanto.tcc.inventorycommon.domain;

import javax.xml.bind.annotation.XmlElement;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
* User: MDSPARK
* Date: Sep 28, 2009
* Time: 9:53:53 AM
* To change this template use File | Settings | File Templates.
*/
public class ObservationAttributeKeyValuePairList {
    @XmlElement
    private List<ObservationAttributeKeyValuePair> entry = new ArrayList<ObservationAttributeKeyValuePair>();

    public List<ObservationAttributeKeyValuePair> getKeyValuePair() {
        return entry;
    }

    public void setKeyValuePair(List<ObservationAttributeKeyValuePair> entry) {
        this.entry = entry;
    }
}
