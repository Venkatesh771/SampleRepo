/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.inventory;

public class UnitOfMeasureTO {
    private Long id;
    private String name;
    private String refActive;
    private String uomRefId;

    public UnitOfMeasureTO() {
    }

    public UnitOfMeasureTO(Long id, String name, String refActive, String uomRefId) {
        this.id = id;
        this.name = name;
        this.refActive = refActive;
        this.uomRefId = uomRefId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }

    public String getUomRefId() {
        return uomRefId;
    }

    public void setUomRefId(String uomRefId) {
        this.uomRefId = uomRefId;
    }

    @Override
    public String toString() {
        return name;
    }
}
