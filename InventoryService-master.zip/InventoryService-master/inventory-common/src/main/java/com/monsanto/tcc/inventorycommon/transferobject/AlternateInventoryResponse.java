/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.transferobject.inventory.InventoryTO;

import java.util.List;

/**
 * User: jjbens2
 * Date: May 26, 2010
 */
public class AlternateInventoryResponse {

    private Long sourceInventoryId;
    private List<InventoryTO> alternateInventories;

    public AlternateInventoryResponse() {}

    public AlternateInventoryResponse(Long sourceInventoryId) {
        this.sourceInventoryId = sourceInventoryId;
    }

    public AlternateInventoryResponse(Long sourceInventoryId, List<InventoryTO> alternateInventories) {
        this.sourceInventoryId = sourceInventoryId;
        this.alternateInventories = alternateInventories;
    }

    public Long getSourceInventoryId() {
        return sourceInventoryId;
    }

    public void setSourceInventoryId(Long sourceInventoryId) {
        this.sourceInventoryId = sourceInventoryId;
    }

    public List<InventoryTO> getAlternateInventories() {
        return alternateInventories;
    }

    public void setAlternateInventories(List<InventoryTO> alternateInventories) {
        this.alternateInventories = alternateInventories;
    }
}
