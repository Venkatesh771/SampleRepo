/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.breeding.TestSetEntryByEntryType;
import com.monsanto.services.domain.common.AbstractEntity;

import javax.xml.bind.annotation.XmlType;
import java.util.Set;

@XmlType(name = "Entry_Type")
public class EntryType extends AbstractEntity implements Cloneable {
    private Long entryTypeId;
    private String name;
    private String entryTypeRefCode;
    private Boolean check;
    private Long listOrder;
    private Boolean refActive;
    private Long entryTypeCtgyId;
    private Set<TestSetEntryByEntryType> testSetEntryByEntryType;

    public EntryType() {
    }

    public EntryType(Long entryTypeId, String name, Long listOrder) {
        this.entryTypeId = entryTypeId;
        this.name = name;
        this.listOrder = listOrder;
    }

    public EntryType(Long entryTypeId, String name, String refCode, Boolean check, Long listOrder, Long entryTypeCtgyId) {
        this.entryTypeId = entryTypeId;
        this.name = name;
        this.entryTypeRefCode = refCode;
        this.check = check;
        this.listOrder = listOrder;
        this.entryTypeCtgyId = entryTypeCtgyId;
    }

    public Long getEntryTypeId() {
        return entryTypeId;
    }

    public void setEntryTypeId(Long entryId) {
        this.entryTypeId = entryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEntryTypeRefCode() {
        return entryTypeRefCode;
    }

    public void setEntryTypeRefCode(String entryTypeRefCode) {
        this.entryTypeRefCode = entryTypeRefCode;
    }

    public Boolean getCheck() {
        return check;
    }

    public void setCheck(Boolean check) {
        this.check = check;
    }

    public Object getID() {
        return entryTypeId;
    }

    public Long getListOrder() {
        return listOrder;
    }

    public void setListOrder(Long listOrder) {
        this.listOrder = listOrder;
    }

    public Boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(Boolean refActive) {
        this.refActive = refActive;
    }

    public Long getEntryTypeCtgyId() {
        return entryTypeCtgyId;
    }

    public void setEntryTypeCtgyId(Long entryTypeCtgyId) {
        this.entryTypeCtgyId = entryTypeCtgyId;
    }

    public Set<TestSetEntryByEntryType> getTestSetEntryByEntryType() {
        return testSetEntryByEntryType;
    }

    public void setTestSetEntryByEntryType(Set<TestSetEntryByEntryType> testSetEntryByEntryType) {
        this.testSetEntryByEntryType = testSetEntryByEntryType;
    }

    @Override
    public Object clone() {
        EntryType other = new EntryType(entryTypeId, name, listOrder);
        return other;
    }

    public String toString() {
        return getName();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((check == null) ? 0 : check.hashCode());
        result = prime * result + ((entryTypeCtgyId == null) ? 0 : entryTypeCtgyId.hashCode());
        result = prime * result + ((entryTypeId == null) ? 0 : entryTypeId.hashCode());
        result = prime * result + ((listOrder == null) ? 0 : listOrder.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((entryTypeRefCode == null) ? 0 : entryTypeRefCode.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!super.equals(obj)) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        EntryType other = (EntryType) obj;
        if (check == null) {
            if (other.check != null) {
                return false;
            }
        } else if (!check.equals(other.check)) {
            return false;
        }
        if (entryTypeCtgyId == null) {
            if (other.entryTypeCtgyId != null) {
                return false;
            }
        } else if (!entryTypeCtgyId.equals(other.entryTypeCtgyId)) {
            return false;
        }
        if (entryTypeId == null) {
            if (other.entryTypeId != null) {
                return false;
            }
        } else if (!entryTypeId.equals(other.entryTypeId)) {
            return false;
        }
        if (listOrder == null) {
            if (other.listOrder != null) {
                return false;
            }
        } else if (!listOrder.equals(other.listOrder)) {
            return false;
        }
        if (name == null) {
            if (other.name != null) {
                return false;
            }
        } else if (!name.equals(other.name)) {
            return false;
        }
        if (entryTypeRefCode == null) {
            if (other.entryTypeRefCode != null) {
                return false;
            }
        } else if (!entryTypeRefCode.equals(other.entryTypeRefCode)) {
            return false;
        }
        return true;
    }
}