package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: sssing5 Date: May 6, 2009 Time: 4:52:08 PM
 */
public class MaterialRequestDTO {

    private Long materialRequestId;
    private Long providingProgramId;
    private Long requestingProgramId; 
    private String comments;
    private Date requestedDate = new Date(System.currentTimeMillis());
    private List<MaterialRequestDetailDTO> details;
    private String requestingUserIdTxt;

    public Long getMaterialRequestId() {
        return materialRequestId;
    }

    public void setMaterialRequestId(Long materialRequestId) {
        this.materialRequestId = materialRequestId;
    }

    public Long getProvidingProgramId() {
        return providingProgramId;
    }

    public void setProvidingProgramId(Long providingProgramId) {
        this.providingProgramId = providingProgramId;
    }

    public Long getRequestingProgramId() {
        return requestingProgramId;
    }

    public void setRequestingProgramId(Long requestingProgramId) {
        this.requestingProgramId = requestingProgramId;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Date getRequestedDate() {
        return requestedDate;
    }

    public void setRequestedDate(Date requestedDate) {
        this.requestedDate = requestedDate;
    }

    public List<MaterialRequestDetailDTO> getDetails() {
        return details;
    }

    public void setDetails(List<MaterialRequestDetailDTO> details) {
        this.details = details;
    }

    public String getRequestingUserIdTxt() {
        return requestingUserIdTxt;
    }

    public void setRequestingUserId(String requestingUserIdTxt) {
        this.requestingUserIdTxt = requestingUserIdTxt;
    }
}
