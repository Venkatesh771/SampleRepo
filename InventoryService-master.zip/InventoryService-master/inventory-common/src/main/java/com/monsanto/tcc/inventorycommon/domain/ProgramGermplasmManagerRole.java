package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Aug 5, 2009
 * Time: 11:10:35 AM
 */
public class ProgramGermplasmManagerRole {
    private String mail_stop;
    private String ref_active;
    private String br_prog_ref_id;
    private Long br_prog_id;
    private String name;
    private Long crop_id;
    private String midas_program;
    private Long acct_id;
    private Long HAS_GERMPLASM_MANAGER_ROLE;

    public String getMail_stop() {
        return mail_stop;
    }

    public void setMail_stop(String mail_stop) {
        this.mail_stop = mail_stop;
    }

    public String getRef_active() {
        return ref_active;
    }

    public void setRef_active(String ref_active) {
        this.ref_active = ref_active;
    }

    public String getBr_prog_ref_id() {
        return br_prog_ref_id;
    }

    public void setBr_prog_ref_id(String br_prog_ref_id) {
        this.br_prog_ref_id = br_prog_ref_id;
    }

    public Long getBr_prog_id() {
        return br_prog_id;
    }

    public void setBr_prog_id(Long br_prog_id) {
        this.br_prog_id = br_prog_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getCrop_id() {
        return crop_id;
    }

    public void setCrop_id(Long crop_id) {
        this.crop_id = crop_id;
    }

    public String getMidas_program() {
        return midas_program;
    }

    public void setMidas_program(String midas_program) {
        this.midas_program = midas_program;
    }

    public Long getAcct_id() {
        return acct_id;
    }

    public void setAcct_id(Long acct_id) {
        this.acct_id = acct_id;
    }

    public Long getHAS_GERMPLASM_MANAGER_ROLE() {
        return HAS_GERMPLASM_MANAGER_ROLE;
    }

    public void setHAS_GERMPLASM_MANAGER_ROLE(Long HAS_GERMPLASM_MANAGER_ROLE) {
        this.HAS_GERMPLASM_MANAGER_ROLE = HAS_GERMPLASM_MANAGER_ROLE;
    }
}
