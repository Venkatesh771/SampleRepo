package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.breeding.FateReason;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: 5/24/11
 * Time: 11:10 AM
 * To change this template use File | Settings | File Templates.
 */
public class FatedInventory {
    private Long inventoryId;
    private FateReason fateReason;
    private Date fateDate;
    private boolean resetInventoryQuantity;

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public FateReason getFateReason() {
        return fateReason;
    }

    public void setFateReason(FateReason fateReason) {
        this.fateReason = fateReason;
    }

    public Date getFateDate() {
        return fateDate;
    }

    public void setFateDate(Date fateDate) {
        this.fateDate = fateDate;
    }

    public boolean isResetInventoryQuantity() {
        return resetInventoryQuantity;
    }

    public void setResetInventoryQuantity(boolean resetInventoryQuantity) {
        this.resetInventoryQuantity = resetInventoryQuantity;
    }
}
