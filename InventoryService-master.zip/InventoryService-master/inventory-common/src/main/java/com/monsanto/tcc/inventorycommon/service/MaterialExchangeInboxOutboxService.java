package com.monsanto.tcc.inventorycommon.service;

import com.monsanto.tcc.inventorycommon.service.exception.MaterialExchangeException;
import com.monsanto.tcc.inventorycommon.transferobject.InactiveInventoryResponse;
import com.monsanto.tcc.inventorycommon.transferobject.MaterialExchangeReferenceDataResponse;
import com.monsanto.tcc.inventorycommon.transferobject.materialexchange.*;

import javax.jws.WebService;
import java.util.List;

@WebService
public interface MaterialExchangeInboxOutboxService {

    InactiveInventoryResponse getInactiveInventory(List<Long> activeProgramIds) throws MaterialExchangeException;

    MaterialExchangeResponse acceptMaterialExchange(List<MaterialExchangeAcceptRequest> materialExchangeAcceptRequests);

    MaterialExchangeReferenceDataResponse getMaterialExchangeReferenceData() throws MaterialExchangeException;

    MaterialExchangeResponse undoReject(MaterialExchangeUndoRejectRequest materialExchangeUndoRejectRequest) throws MaterialExchangeException;

    MaterialExchangeResponse rejectMaterialExchange(MaterialExchangeRejectRequest materialExchangeRejectRequest) throws MaterialExchangeException;
}
