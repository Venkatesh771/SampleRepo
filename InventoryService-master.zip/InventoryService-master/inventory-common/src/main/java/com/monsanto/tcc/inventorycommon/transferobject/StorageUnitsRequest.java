package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.common.filter.Filter;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 26, 2010
 * Time: 7:47:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class StorageUnitsRequest {

    private List<Filter> storageUnitFilters;

    public List<Filter> getStorageUnitFilters() {
        return storageUnitFilters;
    }

    public void setStorageUnitFilters(List<Filter> storageUnitFilters) {
        this.storageUnitFilters = storageUnitFilters;
    }
}
