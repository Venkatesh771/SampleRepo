package com.monsanto.tcc.inventorycommon.domain;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: SSNALL Date: Mar 3, 2010 Time: 10:42:05 AM To change this template use File | Settings | File Templates.
 */
public class SubSiteTO {
    private Long subSiteId;
    private String name;
    private String description;
    private Long subSiteTypeId;
    private Long siteId;
    private Date inactiveDttm;
    private Collection<SubSubSiteTO> subSubSitesBySubSiteIdTO;

    public Long getSubSiteId() {
        return subSiteId;
    }

    public void setSubSiteId(Long subSiteId) {
        this.subSiteId = subSiteId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getSubSiteTypeId() {
        return subSiteTypeId;
    }

    public void setSubSiteTypeId(Long subSiteTypeId) {
        this.subSiteTypeId = subSiteTypeId;
    }

    public Long getSiteId() {
        return siteId;
    }

    public void setSiteId(Long siteId) {
        this.siteId = siteId;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SubSiteTO subSiteTO = (SubSiteTO) o;

        if (name != null ? !name.equals(subSiteTO.name) : subSiteTO.name != null) {
            return false;
        }
        if (subSiteId != null ? !subSiteId.equals(subSiteTO.subSiteId) : subSiteTO.subSiteId != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = subSiteId != null ? subSiteId.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }

    public Collection<SubSubSiteTO> getSubSubSitesBySubSiteId() {
        return subSubSitesBySubSiteIdTO;
    }

    public void setSubSubSitesBySubSiteId(Collection<SubSubSiteTO> subSubSitesBySubSiteIdTO) {
        this.subSubSitesBySubSiteIdTO = subSubSitesBySubSiteIdTO;
    }

}
