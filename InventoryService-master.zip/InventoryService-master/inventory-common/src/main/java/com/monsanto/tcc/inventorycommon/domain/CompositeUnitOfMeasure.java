package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.breeding.uom.UnitOfMeasure;

public class CompositeUnitOfMeasure {

    private Long id;
    private UnitOfMeasure unitOfMeasure;
    private Measurement measurement;
    private MeasurementSystem measurementSystem;
    private boolean precisionAllowed;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public UnitOfMeasure getUnitOfMeasure() {
        return unitOfMeasure;
    }

    public void setUnitOfMeasure(UnitOfMeasure unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }

    public Measurement getMeasurement() {
        return measurement;
    }

    public void setMeasurement(Measurement measurement) {
        this.measurement = measurement;
    }

    public MeasurementSystem getMeasurementSystem() {
        return measurementSystem;
    }

    public void setMeasurementSystem(MeasurementSystem measurementSystem) {
        this.measurementSystem = measurementSystem;
    }

    public boolean isPrecisionAllowed() {
        return precisionAllowed;
    }

    public void setPrecisionAllowed(boolean precisionAllowed) {
        this.precisionAllowed = precisionAllowed;
    }

    @Override
    public String toString() {
        return unitOfMeasure.toString();
    }
}
