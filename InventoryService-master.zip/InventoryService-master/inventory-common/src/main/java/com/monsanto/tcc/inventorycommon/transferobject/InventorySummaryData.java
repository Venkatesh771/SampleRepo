package com.monsanto.tcc.inventorycommon.transferobject;

import org.springframework.util.StringUtils;

import java.util.Collection;
import java.util.Date;

@SuppressWarnings({"UnusedDeclaration"})
public class InventorySummaryData {

    private static final String STORAGE_UNIT_DISPLAY_DNML_DELIMITER = "\\";

    private String germplasmPedigree;
    private String geneticMaterialSource;
    private Double inventorySeedQuantity;
    private String inventoryBarcode;
    private String germplasmEvent;
    private String germplasmConstruct;
    private Long orionLotNumber;
    private String germplasmLineCode;
    private String inventoryOwnerProgram;
    private Long inventoryOwnerProgramId;
    private Boolean shared;
    private Boolean inventoryPreviewStatus;
    private String monNumber;
    private String inventoryComments;
    private String inventoryVirgoId;
    private String inventoryGoiText;
    private String geneticMaterialGeneration;
    private String geneticMaterialTransformationGeneration;
    private String geneticMaterialInbredLineRating;
    private Date geneticMaterialInbredLineRatingTimestamp;
    private String geneticMaterialLineage;
    private String geneticMaterialTester;
    private String geneticMaterialRubiconProjectDisplay;
    private String geneticMaterialRubiconDecisionDisplay;
    private Integer geneticMaterialSourceAbsoluteColumn;
    private Integer geneticMaterialSourceAbsoluteRange;
    private String geneticMaterialSourceCrop;
    private Integer geneticMaterialSourceHarvestMonth;
    private Integer geneticMaterialSourceHarvestYear;
    private String geneticMaterialSourceLocation;
    private Integer geneticMaterialSourceSequenceNumber;
    private String geneticMaterialSourceLotNumber;
    private Integer geneticMaterialSourceMaleColumn;
    private Integer geneticMaterialSourceMaleSequenceNumber;
    private Integer geneticMaterialSourceMaleSubRowNumber;
    private Integer geneticMaterialSourceMaleRange;
    private String geneticMaterialSourceOperation;
    private String geneticMaterialSourceOriginatorCountry;
    private String geneticMaterialSourceOriginatorProgram;
    private Integer geneticMaterialSourcePlantMonth;
    private Integer geneticMaterialSourcePlantYear;
    private Integer geneticMaterialSourcePlotNumber;
    private Integer geneticMaterialSourceRepNumber;
    private Integer geneticMaterialSourceEntryNumber;
    private String geneticMaterialSourceSet;
    private Integer geneticMaterialSourceSubRowNumber;
    private Integer geneticMaterialSourceSubSubRowNumber;
    private String geneticMaterialSourceTrackId;
    private String geneticMaterialSourceMaleProgram;
    private String geneticMaterialSourceSeason;
    private String geneticMaterialSourcePlotBarcode;
    private String geneticMaterialSourceProtocolName;
    private Date geneticMaterialSourcePollinationDate;
    private String storageUnitBarcode;
    private Double germplasmHoldensRefIndex;
    private String germplasmRestriction;
    private String germplasmCytoplasmDonor;
    private String germplasmRemRefNumber;
    private Long germplasmVirgoId;
    private Long germplasmLineFunctionId;
    private String germplasmLineFunction;
    private Boolean germplasmLineFunctionChanged = Boolean.FALSE;
    private Long germplasmLineTypeId;
    private String germplasmLineType;
    private String germplasmOwnerProgram;
    private Long germplasmOwnerProgramId;
    private String productName;
    private String preCommercialProductName;
    private String brandName;
    private String vegetativeStructure;
    private Collection<Integer> rubiconSampleNumbers;
    private String numKernalsPerEar;
    private String warmPercentGerm;
    private String coldPercentGerm;
    private Date germinationDate;
    private String treatment;
    private String quality;
    private Date receiveDate;
    private Double originQuantity;
    private String originQuantityUOM;
    private Long originQuantityUomId;
    private Integer currentQuantity;
    private String currentQuantityUOM;
    private String shortSource;
    private String inventoryType;
    private Long inventoryId;
    private Long geneticMaterialId;
    private Long germplasmId;
    private Long inventoryTypeId;
    private String inventoryAlphaSort1;
    private String inventoryAlphaSort2;
    private String inventoryAlphaSort3;
    private String inventoryAlphaSort4;
    private String inventoryAlphaSort5;
    private Double inventoryNumericSort1;
    private Double inventoryNumericSort2;
    private Double inventoryNumericSort3;
    private Double inventoryNumericSort4;
    private Double inventoryNumericSort5;
    private Long cropId;
    private String cropName;
    private String fateName;
    private Long fateReasonId;
    private String storageUnitDisplayDNML;
    private String genus;
    private String currentLocBID;
    private String species;
    private Date inventoryCreationDate;
    private Date fateDate;
    private String inventoryStatusName;
    private String inventorySeedTreatment;
    private String germplasmOrigin;
    private Date inventoryOriginDate;
    private String parentInventoryBID;
    private Date readyForTransformationDate;
    private Double seedQuantity;
    private String seedQuantityUOM;
    private Long seedQuantityUomId;
    private String geneticMaterialSrcGrowerProgram;
    private String geneticMaterialSrcMalePlotBID;
    private Double subInventoryQuantity;
    private String transformationGenotype;
    private String storageContainerName;
    private Boolean isActive;
    private Long inbredBaseId;
    private String inbredBaseName;
    private String germplasmOldPedigree;
    private Double advanceInvSimilaritySrcRank;
    private String storageSite;
    private String storageSubSite;
    private String storageSubSubSite;
    private String bulkReason;
    private Boolean inventoryIsPlaced;
    private String inventoryPurpose;
    private String modifiedUserName;
    private Date modifiedDate;
    private String geneticMaterialSrcSelection;
    private Long geneticMaterialSrcAdvNumber;
    private Integer geneticMaterialSrcMalePlotNbr;
    private String germplasmCrossName;
    private String germplasmCrossOwnerBrProgId;
    private String germplasmCrossContactUserFirstName;
    private String germplasmCrossContactUserLastName;
    private Integer touCount;
    private Boolean touRestriction;
    private String templateText;
    private Date inventorySeedProcessingDate;
    private Collection<Long> inventorySampleNbrs;
    private Collection<String> molecularBreedingRequestNbrs;


    public String getBulkReason() {
        return bulkReason;
    }

    public void setBulkReason(String bulkReason) {
        this.bulkReason = bulkReason;
    }


    public Boolean getInventoryIsPlaced() {
        return inventoryIsPlaced;
    }

    public void setInventoryIsPlaced(Boolean inventoryIsPlaced) {
        this.inventoryIsPlaced = inventoryIsPlaced;
    }

    public String getInventoryPurpose() {
        return inventoryPurpose;
    }

    public void setInventoryPurpose(String inventoryPurpose) {
        this.inventoryPurpose = inventoryPurpose;
    }


    public String getGermplasmPedigree() {
        return germplasmPedigree;
    }

    public void setGermplasmPedigree(String germplasmPedigree) {
        this.germplasmPedigree = germplasmPedigree;
    }

    public String getGeneticMaterialSource() {
        return geneticMaterialSource;
    }

    public void setGeneticMaterialSource(String geneticMaterialSource) {
        this.geneticMaterialSource = geneticMaterialSource;
    }

    public Double getInventorySeedQuantity() {
        return inventorySeedQuantity;
    }

    public void setInventorySeedQuantity(Double inventorySeedQuantity) {
        this.inventorySeedQuantity = inventorySeedQuantity;
    }

    public String getInventoryBarcode() {
        return inventoryBarcode;
    }

    public void setInventoryBarcode(String inventoryBarcode) {
        this.inventoryBarcode = inventoryBarcode;
    }

    public String getGermplasmEvent() {
        return germplasmEvent;
    }

    public void setGermplasmEvent(String germplasmEvent) {
        this.germplasmEvent = germplasmEvent;
    }

    public String getGermplasmConstruct() {
        return germplasmConstruct;
    }

    public void setGermplasmConstruct(String germplasmConstruct) {
        this.germplasmConstruct = germplasmConstruct;
    }

    public Long getOrionLotNumber() {
        return orionLotNumber;
    }

    public void setOrionLotNumber(Long orionLotNumber) {
        this.orionLotNumber = orionLotNumber;
    }

    public String getGermplasmLineCode() {
        return germplasmLineCode;
    }

    public void setGermplasmLineCode(String germplasmLineCode) {
        this.germplasmLineCode = germplasmLineCode;
    }

    public String getInventoryOwnerProgram() {
        return inventoryOwnerProgram;
    }

    public void setInventoryOwnerProgram(String inventoryOwnerProgram) {
        this.inventoryOwnerProgram = inventoryOwnerProgram;
    }

    public Boolean isShared() {
        return shared;
    }

    public void setShared(Boolean shared) {
        this.shared = shared;
    }

    public String getMonNumber() {
        return monNumber;
    }

    public void setMonNumber(String monNumber) {
        this.monNumber = monNumber;
    }

    public String getInventoryComments() {
        return inventoryComments;
    }

    public void setInventoryComments(String inventoryComments) {
        this.inventoryComments = inventoryComments;
    }

    public String getInventoryVirgoId() {
        return inventoryVirgoId;
    }

    public void setInventoryVirgoId(String inventoryVirgoId) {
        this.inventoryVirgoId = inventoryVirgoId;
    }

    public String getInventoryGoiText() {
        return inventoryGoiText;
    }

    public void setInventoryGoiText(String inventoryGoiText) {
        this.inventoryGoiText = inventoryGoiText;
    }

    public String getGeneticMaterialGeneration() {
        return geneticMaterialGeneration;
    }

    public void setGeneticMaterialGeneration(String geneticMaterialGeneration) {
        this.geneticMaterialGeneration = geneticMaterialGeneration;
    }


    public String getGeneticMaterialInbredLineRating() {
        return geneticMaterialInbredLineRating;
    }

    public void setGeneticMaterialInbredLineRating(String geneticMaterialInbredLineRating) {
        this.geneticMaterialInbredLineRating = geneticMaterialInbredLineRating;
    }

    public Date getGeneticMaterialInbredLineRatingTimestamp() {
        return geneticMaterialInbredLineRatingTimestamp;
    }

    public void setGeneticMaterialInbredLineRatingTimestamp(Date geneticMaterialInbredLineRatingTimestamp) {
        this.geneticMaterialInbredLineRatingTimestamp = geneticMaterialInbredLineRatingTimestamp;
    }

    public String getGeneticMaterialLineage() {
        return geneticMaterialLineage;
    }

    public void setGeneticMaterialLineage(String geneticMaterialLineage) {
        this.geneticMaterialLineage = geneticMaterialLineage;
    }

    public String getGeneticMaterialTester() {
        return geneticMaterialTester;
    }

    public void setGeneticMaterialTester(String geneticMaterialTester) {
        this.geneticMaterialTester = geneticMaterialTester;
    }

    public String getGeneticMaterialRubiconProjectDisplay() {
        return geneticMaterialRubiconProjectDisplay;
    }

    public void setGeneticMaterialRubiconProjectDisplay(String geneticMaterialRubiconProjectDisplay) {
        this.geneticMaterialRubiconProjectDisplay = geneticMaterialRubiconProjectDisplay;
    }

    public String getGeneticMaterialRubiconDecisionDisplay() {
        return geneticMaterialRubiconDecisionDisplay;
    }

    public void setGeneticMaterialRubiconDecisionDisplay(String geneticMaterialRubiconDecisionDisplay) {
        this.geneticMaterialRubiconDecisionDisplay = geneticMaterialRubiconDecisionDisplay;
    }

    public Integer getGeneticMaterialSourceAbsoluteColumn() {
        return geneticMaterialSourceAbsoluteColumn;
    }

    public void setGeneticMaterialSourceAbsoluteColumn(Integer geneticMaterialSourceAbsoluteColumn) {
        this.geneticMaterialSourceAbsoluteColumn = geneticMaterialSourceAbsoluteColumn;
    }

    public Integer getGeneticMaterialSourceAbsoluteRange() {
        return geneticMaterialSourceAbsoluteRange;
    }

    public void setGeneticMaterialSourceAbsoluteRange(Integer geneticMaterialSourceAbsoluteRange) {
        this.geneticMaterialSourceAbsoluteRange = geneticMaterialSourceAbsoluteRange;
    }

    public String getGeneticMaterialSourceCrop() {
        return geneticMaterialSourceCrop;
    }

    public void setGeneticMaterialSourceCrop(String geneticMaterialSourceCrop) {
        this.geneticMaterialSourceCrop = geneticMaterialSourceCrop;
    }

    public Integer getGeneticMaterialSourceHarvestMonth() {
        return geneticMaterialSourceHarvestMonth;
    }

    public void setGeneticMaterialSourceHarvestMonth(Integer geneticMaterialSourceHarvestMonth) {
        this.geneticMaterialSourceHarvestMonth = geneticMaterialSourceHarvestMonth;
    }

    public Integer getGeneticMaterialSourceHarvestYear() {
        return geneticMaterialSourceHarvestYear;
    }

    public void setGeneticMaterialSourceHarvestYear(Integer geneticMaterialSourceHarvestYear) {
        this.geneticMaterialSourceHarvestYear = geneticMaterialSourceHarvestYear;
    }

    public String getGeneticMaterialSourceLocation() {
        return geneticMaterialSourceLocation;
    }

    public void setGeneticMaterialSourceLocation(String geneticMaterialSourceLocation) {
        this.geneticMaterialSourceLocation = geneticMaterialSourceLocation;
    }

    public Integer getGeneticMaterialSourceSequenceNumber() {
        return geneticMaterialSourceSequenceNumber;
    }

    public void setGeneticMaterialSourceSequenceNumber(Integer geneticMaterialSourceSequenceNumber) {
        this.geneticMaterialSourceSequenceNumber = geneticMaterialSourceSequenceNumber;
    }

    public String getGeneticMaterialSourceLotNumber() {
        return geneticMaterialSourceLotNumber;
    }

    public void setGeneticMaterialSourceLotNumber(String geneticMaterialSourceLotNumber) {
        this.geneticMaterialSourceLotNumber = geneticMaterialSourceLotNumber;
    }

    public Integer getGeneticMaterialSourceMaleColumn() {
        return geneticMaterialSourceMaleColumn;
    }

    public String getGeneticMaterialTransformationGeneration() {
        return geneticMaterialTransformationGeneration;
    }

    public void setGeneticMaterialTransformationGeneration(String geneticMaterialTransformationGeneration) {
        this.geneticMaterialTransformationGeneration = geneticMaterialTransformationGeneration;
    }

    public void setGeneticMaterialSourceMaleColumn(Integer geneticMaterialSourceMaleColumn) {
        this.geneticMaterialSourceMaleColumn = geneticMaterialSourceMaleColumn;
    }

    public Integer getGeneticMaterialSourceMaleSequenceNumber() {
        return geneticMaterialSourceMaleSequenceNumber;
    }

    public void setGeneticMaterialSourceMaleSequenceNumber(Integer geneticMaterialSourceMaleSequenceNumber) {
        this.geneticMaterialSourceMaleSequenceNumber = geneticMaterialSourceMaleSequenceNumber;
    }

    public Integer getGeneticMaterialSourceMaleSubRowNumber() {
        return geneticMaterialSourceMaleSubRowNumber;
    }

    public void setGeneticMaterialSourceMaleSubRowNumber(Integer geneticMaterialSourceMaleSubRowNumber) {
        this.geneticMaterialSourceMaleSubRowNumber = geneticMaterialSourceMaleSubRowNumber;
    }

    public Integer getGeneticMaterialSourceMaleRange() {
        return geneticMaterialSourceMaleRange;
    }

    public void setGeneticMaterialSourceMaleRange(Integer geneticMaterialSourceMaleRange) {
        this.geneticMaterialSourceMaleRange = geneticMaterialSourceMaleRange;
    }

    public String getGeneticMaterialSourceOperation() {
        return geneticMaterialSourceOperation;
    }

    public void setGeneticMaterialSourceOperation(String geneticMaterialSourceOperation) {
        this.geneticMaterialSourceOperation = geneticMaterialSourceOperation;
    }

    public String getGeneticMaterialSourceOriginatorCountry() {
        return geneticMaterialSourceOriginatorCountry;
    }

    public void setGeneticMaterialSourceOriginatorCountry(String geneticMaterialSourceOriginatorCountry) {
        this.geneticMaterialSourceOriginatorCountry = geneticMaterialSourceOriginatorCountry;
    }

    public String getGeneticMaterialSourceOriginatorProgram() {
        return geneticMaterialSourceOriginatorProgram;
    }

    public void setGeneticMaterialSourceOriginatorProgram(String geneticMaterialSourceOriginatorProgram) {
        this.geneticMaterialSourceOriginatorProgram = geneticMaterialSourceOriginatorProgram;
    }

    public Integer getGeneticMaterialSourcePlantMonth() {
        return geneticMaterialSourcePlantMonth;
    }

    public void setGeneticMaterialSourcePlantMonth(Integer geneticMaterialSourcePlantMonth) {
        this.geneticMaterialSourcePlantMonth = geneticMaterialSourcePlantMonth;
    }

    public Integer getGeneticMaterialSourcePlantYear() {
        return geneticMaterialSourcePlantYear;
    }

    public void setGeneticMaterialSourcePlantYear(Integer geneticMaterialSourcePlantYear) {
        this.geneticMaterialSourcePlantYear = geneticMaterialSourcePlantYear;
    }

    public Integer getGeneticMaterialSourcePlotNumber() {
        return geneticMaterialSourcePlotNumber;
    }

    public void setGeneticMaterialSourcePlotNumber(Integer geneticMaterialSourcePlotNumber) {
        this.geneticMaterialSourcePlotNumber = geneticMaterialSourcePlotNumber;
    }

    public Integer getGeneticMaterialSourceRepNumber() {
        return geneticMaterialSourceRepNumber;
    }

    public void setGeneticMaterialSourceRepNumber(Integer geneticMaterialSourceRepNumber) {
        this.geneticMaterialSourceRepNumber = geneticMaterialSourceRepNumber;
    }

    public Integer getGeneticMaterialSourceEntryNumber() {
        return geneticMaterialSourceEntryNumber;
    }

    public void setGeneticMaterialSourceEntryNumber(Integer geneticMaterialSourceEntryNumber) {
        this.geneticMaterialSourceEntryNumber = geneticMaterialSourceEntryNumber;
    }

    public String getGeneticMaterialSourceSet() {
        return geneticMaterialSourceSet;
    }

    public void setGeneticMaterialSourceSet(String geneticMaterialSourceSet) {
        this.geneticMaterialSourceSet = geneticMaterialSourceSet;
    }

    public Integer getGeneticMaterialSourceSubRowNumber() {
        return geneticMaterialSourceSubRowNumber;
    }

    public void setGeneticMaterialSourceSubRowNumber(Integer geneticMaterialSourceSubRowNumber) {
        this.geneticMaterialSourceSubRowNumber = geneticMaterialSourceSubRowNumber;
    }

    public Integer getGeneticMaterialSourceSubSubRowNumber() {
        return geneticMaterialSourceSubSubRowNumber;
    }

    public void setGeneticMaterialSourceSubSubRowNumber(Integer geneticMaterialSourceSubSubRowNumber) {
        this.geneticMaterialSourceSubSubRowNumber = geneticMaterialSourceSubSubRowNumber;
    }

    public String getGeneticMaterialSourceTrackId() {
        return geneticMaterialSourceTrackId;
    }

    public void setGeneticMaterialSourceTrackId(String geneticMaterialSourceTrackId) {
        this.geneticMaterialSourceTrackId = geneticMaterialSourceTrackId;
    }

    public String getGeneticMaterialSourceMaleProgram() {
        return geneticMaterialSourceMaleProgram;
    }

    public void setGeneticMaterialSourceMaleProgram(String geneticMaterialSourceMaleProgram) {
        this.geneticMaterialSourceMaleProgram = geneticMaterialSourceMaleProgram;
    }

    public String getGeneticMaterialSourceSeason() {
        return geneticMaterialSourceSeason;
    }

    public void setGeneticMaterialSourceSeason(String geneticMaterialSourceSeason) {
        this.geneticMaterialSourceSeason = geneticMaterialSourceSeason;
    }

    public String getGeneticMaterialSourcePlotBarcode() {
        return geneticMaterialSourcePlotBarcode;
    }

    public void setGeneticMaterialSourcePlotBarcode(String geneticMaterialSourcePlotBarcode) {
        this.geneticMaterialSourcePlotBarcode = geneticMaterialSourcePlotBarcode;
    }

    public String getGeneticMaterialSourceProtocolName() {
        return geneticMaterialSourceProtocolName;
    }

    public void setGeneticMaterialSourceProtocolName(String geneticMaterialSourceProtocolName) {
        this.geneticMaterialSourceProtocolName = geneticMaterialSourceProtocolName;
    }

    public Date getGeneticMaterialSourcePollinationDate() {
        return geneticMaterialSourcePollinationDate;
    }

    public void setGeneticMaterialSourcePollinationDate(Date geneticMaterialSourcePollinationDate) {
        this.geneticMaterialSourcePollinationDate = geneticMaterialSourcePollinationDate;
    }

    public String getStorageUnitBarcode() {
        return storageUnitBarcode;
    }

    public void setStorageUnitBarcode(String storageUnitBarcode) {
        this.storageUnitBarcode = storageUnitBarcode;
    }

    public Double getGermplasmHoldensRefIndex() {
        return germplasmHoldensRefIndex;
    }

    public void setGermplasmHoldensRefIndex(Double germplasmHoldensRefIndex) {
        this.germplasmHoldensRefIndex = germplasmHoldensRefIndex;
    }

    public String getGermplasmRestriction() {
        return germplasmRestriction;
    }

    public void setGermplasmRestriction(String germplasmRestriction) {
        this.germplasmRestriction = germplasmRestriction;
    }

    public String getGermplasmCytoplasmDonor() {
        return germplasmCytoplasmDonor;
    }

    public void setGermplasmCytoplasmDonor(String germplasmCytoplasmDonor) {
        this.germplasmCytoplasmDonor = germplasmCytoplasmDonor;
    }

    public String getGermplasmRemRefNumber() {
        return germplasmRemRefNumber;
    }

    public void setGermplasmRemRefNumber(String germplasmRemRefNumber) {
        this.germplasmRemRefNumber = germplasmRemRefNumber;
    }

    public Long getGermplasmVirgoId() {
        return germplasmVirgoId;
    }

    public void setGermplasmVirgoId(Long germplasmVirgoId) {
        this.germplasmVirgoId = germplasmVirgoId;
    }

    public Long getGermplasmLineFunctionId() {
        return germplasmLineFunctionId;
    }

    public void setGermplasmLineFunctionId(Long germplasmLineFunctionId) {
        this.germplasmLineFunctionId = germplasmLineFunctionId;
    }

    public String getGermplasmOwnerProgram() {
        return germplasmOwnerProgram;
    }

    public void setGermplasmOwnerProgram(String germplasmOwnerProgram) {
        this.germplasmOwnerProgram = germplasmOwnerProgram;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getPreCommercialProductName() {
        return preCommercialProductName;
    }

    public void setPreCommercialProductName(String preCommercialProductName) {
        this.preCommercialProductName = preCommercialProductName;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getVegetativeStructure() {
        return vegetativeStructure;
    }

    public void setVegetativeStructure(String vegetativeStructure) {
        this.vegetativeStructure = vegetativeStructure;
    }

    public Collection<Integer> getRubiconSampleNumbers() {
        return rubiconSampleNumbers;
    }

    public void setRubiconSampleNumbers(Collection<Integer> rubiconSampleNumbers) {
        this.rubiconSampleNumbers = rubiconSampleNumbers;
    }

    public String getNumKernalsPerEar() {
        return numKernalsPerEar;
    }

    public void setNumKernalsPerEar(String numKernalsPerEar) {
        this.numKernalsPerEar = numKernalsPerEar;
    }

    public String getWarmPercentGerm() {
        return warmPercentGerm;
    }

    public void setWarmPercentGerm(String warmPercentGerm) {
        this.warmPercentGerm = warmPercentGerm;
    }

    public String getColdPercentGerm() {
        return coldPercentGerm;
    }

    public void setColdPercentGerm(String coldPercentGerm) {
        this.coldPercentGerm = coldPercentGerm;
    }

    public Date getGerminationDate() {
        return germinationDate;
    }

    public void setGerminationDate(Date germinationDate) {
        this.germinationDate = germinationDate;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public Date getReceiveDate() {
        return receiveDate;
    }

    public void setReceiveDate(Date receiveDate) {
        this.receiveDate = receiveDate;
    }

    public Double getOriginQuantity() {
        return originQuantity;
    }

    public void setOriginQuantity(Double originQuantity) {
        this.originQuantity = originQuantity;
    }

    public String getOriginQuantityUOM() {
        return originQuantityUOM;
    }

    public void setOriginQuantityUOM(String originQuantityUOM) {
        this.originQuantityUOM = originQuantityUOM;
    }

    public Long getOriginQuantityUomId() {
        return originQuantityUomId;
    }

    public void setOriginQuantityUomId(Long originQuantityUomId) {
        this.originQuantityUomId = originQuantityUomId;
    }

    public Integer getCurrentQuantity() {
        return currentQuantity;
    }

    public void setCurrentQuantity(Integer currentQuantity) {
        this.currentQuantity = currentQuantity;
    }

    public String getCurrentQuantityUOM() {
        return currentQuantityUOM;
    }

    public void setCurrentQuantityUOM(String currentQuantityUOM) {
        this.currentQuantityUOM = currentQuantityUOM;
    }

    public String getShortSource() {
        return shortSource;
    }

    public void setShortSource(String shortSource) {
        this.shortSource = shortSource;
    }

    public String getInventoryType() {
        return inventoryType;
    }

    public void setInventoryType(String inventoryType) {
        this.inventoryType = inventoryType;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Long getGeneticMaterialId() {
        return geneticMaterialId;
    }

    public void setGeneticMaterialId(Long geneticMaterialId) {
        this.geneticMaterialId = geneticMaterialId;
    }

    public Long getGermplasmId() {
        return germplasmId;
    }

    public void setGermplasmId(Long germplasmId) {
        this.germplasmId = germplasmId;
    }

    public Long getInventoryTypeId() {
        return inventoryTypeId;
    }

    public void setInventoryTypeId(Long inventoryTypeId) {
        this.inventoryTypeId = inventoryTypeId;
    }

    public String getGermplasmLineFunction() {
        return germplasmLineFunction;
    }

    public void setGermplasmLineFunction(String germplasmLineFunction) {
        this.germplasmLineFunction = germplasmLineFunction;
    }

    public Boolean getGermplasmLineFunctionChanged() {
        return germplasmLineFunctionChanged;
    }

    public void setGermplasmLineFunctionChanged(Boolean germplasmLineFunctionChanged) {
        this.germplasmLineFunctionChanged = germplasmLineFunctionChanged;
    }

    public Long getGermplasmLineTypeId() {
        return germplasmLineTypeId;
    }

    public void setGermplasmLineTypeId(Long germplasmLineTypeId) {
        this.germplasmLineTypeId = germplasmLineTypeId;
    }

    public String getGermplasmLineType() {
        return germplasmLineType;
    }

    public void setGermplasmLineType(String germplasmLineType) {
        this.germplasmLineType = germplasmLineType;
    }

    public Long getGermplasmOwnerProgramId() {
        return germplasmOwnerProgramId;
    }

    public void setGermplasmOwnerProgramId(Long germplasmOwnerProgramId) {
        this.germplasmOwnerProgramId = germplasmOwnerProgramId;
    }

    public Long getInventoryOwnerProgramId() {
        return inventoryOwnerProgramId;
    }

    public void setInventoryOwnerProgramId(Long inventoryOwnerProgramId) {
        this.inventoryOwnerProgramId = inventoryOwnerProgramId;
    }

    public String getInventoryAlphaSort1() {
        return inventoryAlphaSort1;
    }

    public void setInventoryAlphaSort1(String inventoryAlphaSort1) {
        this.inventoryAlphaSort1 = inventoryAlphaSort1;
    }

    public String getInventoryAlphaSort2() {
        return inventoryAlphaSort2;
    }

    public void setInventoryAlphaSort2(String inventoryAlphaSort2) {
        this.inventoryAlphaSort2 = inventoryAlphaSort2;
    }

    public String getInventoryAlphaSort3() {
        return inventoryAlphaSort3;
    }

    public void setInventoryAlphaSort3(String inventoryAlphaSort3) {
        this.inventoryAlphaSort3 = inventoryAlphaSort3;
    }

    public String getInventoryAlphaSort4() {
        return inventoryAlphaSort4;
    }

    public void setInventoryAlphaSort4(String inventoryAlphaSort4) {
        this.inventoryAlphaSort4 = inventoryAlphaSort4;
    }

    public String getInventoryAlphaSort5() {
        return inventoryAlphaSort5;
    }

    public void setInventoryAlphaSort5(String inventoryAlphaSort5) {
        this.inventoryAlphaSort5 = inventoryAlphaSort5;
    }

    public Double getInventoryNumericSort1() {
        return inventoryNumericSort1;
    }

    public void setInventoryNumericSort1(Double inventoryNumericSort1) {
        this.inventoryNumericSort1 = inventoryNumericSort1;
    }

    public Double getInventoryNumericSort2() {
        return inventoryNumericSort2;
    }

    public void setInventoryNumericSort2(Double inventoryNumericSort2) {
        this.inventoryNumericSort2 = inventoryNumericSort2;
    }

    public Double getInventoryNumericSort3() {
        return inventoryNumericSort3;
    }

    public void setInventoryNumericSort3(Double inventoryNumericSort3) {
        this.inventoryNumericSort3 = inventoryNumericSort3;
    }

    public Double getInventoryNumericSort4() {
        return inventoryNumericSort4;
    }

    public void setInventoryNumericSort4(Double inventoryNumericSort4) {
        this.inventoryNumericSort4 = inventoryNumericSort4;
    }

    public Double getInventoryNumericSort5() {
        return inventoryNumericSort5;
    }

    public void setInventoryNumericSort5(Double inventoryNumericSort5) {
        this.inventoryNumericSort5 = inventoryNumericSort5;
    }

    public Boolean isInventoryPreviewStatus() {
        return inventoryPreviewStatus;
    }

    public void setInventoryPreviewStatus(Boolean inventoryPreviewStatus) {
        this.inventoryPreviewStatus = inventoryPreviewStatus;
    }

    public Long getCropId() {
        return cropId;
    }

    public void setCropId(Long cropId) {
        this.cropId = cropId;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public Long getFateReasonId() {
        return fateReasonId;
    }

    public void setFateReasonId(Long fateReasonId) {
        this.fateReasonId = fateReasonId;
    }

    public String getFateName() {
        return fateName;
    }

    public void setFateName(String fateName) {
        this.fateName = fateName;
    }

    public String getStorageUnitDisplayDNML() {
        return storageUnitDisplayDNML;
    }

    public void setStorageUnitDisplayDNML(String storageUnitDisplayDNML) {
        this.storageUnitDisplayDNML = storageUnitDisplayDNML;
        parseStorageUnitDisplayDNML();
    }

    public String getGenus() {
        return genus;
    }

    public void setGenus(String genus) {
        this.genus = genus;
    }

    public String getCurrentLocBID() {
        return currentLocBID;
    }

    public void setCurrentLocBID(String currentLocBID) {
        this.currentLocBID = currentLocBID;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public Date getInventoryCreationDate() {
        return inventoryCreationDate;
    }

    public void setInventoryCreationDate(Date inventoryCreationDate) {
        this.inventoryCreationDate = inventoryCreationDate;
    }

    public Date getFateDate() {
        return fateDate;
    }

    public void setFateDate(Date fateDate) {
        this.fateDate = fateDate;
    }

    public String getInventoryStatusName() {
        return inventoryStatusName;
    }

    public void setInventoryStatusName(String inventoryStatusName) {
        this.inventoryStatusName = inventoryStatusName;
    }

    public String getInventorySeedTreatment() {
        return inventorySeedTreatment;
    }

    public void setInventorySeedTreatment(String inventorySeedTreatment) {
        this.inventorySeedTreatment = inventorySeedTreatment;
    }

    public String getGermplasmOrigin() {
        return germplasmOrigin;
    }

    public void setGermplasmOrigin(String germplasmOrigin) {
        this.germplasmOrigin = germplasmOrigin;
    }

    public Date getInventoryOriginDate() {
        return inventoryOriginDate;
    }

    public void setInventoryOriginDate(Date inventoryOriginDate) {
        this.inventoryOriginDate = inventoryOriginDate;
    }

    public String getParentInventoryBID() {
        return parentInventoryBID;
    }

    public void setParentInventoryBID(String parentInventoryBID) {
        this.parentInventoryBID = parentInventoryBID;
    }

    public Date getReadyForTransformationDate() {
        return readyForTransformationDate;
    }

    public void setReadyForTransformationDate(Date readyForTransformationDate) {
        this.readyForTransformationDate = readyForTransformationDate;
    }

    public Double getSeedQuantity() {
        return seedQuantity;
    }

    public void setSeedQuantity(Double seedQuantity) {
        this.seedQuantity = seedQuantity;
    }

    public String getSeedQuantityUOM() {
        return seedQuantityUOM;
    }

    public void setSeedQuantityUOM(String seedQuantityUOM) {
        this.seedQuantityUOM = seedQuantityUOM;
    }

    public Long getSeedQuantityUomId() {
        return seedQuantityUomId;
    }

    public void setSeedQuantityUomId(Long seedQuantityUomId) {
        this.seedQuantityUomId = seedQuantityUomId;
    }

    public String getGeneticMaterialSrcGrowerProgram() {
        return geneticMaterialSrcGrowerProgram;
    }

    public void setGeneticMaterialSrcGrowerProgram(String geneticMaterialSrcGrowerProgram) {
        this.geneticMaterialSrcGrowerProgram = geneticMaterialSrcGrowerProgram;
    }

    public String getGeneticMaterialSrcMalePlotBID() {
        return geneticMaterialSrcMalePlotBID;
    }

    public void setGeneticMaterialSrcMalePlotBID(String geneticMaterialSrcMalePlotBID) {
        this.geneticMaterialSrcMalePlotBID = geneticMaterialSrcMalePlotBID;
    }

    public Double getSubInventoryQuantity() {
        return subInventoryQuantity;
    }

    public void setSubInventoryQuantity(Double subInventoryQuantity) {
        this.subInventoryQuantity = subInventoryQuantity;
    }

    public String getTransformationGenotype() {
        return transformationGenotype;
    }

    public void setTransformationGenotype(String transformationGenotype) {
        this.transformationGenotype = transformationGenotype;
    }

    public String getStorageContainerName() {
        return storageContainerName;
    }

    public void setStorageContainerName(String storageContainerName) {
        this.storageContainerName = storageContainerName;
    }

    public Boolean isActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }

    public Long getInbredBaseId() {
        return inbredBaseId;
    }

    public void setInbredBaseId(Long inbredBaseId) {
        this.inbredBaseId = inbredBaseId;
    }

    public String getInbredBaseName() {
        return inbredBaseName;
    }

    public void setInbredBaseName(String inbredBaseName) {
        this.inbredBaseName = inbredBaseName;
    }

    public String getGermplasmOldPedigree() {
        return germplasmOldPedigree;
    }

    public void setGermplasmOldPedigree(String germplasmOldPedigree) {
        this.germplasmOldPedigree = germplasmOldPedigree;
    }

    public Double getAdvanceInvSimilaritySrcRank() {
        return advanceInvSimilaritySrcRank;
    }

    public void setAdvanceInvSimilaritySrcRank(Double advanceInvSimilaritySrcRank) {
        this.advanceInvSimilaritySrcRank = advanceInvSimilaritySrcRank;
    }

    public String getStorageSite() {
        return storageSite;
    }

    public void setStorageSite(String storageSite) {
        this.storageSite = storageSite;
    }

    public String getStorageSubSite() {
        return storageSubSite;
    }

    public void setStorageSubSite(String storageSubSite) {
        this.storageSubSite = storageSubSite;
    }

    public String getStorageSubSubSite() {
        return storageSubSubSite;
    }

    public void setStorageSubSubSite(String storageSubSubSite) {
        this.storageSubSubSite = storageSubSubSite;
    }

    public String getModifiedUserName() {
        return modifiedUserName;
    }

    public void setModifiedUserName(String modifiedUserName) {
        this.modifiedUserName = modifiedUserName;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Integer getGeneticMaterialSrcMalePlotNbr() {
        return geneticMaterialSrcMalePlotNbr;
    }

    public void setGeneticMaterialSrcMalePlotNbr(Integer geneticMaterialSrcMalePlotNbr) {
        this.geneticMaterialSrcMalePlotNbr = geneticMaterialSrcMalePlotNbr;
    }

    public String getGeneticMaterialSrcSelection() {
        return geneticMaterialSrcSelection;
    }

    public void setGeneticMaterialSrcSelection(String geneticMaterialSrcSelection) {
        this.geneticMaterialSrcSelection = geneticMaterialSrcSelection;
    }

    public Long getGeneticMaterialSrcAdvNumber() {
        return geneticMaterialSrcAdvNumber;
    }

    public void setGeneticMaterialSrcAdvNumber(Long geneticMaterialSrcAdvNumber) {
        this.geneticMaterialSrcAdvNumber = geneticMaterialSrcAdvNumber;
    }

    public String getGermplasmCrossName() {
        return germplasmCrossName;
    }

    public void setGermplasmCrossName(String germplasmCrossName) {
        this.germplasmCrossName = germplasmCrossName;
    }

    public String getGermplasmCrossOwnerBrProgId() {
        return germplasmCrossOwnerBrProgId;
    }

    public void setGermplasmCrossOwnerBrProgId(String germplasmCrossOwnerBrProgId) {
        this.germplasmCrossOwnerBrProgId = germplasmCrossOwnerBrProgId;
    }

    public String getGermplasmCrossContactUserFirstName() {
        return germplasmCrossContactUserFirstName;
    }

    public void setGermplasmCrossContactUserFirstName(String germplasmCrossContactUserFirstName) {
        this.germplasmCrossContactUserFirstName = germplasmCrossContactUserFirstName;
    }

    public String getGermplasmCrossContactUserLastName() {
        return germplasmCrossContactUserLastName;
    }

    public void setGermplasmCrossContactUserLastName(String germplasmCrossContactUserLastName) {
        this.germplasmCrossContactUserLastName = germplasmCrossContactUserLastName;
    }

    public Integer getTouCount() {
        return touCount;
    }

    public void setTouCount(Integer touCount) {
        this.touCount = touCount;
    }

    public Boolean getTouRestriction() {
        return touRestriction;
    }

    public void setTouRestriction(Boolean touRestriction) {
        this.touRestriction = touRestriction;
    }

    public String getGeneticMaterialTemplateText() {
        return templateText;
    }

    public void setGeneticMaterialTemplateText(String inventoryDescriptor) {
        this.templateText = inventoryDescriptor;
    }

    private void parseStorageUnitDisplayDNML() {
        if ((storageUnitDisplayDNML != null) &&
                (storageUnitDisplayDNML.contains(STORAGE_UNIT_DISPLAY_DNML_DELIMITER))) {
            populateSiteStrings(
                    StringUtils.delimitedListToStringArray(storageUnitDisplayDNML, STORAGE_UNIT_DISPLAY_DNML_DELIMITER));
        }
    }

    private void populateSiteStrings(String[] siteStrings) {
        setStorageSite(getStringFromArray(0, siteStrings));
        setStorageSubSite(getStringFromArray(1, siteStrings));
        setStorageSubSubSite(getStringFromArray(2, siteStrings));
    }

    private String getStringFromArray(int index, String[] siteStrings) {
        try {
            return siteStrings[index];
        } catch (IndexOutOfBoundsException exception) {
            return "";
        }
    }

    public void setInventorySeedProcessingDate(Date inventorySeedProcessingDate) {
        this.inventorySeedProcessingDate = inventorySeedProcessingDate;
    }

    public Date getInventorySeedProcessingDate() {
        return inventorySeedProcessingDate;
    }

    public Collection<Long> getInventorySampleNbrs() {
        return inventorySampleNbrs;
    }

    public void setInventorySampleNbrs(Collection<Long> inventorySampleNbrs) {
        this.inventorySampleNbrs = inventorySampleNbrs;
    }

    public Collection<String> getMolecularBreedingRequestNbrs() {
        return molecularBreedingRequestNbrs;
    }

    public void setMolecularBreedingRequestNbrs(Collection<String> molecularBreedingRequestNbrs) {
        this.molecularBreedingRequestNbrs = molecularBreedingRequestNbrs;
    }
}