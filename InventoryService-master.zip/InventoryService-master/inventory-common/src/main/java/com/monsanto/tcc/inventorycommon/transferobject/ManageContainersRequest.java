package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 3, 2010
 * Time: 4:46:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class ManageContainersRequest {

    Collection<StorageUnitTO> deletedStorageUnits;
    Collection<StorageUnitTO> createdOrModifiedStorageUnits;

    public Collection<StorageUnitTO> getDeletedStorageUnits() {
        return deletedStorageUnits;
    }

    public void setDeletedStorageUnits(Collection<StorageUnitTO> deletedStorageUnits) {
        this.deletedStorageUnits = deletedStorageUnits;
    }

    public Collection<StorageUnitTO> getCreatedOrModifiedStorageUnits() {
        return createdOrModifiedStorageUnits;
    }

    public void setCreatedOrModifiedStorageUnits(Collection<StorageUnitTO> createdOrModifiedStorageUnits) {
        this.createdOrModifiedStorageUnits = createdOrModifiedStorageUnits;
    }


}
