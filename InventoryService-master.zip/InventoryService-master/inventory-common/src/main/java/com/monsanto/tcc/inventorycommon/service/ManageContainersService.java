package com.monsanto.tcc.inventorycommon.service;

import com.monsanto.tcc.inventorycommon.domain.*;
import com.monsanto.tcc.inventorycommon.exception.QueryTimedOutException;
import com.monsanto.tcc.inventorycommon.service.exception.MaterialExchangeException;
import com.monsanto.tcc.inventorycommon.transferobject.*;
import com.monsanto.tcc.inventorycommon.transferobject.suinventory.*;

import javax.jws.WebService;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 3, 2010
 * Time: 2:35:04 PM
 * To change this template use File | Settings | File Templates.
 */
@WebService
public interface ManageContainersService {

    public Collection<StorageUnitTO> getStorageContainers(Long storageLocationId, StorageType parentType) throws Exception;

    public ManageContainersResponse persist(ManageContainersRequest manageContainersRequest) throws Exception;

    public Collection<StorageUnitTypeTO> getStorageUnitTypes();

    public StorageUnitsResponse getStorageUnitsByFilter(StorageUnitsRequest storageUnitsRequest) throws Exception;

    public InventoryStorageUnitResponse updateInventoriesToStorageUnit(InventoryStorageUnitRequest inventoryStorageUnitRequest) throws Exception;

    public AssignInventoriesToStorageContainerResponse assignInventoriesToStorageContainer(AssignInventoriesToStorageContainerRequest assignInventoriesToStorageContainerRequest) throws Exception;

    public StorageUnitSearchResponse search(StorageUnitSearchRequest storageUnitSearchRequest) throws Exception;

    public SUInventoryResponse getSUInventory(SUInventoryRequest suInventoryRequest) throws MaterialExchangeException, QueryTimedOutException;

    public SUInventoryResponse getSUInventoriesByStorageContainerBarcodes(SUInventoriesByBarcodesRequest request);

    public SUInventoryResponse getSUInventoriesByStorageContainerBarcode(String storageContainerBarcode);

    public SUMoveResponse moveStorageUnit(SUMoveRequest suMoveRequest);

    public AssignInventoriesToStorageContainerResponse deleteInventoryContainers(AssignInventoriesToStorageContainerRequest assignInventoriesToStorageContainerRequest);

    SUExportResponse exportStorageContainers(SUExportRequest request);

    public Collection<SiteTO> getSitesForGivenPrograms(Collection<String> programRefIds) throws Exception;

    public DiscardInventoryResponse discardInventory(DiscardInventoryRequest discardInventoryRequest);

    public UndoDiscardInventoryResponse undoDiscardInventory(UndoDiscardInventoryRequest undoDiscardInventoryRequest);
}
