/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.germplasm.Inventory;

/* nbwald - Dec 7, 2010 */
public class InactiveInventory {
    private Inventory inventory;
    private String inventoryType;
    private String germplasmOwnerProgRefId;
    private String inventoryOwnerProgRefId;
    private String pedigree;
    private String inventoryPurpose;
    private String geneticMaterialSource;
    private Long germplasmId;
    private String parentInventoryBarcode;

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public String getInventoryType() {
        return inventoryType;
    }

    public void setInventoryType(String inventoryType) {
        this.inventoryType = inventoryType;
    }

    public String getGermplasmOwnerProgRefId() {
        return germplasmOwnerProgRefId;
    }

    public void setGermplasmOwnerProgRefId(String germplasmOwnerProgRefId) {
        this.germplasmOwnerProgRefId = germplasmOwnerProgRefId;
    }

    public String getInventoryOwnerProgRefId() {
        return inventoryOwnerProgRefId;
    }

    public void setInventoryOwnerProgRefId(String inventoryOwnerProgRefId) {
        this.inventoryOwnerProgRefId = inventoryOwnerProgRefId;
    }

    public String getPedigree() {
        return pedigree;
    }

    public void setPedigree(String pedigree) {
        this.pedigree = pedigree;
    }

    public String getInventoryPurpose() {
        return inventoryPurpose;
    }

    public void setInventoryPurpose(String inventoryPurpose) {
        this.inventoryPurpose = inventoryPurpose;
    }

    public String getGeneticMaterialSource() {
        return geneticMaterialSource;
    }

    public void setGeneticMaterialSource(String geneticMaterialSource) {
        this.geneticMaterialSource = geneticMaterialSource;
    }

    public Long getGermplasmId() {
        return germplasmId;
    }

    public void setGermplasmId(Long germplasmId) {
        this.germplasmId = germplasmId;
    }

    public String getParentInventoryBarcode() {
        return parentInventoryBarcode;
    }

    public void setParentInventoryBarcode(String parentInventoryBarcode) {
        this.parentInventoryBarcode = parentInventoryBarcode;
    }
}