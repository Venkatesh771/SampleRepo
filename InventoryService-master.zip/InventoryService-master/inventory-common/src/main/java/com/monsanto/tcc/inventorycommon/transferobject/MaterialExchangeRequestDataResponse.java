package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.germplasm.InventoryPurpose;
import com.monsanto.services.domain.germplasm.ProductDescription;
import com.monsanto.tcc.inventorycommon.domain.CompositeUnitOfMeasure;
import com.monsanto.tcc.inventorycommon.domain.MaterialRequest;

import java.util.List;

@SuppressWarnings({"UnusedDeclaration"})
public class MaterialExchangeRequestDataResponse {

    private MaterialRequest materialRequest;
    private List<InventoryPurpose> inventoryPurposes;
    private ProductDescription productDescription;
    private List<CompositeUnitOfMeasure> unitOfMeasureList;

    public MaterialRequest getMaterialRequest() {
        return materialRequest;
    }

    public void setMaterialRequest(MaterialRequest materialRequest) {
        this.materialRequest = materialRequest;
    }

    public List<InventoryPurpose> getInventoryPurposes() {
        return inventoryPurposes;
    }

    public void setInventoryPurposes(List<InventoryPurpose> inventoryPurposes) {
        this.inventoryPurposes = inventoryPurposes;
    }

    public ProductDescription getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(ProductDescription productDescription) {
        this.productDescription = productDescription;
    }

    public List<CompositeUnitOfMeasure> getUnitOfMeasureList() {
        return unitOfMeasureList;
    }

    public void setUnitOfMeasureList(List<CompositeUnitOfMeasure> unitOfMeasureList) {
        this.unitOfMeasureList = unitOfMeasureList;
    }
}
