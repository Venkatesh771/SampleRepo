/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.bpm.ActivityInstance;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.*;

import java.util.Date;
import java.util.Set;

/**
 * User: jjbens2
 * Date: May 19, 2010
 */
public class MaterialRequestDetailToProcessTO {

    private Long materialRequestId;
    private Long materialRequestDetailId;
    private String comments;
    private Date dateNeeded;
    private String agencyPermitNotification;
    private Double desiredQuantity;
    private Double minimumQuantity;
    private String rejectionComment;
    private Long shipToContactId;
    private Long shipToSiteId;

    // TransferObjects
    private ProgramSiteTransferObject shipToSite;
    private ContactTO shipToContact;
    private AddressTO shipToAddress;
    private ProgramTO shipToProgram; // wire to the request.requestingProgramId for right now
    private InventoryTO requestedInventory;
    private Set<AlternateInventoryTO> alternateInventories;
    private ReasonTO requestReason;
    private ReasonTO rejectionReason;
    private ActivityInstance activityInstance;
    private UnitOfMeasureTO requestUom;

    public Long getMaterialRequestId() {
        return materialRequestId;
    }

    public void setMaterialRequestId(Long materialRequestId) {
        this.materialRequestId = materialRequestId;
    }

    public Long getMaterialRequestDetailId() {
        return materialRequestDetailId;
    }

    public void setMaterialRequestDetailId(Long materialRequestDetailId) {
        this.materialRequestDetailId = materialRequestDetailId;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Date getDateNeeded() {
        return dateNeeded;
    }

    public void setDateNeeded(Date dateNeeded) {
        this.dateNeeded = dateNeeded;
    }

    public String getAgencyPermitNotification() {
        return agencyPermitNotification;
    }

    public void setAgencyPermitNotification(String agencyPermitNotification) {
        this.agencyPermitNotification = agencyPermitNotification;
    }

    public Double getDesiredQuantity() {
        return desiredQuantity;
    }

    public void setDesiredQuantity(Double desiredQuantity) {
        this.desiredQuantity = desiredQuantity;
    }

    public Double getMinimumQuantity() {
        return minimumQuantity;
    }

    public void setMinimumQuantity(Double minimumQuantity) {
        this.minimumQuantity = minimumQuantity;
    }

    public ContactTO getShipToContact() {
        return shipToContact;
    }

    public void setShipToContact(ContactTO shipToContact) {
        this.shipToContact = shipToContact;
    }

    public AddressTO getShipToAddress() {
        return shipToAddress;
    }

    public void setShipToAddress(AddressTO shipToAddress) {
        this.shipToAddress = shipToAddress;
    }

    public ProgramTO getShipToProgram() {
        return shipToProgram;
    }

    public void setShipToProgram(ProgramTO shipToProgram) {
        this.shipToProgram = shipToProgram;
    }

    public InventoryTO getRequestedInventory() {
        return requestedInventory;
    }

    public void setRequestedInventory(InventoryTO requestedInventory) {
        this.requestedInventory = requestedInventory;
    }

    public Set<AlternateInventoryTO> getAlternateInventories() {
        return alternateInventories;
    }

    public void setAlternateInventories(Set<AlternateInventoryTO> alternateInventories) {
        this.alternateInventories = alternateInventories;
    }

    public ReasonTO getRequestReason() {
        return requestReason;
    }

    public void setRequestReason(ReasonTO requestReason) {
        this.requestReason = requestReason;
    }

    public UnitOfMeasureTO getRequestUom() {
        return requestUom;
    }

    public void setRequestUom(UnitOfMeasureTO requestUom) {
        this.requestUom = requestUom;
    }

    public ActivityInstance getActivityInstance() {
        return activityInstance;
    }

    public void setActivityInstance(ActivityInstance activityInstance) {
        this.activityInstance = activityInstance;
    }

    public String getRejectionComment() {
        return rejectionComment;
    }

    public void setRejectionComment(String rejectionComment) {
        this.rejectionComment = rejectionComment;
    }

    public Long getShipToContactId() {
        return shipToContactId;
    }

    public void setShipToContactId(Long shipToContactId) {
        this.shipToContactId = shipToContactId;
    }

    public ReasonTO getRejectionReason() {
        return rejectionReason;
    }

    public void setRejectionReason(ReasonTO rejectionReason) {
        this.rejectionReason = rejectionReason;
    }

    public ProgramSiteTransferObject getShipToSite() {
        return shipToSite;
    }

    public void setShipToSite(ProgramSiteTransferObject shipToSite) {
        this.shipToSite = shipToSite;
    }

    public Long getShipToSiteId() {
        return shipToSiteId;
    }

    public void setShipToSiteId(Long shipToSiteId) {
        this.shipToSiteId = shipToSiteId;
    }
}
