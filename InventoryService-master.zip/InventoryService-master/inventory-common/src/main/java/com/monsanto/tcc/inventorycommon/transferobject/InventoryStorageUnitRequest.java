package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.shipping.StorageUnit;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 28, 2010
 * Time: 6:44:56 AM
 * To change this template use File | Settings | File Templates.
 */
public class InventoryStorageUnitRequest {
    private Collection<Long> inventoryIds;
    private StorageUnit storageUnit;

    public Collection<Long> getInventoryIds() {
        return inventoryIds;
    }

    public void setInventoryIds(Collection<Long> inventoryIds) {
        this.inventoryIds = inventoryIds;
    }

    public StorageUnit getStorageUnit() {
        return storageUnit;
    }

    public void setStorageUnit(StorageUnit storageUnit) {
        this.storageUnit = storageUnit;
    }
}
