package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jul 1, 2009
 * Time: 4:26:57 PM
 */
public class GetSourcesRequest {
    private String pedigreeName;
    private String providerProgRefId;

    public String getPedigreeName() {
        return pedigreeName;
    }

    public void setPedigreeName(String pedigreeName) {
        this.pedigreeName = pedigreeName;
    }

    public String getProviderProgRefId() {
        return providerProgRefId;
    }

    public void setProviderProgRefId(String providerProgRefId) {
        this.providerProgRefId = providerProgRefId;
    }
}
