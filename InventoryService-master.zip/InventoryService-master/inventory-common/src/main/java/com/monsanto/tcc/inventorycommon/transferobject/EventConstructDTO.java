package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by IntelliJ IDEA.
 * User: RRPATN
 * Date: Feb 5, 2010
 * Time: 4:10:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class EventConstructDTO {

    private Long eventConstructId;
    private String eventName;
    private String constructName;
    private Boolean isActive;

    public EventConstructDTO() {
    }

    public EventConstructDTO(Long eventConstructId, String eventName, String constructName, Boolean active) {
        setEventConstructId(eventConstructId);
        setEventName(eventName);
        setConstructName(constructName);
        setActive(active);
    }

    public Long getEventConstructId() {
        return eventConstructId;
    }

    public void setEventConstructId(Long eventConstructId) {
        this.eventConstructId = eventConstructId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getConstructName() {
        return constructName;
    }

    public void setConstructName(String constructName) {
        this.constructName = constructName;
    }

    public Boolean isActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }
}
