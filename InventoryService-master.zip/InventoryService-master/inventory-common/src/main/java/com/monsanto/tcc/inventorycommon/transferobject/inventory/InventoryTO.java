/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.inventory;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;
import org.springframework.util.StringUtils;

import java.util.Date;

public class InventoryTO {

    private static final String STORAGE_UNIT_DISPLAY_DNML_DELIMITER = "\\";

    private Long id;
    private GeneticMaterialTO geneticMaterial;
    private String inventoryType;
    private String inventoryStatus;
    private String inventoryPurpose;
    private String currentLocation;
    private String asort1;
    private String asort2;
    private String asort3;
    private String asort4;
    private String asort5;
    private Double nsort1;
    private Double nsort2;
    private Double nsort3;
    private Double nsort4;
    private Double nsort5;
    private String barcode;
    private String inventoryOwner;
    private boolean preview;
    private Date fateReasonDate;
    private String fateReason;
    private String virgoId;
    private StorageUnitTO storageUnit;
    private String seedTreatment;
    private String goiTxt;
    private String parentBarcode;
    private String vegetativeStructure;
    private ProgramTO program;
    private Double quantity;
    private String quantityUom;

    private String storageContainerBarcode;
    private String storageContainerName;
    private String storageContainerLocation;
    private String storageSite;
    private String storageSubSite;
    private String storageSubSubSite;

    private String brand;
    private String lotNumber;
    private String productName;
    private String inventoryComments;
    private String bulkReason;
    private Double originQty;
    private String originQuantityUom;
    private Boolean isPlaced;
    private String remRefId;

    private Boolean performanceCheck;
    private Boolean maturity;

    public InventoryTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public GeneticMaterialTO getGeneticMaterial() {
        return geneticMaterial;
    }

    public void setGeneticMaterial(GeneticMaterialTO geneticMaterial) {
        this.geneticMaterial = geneticMaterial;
    }

    public String getInventoryType() {
        return inventoryType;
    }

    public void setInventoryType(String inventoryType) {
        this.inventoryType = inventoryType;
    }

    public String getInventoryStatus() {
        return inventoryStatus;
    }

    public void setInventoryStatus(String inventoryStatus) {
        this.inventoryStatus = inventoryStatus;
    }

    public String getInventoryPurpose() {
        return inventoryPurpose;
    }

    public void setInventoryPurpose(String inventoryPurpose) {
        this.inventoryPurpose = inventoryPurpose;
    }

    public String getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(String location) {
        this.currentLocation = location;
        parseStorageUnitDisplayDNML(location);
    }

    public String getAsort1() {
        return asort1;
    }

    public void setAsort1(String asort1) {
        this.asort1 = asort1;
    }

    public String getAsort2() {
        return asort2;
    }

    public void setAsort2(String asort2) {
        this.asort2 = asort2;
    }

    public String getAsort3() {
        return asort3;
    }

    public void setAsort3(String asort3) {
        this.asort3 = asort3;
    }

    public String getAsort4() {
        return asort4;
    }

    public void setAsort4(String asort4) {
        this.asort4 = asort4;
    }

    public String getAsort5() {
        return asort5;
    }

    public void setAsort5(String asort5) {
        this.asort5 = asort5;
    }

    public Double getNsort1() {
        return nsort1;
    }

    public void setNsort1(Double nsort1) {
        this.nsort1 = nsort1;
    }

    public Double getNsort2() {
        return nsort2;
    }

    public void setNsort2(Double nsort2) {
        this.nsort2 = nsort2;
    }

    public Double getNsort3() {
        return nsort3;
    }

    public void setNsort3(Double nsort3) {
        this.nsort3 = nsort3;
    }

    public Double getNsort4() {
        return nsort4;
    }

    public void setNsort4(Double nsort4) {
        this.nsort4 = nsort4;
    }

    public Double getNsort5() {
        return nsort5;
    }

    public void setNsort5(Double nsort5) {
        this.nsort5 = nsort5;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getInventoryOwner() {
        return inventoryOwner;
    }

    public void setInventoryOwner(String inventoryOwner) {
        this.inventoryOwner = inventoryOwner;
    }

    public boolean isPreview() {
        return preview;
    }

    public void setPreview(boolean preview) {
        this.preview = preview;
    }

    public Date getFateReasonDate() {
        return fateReasonDate;
    }

    public void setFateReasonDate(Date fateReasonDate) {
        this.fateReasonDate = fateReasonDate;
    }

    public String getFateReason() {
        return fateReason;
    }

    public void setFateReason(String fateReason) {
        this.fateReason = fateReason;
    }

    public String getVirgoId() {
        return virgoId;
    }

    public void setVirgoId(String virgoId) {
        this.virgoId = virgoId;
    }

    public StorageUnitTO getStorageUnit() {
        return storageUnit;
    }

    public void setStorageUnit(StorageUnitTO storageUnit) {
        this.storageUnit = storageUnit;
    }

    public String getSeedTreatment() {
        return seedTreatment;
    }

    public void setSeedTreatment(String seedTreatment) {
        this.seedTreatment = seedTreatment;
    }

    public String getGoiTxt() {
        return goiTxt;
    }

    public void setGoiTxt(String goiTxt) {
        this.goiTxt = goiTxt;
    }

    public String getParentBarcode() {
        return parentBarcode;
    }

    public void setParentBarcode(String parentBarcode) {
        this.parentBarcode = parentBarcode;
    }

    public String getVegetativeStructure() {
        return vegetativeStructure;
    }

    public void setVegetativeStructure(String vegetativeStructure) {
        this.vegetativeStructure = vegetativeStructure;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getLotNumber() {
        return lotNumber;
    }

    public void setLotNumber(String lotNumber) {
        this.lotNumber = lotNumber;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getStorageContainerBarcode() {
        return storageContainerBarcode;
    }

    public void setStorageContainerBarcode(String storageContainerBarcode) {
        this.storageContainerBarcode = storageContainerBarcode;
    }

    public String getStorageContainerName() {
        return storageContainerName;
    }

    public void setStorageContainerName(String storageContainerName) {
        this.storageContainerName = storageContainerName;
    }

    public String getStorageContainerLocation() {
        return storageContainerLocation;
    }

    public void setStorageContainerLocation(String storageContainerLocation) {
        this.storageContainerLocation = storageContainerLocation;
    }

    public ProgramTO getProgram() {
        return program;
    }

    public void setProgram(ProgramTO program) {
        this.program = program;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public String getQuantityUom() {
        return quantityUom;
    }

    public void setQuantityUom(String quantityUom) {
        this.quantityUom = quantityUom;
    }

    public String getInventoryComments() {
        return inventoryComments;
    }

    public void setInventoryComments(String inventoryComments) {
        this.inventoryComments = inventoryComments;
    }

    public String getBulkReason() {
        return bulkReason;
    }

    public void setBulkReason(String bulkReason) {
        this.bulkReason = bulkReason;
    }

    public Double getOriginQty() {
        return originQty;
    }

    public void setOriginQty(Double originQty) {
        this.originQty = originQty;
    }

    public String getOriginQuantityUom() {
        return originQuantityUom;
    }

    public void setOriginQuantityUom(String originQuantityUom) {
        this.originQuantityUom = originQuantityUom;
    }

    public Boolean getIsPlaced() {
        return isPlaced;
    }

    public void setIsPlaced(Boolean isPlaced) {
        this.isPlaced = isPlaced;
    }

    public String getRemRefId() {
        return remRefId;
    }

    public void setRemRefId(String remRefId) {
        this.remRefId = remRefId;
    }

    public String getStorageSite() {
        return storageSite;
    }

    private void setStorageSite(String storageSite) {
        this.storageSite = storageSite;
    }

    public String getStorageSubSite() {
        return storageSubSite;
    }

    private void setStorageSubSite(String storageSubSite) {
        this.storageSubSite = storageSubSite;
    }

    public String getStorageSubSubSite() {
        return storageSubSubSite;
    }

    public Boolean getPerformanceCheck() {
        return performanceCheck;
    }

    public void setPerformanceCheck(Boolean performanceCheck) {
        this.performanceCheck = performanceCheck;
    }

    public Boolean isMaturity() {
        return maturity;
    }

    public void setMaturity(Boolean maturity) {
        this.maturity = maturity;
    }

    private void setStorageSubSubSite(String storageSubSubSite) {
        this.storageSubSubSite = storageSubSubSite;
    }

    private void parseStorageUnitDisplayDNML(String storageUnitDisplayDNML) {
        if ((storageUnitDisplayDNML != null) && (storageUnitDisplayDNML.contains(STORAGE_UNIT_DISPLAY_DNML_DELIMITER))) {
            populateSiteStrings(StringUtils.delimitedListToStringArray(storageUnitDisplayDNML, STORAGE_UNIT_DISPLAY_DNML_DELIMITER));
        }
    }

    private void populateSiteStrings(String[] siteStrings) {
        setStorageSite(getStringFromArray(0, siteStrings));
        setStorageSubSite(getStringFromArray(1, siteStrings));
        setStorageSubSubSite(getStringFromArray(2, siteStrings));
    }

    private String getStringFromArray(int index, String[] siteStrings) {
        try {
            return siteStrings[index];
        } catch (IndexOutOfBoundsException exception) {
            return "";
        }
    }
}