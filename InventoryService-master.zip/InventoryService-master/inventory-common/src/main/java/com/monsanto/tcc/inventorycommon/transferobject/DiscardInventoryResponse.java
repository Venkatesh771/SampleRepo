/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import javax.xml.bind.annotation.XmlType;
import java.util.Collection;

@XmlType(name = "SU_DiscardInventoryResponse")
public class DiscardInventoryResponse {
    private ResponseMessage responseMessage;
    private Collection<String> barcodes;

    public ResponseMessage getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(ResponseMessage responseMessage) {
        this.responseMessage = responseMessage;
    }

    public Collection<String> getBarcodes() {
        return barcodes;
    }

    public void setBarcodes(Collection<String> barcodes) {
        this.barcodes = barcodes;
    }

}
