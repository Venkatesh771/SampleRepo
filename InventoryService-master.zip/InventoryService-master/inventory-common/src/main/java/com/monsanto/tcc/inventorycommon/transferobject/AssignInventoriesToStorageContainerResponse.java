package com.monsanto.tcc.inventorycommon.transferobject;

import javax.xml.bind.annotation.XmlType;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: May 19, 2010
 * Time: 4:11:04 PM
 * To change this template use File | Settings | File Templates.
 */
@XmlType(name = "Inventory_AssignInventoriesToStorageContainerResponse")
public class AssignInventoriesToStorageContainerResponse {
    ResponseMessage responseMessage;
    Collection<InventoryStorageLocationDto> inventoryStorageLocationDtos;

    public ResponseMessage getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(ResponseMessage responseMessage) {
        this.responseMessage = responseMessage;
    }

    public Collection<InventoryStorageLocationDto> getInventoryStorageLocationDtos() {
        return inventoryStorageLocationDtos;
    }

    public void setInventoryStorageLocationDtos(Collection<InventoryStorageLocationDto> inventoryStorageLocationDtos) {
        this.inventoryStorageLocationDtos = inventoryStorageLocationDtos;
    }
}
