package com.monsanto.tcc.inventorycommon.domain;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Feb 16, 2010
 * Time: 12:11:52 PM
 * To change this template use File | Settings | File Templates.
 */
public class PlotEventConstruct {
    private Long plotEventConstructId;
    private Long plotId;
    private Long eventConstructId;
    private Date eventConstructAbsenceDate;
    private String sopIdentifierText;
    private Long requestorId;

    public PlotEventConstruct() {

    }

    public PlotEventConstruct(Long plotId, Long eventConstructId, Date eventConstructAbsenceDate, String sopIdentifierText) {
        this.plotId = plotId;
        this.eventConstructId = eventConstructId;
        this.eventConstructAbsenceDate = eventConstructAbsenceDate;
        this.sopIdentifierText = sopIdentifierText;
    }

    public Long getPlotEventConstructId() {
        return plotEventConstructId;
    }

    public void setPlotEventConstructId(Long plotEventConstructId) {
        this.plotEventConstructId = plotEventConstructId;
    }

    public Long getPlotId() {
        return plotId;
    }

    public void setPlotId(Long plotId) {
        this.plotId = plotId;
    }

    public Long getEventConstructId() {
        return eventConstructId;
    }

    public void setEventConstructId(Long eventConstructId) {
        this.eventConstructId = eventConstructId;
    }

    public Date getEventConstructAbsenceDate() {
        return eventConstructAbsenceDate;
    }

    public void setEventConstructAbsenceDate(Date eventConstructAbsenceDate) {
        this.eventConstructAbsenceDate = eventConstructAbsenceDate;
    }

    public String getSopIdentifierText() {
        return sopIdentifierText;
    }

    public void setSopIdentifierText(String sopIdentifierText) {
        this.sopIdentifierText = sopIdentifierText;
    }

    public Long getRequestorId() {
        return requestorId;
    }

    public void setRequestorId(Long requestorId) {
        this.requestorId = requestorId;
    }
}
