package com.monsanto.tcc.inventorycommon.service;

import com.monsanto.tcc.apollo.table.pagination.service.PaginationService;
import com.monsanto.tcc.inventorycommon.domain.DestructionMethod;
import com.monsanto.tcc.inventorycommon.service.exception.DestructionServiceException;
import com.monsanto.tcc.inventorycommon.transferobject.serviceinterfaceobject.DestroyInventoryRequest;
import com.monsanto.tcc.inventorycommon.transferobject.serviceinterfaceobject.DestroyInventoryResponse;
import com.monsanto.tcc.inventorycommon.transferobject.serviceinterfaceobject.InventoryToBeDestroyedPageRequest;
import com.monsanto.tcc.inventorycommon.transferobject.serviceinterfaceobject.InventoryToBeDestroyedPageResponse;

import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import java.util.List;

@WebService(targetNamespace = "http://service.inventoryservice.tcc.monsanto.com/")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
public interface DestructionService extends PaginationService<InventoryToBeDestroyedPageRequest, InventoryToBeDestroyedPageResponse> {

    DestroyInventoryResponse destroy(@WebParam(name = "request") DestroyInventoryRequest request) throws DestructionServiceException;

    List<DestructionMethod> getActiveDestructionMethodList() throws DestructionServiceException;

}
