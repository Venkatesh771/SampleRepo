/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.suinventory;

public class SUProgramTO {
    private String name;
    private String programRefId;    // inv owner

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProgramRefId() {
        return programRefId;
    }

    public void setProgramRefId(String programRefId) {
        this.programRefId = programRefId;
    }

}