package com.monsanto.tcc.inventorycommon.service;

import com.monsanto.tcc.inventorycommon.transferobject.*;

import javax.jws.WebService;

/**
 * Created by IntelliJ IDEA.
 * User: vvalav
 * Date: Apr 3, 2009
 * Time: 10:41:09 AM
 * To change this template use File | Settings | File Templates.
 */
@WebService
public interface InventoryCXFService {
    public InventoryServiceGetSummaryDataResponse getSummaryData(InventoryServiceGetSummaryDataRequest inventoryServiceGetSummaryDataRequest) throws Exception;

    public InventoryServiceGetVegStructuresResponse getVegStructuresData(InventoryServiceGetVegStructuresRequest inventoryServiceGetVegStructuresRequest) throws Exception;
}
