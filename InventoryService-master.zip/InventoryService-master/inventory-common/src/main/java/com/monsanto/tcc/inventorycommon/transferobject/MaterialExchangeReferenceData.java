/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.breeding.FateReason;
import com.monsanto.services.domain.breeding.InventoryType;
import com.monsanto.services.domain.breeding.Program;
import com.monsanto.services.domain.breeding.ProgramSummary;
import com.monsanto.services.domain.germplasm.InventoryPurpose;
import com.monsanto.tcc.inventorycommon.domain.CompositeUnitOfMeasure;

import java.util.List;

/* NBWALD - Feb 23, 2011 */
public class MaterialExchangeReferenceData
{
    private List<CompositeUnitOfMeasure> unitsOfMeasure;
    private FateReason publishedParentInventoryFateReason;

    private List<InventoryPurpose> inventoryPurposes;
    private List<InventoryType> inventoryTypes;
    private List<Program> programs;
    private List<ProgramSummary> programSummaries;
    private List<ProgramSite> programSites;
    private List<ProgramContact> programContacts;

    public List<CompositeUnitOfMeasure> getUnitsOfMeasure() {
        return unitsOfMeasure;
    }

    public void setUnitsOfMeasure(List<CompositeUnitOfMeasure> unitsOfMeasure) {
        this.unitsOfMeasure = unitsOfMeasure;
    }

    public FateReason getPublishedParentInventoryFateReason() {
        return publishedParentInventoryFateReason;
    }

    public void setPublishedParentInventoryFateReason(FateReason publishedParentInventoryFateReason) {
        this.publishedParentInventoryFateReason = publishedParentInventoryFateReason;
    }

    public List<InventoryPurpose> getInventoryPurposes() {
        return inventoryPurposes;
    }

    public void setInventoryPurposes(List<InventoryPurpose> inventoryPurposes) {
        this.inventoryPurposes = inventoryPurposes;
    }

    public List<InventoryType> getInventoryTypes() {
        return inventoryTypes;
    }

    public void setInventoryTypes(List<InventoryType> inventoryTypes) {
        this.inventoryTypes = inventoryTypes;
    }

    public List<Program> getPrograms() {
        return programs;
    }

    public void setPrograms(List<Program> programs) {
        this.programs = programs;
    }

    public List<ProgramSummary> getProgramSummaries() {
        return programSummaries;
    }

    public void setProgramSummaries(List<ProgramSummary> programSummaries) {
        this.programSummaries = programSummaries;
    }

    public List<ProgramSite> getProgramSites() {
        return programSites;
    }

    public void setProgramSites(List<ProgramSite> programSites) {
        this.programSites = programSites;
    }

    public List<ProgramContact> getProgramContacts() {
        return programContacts;
    }

    public void setProgramContacts(List<ProgramContact> programContacts) {
        this.programContacts = programContacts;
    }
}