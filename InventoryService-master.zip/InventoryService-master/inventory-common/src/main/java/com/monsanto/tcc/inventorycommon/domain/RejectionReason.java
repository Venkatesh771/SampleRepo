/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import org.apache.commons.lang.StringUtils;

import java.util.Date;

/**
 * User: jjbens2
 * Date: May 25, 2010
 */
public class RejectionReason extends Reason {
    public RejectionReason() {
    }

    public RejectionReason(Long id, String description, String name) {
        super(id, description, name);
    }

    public RejectionReason(Long id, String description, String name, Date inactiveDttm) {
        super(id, description, name, inactiveDttm);
    }

    @Override
    public String toString() {
        return StringUtils.defaultString(getDescription());
    }
}
