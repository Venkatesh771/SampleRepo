package com.monsanto.tcc.inventorycommon.domain;

import java.sql.Date;
import java.util.Collection;

public class StorageLocation {

    private Long storageLocationId;
    private String name;
    private String description;
    private Long subSubSiteId;
    private String barcode;
    private Date inactiveDttm;
    private StorageLocationType storageLocationType;
    private Collection<StorageLocationCatalog> storageLocationCatalogsByStorageLocationId;
    private Boolean containsChild;

    public Boolean getContainsChild() {
        return containsChild;
    }

    public void setContainsChild(Boolean containsChild) {
        this.containsChild = containsChild;
    }

    public Long getStorageLocationId() {
        return storageLocationId;
    }

    public void setStorageLocationId(Long storageLocationId) {
        this.storageLocationId = storageLocationId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getSubSubSiteId() {
        return subSubSiteId;
    }

    public void setSubSubSiteId(Long subSubSiteId) {
        this.subSubSiteId = subSubSiteId;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }

    public Collection<StorageLocationCatalog> getStorageLocationCatalogsByStorageLocationId() {
        return storageLocationCatalogsByStorageLocationId;
    }

    public void setStorageLocationCatalogsByStorageLocationId(Collection<StorageLocationCatalog> storageLocationCatalogsByStorageLocationId) {
        this.storageLocationCatalogsByStorageLocationId = storageLocationCatalogsByStorageLocationId;
    }

    public StorageLocationType getStorageLocationType() {
        return storageLocationType;
    }

    public void setStorageLocationType(StorageLocationType storageLocationType) {
        this.storageLocationType = storageLocationType;
    }
}
