/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

public class BlendSummary {
    private String pedigreeName;
    private String lineCode;
    private String origin;
    private String eventDisplay;
    private String constructDisplay;
    private String sourceStr;

    public BlendSummary() {
    }

    public BlendSummary(String pedigreeName, String lineCode,
                        String origin, String eventDisplay,
                        String constructDisplay, String sourceStr) {
        this.pedigreeName = pedigreeName;
        this.lineCode = lineCode;
        this.origin = origin;
        this.eventDisplay = eventDisplay;
        this.constructDisplay = constructDisplay;
        this.sourceStr = sourceStr;
    }

    public String getPedigreeName() {
        return pedigreeName;
    }

    public void setPedigreeName(String pedigreeName) {
        this.pedigreeName = pedigreeName;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getEventDisplay() {
        return eventDisplay;
    }

    public void setEventDisplay(String eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    public String getConstructDisplay() {
        return constructDisplay;
    }

    public void setConstructDisplay(String constructDisplay) {
        this.constructDisplay = constructDisplay;
    }

    public String getSourceStr() {
        return sourceStr;
    }

    public void setSourceStr(String sourceStr) {
        this.sourceStr = sourceStr;
    }
}