/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.inventory;

import com.monsanto.tcc.inventorycommon.transferobject.EventConstructDTO;

import java.util.Date;

/**
 * Created by Dan Schnettgoecke with IntelliJ IDEA.
 * Created on Oct 19, 2010 @ 12:06:09 PM.
 */

public class GermplasmEventConstructTO {

    private Long germplasmEventConstructId;
    private Long eventConstructId;
    private EventConstructDTO eventConstruct;
    private Date eventAbsenceDate;
    private Date deregulatedDttm;

    public EventConstructDTO getEventConstruct() {
        return eventConstruct;
    }

    public void setEventConstruct(EventConstructDTO eventConstruct) {
        this.eventConstruct = eventConstruct;
    }

    public Date getEventAbsenceDate() {
        return eventAbsenceDate;
    }

    public void setEventAbsenceDate(Date eventAbsenceDate) {
        this.eventAbsenceDate = eventAbsenceDate;
    }

    public Date getDeregulatedDttm() {
        return deregulatedDttm;
    }

    public void setDeregulatedDttm(Date deregulatedDttm) {
        this.deregulatedDttm = deregulatedDttm;
    }

    public Long getGermplasmEventConstructId() {
        return germplasmEventConstructId;
    }

    public void setGermplasmEventConstructId(Long germplasmEventConstructId) {
        this.germplasmEventConstructId = germplasmEventConstructId;
    }

    public Long getEventConstructId() {
        return eventConstructId;
    }

    public void setEventConstructId(Long eventConstructId) {
        this.eventConstructId = eventConstructId;
    }
}