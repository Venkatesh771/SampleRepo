package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.breeding.Program;
import com.monsanto.services.domain.breeding.uom.UnitOfMeasure;

import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sssing5 Date: Mar 16, 2010 Time: 3:39:52 PM
 */
public class MaterialExchange {
    private Long id;
    private Long geneticMaterialId;
    private Program fromBrProgram;
    private Program toBrProgram;
    private Double sentQuantity;
    private String packagedBy;
    private String permitNumber;
    private Date publicationDate;
    private Long inventoryPurposeId;
    private String comments;
    private Date externalMidasProcessedDate;
    private String senderInventoryBarcode;
    private Inventory receiverInventory;
    private String rubiconProjName;
    private Integer rubiconSampleNumber;
    private Boolean activeStatus;
    private Boolean inventoryExists;
    private UnitOfMeasure sentQuantityUom;
    private MaterialExchangeInfo materialExchangeInfo;
    private Long shipFromContact;


    public Long getShipFromContact() {return shipFromContact;}

    public void setShipFromContact(Long shipFromContact) { this.shipFromContact = shipFromContact;}
    public UnitOfMeasure getSentQuantityUom() {
        return sentQuantityUom;
    }

    public void setSentQuantityUom(UnitOfMeasure sentQuantityUom) {
        this.sentQuantityUom = sentQuantityUom;
    }

    public Long getId() {
        return id;
    }

    public Long getGeneticMaterialId() {
        return geneticMaterialId;
    }

    public Program getFromBrProgram() {
        return fromBrProgram;
    }

    public Program getToBrProgram() {
        return toBrProgram;
    }

    public Double getSentQuantity() {
        return sentQuantity;
    }

    public String getPackagedBy() {
        return packagedBy;
    }

    public String getPermitNumber() {
        return permitNumber;
    }

    public Date getPublicationDate() {
        return publicationDate;
    }

    public Long getInventoryPurposeId() {
        return inventoryPurposeId;
    }

    public String getComments() {
        return comments;
    }

    public Date getExternalMidasProcessedDate() {
        return externalMidasProcessedDate;
    }

    public String getSenderInventoryBarcode() {
        return senderInventoryBarcode;
    }

    public Inventory getReceiverInventory() {
        return receiverInventory;
    }

    public String getRubiconProjName() {
        return rubiconProjName;
    }

    public Integer getRubiconSampleNumber() {
        return rubiconSampleNumber;
    }

    public Boolean getActiveStatus() {
        return activeStatus;
    }

    public Boolean getInventoryExists() {
        return inventoryExists;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setGeneticMaterialId(Long geneticMaterialId) {
        this.geneticMaterialId = geneticMaterialId;
    }

    public void setFromBrProgram(Program fromBrProgram) {
        this.fromBrProgram = fromBrProgram;
    }

    public void setToBrProgram(Program toBrProgram) {
        this.toBrProgram = toBrProgram;
    }

    public void setSentQuantity(Double sentQuantity) {
        this.sentQuantity = sentQuantity;
    }

    public void setPackagedBy(String packagedBy) {
        this.packagedBy = packagedBy;
    }

    public void setPermitNumber(String permitNumber) {
        this.permitNumber = permitNumber;
    }

    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }

    public void setInventoryPurposeId(Long inventoryPurposeId) {
        this.inventoryPurposeId = inventoryPurposeId;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public void setExternalMidasProcessedDate(Date externalMidasProcessedDate) {
        this.externalMidasProcessedDate = externalMidasProcessedDate;
    }

    public void setSenderInventoryBarcode(String senderInventoryBarcode) {
        this.senderInventoryBarcode = senderInventoryBarcode;
    }

    public void setReceiverInventory(Inventory receiverInventory) {
        this.receiverInventory = receiverInventory;
    }

    public void setRubiconProjName(String rubiconProjName) {
        this.rubiconProjName = rubiconProjName;
    }

    public void setRubiconSampleNumber(Integer rubiconSampleNumber) {
        this.rubiconSampleNumber = rubiconSampleNumber;
    }

    public void setActiveStatus(Boolean activeStatus) {
        this.activeStatus = activeStatus;
    }

    public void setInventoryExists(Boolean inventoryExists) {
        this.inventoryExists = inventoryExists;
    }

    public MaterialExchangeInfo getMaterialExchangeInfo() {
        return materialExchangeInfo;
    }

    public void setMaterialExchangeInfo(MaterialExchangeInfo materialExchangeInfo) {
        this.materialExchangeInfo = materialExchangeInfo;
    }
}
