package com.monsanto.tcc.inventorycommon.domain;

import java.util.Collection;
import java.util.Date;

public class StorageContainer {

    public static final String DEFAULT_CONTAINER_TYPE_NAME = "Box";

    private Long storageContainerId;
    private String name;
    private Date creationDate;
    private Date inactiveDttm;
    private StorageContainerType storageContainerType;
    private Long parentContainerId;
    private Long activityId;
    private String barcode;
    private String description;
    private Collection<StorageContainer> storageContainersByStorageContainerId;
    private Collection<StorageContainerLocation> storageContainerLocationsByStorageContainerId;
    private Collection<InventoryContainer> inventoryContainers;
    private StorageContainer parentStorageContainer;
    private Boolean containsChild;
    private boolean hasInventory;


    public void setDefaultDescription() {
        if( null != this.barcode ) {
            this.description = this.barcode + " " + DEFAULT_CONTAINER_TYPE_NAME;
        }
    }

    public StorageContainer getParentStorageContainer() {
        return parentStorageContainer;
    }

    public void setParentStorageContainer(StorageContainer parentStorageContainer) {
        this.parentStorageContainer = parentStorageContainer;
    }

    public Long getStorageContainerId() {
        return storageContainerId;
    }

    public void setStorageContainerId(Long storageContainerId) {
        this.storageContainerId = storageContainerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }


    public void setDescription(String description) {
        this.description = description;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Long getParentContainerId() {
        return parentContainerId;
    }

    public void setParentContainerId(Long parentContainerId) {
        this.parentContainerId = parentContainerId;
    }

    public Long getActivityId() {
        return activityId;
    }

    public void setActivityId(Long activityId) {
        this.activityId = activityId;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }

    public Collection<StorageContainer> getStorageContainersByStorageContainerId() {
        return storageContainersByStorageContainerId;
    }

    public void setStorageContainersByStorageContainerId(Collection<StorageContainer> storageContainersByStorageContainerId) {
        this.storageContainersByStorageContainerId = storageContainersByStorageContainerId;
    }

    public Collection<StorageContainerLocation> getStorageContainerLocationsByStorageContainerId() {
        return storageContainerLocationsByStorageContainerId;
    }

    public void setStorageContainerLocationsByStorageContainerId(Collection<StorageContainerLocation> storageContainerLocationsByStorageContainerId) {
        this.storageContainerLocationsByStorageContainerId = storageContainerLocationsByStorageContainerId;
    }

    public StorageContainerType getStorageContainerType() {
        return storageContainerType;
    }

    public void setStorageContainerType(StorageContainerType storageContainerType) {
        this.storageContainerType = storageContainerType;
    }

    public Boolean getContainsChild() {
        return containsChild;
    }

    public void setContainsChild(Boolean containsChild) {
        this.containsChild = containsChild;
    }

    /** This is a convenience function that will find the first storage location
     * and return the name.
     * @return Storage Location Name
     */
    public String getLocationName()  {
        String locationName = null;
        if ((null != storageContainerLocationsByStorageContainerId) &&
                (0 != storageContainerLocationsByStorageContainerId.size()))  {
            StorageContainerLocation storageContainerLocation
                    = storageContainerLocationsByStorageContainerId.iterator().next();
            if (null != storageContainerLocation.getStorageLocationCatalogByStorageLocationCatalogId())  {
                StorageLocationCatalog catalog = storageContainerLocation.getStorageLocationCatalogByStorageLocationCatalogId();
                if (null != catalog.getStorageLocation())  {
                    locationName = catalog.getStorageLocation().getName();
                }
            }
        }

        return locationName;
    }

    public boolean getHasInventory() {
        return hasInventory;
    }

    public void setHasInventory(boolean hasInventory) {
        this.hasInventory = hasInventory;
    }

    public Collection<InventoryContainer> getInventoryContainers() {
        return inventoryContainers;
    }

    public void setInventoryContainers(Collection<InventoryContainer> inventoryContainers) {
        this.inventoryContainers = inventoryContainers;
    }
}
