package com.monsanto.tcc.inventorycommon.service;

import com.monsanto.tcc.inventorycommon.exception.QueryTimedOutException;
import com.monsanto.tcc.inventorycommon.service.exception.MaterialExchangeException;
import com.monsanto.tcc.inventorycommon.transferobject.*;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.InventoryLotNumberTO;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import java.util.List;

@SuppressWarnings({"UnusedDeclaration"})
@WebService(targetNamespace = "http://service.inventoryservice.tcc.monsanto.com/")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
public interface MaterialExchangeService {

    AvailableMaterialResponse getAvailableMaterial(AvailableMaterialRequest request) throws Exception;

    AvailableMaterialReferenceDataResponse getAvailableMaterialReferenceData(AvailableMaterialReferenceDataRequest request) throws MaterialExchangeException;

    MaterialRequestResponse requestMaterial(RequestForMaterial request) throws MaterialExchangeException;

    RejectResponse rejectRequestDetail(MaterialExchangeRejectionRequest rejectionRequest) throws MaterialExchangeException;

    MaterialExchangeReferenceData getMaterialExchangeReferenceData(long cropId) throws MaterialExchangeException;

    MaterialExchangeDataResponse getMaterialExchangeDataForInventories(MaterialExchangeDataRequest request) throws MaterialExchangeException;

    List<InventoryLotNumberTO> getOrionLotNumbersForBarcodes(List<String> barcodeList) throws MaterialExchangeException;

    PublishResponse publishInventory(PublishRequest requestObjects) throws MaterialExchangeException;

    PublishResponse publishInventoryMonsantoData(PublishRequest requestObjects) throws MaterialExchangeException;

    void updateMaterialRequestAfterSuccessfulPublish(UpdateMaterialRequest request) throws MaterialExchangeException;

    MaterialRequestHistoryResponse getRequestHistory(MaterialRequestHistoryRequest materialRequestHistoryRequest) throws MaterialExchangeException;

    MaterialRequestHistoryFilterResponse getRequestHistoryFilterRefData(MaterialRequestHistoryFilterRequest request);

    PublishResponse publishMaterialRequests(List<MaterialRequestPublishData> materialRequestPublishDataCollection) throws MaterialExchangeException;

    MaterialRequestsToProcessResponse getRequestsToProcessByProgramForUser(ProcessingMaterialReqRequest programIds) throws MaterialExchangeException;

    @Deprecated
    AlternateInventoryResponse getAlternateInventories(Long inventoryId) throws MaterialExchangeException;

    AlternateInventoryResponse getAlternateInventoryByPedigree(Long inventoryId) throws MaterialExchangeException,
            QueryTimedOutException;

    AlternateInventoryResponse getAlternateInventoryByFilter(AlternateInventoryRequest request) throws
            QueryTimedOutException, MaterialExchangeException;

    Boolean sendFailureNotification(Long materialRequestDetailId) throws MaterialExchangeException;
    
}
