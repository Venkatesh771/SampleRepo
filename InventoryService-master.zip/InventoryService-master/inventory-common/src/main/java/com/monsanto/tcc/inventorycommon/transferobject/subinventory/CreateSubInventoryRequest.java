package com.monsanto.tcc.inventorycommon.transferobject.subinventory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: May 25, 2010
 * Time: 2:26:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateSubInventoryRequest {
    private List<SubInventoryParentGroupDto> subInventoryParentGroups = new ArrayList<SubInventoryParentGroupDto>();

    public CreateSubInventoryRequest() {
    }

    public CreateSubInventoryRequest(List<SubInventoryParentGroupDto> subInventoryParentGroups) {
        this.subInventoryParentGroups = subInventoryParentGroups;
    }

    public List<SubInventoryParentGroupDto> getSubInventoryParentGroups() {
        return subInventoryParentGroups;
    }

    public void setSubInventoryParentGroups(List<SubInventoryParentGroupDto> subInventoryParentGroups) {
        this.subInventoryParentGroups = subInventoryParentGroups;
    }
}
