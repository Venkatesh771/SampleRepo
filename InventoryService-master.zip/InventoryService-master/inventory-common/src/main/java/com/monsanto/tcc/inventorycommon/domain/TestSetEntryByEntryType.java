/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.common.AbstractEntity;

import javax.xml.bind.annotation.XmlType;
import java.util.Date;

@XmlType(name = "Test_Set_Entry_By_Entry_Type")
public class TestSetEntryByEntryType extends AbstractEntity {

    private Long testSetEntryByEntryTypeId;
    private TestSetEntry testSetEntry;
    private EntryType entryType;
    private Date inactiveDate;

    public TestSetEntryByEntryType() {
    }

    //@Override
    public Object getID() {
        return getTestSetEntryByEntryTypeId();
    }

    public Long getTestSetEntryByEntryTypeId() {
        return testSetEntryByEntryTypeId;
    }

    public void setTestSetEntryByEntryTypeId(Long testSetEntryByEntryTypeId) {
        this.testSetEntryByEntryTypeId = testSetEntryByEntryTypeId;
    }


    public Date getInactiveDate() {
        return inactiveDate;
    }

    public void setInactiveDate(Date inactiveDate) {
        this.inactiveDate = inactiveDate;
    }

    public EntryType getEntryType() {
        return entryType;
    }

    public void setEntryType(EntryType entryType) {
        this.entryType = entryType;
    }

    public TestSetEntry getTestSetEntry() {
        return testSetEntry;
    }

    public void setTestSetEntry(TestSetEntry testSetEntry) {
        this.testSetEntry = testSetEntry;
    }
}
