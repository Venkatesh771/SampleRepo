package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Apr 6, 2010
 * Time: 3:28:16 PM
 * To change this template use File | Settings | File Templates.
 */
public class ActivateInventoriesRequest {

    private Collection<Long> inventoryIds;

    public Collection<Long> getInventoryIds() {
        return inventoryIds;
    }

    public void setInventoryIds(Collection<Long> inventoryIds) {
        this.inventoryIds = inventoryIds;
    }
}
