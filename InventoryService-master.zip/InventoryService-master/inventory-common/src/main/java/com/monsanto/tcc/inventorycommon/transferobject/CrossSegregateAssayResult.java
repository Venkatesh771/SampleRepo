package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.domain.RemovableEventSop;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jdvoll
 * Date: Jan 13, 2011
 * Time: 2:04:25 PM
 */
public class CrossSegregateAssayResult implements Serializable {

    private Long crossSegregateIndividualStatusId;
    private List<EventAssayResult> eventAssayResults = new ArrayList<EventAssayResult>();
    private RemovableEventSop removableEventSop;

    public Long getCrossSegregateIndividualStatusId() {
        return crossSegregateIndividualStatusId;
    }

    public void setCrossSegregateIndividualStatusId(Long crossSegregateIndividualStatusId) {
        this.crossSegregateIndividualStatusId = crossSegregateIndividualStatusId;
    }

    public List<EventAssayResult> getEventAssayResults() {
        return eventAssayResults;
    }

    public void setEventAssayResults(List<EventAssayResult> eventAssayResults) {
        this.eventAssayResults = eventAssayResults;
    }

    public RemovableEventSop getRemovableEventSop() {
        return removableEventSop;
    }

    public void setRemovableEventSop(RemovableEventSop removableEventSop) {
        this.removableEventSop = removableEventSop;
    }
}
