/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.inventory;

public class InbredGermplasmTO {

    private Long inbredGermplasmId;
    private Long inbredBaseId;
    private String inbredBaseName;
    private String baseSuffixTxt;

    public Long getInbredGermplasmId() {
        return inbredGermplasmId;
    }

    public void setInbredGermplasmId(Long inbredGermplasmId) {
        this.inbredGermplasmId = inbredGermplasmId;
    }

    public Long getInbredBaseId() {
        return inbredBaseId;
    }

    public void setInbredBaseId(Long inbredBaseId) {
        this.inbredBaseId = inbredBaseId;
    }

    public String getInbredBaseName() {
        return inbredBaseName;
    }

    public void setInbredBaseName(String inbredBaseName) {
        this.inbredBaseName = inbredBaseName;
    }

    public String getBaseSuffixTxt() {
        return baseSuffixTxt;
    }

    public void setBaseSuffixTxt(String baseSuffixTxt) {
        this.baseSuffixTxt = baseSuffixTxt;
    }
}