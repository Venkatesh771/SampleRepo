package com.monsanto.tcc.inventorycommon.service;

import com.monsanto.tcc.inventorycommon.transferobject.subinventory.CreateSubInventoryRequest;
import com.monsanto.tcc.inventorycommon.transferobject.subinventory.CreateSubInventoryResponse;
import com.monsanto.tcc.inventorycommon.transferobject.subinventory.ImportSubInventoryRequest;
import com.monsanto.tcc.inventorycommon.transferobject.subinventory.ImportSubInventoryResponse;

import javax.jws.WebService;

@WebService
public interface CreateSubInventoryService {
    public CreateSubInventoryResponse create(CreateSubInventoryRequest subInventoryRequest);

    public CreateSubInventoryResponse createSubInventoriesForMonsantoData(CreateSubInventoryRequest subInventoryRequest);

    public ImportSubInventoryResponse importValidation(ImportSubInventoryRequest importSubInventoryRequest);
}