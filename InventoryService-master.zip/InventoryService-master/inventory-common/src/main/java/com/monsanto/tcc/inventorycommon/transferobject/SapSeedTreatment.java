package com.monsanto.tcc.inventorycommon.transferobject;

public class SapSeedTreatment extends SapSeedTreatmentInput {
    private String acronym;
    private String materialDescription;
    private String treatment;
    private String seedSize;
    private String seedColor;

    public String getAcronym() {
        return acronym;
    }

    public void setAcronym(String acronym) {
        this.acronym = acronym;
    }

    public String getMaterialDescription() {
        return materialDescription;
    }

    public void setMaterialDescription(String materialDescription) {
        this.materialDescription = materialDescription;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    public String getSeedSize() {
        return seedSize;
    }

    public void setSeedSize(String seedSize) {
        this.seedSize = seedSize;
    }

    public String getSeedColor() {
        return seedColor;
    }

    public void setSeedColor(String seedColor) {
        this.seedColor = seedColor;
    }
}
