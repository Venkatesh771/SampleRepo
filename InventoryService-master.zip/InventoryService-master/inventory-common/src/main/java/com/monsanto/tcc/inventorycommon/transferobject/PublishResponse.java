package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.domain.ShipmentToInventoryIdRelation;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jul 30, 2009
 * Time: 10:41:00 AM
 */
public class PublishResponse {
    private Boolean result;
    private String responseDetail;
    private List<String> inventoryBarcodes;
    private List<ShipmentToInventoryIdRelation> relations;

    public PublishResponse() {
    }

    public PublishResponse(Boolean result, String responseDetail, List<String> inventoryBarcodes) {
        this.result = result;
        this.responseDetail = responseDetail;
        this.inventoryBarcodes = inventoryBarcodes;
    }

    public PublishResponse(Boolean result, String responseDetail, List<String> inventoryBarcodes, List<ShipmentToInventoryIdRelation> relations) {
        this.result = result;
        this.responseDetail = responseDetail;
        this.inventoryBarcodes = inventoryBarcodes;
        this.relations = relations;
    }

    public Boolean getResult() {
        return result;
    }

    public void setResult(Boolean result) {
        this.result = result;
    }

    public String getResponseDetail() {
        return responseDetail;
    }

    public void setResponseDetail(String responseDetail) {
        this.responseDetail = responseDetail;
    }

    public List<String> getInventoryBarcodes() {
        return inventoryBarcodes;
    }

    public void setInventoryBarcodes(List<String> inventoryBarcodes) {
        this.inventoryBarcodes = inventoryBarcodes;
    }

    public List<ShipmentToInventoryIdRelation> getRelations() {
        return relations;
    }

    public void setRelations(List<ShipmentToInventoryIdRelation> relations) {
        this.relations = relations;
    }
}
