package com.monsanto.tcc.inventorycommon.projectcreation.transferobject;

import com.monsanto.tcc.inventorycommon.projectcreation.client.ProjectCreationStartUpResponse;

import javax.xml.bind.annotation.XmlType;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: MDSPARK
 * Date: Oct 15, 2009
 * Time: 8:55:27 PM
 * To change this template use File | Settings | File Templates.
 */
@XmlType(name = "SendToProjectCreationResponse_Name")
public class SendToProjectCreationResponse {
    private List<SendToProjectCreationResponseItem> responseItems = new ArrayList<SendToProjectCreationResponseItem>();
    ProjectCreationStartUpResponse startUpResponse;

    public List<SendToProjectCreationResponseItem> getResponseItems() {
        return responseItems;
    }

    public void setResponseItems(List<SendToProjectCreationResponseItem> responseItems) {
        this.responseItems = responseItems;
    }

    public ProjectCreationStartUpResponse getStartUpResponse() {
        return startUpResponse;
    }

    public void setStartUpResponse(ProjectCreationStartUpResponse startUpResponse) {
        this.startUpResponse = startUpResponse;
    }
}
