package com.monsanto.tcc.inventorycommon.domain;

import java.util.Date;


/**
 * Created by IntelliJ IDEA. User: SSNALL Date: Mar 3, 2010 Time: 10:46:49 AM To change this template use File | Settings | File Templates.
 */
public class SubSubSiteTO {

    private Long subSubSiteId;
    private String name;
    private String description;
    private Long subSubSiteTypeId;
    private Long subSiteId;
    private Date inactiveDttm;

    public Long getSubSubSiteId() {
        return subSubSiteId;
    }

    public void setSubSubSiteId(Long subSubSiteId) {
        this.subSubSiteId = subSubSiteId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getSubSubSiteTypeId() {
        return subSubSiteTypeId;
    }

    public void setSubSubSiteTypeId(Long subSubSiteTypeId) {
        this.subSubSiteTypeId = subSubSiteTypeId;
    }

    public Long getSubSiteId() {
        return subSiteId;
    }

    public void setSubSiteId(Long subSiteId) {
        this.subSiteId = subSiteId;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SubSubSiteTO that = (SubSubSiteTO) o;

        if (name != null ? !name.equals(that.name) : that.name != null) {
            return false;
        }
        if (subSubSiteId != null ? !subSubSiteId.equals(that.subSubSiteId) : that.subSubSiteId != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = subSubSiteId != null ? subSubSiteId.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }
}
