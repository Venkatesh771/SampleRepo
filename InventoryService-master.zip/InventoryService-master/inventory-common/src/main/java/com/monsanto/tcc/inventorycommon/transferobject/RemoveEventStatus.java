package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Feb 17, 2010
 * Time: 2:49:03 PM
 */
public enum RemoveEventStatus {
    SUCCESS,
    ERROR,
    ALREADY_MARKED_FOR_DELETE
}
