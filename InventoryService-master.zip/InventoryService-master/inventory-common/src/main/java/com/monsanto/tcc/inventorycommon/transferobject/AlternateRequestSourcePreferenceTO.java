package com.monsanto.tcc.inventorycommon.transferobject;

public class AlternateRequestSourcePreferenceTO {

    private String alternateBarcode;
    private Long sequence;


    public String getAlternateBarcode() {
        return alternateBarcode;
    }

    public void setAlternateBarcode(String alternateBarcode) {
        this.alternateBarcode = alternateBarcode;
    }

    public Long getSequence() {
        return sequence;
    }

    public void setSequence(Long sequence) {
        this.sequence = sequence;
    }
}
