package com.monsanto.tcc.inventorycommon.domain;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: lapoel
 * Date: May 28, 2009
 * Time: 9:40:17 AM
 */
public class RequestReason extends Reason {

    public RequestReason() {
    }

    public RequestReason(Long id, String description, String name) {
        super(id, description, name);
    }

    public RequestReason(Long id, String description, String name, Date inactiveDttm) {
        super(id, description, name, inactiveDttm);
    }
}
