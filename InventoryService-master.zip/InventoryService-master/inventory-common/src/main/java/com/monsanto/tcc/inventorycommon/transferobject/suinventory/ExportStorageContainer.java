/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.suinventory;

/* nbwald - Dec 17, 2010 */
public class ExportStorageContainer {
    private String siteName;
    private String subSiteName;
    private String subSubSiteName;
    private String storageLocationName;
    private String storageContainerName;
    private String storageContainerBarcode;
    private String storageContainerTypeName;
    private String storageContainerDescription;
    private long numInventories;
    private String parentStorageUnitBarcode;
    private String storageLocationPath;

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getSubSiteName() {
        return subSiteName;
    }

    public void setSubSiteName(String subSiteName) {
        this.subSiteName = subSiteName;
    }

    public String getSubSubSiteName() {
        return subSubSiteName;
    }

    public void setSubSubSiteName(String subSubSiteName) {
        this.subSubSiteName = subSubSiteName;
    }

    public String getStorageLocationName() {
        return storageLocationName;
    }

    public void setStorageLocationName(String storageLocationName) {
        this.storageLocationName = storageLocationName;
    }

    public String getStorageContainerName() {
        return storageContainerName;
    }

    public void setStorageContainerName(String storageContainerName) {
        this.storageContainerName = storageContainerName;
    }

    public String getStorageContainerBarcode() {
        return storageContainerBarcode;
    }

    public void setStorageContainerBarcode(String storageContainerBarcode) {
        this.storageContainerBarcode = storageContainerBarcode;
    }

    public String getStorageContainerTypeName() {
        return storageContainerTypeName;
    }

    public void setStorageContainerTypeName(String storageContainerTypeName) {
        this.storageContainerTypeName = storageContainerTypeName;
    }

    public String getStorageContainerDescription() {
        return storageContainerDescription;
    }

    public void setStorageContainerDescription(String storageContainerDescription) {
        this.storageContainerDescription = storageContainerDescription;
    }

    public long getNumInventories() {
        return numInventories;
    }

    public void setNumInventories(long numInventories) {
        this.numInventories = numInventories;
    }

    public String getParentStorageUnitBarcode() {
        return parentStorageUnitBarcode;
    }

    public void setParentStorageUnitBarcode(String parentStorageUnitBarcode) {
        this.parentStorageUnitBarcode = parentStorageUnitBarcode;
    }

    public String getStorageLocationPath() {
        return storageLocationPath;
    }

    public void setStorageLocationPath(String storageLocationPath) {
        this.storageLocationPath = storageLocationPath;
    }
}