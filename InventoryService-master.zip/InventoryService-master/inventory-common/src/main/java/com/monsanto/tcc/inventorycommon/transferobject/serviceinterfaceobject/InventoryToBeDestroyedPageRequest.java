package com.monsanto.tcc.inventorycommon.transferobject.serviceinterfaceobject;

import java.util.List;

public class InventoryToBeDestroyedPageRequest {
    private List<Long> programIds;

    public List<Long> getProgramIds() {
        return programIds;
    }

    public void setProgramIds(List<Long> programIds) {
        this.programIds = programIds;
    }
}
