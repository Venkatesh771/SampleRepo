package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.filter.Filter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: vvalav
 * Date: Apr 3, 2009
 * Time: 10:42:07 AM
 * To change this template use File | Settings | File Templates.
 */
public class InventoryServiceGetSummaryDataRequest {
    private Filter[] filter;

    public InventoryServiceGetSummaryDataRequest() {

    }

    public Filter[] getFilter() {
        return filter;
    }

    public List<Filter> getListOfFilters() {
        List filterList = new ArrayList();
        for(int i=0;i<filter.length;i++) {
            filterList.add(filter[i]);
        }
        return filterList;
    }

    public void setFilter(Filter[] filter) {
        this.filter = filter;
    }

    public CompositeObject getCompositeObject() {
        CompositeObject compositeObject = new CompositeObject();
        compositeObject.addAll(getListOfFilters());
        return compositeObject;
    }
}
