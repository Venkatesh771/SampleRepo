package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.domain.Observation;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: RRPATN
 * Date: Feb 5, 2010
 * Time: 10:55:13 AM
 */
public class EventAssayResult {
    private Long observationId;
    private String plotBarcode;
    private String inventoryBarcode;
    private String generation;
    private String labName;
    private Date updateTime;
    private LabTechnologyAssayResult labTechnologyAssayResult;
    private Long inventoryId;
    private Long plotId;
    private Long laboratoryId;
    private String requestId;
    private String sampleNumber;
    private Long observationClassificationId;

    public EventAssayResult() {
    }

    public EventAssayResult(Observation observation) {
        if (null != observation) {
            observationId = observation.getObservationId();
            updateTime = observation.getUpdateGmtTimestamp();
            setMaterialInformation(observation);
            setLaboratoryInformation(observation);
            setObservationClassificationId(observation);
        }
    }

    private void setObservationClassificationId(Observation observation) {
        if (null != observation.getObservationClassification()) {
            observationClassificationId = observation.getObservationClassification().getObsvClassificationId();
        }
    }

    private void setLaboratoryInformation(Observation observation) {
        if (null != observation.getLaboratorySample()) {
            sampleNumber = observation.getLaboratorySample().getSampleNumber();
            if (null != observation.getLaboratorySample().getLaboratoryRequest()) {
                requestId = observation.getLaboratorySample().getLaboratoryRequest().getRequestId();
                if (null != observation.getLaboratorySample().getLaboratoryRequest().getLaboratory()) {
                    laboratoryId = observation.getLaboratorySample().getLaboratoryRequest().getLaboratory().getLaboratoryId();
                    labName = observation.getLaboratorySample().getLaboratoryRequest().getLaboratory().getName();
                }
            }
        }
    }

    private void setMaterialInformation(Observation observation) {
        if (observation.getPlot() != null) {
            plotId = observation.getPlot().getPlotId();
            plotBarcode = observation.getPlot().getBarcode();
            generation = observation.getPlot().getInventory().getGeneticMaterial().getGeneration();
        }
        if (observation.getInventory() != null) {
            inventoryId = observation.getInventory().getId();
            inventoryBarcode = observation.getInventory().getBarcode();
            generation = observation.getInventory().getGeneticMaterial().getGeneration();
        }
    }

    public Long getObservationId() {
        return observationId;
    }

    public void setObservationId(Long observationId) {
        this.observationId = observationId;
    }

    public String getPlotBarcode() {
        return plotBarcode;
    }

    public void setPlotBarcode(String plotBarcode) {
        this.plotBarcode = plotBarcode;
    }

    public String getInventoryBarcode() {
        return inventoryBarcode;
    }

    public void setInventoryBarcode(String inventoryBarcode) {
        this.inventoryBarcode = inventoryBarcode;
    }

    public String getGeneration() {
        return generation;
    }

    public void setGeneration(String generation) {
        this.generation = generation;
    }

    public String getLabName() {
        return labName;
    }

    public void setLabName(String labName) {
        this.labName = labName;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public LabTechnologyAssayResult getLabTechnologyAssayResult() {
        return labTechnologyAssayResult;
    }

    public void setLabTechnologyAssayResult(LabTechnologyAssayResult labTechnologyAssayResult) {
        this.labTechnologyAssayResult = labTechnologyAssayResult;
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Long getPlotId() {
        return plotId;
    }

    public void setPlotId(Long plotId) {
        this.plotId = plotId;
    }

    public Long getLaboratoryId() {
        return laboratoryId;
    }

    public void setLaboratoryId(Long laboratoryId) {
        this.laboratoryId = laboratoryId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getSampleNumber() {
        return sampleNumber;
    }

    public void setSampleNumber(String sampleNumber) {
        this.sampleNumber = sampleNumber;
    }

    public Long getObservationClassificationId() {
        return observationClassificationId;
    }

    public void setObservationClassificationId(Long observationClassificationId) {
        this.observationClassificationId = observationClassificationId;
    }
}
