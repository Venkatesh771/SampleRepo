package com.monsanto.tcc.inventorycommon.service;

import com.monsanto.tcc.inventorycommon.transferobject.serviceinterfaceobject.CreateInventoryContainerRequest;

import javax.jws.Oneway;
import javax.jws.WebService;
import java.util.Collection;

@WebService(name = "CreateInventoryContainerQueueService", targetNamespace = "http://jms.inventoryservice.tcc.monsanto.com")
public interface CreateInventoryContainerQueueService {
    @Oneway
    void create(Collection<CreateInventoryContainerRequest> requests);
}
