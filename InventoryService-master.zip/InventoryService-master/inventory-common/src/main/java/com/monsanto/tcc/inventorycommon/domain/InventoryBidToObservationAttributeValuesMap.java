package com.monsanto.tcc.inventorycommon.domain;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * Created by IntelliJ IDEA.
 * User: mdspark
 * Date: Sep 23, 2009
 * Time: 10:19:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class InventoryBidToObservationAttributeValuesMap {
    @XmlJavaTypeAdapter(MapAdapter.class)
    Map<String, List<ObservationAttributeValue>> map = new HashMap<String, List<ObservationAttributeValue>>();

    public void put(String inventoryBarcode, ObservationAttributeValue obsvervationAttributeValue){
        List<ObservationAttributeValue> observationAttributeValueList = map.get(inventoryBarcode);
        if(null == observationAttributeValueList){
            observationAttributeValueList = new ArrayList<ObservationAttributeValue>();
        }
        observationAttributeValueList.add(obsvervationAttributeValue);
        map.put(inventoryBarcode, observationAttributeValueList);
    }

    public List<ObservationAttributeValue> get(String inventoryBarcode) {
        return map.get(inventoryBarcode);
    }

    public Map<String, List<ObservationAttributeValue>> getMap() {
        return map;
    }

}
