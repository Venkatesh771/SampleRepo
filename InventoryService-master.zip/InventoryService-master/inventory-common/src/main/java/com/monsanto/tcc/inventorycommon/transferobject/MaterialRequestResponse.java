package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: May 6, 2009
 * Time: 3:55:12 PM
 */
public class MaterialRequestResponse {
    private Boolean result;
    private String responseDetail;
    private List<String> regulatedBarCodes;

    public MaterialRequestResponse() {
    }

    public MaterialRequestResponse(Boolean result, String responseDetail) {
        this.result = result;
        this.responseDetail = responseDetail;
    }

    public MaterialRequestResponse(Boolean result, String responseDetail, List<String> regulatedBarCodes) {
        this.result = result;
        this.responseDetail = responseDetail;
        this.regulatedBarCodes = regulatedBarCodes;
    }

    public Boolean getResult() {
        return result;
    }

    public void setResult(Boolean result) {
        this.result = result;
    }

    public String getResponseDetail() {
        return responseDetail;
    }

    public void setResponseDetail(String responseDetail) {
        this.responseDetail = responseDetail;
    }

    public List<String> getRegulatedBarCodes() {
        return regulatedBarCodes;
    }

    public void setRegulatedBarCodes(List<String> regulatedBarCodes) {
        this.regulatedBarCodes = regulatedBarCodes;
    }
}
