package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.List;

public class SapSeedTreatmentResponse {
    private List<SapSeedTreatment> sapSeedTreatments;

    public List<SapSeedTreatment> getSapSeedTreatments() {
        return sapSeedTreatments;
    }

    public void setSapSeedTreatments(List<SapSeedTreatment> sapSeedTreatments) {
        this.sapSeedTreatments = sapSeedTreatments;
    }
}
