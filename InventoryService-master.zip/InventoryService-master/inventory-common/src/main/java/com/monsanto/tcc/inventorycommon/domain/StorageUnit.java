package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.storageunit.StorageUnitType;

import javax.xml.bind.annotation.XmlType;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jul 7, 2009
 * Time: 4:59:54 PM
 */
@XmlType(name= "Storage_Unit")
public class StorageUnit {
    private String isActive;
    private String description;
    private Long addressId;
    private Long parentStorageUnitId;
    private Date creationDate;
    private Long counter;
    private StorageUnitType storageUnitType;
    private Long inventorySystemId;
    private Long year;
    private String barcode;
    private String name;
    private Long storageUnitId;

    public Long getStorageUnitId() {
        return storageUnitId;
    }

    public void setStorageUnitId(Long storageUnitId) {
        this.storageUnitId = storageUnitId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Long getYear() {
        return year;
    }

    public void setYear(Long year) {
        this.year = year;
    }

    public Long getInventorySystemId() {
        return inventorySystemId;
    }

    public void setInventorySystemId(Long inventorySystemId) {
        this.inventorySystemId = inventorySystemId;
    }

    public StorageUnitType getStorageUnitType() {
        return storageUnitType;
    }

    public void setStorageUnitType(StorageUnitType storageUnitType) {
        this.storageUnitType = storageUnitType;
    }

    public Long getCounter() {
        return counter;
    }

    public void setCounter(Long counter) {
        this.counter = counter;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Long getParentStorageUnitId() {
        return parentStorageUnitId;
    }

    public void setParentStorageUnitId(Long parentStorageUnitId) {
        this.parentStorageUnitId = parentStorageUnitId;
    }

    public Long getAddressId() {
        return addressId;
    }

    public void setAddressId(Long addressId) {
        this.addressId = addressId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String active) {
        isActive = active;
    }
}
