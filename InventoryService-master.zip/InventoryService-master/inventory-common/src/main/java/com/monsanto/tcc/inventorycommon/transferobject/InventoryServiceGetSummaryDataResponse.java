package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.client.breedingsamplemanagement.InventoryLotRelation;
import com.monsanto.services.domain.breeding.uom.UnitOfMeasure;
import com.monsanto.services.domain.common.CompositeObject;
import com.monsanto.services.domain.common.envelope.ResponseEnvelope;
import com.monsanto.services.domain.shipping.StorageContainer;
import com.monsanto.services.domain.shipping.StorageUnit;
import com.monsanto.tcc.inventorycommon.domain.InventoryBidToObservationAttributeValuesMap;
import com.monsanto.services.domain.breeding.*;
import com.monsanto.services.domain.germplasm.*;
import com.monsanto.tcc.inventorycommon.domain.InventorySample;
import com.monsanto.tcc.inventorycommon.domain.MolecularBreedingRequest;
import com.monsanto.tcc.inventorycommon.domain.TermsOfUseSummaryData;
import com.monsanto.tcc.inventorycommon.domain.RubProj;

import javax.xml.bind.annotation.XmlType;
import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: vvalav Date: Apr 3, 2009 Time: 10:18:32 AM To change this template use File |
 * Settings | File Templates.
 */
@XmlType(name = "Inventory_Service_Get_Summary_Data_Response")
public class InventoryServiceGetSummaryDataResponse {

    private List<Inventory> inventories;
    private List<GeneticMaterial> geneticMaterials;
    private List<Germplasm> germplasms;
    private List<Program> programs;
    private List<SharedInventory> sharedInventories;
    private List<SharedInventorySummary> sharedInventorySummaries;
    private List<InventoryLotRelation> inventoryLotRelations;
    private List<ProductDescription> productDescriptions;
    private List<InventoryType> inventoryTypes;
    private List<ProgramRole> programRoles;
    private List<LineFunction> lineFunctions;
    private List<LineType> lineTypes;
    private List<InventoryContainer> inventoryContainers;
    private List<StorageUnit> storageUnits;
    private List<DisplayInventoryProductName> displayInventoryProductNames;
    private List<ProductName> productNames;
    private List<VegetativeStructure> vegetativeStructures;
    private List<GeneticMaterialRubProj> geneticMaterialRubProjs;
    private InventoryBidToObservationAttributeValuesMap invBidToObservationAttributeValuesMap;
    private List<MaterialExchange> materialExchanges;
    private List<UnitOfMeasure> unitOfMeasures;
    private List<InbredGermplasm> inbredGermplasms;
    private List<Crop> crops;
    private List<FateReason> fateReasons;
    private List<GenusSpecies> genusSpecies;
    private List<StorageContainer> storageContainers;
    private List<InventoryStatus> inventoryStatus;
    private List<InventoryRelatedData> inventoryRelatedData;
    private List<ParentInventory> parentInventories;
    private List<InventoryPurpose> inventoryPurposes;
    private List<TermsOfUseSummaryData> termsOfUseSummaries;
    private List<RubProj> rubProjs;
    private List<InventorySample> inventorySamples;
    private List<MolecularBreedingRequest> molecularBreedingRequests;


    public List<InventoryPurpose> getInventoryPurposes() {
        return inventoryPurposes;
    }

    public void setInventoryPurposes(List<InventoryPurpose> inventoryPurposes) {
        this.inventoryPurposes = inventoryPurposes;
    }


    public List<Inventory> getInventories() {
        return inventories;
    }

    public void setInventories(List<Inventory> inventories) {
        this.inventories = inventories;
    }

    public List<GeneticMaterial> getGeneticMaterials() {
        return geneticMaterials;
    }

    public void setGeneticMaterials(List<GeneticMaterial> geneticMaterials) {
        this.geneticMaterials = geneticMaterials;
    }

    public List<Germplasm> getGermplasms() {
        return germplasms;
    }

    public void setGermplasms(List<Germplasm> germplasms) {
        this.germplasms = germplasms;
    }

    public List<Program> getPrograms() {
        return programs;
    }

    public void setPrograms(List<Program> programs) {
        this.programs = programs;
    }

    public List<SharedInventory> getSharedInventories() {
        return sharedInventories;
    }

    public void setSharedInventories(List<SharedInventory> sharedInventories) {
        this.sharedInventories = sharedInventories;
    }

    public List<SharedInventorySummary> getSharedInventorySummaries() {
        return sharedInventorySummaries;
    }

    public void setSharedInventorySummaries(List<SharedInventorySummary> sharedInventorySummaries) {
        this.sharedInventorySummaries = sharedInventorySummaries;
    }

    public List<InventoryLotRelation> getInventoryLotRelations() {
        return inventoryLotRelations;
    }

    public void setInventoryLotRelations(List<InventoryLotRelation> inventoryLotRelations) {
        this.inventoryLotRelations = inventoryLotRelations;
    }

    public List<ProductDescription> getProductDescriptions() {
        return productDescriptions;
    }

    public void setProductDescriptions(List<ProductDescription> productDescriptions) {
        this.productDescriptions = productDescriptions;
    }

    public List<InventoryType> getInventoryTypes() {
        return inventoryTypes;
    }

    public void setInventoryTypes(List<InventoryType> inventoryTypes) {
        this.inventoryTypes = inventoryTypes;
    }

    public List<ProgramRole> getProgramRoles() {
        return programRoles;
    }

    public void setProgramRoles(List<ProgramRole> programRoles) {
        this.programRoles = programRoles;
    }

    public List<LineFunction> getLineFunctions() {
        return lineFunctions;
    }

    public void setLineFunctions(List<LineFunction> lineFunctions) {
        this.lineFunctions = lineFunctions;
    }

    public List<LineType> getLineTypes() {
        return lineTypes;
    }

    public void setLineTypes(List<LineType> lineTypes) {
        this.lineTypes = lineTypes;
    }

    public List<InventoryContainer> getInventoryContainers() {
        return inventoryContainers;
    }

    public void setInventoryContainers(List<InventoryContainer> inventoryContainers) {
        this.inventoryContainers = inventoryContainers;
    }

    public List<StorageUnit> getStorageUnits() {
        return storageUnits;
    }

    public void setStorageUnits(List<StorageUnit> storageUnits) {
        this.storageUnits = storageUnits;
    }

    public List<DisplayInventoryProductName> getDisplayInventoryProductNames() {
        return displayInventoryProductNames;
    }

    public void setDisplayInventoryProductNames(List<DisplayInventoryProductName> displayInventoryProductNames) {
        this.displayInventoryProductNames = displayInventoryProductNames;
    }

    public List<ProductName> getProductNames() {
        return productNames;
    }

    public void setProductNames(List<ProductName> productNames) {
        this.productNames = productNames;
    }

    public List<VegetativeStructure> getVegetativeStructures() {
        return vegetativeStructures;
    }

    public void setVegetativeStructures(List<VegetativeStructure> vegetativeStructures) {
        this.vegetativeStructures = vegetativeStructures;
    }

    public List<GeneticMaterialRubProj> getGeneticMaterialRubProjs() {
        return geneticMaterialRubProjs;
    }

    public void setGeneticMaterialRubProjs(List<GeneticMaterialRubProj> geneticMaterialRubProjs) {
        this.geneticMaterialRubProjs = geneticMaterialRubProjs;
    }

    public InventoryBidToObservationAttributeValuesMap getInvBidToObservationAttributeValuesMap() {
        return invBidToObservationAttributeValuesMap;
    }

    public void setInvBidToObservationAttributeValuesMap(
            InventoryBidToObservationAttributeValuesMap invBidToObservationAttributeValuesMap) {
        this.invBidToObservationAttributeValuesMap = invBidToObservationAttributeValuesMap;
    }

    public void setMaterialExchanges(List<MaterialExchange> materialExchanges) {
        this.materialExchanges = materialExchanges;
    }

    public List<MaterialExchange> getMaterialExchanges() {
        return materialExchanges;
    }

    public void setUnitOfMeasures(List<UnitOfMeasure> unitOfMeasures) {
        this.unitOfMeasures = unitOfMeasures;
    }

    public List<UnitOfMeasure> getUnitOfMeasures() {
        return unitOfMeasures;
    }

    public void setInbredGermplasms(List<InbredGermplasm> inbredGermplasms) {
        this.inbredGermplasms = inbredGermplasms;
    }

    public List<InbredGermplasm> getInbredGermplasms() {
        return inbredGermplasms;
    }

    public CompositeObject getComposite() {
        return getResponseEnvelope();
    }

    public List<Crop> getCrops() {
        return crops;
    }

    public void setCrops(List<Crop> crops) {
        this.crops = crops;
    }

    public List<FateReason> getFateReasons() {
        return fateReasons;
    }

    public void setFateReasons(List<FateReason> fateReasons) {
        this.fateReasons = fateReasons;
    }

    public List<GenusSpecies> getGenusSpecies() {
        return genusSpecies;
    }

    public void setGenusSpecies(List<GenusSpecies> genusSpecies) {
        this.genusSpecies = genusSpecies;
    }

    public List<StorageContainer> getStorageContainers() {
        return storageContainers;
    }

    public void setStorageContainers(List<StorageContainer> storageContainers) {
        this.storageContainers = storageContainers;
    }

    public List<InventoryStatus> getInventoryStatus() {
        return inventoryStatus;
    }

    public void setInventoryStatus(List<InventoryStatus> inventoryStatus) {
        this.inventoryStatus = inventoryStatus;
    }

    public List<InventoryRelatedData> getInventoryRelatedData() {
        return inventoryRelatedData;
    }

    public void setInventoryRelatedData(List<InventoryRelatedData> inventoryRelatedData) {
        this.inventoryRelatedData = inventoryRelatedData;
    }

    public List<ParentInventory> getParentInventories() {
        return parentInventories;
    }

    public void setParentInventories(List<ParentInventory> parentInventories) {
        this.parentInventories = parentInventories;
    }

    public List<TermsOfUseSummaryData> getTermsOfUseSummaries() {
        return termsOfUseSummaries;
    }

    public void setTermsOfUseSummaries(List<TermsOfUseSummaryData> termsOfUseSummaries) {
        this.termsOfUseSummaries = termsOfUseSummaries;
    }

    public List<RubProj> getRubProjs() {
        return rubProjs;
    }

    public void setRubProjs(List<RubProj> rubProjs) {
        this.rubProjs = rubProjs;
    }

    public List<InventorySample> getInventorySamples() {
        return inventorySamples;
    }

    public void setInventorySamples(List<InventorySample> inventorySamples) {
        this.inventorySamples = inventorySamples;
    }

    public List<MolecularBreedingRequest> getMolecularBreedingRequests() {
        return molecularBreedingRequests;
    }

    public void setMolecularBreedingRequests(List<MolecularBreedingRequest> molecularBreedingRequests) {
        this.molecularBreedingRequests = molecularBreedingRequests;
    }

    public ResponseEnvelope getResponseEnvelope() {
        ResponseEnvelope responseEnvelope = new ResponseEnvelope();
        add(responseEnvelope, getDisplayInventoryProductNames());
        add(responseEnvelope, getGeneticMaterials());
        add(responseEnvelope, getGermplasms());
        add(responseEnvelope, getInventories());
        add(responseEnvelope, getInventoryContainers());
        add(responseEnvelope, getInventoryLotRelations());
        add(responseEnvelope, getInventoryTypes());
        add(responseEnvelope, getLineFunctions());
        add(responseEnvelope, getLineTypes());
        add(responseEnvelope, getProductDescriptions());
        add(responseEnvelope, getProductNames());
        add(responseEnvelope, getPrograms());
        add(responseEnvelope, getProgramRoles());
        add(responseEnvelope, getSharedInventories());
        add(responseEnvelope, getSharedInventorySummaries());
        add(responseEnvelope, getStorageUnits());
        add(responseEnvelope, getVegetativeStructures());
        add(responseEnvelope, getGeneticMaterialRubProjs());
        responseEnvelope.add(getInvBidToObservationAttributeValuesMap());
        add(responseEnvelope, getMaterialExchanges());
        add(responseEnvelope, getUnitOfMeasures());
        add(responseEnvelope, getInbredGermplasms());
        add(responseEnvelope, getCrops());
        add(responseEnvelope, getFateReasons());
        add(responseEnvelope, getGenusSpecies());
        add(responseEnvelope, getStorageContainers());
        add(responseEnvelope, getInventoryStatus());
        add(responseEnvelope, getInventoryRelatedData());
        add(responseEnvelope, getParentInventories());
        add(responseEnvelope, getInventoryPurposes());
        add(responseEnvelope, getTermsOfUseSummaries());
        add(responseEnvelope, getRubProjs());
        add(responseEnvelope, getInventorySamples());
        add(responseEnvelope, getMolecularBreedingRequests());

        return responseEnvelope;
    }

    private void add(ResponseEnvelope responseEnvelope, Collection collection) {
        if (null != collection) {
            responseEnvelope.addAll(collection);
        }
    }
}
