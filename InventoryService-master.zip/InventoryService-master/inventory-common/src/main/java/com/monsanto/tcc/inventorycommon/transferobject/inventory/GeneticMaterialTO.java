/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.inventory;

public class GeneticMaterialTO {
    private Long geneticMaterialId;
    private GermplasmTO germplasm;
    private String sourceStr;
    private String generation;
    private String lineage;
    private String srcCrop;
    private String srcGrowProg;
    private Integer srcHarvMonth;
    private Integer srcHarvYear;
    private String srcLoc;
    private String srcOrigCountry;
    private String srcOrigProg;
    private Integer srcPlantMonth;
    private Integer srcPlantYear;
    private String srcMalePlotBid;
    private String srcSet;
    private String srcPlotBid;
    private Integer srcPlotNumber;
    private String srcProtocolName;
    private String srcTrkId;
    private InventorySourceRankTO inventorySourceRank;
    private Integer srcAbsCol;
    private Integer srcAbsRng;
    private Double srcEntryNumber;
    private String srcLotNumber;
    private Integer srcMaleCol;
    private String srcMaleProg;
    private Integer srcMaleRng;
    private Integer srcMaleSeqNumber;
    private String srcMaleSrNumber;
    private String srcMPlotBid;
    private String srcOperation;
    private String srcPollinationDate;
    private String srcRepNumber;
    private String srcSeason;
    private Integer srcSeqNumber;
    private Integer srcSubRowNumber;
    private Integer srcSubSubRowNumber;
    private String testerDisplay;
    private String rubProjDisplay;
    private String rubKeeperDisplay;
    private String transformationGeneration;
    private String templateText;

    public GeneticMaterialTO() {
    }

    public Long getGeneticMaterialId() {
        return geneticMaterialId;
    }

    public void setGeneticMaterialId(Long geneticMaterialId) {
        this.geneticMaterialId = geneticMaterialId;
    }

    public GermplasmTO getGermplasm() {
        return germplasm;
    }

    public void setGermplasm(GermplasmTO germplasm) {
        this.germplasm = germplasm;
    }

    public String getSourceStr() {
        return sourceStr;
    }

    public void setSourceStr(String sourceStr) {
        this.sourceStr = sourceStr;
    }

    public String getGeneration() {
        return generation;
    }

    public void setGeneration(String generation) {
        this.generation = generation;
    }


    public String getLineage() {
        return lineage;
    }

    public void setLineage(String lineage) {
        this.lineage = lineage;
    }

    public String getSrcCrop() {
        return srcCrop;
    }

    public void setSrcCrop(String srcCrop) {
        this.srcCrop = srcCrop;
    }

    public String getSrcGrowProg() {
        return srcGrowProg;
    }

    public void setSrcGrowProg(String srcGrowProg) {
        this.srcGrowProg = srcGrowProg;
    }

    public Integer getSrcHarvMonth() {
        return srcHarvMonth;
    }

    public void setSrcHarvMonth(Integer srcHarvMonth) {
        this.srcHarvMonth = srcHarvMonth;
    }

    public Integer getSrcHarvYear() {
        return srcHarvYear;
    }

    public void setSrcHarvYear(Integer srcHarvYear) {
        this.srcHarvYear = srcHarvYear;
    }

    public String getSrcLoc() {
        return srcLoc;
    }

    public void setSrcLoc(String srcLoc) {
        this.srcLoc = srcLoc;
    }

    public String getSrcOrigCountry() {
        return srcOrigCountry;
    }

    public void setSrcOrigCountry(String srcOrigCountry) {
        this.srcOrigCountry = srcOrigCountry;
    }

    public String getSrcOrigProg() {
        return srcOrigProg;
    }

    public void setSrcOrigProg(String srcOrigProg) {
        this.srcOrigProg = srcOrigProg;
    }

    public Integer getSrcPlantMonth() {
        return srcPlantMonth;
    }

    public void setSrcPlantMonth(Integer srcPlantMonth) {
        this.srcPlantMonth = srcPlantMonth;
    }

    public Integer getSrcPlantYear() {
        return srcPlantYear;
    }

    public void setSrcPlantYear(Integer srcPlantYear) {
        this.srcPlantYear = srcPlantYear;
    }

    public String getSrcMalePlotBid() {
        return srcMalePlotBid;
    }

    public void setSrcMalePlotBid(String srcMalePlotBid) {
        this.srcMalePlotBid = srcMalePlotBid;
    }

    public String getSrcSet() {
        return srcSet;
    }

    public void setSrcSet(String srcSet) {
        this.srcSet = srcSet;
    }

    public String getSrcPlotBid() {
        return srcPlotBid;
    }

    public void setSrcPlotBid(String srcPlotBid) {
        this.srcPlotBid = srcPlotBid;
    }

    public Integer getSrcPlotNumber() {
        return srcPlotNumber;
    }

    public void setSrcPlotNumber(Integer srcPlotNumber) {
        this.srcPlotNumber = srcPlotNumber;
    }

    public String getSrcProtocolName() {
        return srcProtocolName;
    }

    public void setSrcProtocolName(String srcProtocolName) {
        this.srcProtocolName = srcProtocolName;
    }

    public InventorySourceRankTO getInventorySourceRank() {
        return inventorySourceRank;
    }

    public void setInventorySourceRank(InventorySourceRankTO inventorySourceRank) {
        this.inventorySourceRank = inventorySourceRank;
    }

    public String getSrcTrkId() {
        return srcTrkId;
    }

    public void setSrcTrkId(String srcTrkId) {
        this.srcTrkId = srcTrkId;
    }

    public Integer getSrcAbsCol() {
        return srcAbsCol;
    }

    public void setSrcAbsCol(Integer srcAbsCol) {
        this.srcAbsCol = srcAbsCol;
    }

    public Integer getSrcAbsRng() {
        return srcAbsRng;
    }

    public void setSrcAbsRng(Integer srcAbsRng) {
        this.srcAbsRng = srcAbsRng;
    }

    public Double getSrcEntryNumber() {
        return srcEntryNumber;
    }

    public void setSrcEntryNumber(Double srcEntryNumber) {
        this.srcEntryNumber = srcEntryNumber;
    }

    public String getSrcLotNumber() {
        return srcLotNumber;
    }

    public void setSrcLotNumber(String srcLotNumber) {
        this.srcLotNumber = srcLotNumber;
    }

    public Integer getSrcMaleCol() {
        return srcMaleCol;
    }

    public void setSrcMaleCol(Integer srcMaleCol) {
        this.srcMaleCol = srcMaleCol;
    }

    public String getSrcMaleProg() {
        return srcMaleProg;
    }

    public void setSrcMaleProg(String srcMaleProg) {
        this.srcMaleProg = srcMaleProg;
    }

    public Integer getSrcMaleRng() {
        return srcMaleRng;
    }

    public void setSrcMaleRng(Integer srcMaleRng) {
        this.srcMaleRng = srcMaleRng;
    }

    public Integer getSrcMaleSeqNumber() {
        return srcMaleSeqNumber;
    }

    public void setSrcMaleSeqNumber(Integer srcMaleSeqNumber) {
        this.srcMaleSeqNumber = srcMaleSeqNumber;
    }

    public String getSrcMaleSrNumber() {
        return srcMaleSrNumber;
    }

    public void setSrcMaleSrNumber(String srcMaleSrNumber) {
        this.srcMaleSrNumber = srcMaleSrNumber;
    }

    public String getSrcMPlotBid() {
        return srcMPlotBid;
    }

    public void setSrcMPlotBid(String srcMPlotBid) {
        this.srcMPlotBid = srcMPlotBid;
    }

    public String getSrcOperation() {
        return srcOperation;
    }

    public void setSrcOperation(String srcOperation) {
        this.srcOperation = srcOperation;
    }

    public String getSrcPollinationDate() {
        return srcPollinationDate;
    }

    public void setSrcPollinationDate(String srcPollinationDate) {
        this.srcPollinationDate = srcPollinationDate;
    }

    public String getSrcRepNumber() {
        return srcRepNumber;
    }

    public void setSrcRepNumber(String srcRepNumber) {
        this.srcRepNumber = srcRepNumber;
    }

    public String getSrcSeason() {
        return srcSeason;
    }

    public void setSrcSeason(String srcSeason) {
        this.srcSeason = srcSeason;
    }

    public Integer getSrcSeqNumber() {
        return srcSeqNumber;
    }

    public void setSrcSeqNumber(Integer srcSeqNumber) {
        this.srcSeqNumber = srcSeqNumber;
    }

    public Integer getSrcSubRowNumber() {
        return srcSubRowNumber;
    }

    public void setSrcSubRowNumber(Integer srcSubRowNumber) {
        this.srcSubRowNumber = srcSubRowNumber;
    }

    public Integer getSrcSubSubRowNumber() {
        return srcSubSubRowNumber;
    }

    public void setSrcSubSubRowNumber(Integer srcSubSubRowNumber) {
        this.srcSubSubRowNumber = srcSubSubRowNumber;
    }

    public String getTesterDisplay() {
        return testerDisplay;
    }

    public void setTesterDisplay(String testerDisplay) {
        this.testerDisplay = testerDisplay;
    }

    public String getRubProjDisplay() {
        return rubProjDisplay;
    }

    public void setRubProjDisplay(String rubProjDisplay) {
        this.rubProjDisplay = rubProjDisplay;
    }

    public String getRubKeeperDisplay() {
        return rubKeeperDisplay;
    }

    public void setRubKeeperDisplay(String rubKeeperDisplay) {
        this.rubKeeperDisplay = rubKeeperDisplay;
    }

    public String getTransformationGeneration() {
        return transformationGeneration;
    }

    public void setTransformationGeneration(String transformationGeneration) {
        this.transformationGeneration = transformationGeneration;
    }

    public String getTemplateText() {
        return templateText;
    }

    public void setTemplateText(String templateText) {
        this.templateText = templateText;
    }
}
