package com.monsanto.tcc.inventorycommon.domain;

import java.sql.Date;

public class StorageContainerLocation {

    private Long storageContainerLocationId;
    private Long storageLocationCatalogId;
    private Long storageContainerId;
    private Long activityId;
    private Date inactiveDttm;
    private StorageContainer storageContainerByStorageContainerId;
    private StorageLocationCatalog storageLocationCatalogByStorageLocationCatalogId;

    public Long getStorageContainerLocationId() {
        return storageContainerLocationId;
    }

    public void setStorageContainerLocationId(Long storageContainerLocationId) {
        this.storageContainerLocationId = storageContainerLocationId;
    }

    public Long getStorageLocationCatalogId() {
        return storageLocationCatalogId;
    }

    public void setStorageLocationCatalogId(Long storageLocationCatalogId) {
        this.storageLocationCatalogId = storageLocationCatalogId;
    }

    public Long getStorageContainerId() {
        return storageContainerId;
    }

    public void setStorageContainerId(Long storageContainerId) {
        this.storageContainerId = storageContainerId;
    }

    public Long getActivityId() {
        return activityId;
    }

    public void setActivityId(Long activityId) {
        this.activityId = activityId;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }

    public StorageContainer getStorageContainerByStorageContainerId() {
        return storageContainerByStorageContainerId;
    }

    public void setStorageContainerByStorageContainerId(StorageContainer storageContainerByStorageContainerId) {
        this.storageContainerByStorageContainerId = storageContainerByStorageContainerId;
    }

    public StorageLocationCatalog getStorageLocationCatalogByStorageLocationCatalogId() {
        return storageLocationCatalogByStorageLocationCatalogId;
    }

    public void setStorageLocationCatalogByStorageLocationCatalogId(StorageLocationCatalog storageLocationCatalogByStorageLocationCatalogId) {
        this.storageLocationCatalogByStorageLocationCatalogId = storageLocationCatalogByStorageLocationCatalogId;
    }
}
