package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.bpm.ActivityInstance;

import java.util.List;


public class MaterialRequestPublishData {

    private long materialRequestDetailId;
    private String comments;
    private ActivityInstance bpmActivityInstance;
    private List<InventoryAmount> publishInventoryAmounts;


    public MaterialRequestPublishData() {
    }

    public long getMaterialRequestDetailId() {
        return materialRequestDetailId;
    }

    public void setMaterialRequestDetailId(long materialRequestDetailId) {
        this.materialRequestDetailId = materialRequestDetailId;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public List<InventoryAmount> getPublishInventoryAmounts() {
        return publishInventoryAmounts;
    }

    public void setPublishInventoryAmounts(List<InventoryAmount> publishInventoryAmounts) {
        this.publishInventoryAmounts = publishInventoryAmounts;
    }

    public ActivityInstance getBpmActivityInstance() {
        return bpmActivityInstance;
    }

    public void setBpmActivityInstance(ActivityInstance bpmActivityInstance) {
        this.bpmActivityInstance = bpmActivityInstance;
    }
}
