package com.monsanto.tcc.inventorycommon.transferobject;

import javax.xml.bind.annotation.XmlType;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Feb 17, 2010
 * Time: 2:50:38 PM
 */
@XmlType(name = "Inventory_RemoveEventResponse")
public class RemoveEventResponse {
    private RemoveEventStatus removeEventStatus;
    private String message;

    public RemoveEventResponse(RemoveEventStatus removeEventStatus, String message) {
        this.removeEventStatus = removeEventStatus;
        this.message = message;
    }

    public RemoveEventResponse() {
        removeEventStatus = RemoveEventStatus.SUCCESS;
    }

    public RemoveEventStatus getRemoveEventStatus() {
        return removeEventStatus;
    }

    public void setRemoveEventStatus(RemoveEventStatus removeEventStatus) {
        this.removeEventStatus = removeEventStatus;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
