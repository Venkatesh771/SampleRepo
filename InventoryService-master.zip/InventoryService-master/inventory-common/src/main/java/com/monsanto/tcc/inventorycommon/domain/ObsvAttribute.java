package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: mdspark
 * Date: Sep 23, 2009
 * Time: 12:09:31 PM
 * To change this template use File | Settings | File Templates.
 */
public class ObsvAttribute {
    private Long obsvAttributeId;
    private String name;
    private TraitValType obsvAttributeValType;
    private String obsvAttributeRefId;
    private String rankOrder;
    private String refActive;

    public Long getObsvAttributeId() {
        return obsvAttributeId;
    }

    public void setObsvAttributeId(Long obsvAttributeId) {
        this.obsvAttributeId = obsvAttributeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public TraitValType getObsvAttributeValType() {
        return obsvAttributeValType;
    }

    public void setObsvAttributeValType(TraitValType obsvAttributeValType) {
        this.obsvAttributeValType = obsvAttributeValType;
    }

    public String getObsvAttributeRefId() {
        return obsvAttributeRefId;
    }

    public void setObsvAttributeRefId(String obsvAttributeRefId) {
        this.obsvAttributeRefId = obsvAttributeRefId;
    }

    public String getRankOrder() {
        return rankOrder;
    }

    public void setRankOrder(String rankOrder) {
        this.rankOrder = rankOrder;
    }

    public String getRefActive() {
        return refActive;
    }

    public void setRefActive(String refActive) {
        this.refActive = refActive;
    }
}
