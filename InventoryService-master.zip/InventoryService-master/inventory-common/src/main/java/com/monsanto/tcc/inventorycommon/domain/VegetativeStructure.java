/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "Vegetative_Structure")
public class VegetativeStructure {
    private Long vegetativeStructureId;
    private String name;
    private String refCode;
    private Boolean refActive;

    public VegetativeStructure() {
    }

    public VegetativeStructure(Long vegatativeStructureId, String name, String refCode, Boolean refActive) {
        this.vegetativeStructureId = vegatativeStructureId;
        this.name = name;
        this.refCode = refCode;
        this.refActive = refActive;
    }

    public Long getVegetativeStructureId() {
        return vegetativeStructureId;
    }

    public void setVegetativeStructureId(Long vegetativeStructureId) {
        this.vegetativeStructureId = vegetativeStructureId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRefCode() {
        return refCode;
    }

    public void setRefCode(String refCode) {
        this.refCode = refCode;
    }

    public Boolean getRefActive() {
        return refActive;
    }

    public void setRefActive(Boolean refActive) {
        this.refActive = refActive;
    }
}