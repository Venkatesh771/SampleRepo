package com.monsanto.tcc.inventorycommon.domain;

import javax.xml.bind.annotation.XmlType;
import java.lang.String;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 15, 2009
 * Time: 12:37:57 PM
 */
@XmlType(name = "Inventory_GeneticMaterial")
public class GeneticMaterial {

    private Long geneticMaterialId;
    private Germplasm germplasm;
    private String sourceStr;
    private String generation;
    private String lineage;
    private Integer srcAbsCol;
    private Integer srcAbsRng;
    private String srcCrop;
    private String srcGrowProg;
    private Integer srcHarvMonth;
    private Integer srcHarvYear;
    private String srcLoc;
    private Integer srcSeqNumber;
    private String srcLotNumber;
    private Integer srcMaleCol;
    private Integer srcMaleSeqNumber;
    private Integer srcMaleSrNumber;
    private Integer srcMaleRng;
    private String srcOperation;
    private String srcOrigCountry;
    private String srcOrigProg;
    private String srcOrigStation;
    private Integer srcPlantMonth;
    private Integer srcPlantYear;
    private Integer srcPlotNumber;
    private Integer srcRepNumber;
    private Integer srcSampleNumber;
    private Integer srcEntryNumber;
    private String srcSet;
    private Integer srcSubRowNumber;
    private Integer srcSubSubRowNumber;
    private String srcTrkId;
    private String srcMaleProg;
    private String testerDisplay;
    private String rubProjDisplay;
    private String rubKeeperDisplay;
    private String srcSeason;
    private String srcPlotBid;
    private String srcMalePlotBid;
    private String srcExtBid;
    private String srcProtocolName;
    private String genCount;
    private Date srcPollinationDate;
    private Boolean autogen;
    private String transformationGeneration;
    private InventorySourceRank inventorySourceRank;
    private String templateText;

    public Object getID() {
        return getGeneticMaterialId();
    }

    public Long getGeneticMaterialId() {
        return this.geneticMaterialId;
    }

    public void setGeneticMaterialId(Long geneticMaterialId) {
        this.geneticMaterialId = geneticMaterialId;
    }

    public Germplasm getGermplasm() {
        return this.germplasm;
    }

    public void setGermplasm(Germplasm germplasm) {
        this.germplasm = germplasm;
    }

    public String getSourceStr() {
        return this.sourceStr;
    }

    public void setSourceStr(String sourceStr) {
        this.sourceStr = sourceStr;
    }

    public String getGeneration() {
        return this.generation;
    }

    public void setGeneration(String generation) {
        this.generation = generation;
    }

    public String getLineage() {
        return this.lineage;
    }

    public void setLineage(String lineage) {
        this.lineage = lineage;
    }

    public Integer getSrcAbsCol() {
        return this.srcAbsCol;
    }

    public void setSrcAbsCol(Integer srcAbsCol) {
        this.srcAbsCol = srcAbsCol;
    }

    public Integer getSrcAbsRng() {
        return this.srcAbsRng;
    }

    public void setSrcAbsRng(Integer srcAbsRng) {
        this.srcAbsRng = srcAbsRng;
    }

    public String getSrcCrop() {
        return this.srcCrop;
    }

    public void setSrcCrop(String srcCrop) {
        this.srcCrop = srcCrop;
    }

    public String getSrcGrowProg() {
        return this.srcGrowProg;
    }

    public void setSrcGrowProg(String srcGrowProg) {
        this.srcGrowProg = srcGrowProg;
    }

    public Integer getSrcHarvMonth() {
        return this.srcHarvMonth;
    }

    public void setSrcHarvMonth(Integer srcHarvMonth) {
        this.srcHarvMonth = srcHarvMonth;
    }

    public Integer getSrcHarvYear() {
        return this.srcHarvYear;
    }

    public void setSrcHarvYear(Integer srcHarvYear) {
        this.srcHarvYear = srcHarvYear;
    }

    public String getSrcLoc() {
        return this.srcLoc;
    }

    public void setSrcLoc(String srcLoc) {
        this.srcLoc = srcLoc;
    }

    public Integer getSrcSeqNumber() {
        return this.srcSeqNumber;
    }

    public void setSrcSeqNumber(Integer srcSeqNumber) {
        this.srcSeqNumber = srcSeqNumber;
    }

    public String getSrcLotNumber() {
        return this.srcLotNumber;
    }

    public void setSrcLotNumber(String srcLotNumber) {
        this.srcLotNumber = srcLotNumber;
    }

    public Integer getSrcMaleCol() {
        return this.srcMaleCol;
    }

    public void setSrcMaleCol(Integer srcMaleCol) {
        this.srcMaleCol = srcMaleCol;
    }

    public Integer getSrcMaleSeqNumber() {
        return this.srcMaleSeqNumber;
    }

    public void setSrcMaleSeqNumber(Integer srcMaleSeqNumber) {
        this.srcMaleSeqNumber = srcMaleSeqNumber;
    }

    public Integer getSrcMaleSrNumber() {
        return this.srcMaleSrNumber;
    }

    public void setSrcMaleSrNumber(Integer srcMaleSrNumber) {
        this.srcMaleSrNumber = srcMaleSrNumber;
    }

    public Integer getSrcMaleRng() {
        return this.srcMaleRng;
    }

    public void setSrcMaleRng(Integer srcMaleRng) {
        this.srcMaleRng = srcMaleRng;
    }

    public String getSrcOperation() {
        return this.srcOperation;
    }

    public void setSrcOperation(String srcOperation) {
        this.srcOperation = srcOperation;
    }

    public String getSrcOrigCountry() {
        return this.srcOrigCountry;
    }

    public void setSrcOrigCountry(String srcOrigCountry) {
        this.srcOrigCountry = srcOrigCountry;
    }

    public String getSrcOrigProg() {
        return this.srcOrigProg;
    }

    public void setSrcOrigProg(String srcOrigProg) {
        this.srcOrigProg = srcOrigProg;
    }

    public String getSrcOrigStation() {
        return this.srcOrigStation;
    }

    public void setSrcOrigStation(String srcOrigStation) {
        this.srcOrigStation = srcOrigStation;
    }

    public Integer getSrcPlantMonth() {
        return this.srcPlantMonth;
    }

    public void setSrcPlantMonth(Integer srcPlantMonth) {
        this.srcPlantMonth = srcPlantMonth;
    }

    public Integer getSrcPlantYear() {
        return this.srcPlantYear;
    }

    public void setSrcPlantYear(Integer srcPlantYear) {
        this.srcPlantYear = srcPlantYear;
    }

    public Integer getSrcPlotNumber() {
        return this.srcPlotNumber;
    }

    public void setSrcPlotNumber(Integer srcPlotNumber) {
        this.srcPlotNumber = srcPlotNumber;
    }

    public Integer getSrcRepNumber() {
        return this.srcRepNumber;
    }

    public void setSrcRepNumber(Integer srcRepNumber) {
        this.srcRepNumber = srcRepNumber;
    }

    public Integer getSrcSampleNumber() {
        return this.srcSampleNumber;
    }

    public void setSrcSampleNumber(Integer srcSampleNumber) {
        this.srcSampleNumber = srcSampleNumber;
    }

    public Integer getSrcEntryNumber() {
        return this.srcEntryNumber;
    }

    public void setSrcEntryNumber(Integer srcEntryNumber) {
        this.srcEntryNumber = srcEntryNumber;
    }

    public String getSrcSet() {
        return this.srcSet;
    }

    public void setSrcSet(String srcSet) {
        this.srcSet = srcSet;
    }

    public Integer getSrcSubRowNumber() {
        return this.srcSubRowNumber;
    }

    public void setSrcSubRowNumber(Integer srcSubRowNumber) {
        this.srcSubRowNumber = srcSubRowNumber;
    }

    public Integer getSrcSubSubRowNumber() {
        return this.srcSubSubRowNumber;
    }

    public void setSrcSubSubRowNumber(Integer srcSubSubRowNumber) {
        this.srcSubSubRowNumber = srcSubSubRowNumber;
    }

    public String getSrcTrkId() {
        return this.srcTrkId;
    }

    public void setSrcTrkId(String srcTrkId) {
        this.srcTrkId = srcTrkId;
    }

    public String getSrcMaleProg() {
        return this.srcMaleProg;
    }

    public void setSrcMaleProg(String srcMaleProg) {
        this.srcMaleProg = srcMaleProg;
    }

    public String getTesterDisplay() {
        return this.testerDisplay;
    }

    public void setTesterDisplay(String testerDisplay) {
        this.testerDisplay = testerDisplay;
    }

    public String getRubProjDisplay() {
        return this.rubProjDisplay;
    }

    public void setRubProjDisplay(String rubProjDisplay) {
        this.rubProjDisplay = rubProjDisplay;
    }

    public String getRubKeeperDisplay() {
        return this.rubKeeperDisplay;
    }

    public void setRubKeeperDisplay(String rubKeeperDisplay) {
        this.rubKeeperDisplay = rubKeeperDisplay;
    }

    public String getSrcSeason() {
        return this.srcSeason;
    }

    public void setSrcSeason(String srcSeason) {
        this.srcSeason = srcSeason;
    }

    public String getSrcPlotBid() {
        return this.srcPlotBid;
    }

    public void setSrcPlotBid(String srcPlotBid) {
        this.srcPlotBid = srcPlotBid;
    }

    public String getSrcExtBid() {
        return this.srcExtBid;
    }

    public void setSrcExtBid(String srcExtBid) {
        this.srcExtBid = srcExtBid;
    }

    public String getSrcProtocolName() {
        return this.srcProtocolName;
    }

    public void setSrcProtocolName(String srcProtocolName) {
        this.srcProtocolName = srcProtocolName;
    }

    public String getGenCount() {
        return genCount;
    }

    public void setGenCount(String genCount) {
        this.genCount = genCount;
    }

    public Date getSrcPollinationDate() {
        return srcPollinationDate;
    }

    public void setSrcPollinationDate(java.util.Date srcPollinationDate) {
        this.srcPollinationDate = srcPollinationDate;
    }

    public String getSrcMalePlotBid() {
        return srcMalePlotBid;
    }

    public void setSrcMalePlotBid(String srcMalePlotBid) {
        this.srcMalePlotBid = srcMalePlotBid;
    }

    public Boolean getAutogen() {
        return autogen;
    }

    public void setAutogen(Boolean autogen) {
        this.autogen = autogen;
    }

    public String getTransformationGeneration() {
        return transformationGeneration;
    }

    public void setTransformationGeneration(String transformationGeneration) {
        this.transformationGeneration = transformationGeneration;
    }

    public InventorySourceRank getInventorySourceRank() {
        return inventorySourceRank;
    }

    public void setInventorySourceRank(InventorySourceRank inventorySourceRank) {
        this.inventorySourceRank = inventorySourceRank;
    }

    public String getTemplateText() {
        return templateText;
    }

    public void setTemplateText(String templateText) {
        this.templateText = templateText;
    }
}
