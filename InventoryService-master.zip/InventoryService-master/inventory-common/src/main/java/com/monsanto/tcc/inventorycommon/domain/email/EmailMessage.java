/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain.email;

import java.util.ArrayList;
import java.util.List;

/**
 * User: jjbens2
 * Date: Jun 2, 2010
 * Copied from com.monsanto.tps.compliancefieldauditmonitor.pojos.EmailMessage
 */
public class EmailMessage {
    private String fromAddress;
    private List<String> toAddresses;
    private String subject;
    private String body;

    public EmailMessage() {
    }

    public EmailMessage(String fromAddress, List<String> toAddresses, String subject, String body) {
        this.fromAddress = fromAddress;
        this.toAddresses = toAddresses;
        this.subject = subject;
        this.body = body;
    }

    public List<String> getToAddresses() {
        return toAddresses;
    }

    public void setToAddresses(List<String> toAddresses) {
        this.toAddresses = toAddresses;
    }

    public void addToAddress(String emailAddress) {
        createAddressListIfNull();
        if (emailAddress != null) {
            toAddresses.add(emailAddress);
        }
    }

    public void addToAddresses(List<String> listToAdd) {
        createAddressListIfNull();

        if (listToAdd != null) {
            toAddresses.addAll(listToAdd);
        }
    }

    private void createAddressListIfNull() {
        if (toAddresses == null) {
            toAddresses = new ArrayList<String>();
        }
    }

    public String getFromAddress() {
        return fromAddress;
    }

    public void setFromAddress(String fromAddress) {
        this.fromAddress = fromAddress;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    @Override
    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();

        stringBuffer.append("[Email Message] To: ");
        for (String toAddress : toAddresses) {
            stringBuffer.append(toAddress + " ");
        }
        stringBuffer.append("\n");
        stringBuffer.append("Subject:" + subject + " :: Body: " + body);
        return stringBuffer.toString();
    }
}
