package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 4, 2010
 * Time: 5:56:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class ManageContainersResponse {
    private Collection<ResponseMessage> responseMessages;
    private Collection<StorageUnitTO> newStorageUnits;

    public Collection<ResponseMessage> getResponseMessages() {
        if (responseMessages == null) {
            responseMessages = new ArrayList<ResponseMessage>();
        }
        return responseMessages;
    }

    public void setResponseMessages(Collection<ResponseMessage> responseMessages) {
        this.responseMessages = responseMessages;
    }

    public Collection<StorageUnitTO> getNewStorageUnits() {
        return newStorageUnits;
    }

    public void setNewStorageUnits(Collection<StorageUnitTO> newStorageUnits) {
        this.newStorageUnits = newStorageUnits;
    }
}
