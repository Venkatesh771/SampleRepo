package com.monsanto.tcc.inventorycommon.domain;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Oct 20, 2009
 * Time: 6:56:54 PM
 */
public class Decision {
    private Long decisionId;
    private String name;
    private String code;
    private Boolean refActive;
    private String decisionRefId;
    private Long listOrder;

    public Long getDecisionId() {
        return decisionId;
    }

    public void setDecisionId(Long decisionId) {
        this.decisionId = decisionId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Boolean getRefActive() {
        return refActive;
    }

    public void setRefActive(Boolean refActive) {
        this.refActive = refActive;
    }

    public String getDecisionRefId() {
        return decisionRefId;
    }

    public void setDecisionRefId(String decisionRefId) {
        this.decisionRefId = decisionRefId;
    }

    public Long getListOrder() {
        return listOrder;
    }

    public void setListOrder(Long listOrder) {
        this.listOrder = listOrder;
    }
}
