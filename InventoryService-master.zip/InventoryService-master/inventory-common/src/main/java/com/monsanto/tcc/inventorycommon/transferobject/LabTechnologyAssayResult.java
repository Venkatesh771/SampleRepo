package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: RRPATN
 * Date: Mar 25, 2010
 * Time: 9:46:34 AM
 */
public class LabTechnologyAssayResult {
    private ZygosityObsvAttributeValue technology;
    private ZygosityObsvAttributeValue subst;
    private ZygosityObsvAttributeValue unit;
    private List<ZygosityObsvAttributeValue> zygosityObsvReadings;
    private String obsvClassificationRefId;

    public LabTechnologyAssayResult() {
    }

    public ZygosityObsvAttributeValue getTechnology() {
        return technology;
    }

    public void setTechnology(ZygosityObsvAttributeValue technology) {
        this.technology = technology;
    }

    public ZygosityObsvAttributeValue getSubst() {
        return subst;
    }

    public void setSubst(ZygosityObsvAttributeValue subst) {
        this.subst = subst;
    }

    public ZygosityObsvAttributeValue getUnit() {
        return unit;
    }

    public void setUnit(ZygosityObsvAttributeValue unit) {
        this.unit = unit;
    }

    public List<ZygosityObsvAttributeValue> getZygosityObsvReadings() {
        if (zygosityObsvReadings == null) {
            zygosityObsvReadings = new ArrayList<ZygosityObsvAttributeValue>();
        }
        return zygosityObsvReadings;
    }

    public void setZygosityObsvReadings(List<ZygosityObsvAttributeValue> zygosityObsvReadings) {
        this.zygosityObsvReadings = zygosityObsvReadings;
    }

    public String getObsvClassificationRefId() {
        return obsvClassificationRefId;
    }

    public void setObsvClassificationRefId(String obsvClassificationRefId) {
        this.obsvClassificationRefId = obsvClassificationRefId;
    }
}
