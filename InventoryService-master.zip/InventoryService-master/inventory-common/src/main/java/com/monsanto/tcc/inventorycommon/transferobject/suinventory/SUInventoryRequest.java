/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.suinventory;

import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.ProgramTO;

public class SUInventoryRequest {
    private Filter[] filter;
    private ProgramTO[] programs;


    public Filter[] getFilter() {
        return filter;
    }

    public void setFilter(Filter[] filter) {
        this.filter = filter;
    }

    public ProgramTO[] getPrograms() {
        return programs;
    }

    public void setPrograms(ProgramTO[] programs) {
        this.programs = programs;
    }
}