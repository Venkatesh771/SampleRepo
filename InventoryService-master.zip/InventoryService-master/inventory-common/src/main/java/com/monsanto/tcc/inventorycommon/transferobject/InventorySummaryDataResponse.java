package com.monsanto.tcc.inventorycommon.transferobject;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Jan 4, 2010
 * Time: 4:53:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class InventorySummaryDataResponse {
    private Collection<InventorySummaryData> inventorySummaryDataCollection;

    public Collection<InventorySummaryData> getInventorySummaryDataCollection() {
        return inventorySummaryDataCollection;
    }

    public void setInventorySummaryDataCollection(Collection<InventorySummaryData> inventorySummaryDataCollection) {
        this.inventorySummaryDataCollection = inventorySummaryDataCollection;
    }
}
