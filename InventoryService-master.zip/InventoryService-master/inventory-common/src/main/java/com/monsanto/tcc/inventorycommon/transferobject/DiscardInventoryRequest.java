/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

public class DiscardInventoryRequest {
    private List<FatedInventory> fatedInventories;
    private StorageUnitTO discardStorage;

    public StorageUnitTO getDiscardStorage() {
        return discardStorage;
    }

    public void setDiscardStorage(StorageUnitTO discardStorage) {
        this.discardStorage = discardStorage;
    }

    public List<FatedInventory> getFatedInventories() {
        return fatedInventories;
    }

    public void setFatedInventories(List<FatedInventory> fatedInventories) {
        this.fatedInventories = fatedInventories;
    }

    public List<Long> getAllInventoryIds() {
        List<Long> allInventoryIds = new ArrayList<Long>();
        if (!CollectionUtils.isEmpty(getFatedInventories())) {
            for (FatedInventory fatedInventory : fatedInventories) {
                allInventoryIds.add(fatedInventory.getInventoryId());
            }
        }
        return allInventoryIds;
    }

    public List<FatedInventory> getResetQuantityFatedInventory() {
        return getFatedInventory(true);
    }

    public List<FatedInventory> getKeepQuantityFatedInventory() {
        return getFatedInventory(false);
    }

    private List<FatedInventory> getFatedInventory(boolean resetQuantityFlag) {
        List<FatedInventory> fatedInventories = new ArrayList<FatedInventory>();
        if (!CollectionUtils.isEmpty(getFatedInventories())) {
            for (FatedInventory fatedInventory : getFatedInventories()) {
                if (fatedInventory.isResetInventoryQuantity() == resetQuantityFlag) {
                    fatedInventories.add(fatedInventory);
                }
            }
        }
        return fatedInventories;
    }

}

