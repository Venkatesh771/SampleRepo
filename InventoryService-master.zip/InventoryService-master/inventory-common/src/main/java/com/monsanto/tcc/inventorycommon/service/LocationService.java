package com.monsanto.tcc.inventorycommon.service;

import com.monsanto.tcc.inventorycommon.domain.SiteTO;
import com.monsanto.tcc.inventorycommon.domain.SubSiteTO;
import com.monsanto.tcc.inventorycommon.domain.SubSiteTypeTO;
import com.monsanto.tcc.inventorycommon.domain.SubSubSiteTypeTO;

import javax.jws.WebService;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 3, 2010
 * Time: 11:41:43 AM
 * To change this template use File | Settings | File Templates.
 */
@WebService
public interface LocationService {

    public Collection<SiteTO> getSites() throws Exception;

    public Collection<SubSiteTO> getSiteInformation(Long siteId) throws Exception;

    public Collection<SubSiteTypeTO> getSubSiteTypes() throws Exception;

    public Collection<SubSubSiteTypeTO> getSubSubSiteTypes() throws Exception;


}
