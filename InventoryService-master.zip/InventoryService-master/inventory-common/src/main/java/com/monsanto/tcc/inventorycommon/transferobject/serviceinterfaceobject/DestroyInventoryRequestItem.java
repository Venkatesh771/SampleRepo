package com.monsanto.tcc.inventorycommon.transferobject.serviceinterfaceobject;

import java.util.Date;

public class DestroyInventoryRequestItem {

    private Long inventoryId;
    private Date destroyedDate;
    private Long destructionMethodId;
    private String inventoryComments;
    private Double seedQuantity;
    private Long uomId;

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Date getDestroyedDate() {
        return destroyedDate;
    }

    public void setDestroyedDate(Date destroyedDate) {
        this.destroyedDate = destroyedDate;
    }

    public Long getDestructionMethodId() {
        return destructionMethodId;
    }

    public void setDestructionMethodId(Long destructionMethodId) {
        this.destructionMethodId = destructionMethodId;
    }

    public String getInventoryComments() {
        return inventoryComments;
    }

    public void setInventoryComments(String inventoryComments) {
        this.inventoryComments = inventoryComments;
    }

    public Double getSeedQuantity() {
        return seedQuantity;
    }

    public void setSeedQuantity(Double seedQuantity) {
        this.seedQuantity = seedQuantity;
    }

    public Long getUomId() {
        return uomId;
    }

    public void setUomId(Long uomId) {
        this.uomId = uomId;
    }
}
