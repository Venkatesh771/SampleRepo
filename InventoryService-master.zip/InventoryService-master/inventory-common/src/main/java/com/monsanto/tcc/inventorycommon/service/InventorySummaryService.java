package com.monsanto.tcc.inventorycommon.service;

import com.monsanto.services.domain.breeding.Program;
import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.tcc.apollo.table.pagination.PageRequest;
import com.monsanto.tcc.apollo.table.pagination.PageResponse;
import com.monsanto.tcc.apollo.table.pagination.service.PaginationService;
import com.monsanto.tcc.inventorycommon.domain.LineFunction;
import com.monsanto.tcc.inventorycommon.transferobject.ActivateInventoriesRequest;
import com.monsanto.tcc.inventorycommon.transferobject.ActivateInventoriesResponse;
import com.monsanto.tcc.inventorycommon.transferobject.DeleteInventoryInPreviewResponse;
import com.monsanto.tcc.inventorycommon.transferobject.InventorySummaryData;
import com.monsanto.tcc.inventorycommon.transferobject.InventorySummaryDataResponse;
import com.monsanto.tcc.inventorycommon.transferobject.InventorySummaryPageRequest;
import com.monsanto.tcc.inventorycommon.transferobject.PlotRelatedDataResponse;
import com.monsanto.tcc.inventorycommon.transferobject.UpdateInventoryResponse;
import com.monsanto.tcc.inventorycommon.transferobject.inventory.SeedProductInventory;
import com.monsanto.tps.aop.exception.GenericWebFaultException;

import javax.jws.WebService;
import java.util.List;

@WebService
public interface InventorySummaryService extends PaginationService<InventorySummaryPageRequest, InventorySummaryDataResponse> {

    public InventorySummaryDataResponse getSummaryData(List<Long> geneticMaterialIds) throws Exception;

    public InventorySummaryDataResponse getSummaryDataByInventoryBarcodes(List<String> inventoryBarcodes) throws Exception;

    public InventorySummaryDataResponse getSummaryDataByFilters(List<Filter> filters) throws Exception;

    public InventorySummaryDataResponse getSummaryDataByFiltersInternalOnly(List<Filter> filters) throws Exception;

    @Deprecated
    public List<Program> getProgramsByCropId(Long cropId) throws Exception;

    public List<Program> getShareablePrograms(Long programId) throws Exception;

    public void shareInventories(List<Long> inventoryIds, List<Long> programIds) throws Exception;

    public ActivateInventoriesResponse activate(ActivateInventoriesRequest activateInventoriesRequest) throws Exception;

    ActivateInventoriesResponse activateInternal(ActivateInventoriesRequest activateInventoriesRequest) throws GenericWebFaultException;

    public DeleteInventoryInPreviewResponse deleteInventoryInPreviewAndUpdatePlotDecision(List<Long> inventoryIdList) throws Exception;

    public UpdateInventoryResponse updateInventorySummaryRows(List<InventorySummaryData> inventorySummaryDataList) throws Exception;

    public PlotRelatedDataResponse getInventorySummaryPlotRelatedData(List<Long> inventoryIds) throws Exception;

    public List<SeedProductInventory> getSeedProductInventoriesByFilters(List<Filter> filters) throws Exception;

    public List<String> getPotentialTesters(Long inventoryId) throws Exception;

    public List<LineFunction> getLineFunctions(Long inventoryId) throws Exception;

    PageResponse<InventorySummaryDataResponse> getPage(PageRequest<InventorySummaryPageRequest> request);

    public void updateToBeDestroyedFlag(List<Long> inventoryIds) throws Exception;

}