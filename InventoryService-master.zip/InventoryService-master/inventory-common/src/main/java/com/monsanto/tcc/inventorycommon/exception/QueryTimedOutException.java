/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.exception;

import javax.xml.ws.WebFault;

@WebFault
public class QueryTimedOutException extends Exception {
    public QueryTimedOutException() {
    }

    public QueryTimedOutException(String message) {
        super(message);
    }

    public QueryTimedOutException(String message, Throwable cause) {
        super(message, cause);
    }

    public QueryTimedOutException(Throwable cause) {
        super(cause);
    }
}