package com.monsanto.tcc.inventorycommon.transferobject;

import com.monsanto.services.domain.common.AbstractEntity;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: RRPATN
 * Date: May 5, 2010
 * Time: 10:03:07 AM
 */
public class InventoryRelatedData extends AbstractEntity {
    private Long inventoryId;
    private Double advanceInvSimilaritySrcRank;
    private String inbredLineRating;
    private Date inbredLineRatingTimestamp;
    

    @Override
    public Object getID() {
        return getInventoryId();
    }

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    public Double getAdvanceInvSimilaritySrcRank() {
        return advanceInvSimilaritySrcRank;
    }

    public void setAdvanceInvSimilaritySrcRank(Double advanceInvSimilaritySrcRank) {
        this.advanceInvSimilaritySrcRank = advanceInvSimilaritySrcRank;
    }

    public String getInbredLineRating() {
        return inbredLineRating;
    }

    public void setInbredLineRating(String inbredLineRating) {
        this.inbredLineRating = inbredLineRating;
    }

    public Date getInbredLineRatingTimestamp() {
        return inbredLineRatingTimestamp;
    }

    public void setInbredLineRatingTimestamp(Date inbredLineRatingTimestamp) {
        this.inbredLineRatingTimestamp = inbredLineRatingTimestamp;
    }
}
