/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject;

public class DeleteInventoryInPreviewResponse {
    private ResponseMessage responseMessage;
    private Integer numberInventoryDeleted;

    public ResponseMessage getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(ResponseMessage responseMessage) {
        this.responseMessage = responseMessage;
    }

    public Integer getNumberInventoryDeleted() {
        return numberInventoryDeleted;
    }

    public void setNumberInventoryDeleted(Integer numberInventoryDeleted) {
        this.numberInventoryDeleted = numberInventoryDeleted;
    }
}