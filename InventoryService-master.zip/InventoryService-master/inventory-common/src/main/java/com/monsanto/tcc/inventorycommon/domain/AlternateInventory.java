package com.monsanto.tcc.inventorycommon.domain;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: vkdasy
 * Date: Sep 2, 2010
 * Time: 4:19:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class AlternateInventory{
    private Long materialRequestDetailSrcPrefOrderId;
    private Long materialRequestDetailId;
    private Inventory inventory;
    private Long prefOrder;
    private Date inactiveDateTime;

    public Object getID() {
        return getMaterialRequestDetailSrcPrefOrderId();
    }

    public Long getMaterialRequestDetailSrcPrefOrderId() {
        return materialRequestDetailSrcPrefOrderId;
    }

    public void setMaterialRequestDetailSrcPrefOrderId(Long materialRequestDetailSrcPrefOrderId) {
        this.materialRequestDetailSrcPrefOrderId = materialRequestDetailSrcPrefOrderId;
    }

    public Long getMaterialRequestDetailId() {
        return materialRequestDetailId;
    }

    public void setMaterialRequestDetailId(Long materialRequestDetailId) {
        this.materialRequestDetailId = materialRequestDetailId;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public Long getPrefOrder() {
        return prefOrder;
    }

    public void setPrefOrder(Long prefOrder) {
        this.prefOrder = prefOrder;
    }

    public Date getInactiveDateTime() {
        return inactiveDateTime;
    }

    public void setInactiveDateTime(Date inactiveDateTime) {
        this.inactiveDateTime = inactiveDateTime;
    }
}
