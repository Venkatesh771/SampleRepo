package com.monsanto.tcc.inventorycommon.transferobject;

import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 4, 2010
 * Time: 5:48:40 PM
 */
public enum ResponseMessageType implements Serializable {
    WARNING,
    ERROR,
    SUCCESS;

    ResponseMessageType() {
    }

}
