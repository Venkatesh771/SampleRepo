/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "Line_Type")
public class LineType {
    private Long lineTypeId;
    private String name;
    private boolean refActive;
    private String lineTypeRefId;
    private String pedEngRefId;
    private Long listOrder;

    public LineType() {
    }

    public Long getLineTypeId() {
        return lineTypeId;
    }

    public void setLineTypeId(Long lineTypeId) {
        this.lineTypeId = lineTypeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isRefActive() {
        return refActive;
    }

    public void setRefActive(boolean refActive) {
        this.refActive = refActive;
    }

    public String getLineTypeRefId() {
        return lineTypeRefId;
    }

    public void setLineTypeRefId(String lineTypeRefId) {
        this.lineTypeRefId = lineTypeRefId;
    }

    public String getPedEngRefId() {
        return pedEngRefId;
    }

    public void setPedEngRefId(String pedEngRefId) {
        this.pedEngRefId = pedEngRefId;
    }

    public Long getListOrder() {
        return listOrder;
    }

    public void setListOrder(Long listOrder) {
        this.listOrder = listOrder;
    }
}
