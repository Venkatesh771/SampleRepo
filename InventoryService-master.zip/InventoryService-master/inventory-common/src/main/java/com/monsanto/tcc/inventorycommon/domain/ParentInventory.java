/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

public class ParentInventory {

    private Long id;

    private Inventory inventory;
    private Inventory parentalInventory;

    public ParentInventory() {
    }

    public ParentInventory(Long id, Inventory inventory, Inventory parentalInventory) {
        this.id = id;
        this.inventory = inventory;
        this.parentalInventory = parentalInventory;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public Inventory getParentalInventory() {
        return parentalInventory;
    }

    public void setParentalInventory(Inventory parentalInventory) {
        this.parentalInventory = parentalInventory;
    }
}