/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.common.Entity;

import javax.xml.bind.annotation.XmlTransient;
import java.util.Set;

public class TestSetEntry implements Entity {
    private Long testSetEntryId;

    public Long getTestSetEntryId() {
        return testSetEntryId;
    }

    public void setTestSetEntryId(Long testSetEntryId) {
        this.testSetEntryId = testSetEntryId;
    }

    private String isChk;

    public String getIsChk() {
        return isChk;
    }

    public void setIsChk(String chk) {
        isChk = chk;
    }

    private Long entryNum;

    public Long getEntryNum() {
        return entryNum;
    }

    public void setEntryNum(Long entryNum) {
        this.entryNum = entryNum;
    }

    private Long relMatyUomId;

    public Long getRelMatyUomId() {
        return relMatyUomId;
    }

    public void setRelMatyUomId(Long relMatyUomId) {
        this.relMatyUomId = relMatyUomId;
    }

    private Long testSetId;

    public Long getTestSetId() {
        return testSetId;
    }

    public void setTestSetId(Long testSetId) {
        this.testSetId = testSetId;
    }

    private Long inventoryId;

    public Long getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(Long inventoryId) {
        this.inventoryId = inventoryId;
    }

    private Long origEntryId;

    public Long getOrigEntryId() {
        return origEntryId;
    }

    public void setOrigEntryId(Long origEntryId) {
        this.origEntryId = origEntryId;
    }

    private Long objType;

    public Long getObjType() {
        return objType;
    }

    public void setObjType(Long objType) {
        this.objType = objType;
    }

    private Long chkRng;

    public Long getChkRng() {
        return chkRng;
    }

    public void setChkRng(Long chkRng) {
        this.chkRng = chkRng;
    }

    private Long chkCol;

    public Long getChkCol() {
        return chkCol;
    }

    public void setChkCol(Long chkCol) {
        this.chkCol = chkCol;
    }

    private String group1;

    public String getGroup1() {
        return group1;
    }

    public void setGroup1(String group1) {
        this.group1 = group1;
    }

    private String group2;

    public String getGroup2() {
        return group2;
    }

    public void setGroup2(String group2) {
        this.group2 = group2;
    }

    private String comments;

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    private String group3;

    public String getGroup3() {
        return group3;
    }

    public void setGroup3(String group3) {
        this.group3 = group3;
    }

    private Long brCopies;

    public Long getBrCopies() {
        return brCopies;
    }

    public void setBrCopies(Long brCopies) {
        this.brCopies = brCopies;
    }

    private String rubParentalCk;

    public String getRubParentalCk() {
        return rubParentalCk;
    }

    public void setRubParentalCk(String rubParentalCk) {
        this.rubParentalCk = rubParentalCk;
    }

    private String barcode;

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    private String isElite;

    public String getIsElite() {
        return isElite;
    }

    public void setIsElite(String elite) {
        isElite = elite;
    }

    private Long ytDecisionId;

    public Long getYtDecisionId() {
        return ytDecisionId;
    }

    public void setYtDecisionId(Long ytDecisionId) {
        this.ytDecisionId = ytDecisionId;
    }

    private Long entryTypeId;

    public Long getEntryTypeId() {
        return entryTypeId;
    }

    public void setEntryTypeId(Long entryTypeId) {
        this.entryTypeId = entryTypeId;
    }

    private Long comlTraitId;

    public Long getComlTraitId() {
        return comlTraitId;
    }

    public void setComlTraitId(Long comlTraitId) {
        this.comlTraitId = comlTraitId;
    }

    @XmlTransient
    private Set<TestSetEntryByEntryType> testSetEntryByEntryTypes;

    public Set<TestSetEntryByEntryType> getTestSetEntryByEntryTypes() {
        return testSetEntryByEntryTypes;
    }

    public void setTestSetEntryByEntryTypes(Set<TestSetEntryByEntryType> testSetEntryByEntryTypes) {
        this.testSetEntryByEntryTypes = testSetEntryByEntryTypes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        TestSetEntry that = (TestSetEntry) o;

        if (testSetEntryId != null ? !testSetEntryId.equals(that.testSetEntryId) : that.testSetEntryId != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return testSetEntryId != null ? testSetEntryId.hashCode() : 0;
    }

    private Inventory inventoryByInventoryId;

    public Inventory getInventoryByInventoryId() {
        return inventoryByInventoryId;
    }

    public void setInventoryByInventoryId(Inventory inventoryByInventoryId) {
        this.inventoryByInventoryId = inventoryByInventoryId;
    }

    public Object getID() {
        return this.getTestSetEntryId();
    }
}