package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.breeding.FateReason;
import com.monsanto.services.domain.breeding.InventoryType;
import com.monsanto.services.domain.breeding.Program;
import com.monsanto.services.domain.breeding.uom.UnitOfMeasure;
import com.monsanto.services.domain.germplasm.InventoryPurpose;
import com.monsanto.services.domain.germplasm.InventoryStatus;
import com.monsanto.tps.filter.annotation.Filterable;
import com.monsanto.tps.filter.annotation.FilterableProperty;

import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 15, 2009
 * Time: 2:16:36 PM
 */
@XmlType(name = "Inventory_Inventory")
@Filterable
public class Inventory {
    private Long id;
    private Long brProgId;
    private Long inventoryTypeId;
    private FateReason fateReason;
    private Long fateReasonId;


    private Date seedProcessingDate;
    private GeneticMaterial geneticMaterial;
    
    private String checkIndicator;
    private InventoryType inventoryType;

    @FilterableProperty(filterKey = "isActive")
    private String isActive;
    private InventoryPurpose inventoryPurpose;
    private Boolean isPlaced;
    private InventoryStatus inventoryStatus;
    private String location;
    private String bulkReason;
    private Boolean archivedMaterial;

    @FilterableProperty(filterKey = "isPreview")
    private String isPreview;
    
    private Double quantity;

    @FilterableProperty(filterKey = "alphasort1")
    private String asort1;

    @FilterableProperty(filterKey = "alphasort2")
    private String asort2;

    @FilterableProperty(filterKey = "alphasort3")
    private String asort3;

    @FilterableProperty(filterKey = "alphasort4")
    private String asort4;

    @FilterableProperty(filterKey = "alphasort5")
    private String asort5;

    @FilterableProperty(filterKey = "numericsort1")
    private Double nsort1;

    @FilterableProperty(filterKey = "numericsort2")
    private Double nsort2;

    @FilterableProperty(filterKey = "numericsort3")
    private Double nsort3;

    @FilterableProperty(filterKey = "numericsort4")
    private Double nsort4;

    @FilterableProperty(filterKey = "numericsort5")
    private Double nsort5;

    private String invComments;

    @FilterableProperty(filterKey = "inv_bid")
    private String barcode;

    private Boolean toBeDestroyed;
    private Date destructionDate;
    private Long destructionMethodId;
    private Long destructionVerifiedUserId;
    private Boolean isPlacedInArchivedBook;

    @FilterableProperty(filterKey = "fate_date")
    private Date fateReasonDate;
    
    private Date creationDate;
    private Long currentQty;
    private Integer nbrSubinventoryToCreate;
    private Double subinventoryQuantity;
    private String virgoId;
    private StorageUnit storageUnit;

    @FilterableProperty(filterKey = "storageUnitDisplayDnml")
    private String storageUnitDisplayDnml;
    
    private Date readyForTransformationDate;
    private Long readyForTransformationUsrid;
    private Long currentQtyUomId;
    private String seedTreatment;

    @FilterableProperty(filterKey="goi_txt")
    private String goiTxt;

    private Double originQty;
    private Long originQuantityUomId;
    private UnitOfMeasure originQuantityUom;    
    private UnitOfMeasure quantityUom;
    private Long quantityUomId;
    private Date originDate;
    private VegetativeStructure vegetativeStructure;
    private String storageUnitBarcode;
    private Long inventoryStatusReasonId;

    @XmlTransient
    private Set<InventoryContainer> inventoryContainers;
    @XmlTransient
    private Set<MidasMessage> midasMessages;
    @XmlTransient
    private Set<Plot> plots;
    @XmlTransient
    private Set<ParentInventory> parentInventories;
    @XmlTransient
    private Set<TestSetEntry> testSetEntries;

    private Program program;

    @XmlTransient
    private Set<DisplayInventoryProdNm> displayInventoryProductNameList = new HashSet<DisplayInventoryProdNm>();

    private Date modifiedDate;
    private String modifiedUserName;

    public Object getID() {
        return getId();
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBrProgId() {
        return brProgId;
    }

    public void setBrProgId(Long brProgId) {
        this.brProgId = brProgId;
    }

    public Long getInventoryTypeId() {
        return inventoryTypeId;
    }

    public void setInventoryTypeId(Long inventoryTypeId) {
        this.inventoryTypeId = inventoryTypeId;
    }

    public FateReason getFateReason() {
        return fateReason;
    }

    public void setFateReason(FateReason fateReason) {
        this.fateReason = fateReason;
    }

    public Long getFateReasonId() {
        return fateReasonId;
    }

    public void setFateReasonId(Long fateReasonId) {
        this.fateReasonId = fateReasonId;
    }

    public GeneticMaterial getGeneticMaterial() {
        return geneticMaterial;
    }

    public void setGeneticMaterial(GeneticMaterial geneticMaterial) {
        this.geneticMaterial = geneticMaterial;
    }

    public InventoryStatus getInventoryStatus() {
        return inventoryStatus;
    }

    public void setInventoryStatus(InventoryStatus inventoryStatus) {
        this.inventoryStatus = inventoryStatus;
    }

    public StorageUnit getStorageUnit() {
        return storageUnit;
    }

    public void setStorageUnit(StorageUnit storageUnit) {
        this.storageUnit = storageUnit;
    }

    public Long getOriginQuantityUomId() {
        return originQuantityUomId;
    }

    public void setOriginQuantityUomId(Long originQuantityUomId) {
        this.originQuantityUomId = originQuantityUomId;
    }

    public UnitOfMeasure getOriginQuantityUom() {
        return quantityUom;
    }

    public void setOriginQuantityUom(UnitOfMeasure quantityUom) {
        this.quantityUom = quantityUom;
    }

    public UnitOfMeasure getQuantityUom() {
        return quantityUom;
    }

    public void setQuantityUom(UnitOfMeasure quantityUom) {
        this.quantityUom = quantityUom;
    }

    public Long getQuantityUomId() {
        return quantityUomId;
    }

    public void setQuantityUomId(Long quantityUomId) {
        this.quantityUomId = quantityUomId;
    }

    public String getCheckIndicator() {
        return this.checkIndicator;
    }

    public void setCheckIndicator(String checkIndicator) {
        this.checkIndicator = checkIndicator;
    }

    public InventoryType getInventoryType() {
        return inventoryType;
    }

    public void setInventoryType(InventoryType inventoryType) {
        this.inventoryType = inventoryType;
    }

    public String getIsActive() {
        return this.isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public InventoryPurpose getInventoryPurpose() {
        return inventoryPurpose;
    }

    public void setInventoryPurpose(InventoryPurpose inventoryPurpose) {
        this.inventoryPurpose = inventoryPurpose;
    }

    public Boolean getIsPlaced() {
        return this.isPlaced;
    }

    public void setIsPlaced(Boolean isPlaced) {
        this.isPlaced = isPlaced;
    }

    public String getLocation() {
        return this.location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getBulkReason() {
        return this.bulkReason;
    }

    public void setBulkReason(String bulkReason) {
        this.bulkReason = bulkReason;
    }

    public Boolean getArchivedMaterial() {
        return this.archivedMaterial;
    }

    public void setArchivedMaterial(Boolean archivedMaterial) {
        this.archivedMaterial = archivedMaterial;
    }

    public String getIsPreview() {
        return this.isPreview;
    }

    public void setIsPreview(String isPreview) {
        this.isPreview = isPreview;
    }

    public Double getQuantity() {
        return this.quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public String getAsort1() {
        return this.asort1;
    }

    public void setAsort1(String asort1) {
        this.asort1 = asort1;
    }

    public String getAsort2() {
        return this.asort2;
    }

    public void setAsort2(String asort2) {
        this.asort2 = asort2;
    }

    public String getAsort3() {
        return this.asort3;
    }

    public void setAsort3(String asort3) {
        this.asort3 = asort3;
    }

    public String getAsort4() {
        return this.asort4;
    }

    public void setAsort4(String asort4) {
        this.asort4 = asort4;
    }

    public String getAsort5() {
        return this.asort5;
    }

    public void setAsort5(String asort5) {
        this.asort5 = asort5;
    }

    public Double getNsort1() {
        return this.nsort1;
    }

    public void setNsort1(Double nsort1) {
        this.nsort1 = nsort1;
    }

    public Double getNsort2() {
        return this.nsort2;
    }

    public void setNsort2(Double nsort2) {
        this.nsort2 = nsort2;
    }

    public Double getNsort3() {
        return this.nsort3;
    }

    public void setNsort3(Double nsort3) {
        this.nsort3 = nsort3;
    }

    public Double getNsort4() {
        return this.nsort4;
    }

    public void setNsort4(Double nsort4) {
        this.nsort4 = nsort4;
    }

    public Double getNsort5() {
        return this.nsort5;
    }

    public void setNsort5(Double nsort5) {
        this.nsort5 = nsort5;
    }

    public String getInvComments() {
        return this.invComments;
    }

    public void setInvComments(String invComments) {
        this.invComments = invComments;
    }

    public String getBarcode() {
        return this.barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Boolean getToBeDestroyed() {
        return this.toBeDestroyed;
    }

    public void setToBeDestroyed(Boolean toBeDestroyed) {
        this.toBeDestroyed = toBeDestroyed;
    }

    public Date getDestructionDate() {
        return this.destructionDate;
    }

    public void setDestructionDate(Date destructionDate) {
        this.destructionDate = destructionDate;
    }

    public Long getDestructionMethodId() {
        return this.destructionMethodId;
    }

    public void setDestructionMethodId(Long destructionMethodId) {
        this.destructionMethodId = destructionMethodId;
    }

    public Long getDestructionVerifiedUserId() {
        return this.destructionVerifiedUserId;
    }

    public void setDestructionVerifiedUserId(
            Long destructionVerifiedUserId) {
        this.destructionVerifiedUserId = destructionVerifiedUserId;
    }

    public Boolean getIsPlacedInArchivedBook() {
        return this.isPlacedInArchivedBook;
    }

    public void setIsPlacedInArchivedBook(Boolean isPlacedInArchivedBook) {
        this.isPlacedInArchivedBook = isPlacedInArchivedBook;
    }

    public Date getFateReasonDate() {
        return this.fateReasonDate;
    }

    public void setFateReasonDate(Date fateReasonDate) {
        this.fateReasonDate = fateReasonDate;
    }

    public Date getCreationDate() {
        return this.creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Long getCurrentQty() {
        return this.currentQty;
    }

    public void setCurrentQty(Long currentQty) {
        this.currentQty = currentQty;
    }

    public Integer getNbrSubinventoryToCreate() {
        return this.nbrSubinventoryToCreate;
    }

    public void setNbrSubinventoryToCreate(Integer nbrSubinventoryToCreate) {
        this.nbrSubinventoryToCreate = nbrSubinventoryToCreate;
    }

    public Double getSubinventoryQuantity() {
        return this.subinventoryQuantity;
    }

    public void setSubinventoryQuantity(Double subinventoryQuantity) {
        this.subinventoryQuantity = subinventoryQuantity;
    }

    public String getVirgoId() {
        return this.virgoId;
    }

    public void setVirgoId(String virgoId) {
        this.virgoId = virgoId;
    }

    public String getStorageUnitDisplayDnml() {
        return this.storageUnitDisplayDnml;
    }

    public void setStorageUnitDisplayDnml(String storageUnitDisplayDnml) {
        this.storageUnitDisplayDnml = storageUnitDisplayDnml;
    }

    public Date getReadyForTransformationDate() {
        return this.readyForTransformationDate;
    }

    public void setReadyForTransformationDate(Date readyForTransformationDate) {
        this.readyForTransformationDate = readyForTransformationDate;
    }

    public Long getReadyForTransformationUsrid() {
        return this.readyForTransformationUsrid;
    }

    public void setReadyForTransformationUsrid(
            Long readyForTransformationUsrid) {
        this.readyForTransformationUsrid = readyForTransformationUsrid;
    }

    public Long getCurrentQtyUomId() {
        return this.currentQtyUomId;
    }

    public void setCurrentQtyUomId(Long currentQtyUomId) {
        this.currentQtyUomId = currentQtyUomId;
    }

    public String getSeedTreatment() {
        return this.seedTreatment;
    }

    public void setSeedTreatment(String seedTreatment) {
        this.seedTreatment = seedTreatment;
    }

    public String getGoiTxt() {
        return this.goiTxt;
    }

    public void setGoiTxt(String goiTxt) {
        this.goiTxt = goiTxt;
    }

    public Double getOriginQty() {
        return this.originQty;
    }

    public void setOriginQty(Double originQty) {
        this.originQty = originQty;
    }

    public Date getOriginDate() {
        return originDate;
    }

    public void setOriginDate(Date originDate) {
        this.originDate = originDate;
    }

    public VegetativeStructure getVegetativeStructure() {
        return vegetativeStructure;
    }

    public void setVegetativeStructure(VegetativeStructure vegetativeStructure) {
        this.vegetativeStructure = vegetativeStructure;
    }

    public String getStorageUnitBarcode() {
        return storageUnitBarcode;
    }

    public void setStorageUnitBarcode(String storageUnitBarcode) {
        this.storageUnitBarcode = storageUnitBarcode;
    }

    @XmlTransient
    public Set<InventoryContainer> getInventoryContainers() {
        return inventoryContainers;
    }

    public void setInventoryContainers(Set<InventoryContainer> inventoryContainers) {
        this.inventoryContainers = inventoryContainers;
    }

    public String getStorageContainerBarcode()  {
        String barcode = null;
        InventoryContainer inventoryContainer = getFirstInventoryContainer();
        if (null != inventoryContainer)  {
            barcode = inventoryContainer.getStorageContainerBarcode();
        }
        return barcode;
    }

    public StorageContainer getStorageContainer() {
        InventoryContainer invContainer = getFirstInventoryContainer();
        if( null != invContainer ) {
            return invContainer.getStorageContainer();
        }
        return null;
    }
    
    public String getStorageContainerName()  {
        String name = null;
        InventoryContainer inventoryContainer = getFirstInventoryContainer();
        if (null != inventoryContainer)  {
            name = inventoryContainer.getStorageContainerName();
        }
        return name;
    }

    public String getStorageContainerLocation() {
        String currentLocation = null;
        InventoryContainer inventoryContainer = getFirstInventoryContainer();
        if ((null != inventoryContainer) && (0 != inventoryContainers.size())) {
            if (null != inventoryContainer.getStorageContainer()) {
                StorageContainer storageContainer = inventoryContainer.getStorageContainer();
                if (null != storageContainer) {
                    currentLocation = storageContainer.getLocationName();
                }
            }
        }
        return currentLocation;
    }

    @XmlTransient
    public InventoryContainer getFirstInventoryContainer() {
        InventoryContainer inventoryContainer = null;
        if ((null != inventoryContainers) && (!inventoryContainers.isEmpty())) {
            inventoryContainer = inventoryContainers.iterator().next();
        }
        return inventoryContainer;
    }


    @XmlTransient
    public Set<Plot> getPlots() {
        return plots;
    }

    public void setPlots(Set<Plot> plots) {
        this.plots = plots;
    }

    @XmlTransient
    public Set<MidasMessage> getMidasMessages() {
        return midasMessages;
    }

    public void setMidasMessages(Set<MidasMessage> midasMessages) {
        this.midasMessages = midasMessages;
    }

    @XmlTransient
    public Set<ParentInventory> getParentInventories() {
        return parentInventories;
    }

    public void setParentInventories(Set<ParentInventory> parentInventories) {
        this.parentInventories = parentInventories;
    }

    public ParentInventory getFirstParentalInventory() {
        ParentInventory parentInventory = null;
        if ((null != parentInventories) && (0 != parentInventories.size())) {
            parentInventory = parentInventories.iterator().next();
        }
        return parentInventory;
    }

    public Program getProgram() {
        return program;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    @XmlTransient
    public Set<DisplayInventoryProdNm> getDisplayInventoryProductNameList() {
        return displayInventoryProductNameList;
    }

    public void setDisplayInventoryProductNameList(Set<DisplayInventoryProdNm> displayInventoryProductNameList) {
        this.displayInventoryProductNameList = displayInventoryProductNameList;
    }

    @XmlTransient
    public Set<TestSetEntry> getTestSetEntries() {
        return testSetEntries;
    }

    public void setTestSetEntries(Set<TestSetEntry> testSetEntries) {
        this.testSetEntries = testSetEntries;
    }

    public Long getInventoryStatusReasonId() {
        return inventoryStatusReasonId;
    }

    public void setInventoryStatusReasonId(Long inventoryStatusReasonId) {
        this.inventoryStatusReasonId = inventoryStatusReasonId;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getModifiedUserName() {
        return modifiedUserName;
    }

    public void setModifiedUserName(String modifiedUserName) {
        this.modifiedUserName = modifiedUserName;
    }

    public Date getSeedProcessingDate() {
        return seedProcessingDate;
    }

    public void setSeedProcessingDate(Date seedProcessingDate) {
        this.seedProcessingDate = seedProcessingDate;
    }

    public Object clone() {
        Inventory inventory = new Inventory();
        inventory.setArchivedMaterial(archivedMaterial);
        inventory.setAsort1(asort1);
        inventory.setAsort2(asort2);
        inventory.setAsort3(asort3);
        inventory.setAsort4(asort4);
        inventory.setAsort5(asort5);
        inventory.setBarcode(barcode);
        inventory.setBrProgId(brProgId);
        inventory.setBulkReason(bulkReason);
        inventory.setCheckIndicator(checkIndicator);
        inventory.setCreationDate(creationDate);
        inventory.setCurrentQty(currentQty);
        inventory.setCurrentQtyUomId(currentQtyUomId);
        inventory.setDestructionDate(destructionDate);
        inventory.setDestructionMethodId(destructionMethodId);
        inventory.setDestructionVerifiedUserId(destructionVerifiedUserId);
        inventory.setFateReasonDate(fateReasonDate);
        inventory.setFateReason(fateReason);
        inventory.setGeneticMaterial(geneticMaterial);
        inventory.setGoiTxt(goiTxt);
        inventory.setId(id);
        inventory.setInvComments(invComments);
        inventory.setInventoryPurpose(inventoryPurpose);
        inventory.setInventoryStatus(inventoryStatus);
        inventory.setInventoryType(inventoryType);
        inventory.setIsActive(isActive);
        inventory.setIsPlaced(isPlaced);
        inventory.setIsPlacedInArchivedBook(isPlacedInArchivedBook);
        inventory.setIsPreview(isPreview);
        inventory.setLocation(location);
        inventory.setNbrSubinventoryToCreate(nbrSubinventoryToCreate);
        inventory.setNsort1(nsort1);
        inventory.setNsort2(nsort2);
        inventory.setNsort3(nsort3);
        inventory.setNsort4(nsort4);
        inventory.setNsort5(nsort5);
        inventory.setOriginDate(originDate);
        inventory.setOriginQty(originQty);
        inventory.setOriginQuantityUomId(originQuantityUomId);
        inventory.setQuantity(quantity);
        inventory.setQuantityUom(quantityUom);
        inventory.setReadyForTransformationDate(readyForTransformationDate);
        inventory.setReadyForTransformationUsrid(readyForTransformationUsrid);
        inventory.setSeedTreatment(seedTreatment);
        inventory.setStorageUnit(storageUnit);
        inventory.setStorageUnitDisplayDnml(storageUnitDisplayDnml);
        inventory.setSubinventoryQuantity(subinventoryQuantity);
        inventory.setToBeDestroyed(toBeDestroyed);
        inventory.setVirgoId(virgoId);
        inventory.setVegetativeStructure(vegetativeStructure);
        inventory.setInventoryContainers(inventoryContainers);
        inventory.setPlots(plots);
        inventory.setMidasMessages(midasMessages);
        inventory.setProgram(program);
        return inventory;
    }

    public String getProductName() {
        ProductName productName = getFirstProductName();
        if (productName != null) {
            return productName.getName();
        }
        return null;
    }

    public String getBrand() {
        ProductName productName = getFirstProductName();
        if ((null != productName) &&
                (null != productName.getBrand())) {
            return productName.getBrand().getName();
        }
        return null;
    }

    public Boolean getPerformanceCheck() {
        boolean performanceCheck = false;
        if (testSetEntries != null) {
            for (TestSetEntry entry : testSetEntries) {
                if ("T".equalsIgnoreCase(entry.getIsChk())) {
                    performanceCheck = true;
                    break;
                }
            }
        }
        return performanceCheck;
    }

    public Boolean getMaturity() {
        boolean maturity = false;
        if (testSetEntries != null) {
            for (TestSetEntry entry : testSetEntries) {
                if (entry.getTestSetEntryByEntryTypes() != null) {
                    for (TestSetEntryByEntryType testSetEntryByEntryType : entry.getTestSetEntryByEntryTypes()) {
                        if ("Maturity".equalsIgnoreCase(testSetEntryByEntryType.getEntryType().getName())) {
                            if (testSetEntryByEntryType.getInactiveDate() == null) {
                                maturity = true;
                                break;
                            }
                        }
                    }
                }
            }
        }
        return maturity;
    }

    private ProductName getFirstProductName() {
        if ((null != geneticMaterial) &&
                (null != geneticMaterial.getGermplasm()) &&
                (null != geneticMaterial.getGermplasm().getFirstGermplasmXRef())) {
            Product product = geneticMaterial.getGermplasm().getFirstGermplasmXRef().getProduct();
            if ((null != product) &&
                    (null != product.getFirstProductName())) {
                return product.getFirstProductName();
            }
        }
        return null;
    }

    public String getProductNameForTechDataUser()  {
        DisplayInventoryProdNm displayProductName = getActiveDisplayInventoryProductName();
        if (null != displayProductName)  {
            ProductName productName = displayProductName.getProductName();
            if ((null != productName) && (productName.isActive()) )  {
                return productName.getName();
            }
        }
        return null;
    }

    public String getBrandNameForTechDataUser()  {
        DisplayInventoryProdNm displayProductName = getActiveDisplayInventoryProductName();
        if (null != displayProductName)  {
            ProductName productName = displayProductName.getProductName();
            if ((null != productName) && (productName.isActive()) )  {
                if ((null != productName.getBrand()) && ("T".equals(productName.getBrand().getRefActive())) ) {
                    return productName.getBrand().getName();
                }
            }
        }
        return null;
    }

    private DisplayInventoryProdNm getActiveDisplayInventoryProductName()  {
        DisplayInventoryProdNm result = null;
        if ((null != displayInventoryProductNameList) && (0 != displayInventoryProductNameList.size())) {
            for(DisplayInventoryProdNm displayProductName : displayInventoryProductNameList)  {
                if ("T".equals(displayProductName.getIsVirtualInd()))  {
                    return displayProductName;
                }
            }
        }
        return result;
    }
}