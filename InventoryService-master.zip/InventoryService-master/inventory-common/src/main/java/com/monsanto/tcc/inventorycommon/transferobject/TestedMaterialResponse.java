package com.monsanto.tcc.inventorycommon.transferobject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 23, 2010
 * Time: 3:23:26 PM
 */
public class TestedMaterialResponse implements Serializable {
    private ResponseMessage responseMessage;
    private Collection<TestedMaterialSummary> testedMaterialSummaries = new ArrayList<TestedMaterialSummary>();

    public ResponseMessage getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(ResponseMessage responseMessage) {
        this.responseMessage = responseMessage;
    }

    public Collection<TestedMaterialSummary> getTestedMaterialSummaries() {
        return testedMaterialSummaries;
    }

    public void setTestedMaterialSummaries(Collection<TestedMaterialSummary> testedMaterialSummaries) {
        this.testedMaterialSummaries = testedMaterialSummaries;
    }
}
