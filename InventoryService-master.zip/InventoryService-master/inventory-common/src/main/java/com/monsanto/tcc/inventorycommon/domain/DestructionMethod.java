package com.monsanto.tcc.inventorycommon.domain;


public class DestructionMethod {
    private Long destructionMethodId;
    private String name;
    private String refId;
    private boolean active;

    public DestructionMethod() {
    }

    public DestructionMethod(Long destructionMethodId, String name, String refId, boolean active) {
        this.destructionMethodId = destructionMethodId;
        this.name = name;
        this.refId = refId;
        this.active = active;
    }

    public Long getDestructionMethodId() {
        return destructionMethodId;
    }

    public void setDestructionMethodId(Long destructionMethodId) {
        this.destructionMethodId = destructionMethodId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return name;
    }
}
