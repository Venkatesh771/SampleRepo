package com.monsanto.tcc.inventorycommon.transferobject.materialexchange;


import java.util.Collection;

public class MaterialExchangeRejectRequest {

    Collection<RejectedInventory> rejectedInventories;

    public Collection<RejectedInventory> getRejectedInventories() {
        return rejectedInventories;
    }

    public void setRejectedInventories(Collection<RejectedInventory> rejectedInventories) {
        this.rejectedInventories = rejectedInventories;
    }
}