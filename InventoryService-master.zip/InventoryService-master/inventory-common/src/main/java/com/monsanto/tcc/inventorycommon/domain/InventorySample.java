package com.monsanto.tcc.inventorycommon.domain;

import com.monsanto.services.domain.common.Entity;

import java.util.Date;

public class InventorySample implements Entity {
    private Long inventorySampleId;
    private Long molecularBreedingRequestId;
    private Long sampleNbr;
    private String inventoryBarcodeNbr;
    private Date createdDate;
    private String createdByUid;

    public Long getInventorySampleId() {
        return inventorySampleId;
    }

    public void setInventorySampleId(Long inventorySampleId) {
        this.inventorySampleId = inventorySampleId;
    }

    public Long getMolecularBreedingRequestId() {
        return molecularBreedingRequestId;
    }

    public void setMolecularBreedingRequestId(Long molecularBreedingRequestId) {
        this.molecularBreedingRequestId = molecularBreedingRequestId;
    }

    public Long getSampleNbr() {
        return sampleNbr;
    }

    public void setSampleNbr(Long sampleNbr) {
        this.sampleNbr = sampleNbr;
    }

    public String getInventoryBarcodeNbr() {
        return inventoryBarcodeNbr;
    }

    public void setInventoryBarcodeNbr(String inventoryBarcodeNbr) {
        this.inventoryBarcodeNbr = inventoryBarcodeNbr;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedByUid() {
        return createdByUid;
    }

    public void setCreatedByUid(String createdByUid) {
        this.createdByUid = createdByUid;
    }

    @Override
    public Object getID() {
        return inventorySampleId;
    }
}