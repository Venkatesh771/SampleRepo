package com.monsanto.tcc.inventorycommon.transferobject;

/**
 * Created by IntelliJ IDEA.
 * User: SSSING5
 * Date: Aug 21, 2009
 * Time: 4:23:37 PM
 */
public class UpdateMaterialRequest {
    private Long materialRequestId;
    private String inventoryBarcode;

    public Long getMaterialRequestId() {
        return materialRequestId;
    }

    public void setMaterialRequestId(Long materialRequestId) {
        this.materialRequestId = materialRequestId;
    }

    public String getInventoryBarcode() {
        return inventoryBarcode;
    }

    public void setInventoryBarcode(String inventoryBarcode) {
        this.inventoryBarcode = inventoryBarcode;
    }
}
