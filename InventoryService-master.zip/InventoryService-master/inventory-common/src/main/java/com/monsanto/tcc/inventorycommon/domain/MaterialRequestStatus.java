package com.monsanto.tcc.inventorycommon.domain;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 26, 2009
 * Time: 11:02:25 AM
 */
public class MaterialRequestStatus {
    private Long materialRequestStatusId;
    private String name;
    private String description;
    private Date inactiveDttm;

    public Long getMaterialRequestStatusId() {
        return materialRequestStatusId;
    }

    public void setMaterialRequestStatusId(Long materialRequestStatusId) {
        this.materialRequestStatusId = materialRequestStatusId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getInactiveDttm() {
        return inactiveDttm;
    }

    public void setInactiveDttm(Date inactiveDttm) {
        this.inactiveDttm = inactiveDttm;
    }
}
