/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.transferobject.suinventory;

public class SUGermplasmTO {
    private String constructDisplay;
    private String ownerProgramRefId;
    private String eventDisplay;
    private String lineCode;
    private String pedigreeName;
    private String crossName;
    private SUUserTO crossContactUser;
    private SUProgramTO crossOwnerProgram;

    public String getConstructDisplay() {
        return constructDisplay;
    }

    public void setConstructDisplay(String constructDisplay) {
        this.constructDisplay = constructDisplay;
    }

    public String getOwnerProgramRefId() {
        return ownerProgramRefId;
    }

    public void setOwnerProgramRefId(String ownerProgramRefId) {
        this.ownerProgramRefId = ownerProgramRefId;
    }

    public String getEventDisplay() {
        return eventDisplay;
    }

    public void setEventDisplay(String eventDisplay) {
        this.eventDisplay = eventDisplay;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getPedigreeName() {
        return pedigreeName;
    }

    public void setPedigreeName(String pedigreeName) {
        this.pedigreeName = pedigreeName;
    }

    public String getCrossName() {
        return crossName;
    }

    public void setCrossName(String crossName) {
        this.crossName = crossName;
    }

    public SUUserTO getCrossContactUser() {
        return crossContactUser;
    }

    public void setCrossContactUser(SUUserTO crossContactUser) {
        this.crossContactUser = crossContactUser;
    }

    public SUProgramTO getCrossOwnerProgram() {
        return crossOwnerProgram;
    }

    public void setCrossOwnerProgram(SUProgramTO crossOwnerProgram) {
        this.crossOwnerProgram = crossOwnerProgram;
    }
}