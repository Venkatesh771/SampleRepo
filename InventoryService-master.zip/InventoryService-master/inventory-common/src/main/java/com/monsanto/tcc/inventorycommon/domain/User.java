package com.monsanto.tcc.inventorycommon.domain;

import javax.xml.bind.annotation.XmlType;

/**
 * Created with IntelliJ IDEA.
 * User: ssjamm1
 * Date: 10/17/12
 * Time: 3:41 PM
 * To change this template use File | Settings | File Templates.
 */
@XmlType(name = "Midas_User")
public class User {

    private Long userId;
    private String loginId;
    private String firstName;
    private String lastName;
    private String middleName;

    public User() {
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }
}
