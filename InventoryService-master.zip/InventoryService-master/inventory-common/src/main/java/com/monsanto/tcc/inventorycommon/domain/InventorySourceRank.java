/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventorycommon.domain;

import java.util.Date;

public class InventorySourceRank {
    private Long id;
    private Long geneticMaterialId;
    private Long maleRank;
    private Long femaleRank;
    private Long src_value;
    private Date srcValueCalcDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getGeneticMaterialId() {
        return geneticMaterialId;
    }

    public void setGeneticMaterialId(Long geneticMaterialId) {
        this.geneticMaterialId = geneticMaterialId;
    }

    public Long getMaleRank() {
        return maleRank;
    }

    public void setMaleRank(Long maleRank) {
        this.maleRank = maleRank;
    }

    public Long getFemaleRank() {
        return femaleRank;
    }

    public void setFemaleRank(Long femaleRank) {
        this.femaleRank = femaleRank;
    }

    public Long getSrc_value() {
        return src_value;
    }

    public void setSrc_value(Long src_value) {
        this.src_value = src_value;
    }

    public Date getSrcValueCalcDate() {
        return srcValueCalcDate;
    }

    public void setSrcValueCalcDate(Date srcValueCalcDate) {
        this.srcValueCalcDate = srcValueCalcDate;
    }
}