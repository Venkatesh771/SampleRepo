package com.monsanto.tcc.inventoryservice.genericparameters;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Collection;

/**
 * User: Mark D. Sparks
 * Date: 8/15/11
 * Time: 4:16 PM
 */
@Component
public class GenericParametersBoImpl implements GenericParametersBo {
    @Resource
    private GenericParametersDao genericParametersDao;

    public void setGenericParametersDao(GenericParametersDao genericParametersDao) {
        this.genericParametersDao = genericParametersDao;
    }

    @Override
    @Transactional
    public Long createGenericParameters(Collection<GenericParameters> genericParametersList) {
        return genericParametersDao.createGenericParameters(genericParametersList);
    }
}
