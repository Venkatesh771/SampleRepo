/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.email.builder;

import com.monsanto.tcc.inventorycommon.domain.email.EmailConfiguration;
import com.monsanto.tcc.inventoryservice.email.EmailBindUtil;

import java.util.Map;

/**
 * User: jjbens2
 * Date: Jun 4, 2010
 */

/**
 * Builds an email body from a text-based source.  The data for the email body will be populated from a lookup
 * on the EmailConfiguration object.
 */
public class TextEmailBuilder implements EmailBuilder {

    private EmailBindUtil emailBindUtil;

    public TextEmailBuilder() {
        
    }

    @Override
    public String getText(String emailTextIdentifier, Map<String, String> emailParameters) throws Exception {

        String body = EmailConfiguration.getProperty(emailTextIdentifier);
        return emailBindUtil.bindParametersToString(body, emailParameters);
    }

    public void setEmailBindUtil(EmailBindUtil emailBindUtil) {
        this.emailBindUtil = emailBindUtil;
    }
}
