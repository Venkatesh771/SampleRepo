package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.StorageContainerLocation;
import com.monsanto.tps.dao.GenericDao;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 3, 2010
 * Time: 9:15:18 AM
 * To change this template use File | Settings | File Templates.
 */
public interface StorageContainerLocationDao extends GenericDao<StorageContainerLocation, Long> {
}

