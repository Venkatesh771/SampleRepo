package com.monsanto.tcc.inventoryservice.domain;

import com.monsanto.tcc.inventorycommon.domain.GeneticMaterial;

import java.util.Date;

/**
 * User: DCENGL
 */
public class GeneticMaterialTermsOfUseEntity {

    private Long id;
    private TermsOfUseEntity termsOfUse;
    private GeneticMaterial geneticMaterial;
    private Date modifiedDate;
    private String modifiedBy;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TermsOfUseEntity getTermsOfUse() {
        return termsOfUse;
    }

    public void setTermsOfUse(TermsOfUseEntity termsOfUse) {
        this.termsOfUse = termsOfUse;
    }

    public GeneticMaterial getGeneticMaterial() {
        return geneticMaterial;
    }

    public void setGeneticMaterial(GeneticMaterial geneticMaterial) {
        this.geneticMaterial = geneticMaterial;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }
}
