/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.InventorySourceRank;
import com.monsanto.tps.dao.GenericDao;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$     On:$Date$
 *
 * @author mmatho
 * @version $Revision$
 */
public interface InventorySourceRankDao extends GenericDao<InventorySourceRank, Long> {
}