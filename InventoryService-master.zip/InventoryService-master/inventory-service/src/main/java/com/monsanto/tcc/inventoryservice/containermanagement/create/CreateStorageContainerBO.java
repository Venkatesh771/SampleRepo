package com.monsanto.tcc.inventoryservice.containermanagement.create;

import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventoryservice.dao.StorageContainerDao;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Apr 8, 2010
 * Time: 10:25:46 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateStorageContainerBO {
    private StorageContainerDao storageContainerDao;

    public Collection<StorageContainer> process(Collection<StorageContainer> storageContainers) {
        for (StorageContainer storageContainer : storageContainers) {
            setParent(storageContainer);
            getStorageContainerDao().saveOrUpdate(storageContainer);
        }
        return storageContainers;
    }

    private void setParent(StorageContainer storageContainer) {
        if (storageContainer.getParentContainerId() != null) {
            storageContainer.setParentStorageContainer(getStorageContainerDao().load(storageContainer.getParentContainerId()));
        }
    }

    public StorageContainerDao getStorageContainerDao() {
        return storageContainerDao;
    }

    public void setStorageContainerDao(StorageContainerDao storageContainerDao) {
        this.storageContainerDao = storageContainerDao;
    }
}
