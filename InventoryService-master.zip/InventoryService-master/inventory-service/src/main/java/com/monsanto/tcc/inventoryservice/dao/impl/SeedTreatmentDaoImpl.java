package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.transferobject.SapSeedTreatmentInput;
import com.monsanto.tcc.inventoryservice.dao.SeedTreatmentDao;
import org.hibernate.SQLQuery;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;

import java.util.List;

public class SeedTreatmentDaoImpl extends DynamicGroupBaseDao implements SeedTreatmentDao {
    private static final String FILE_NAME = "com/monsanto/tcc/inventoryservice/inventory/filter/sql/GetInventoryBatchAndMaterialNumbers.sql";
    private static final Class TRANSFORMER = SapSeedTreatmentInput.class;

    @Override
    public List<SapSeedTreatmentInput> getSeedTreatmentInfo(List<Long> inventoryIds) {
        return getData(inventoryIds);
    }

    @Override
    protected String getFilename() {
        return FILE_NAME;
    }

    @Override
    protected Class getTransformerClass() {
        return TRANSFORMER;
    }

    @Override
    protected void addScalars(SQLQuery query) {
        query.addScalar("inventoryId", new LongType())
                .addScalar("batchNumber", new StringType())
                .addScalar("materialNumber", new StringType());
    }

}
