package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.Observation;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rrelli6
 * Date: Jun 16, 2009
 * Time: 9:59:05 AM
 */
public interface ObservationDao {
    public List<Observation> getObservationsWithZygositySummaryForEventPresenceAnalysis(Long crossSegregateIndividualStatusId);
}