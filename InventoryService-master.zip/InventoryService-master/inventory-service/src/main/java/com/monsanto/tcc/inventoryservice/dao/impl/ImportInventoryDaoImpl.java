/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventoryservice.dao.ImportInventoryDao;
import com.monsanto.tcc.inventoryservice.importing.ImportInventory;
import com.monsanto.tps.dao.GenericDaoImpl;
import org.hibernate.CacheMode;
import org.hibernate.Query;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$     On:$Date$
 *
 * @author SSSING5
 * @version $Revision$
 */
public class ImportInventoryDaoImpl extends GenericDaoImpl<ImportInventory, Long> implements ImportInventoryDao {
    public ImportInventoryDaoImpl(Class entityClass) {
        super(entityClass);
    }

    public Map<String, ImportInventory> getBarcodeToInventoryMap(Long sessionId) {
        Query query = getSession().getNamedQuery("ImportInventory.findInventoryByBarcodesInTemp");
        query.setParameter("requestId", sessionId);
        query.setCacheMode(CacheMode.IGNORE);
        List<ImportInventory> results = query.list();
        Map<String, ImportInventory> barcodeToInventoryMap = new HashMap<String, ImportInventory>();
        if (!CollectionUtils.isEmpty(results)) {
            for (ImportInventory result : results) {
                barcodeToInventoryMap.put(result.getBarcode(), result);
            }
        }
        return barcodeToInventoryMap;
    }
}