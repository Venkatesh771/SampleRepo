package com.monsanto.tcc.inventoryservice.containermanagement;

import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.inventorycommon.domain.InventoryContainer;
import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventorycommon.domain.StorageContainerLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageLocationCatalog;
import com.monsanto.tcc.inventorycommon.domain.StorageUnit;
import com.monsanto.tcc.inventoryservice.dao.StorageLocationDao;
import com.monsanto.tcc.inventoryservice.dao.StorageUnitDao;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Jun 3, 2010
 * Time: 4:40:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class StorageLocationCollaborator {
    private StorageUnitDao storageUnitDao;
    private StorageLocationDao storageLocationDao;
    private Log logger = LogFactory.getLog(StorageLocationCollaborator.class);
    public static final String STORAGE_CONTAINER_NAME_SEPARATOR = "\\";

    public String buildDNML(InventoryContainer inventoryContainer) {
        String storageLocationDNML = "";
        if (inventoryContainer != null) {
            try {
                storageLocationDNML = processStorageContainerAndIfNullUseStorageUnit(inventoryContainer);
            } catch (Exception exp) {
                logger.error("Failed to buildDNML DNML for inventoryContainer: " + inventoryContainer.getInventoryContainerId(), exp);
            }
        }
        return storageLocationDNML;
    }

    public String getStroageLocationName(InventoryContainer inventoryContainer) {
        String storageLocationName = "";
        if (inventoryContainer != null) {
            storageLocationName = getStorageContainerNameAndIfNullUseStorageUnitName(inventoryContainer, storageLocationName);
        }
        return storageLocationName;
    }

    private String getStorageContainerNameAndIfNullUseStorageUnitName(InventoryContainer inventoryContainer, String storageLocationName) {
        if (inventoryContainer.getStorageContainer() != null) {
            storageLocationName = inventoryContainer.getStorageContainer().getName();
        } else if (inventoryContainer.getStorageUnit() != null) {
            storageLocationName = inventoryContainer.getStorageUnit().getName();
        }
        return storageLocationName;
    }

    public String getStorageLocationType(InventoryContainer inventoryContainer) {
        String storageLocationTypeName = "";
        if (inventoryContainer != null) {
            storageLocationTypeName = getStorageContainerTypeAndIfNullStorageUnitType(inventoryContainer, storageLocationTypeName);
        }
        return storageLocationTypeName;
    }

    private String getStorageContainerTypeAndIfNullStorageUnitType(InventoryContainer inventoryContainer, String storageLocationTypeName) {
        if (inventoryContainer.getStorageContainer() != null) {
            storageLocationTypeName = inventoryContainer.getStorageContainer().getStorageContainerType().getName();
        } else if (inventoryContainer.getStorageUnit() != null) {
            storageLocationTypeName = inventoryContainer.getStorageUnit().getStorageUnitType().getStorageUnitName();
        }
        return storageLocationTypeName;
    }

    private String processStorageContainerAndIfNullUseStorageUnit(InventoryContainer inventoryContainer) {
        String storageLocationDNML;
        if (inventoryContainer.getStorageContainer() != null) {
            storageLocationDNML = deriveStorageContainerDNML(inventoryContainer.getStorageContainer());
        } else {
            storageLocationDNML = deriveStorageUnitDNML(inventoryContainer.getStorageUnit());
        }
        return storageLocationDNML;
    }

    public String deriveStorageContainerDNML(StorageContainer storageContainer) {
        StringBuilder storageLocDnml = new StringBuilder();
        if (storageContainer != null) {
            storageLocDnml.append(storageContainer.getName());
            while (storageContainer.getParentStorageContainer() != null) {
                storageContainer = storageContainer.getParentStorageContainer();
                storageLocDnml.insert(0, storageContainer.getName() + STORAGE_CONTAINER_NAME_SEPARATOR);
            }
            deriveParentContainerPath(storageContainer, storageLocDnml);
        }
        return storageLocDnml.toString();
    }

    private void deriveParentContainerPath(StorageContainer storageContainer, StringBuilder storageLocDnml) {
        StorageContainerLocation storageContainerLocation = storageContainer.getStorageContainerLocationsByStorageContainerId().iterator().next();
        StorageLocationCatalog storageLocationCatalog = storageContainerLocation.getStorageLocationCatalogByStorageLocationCatalogId();
        StorageLocation storageLocation = storageLocationCatalog.getStorageLocation();
        storageLocDnml.insert(0, deriveStorageLocationPath(storageLocation));
    }

    public String deriveStorageLocationPath(StorageLocation storageLocation) {
        StringBuilder storageLocDnml = new StringBuilder();
        storageLocDnml.insert(0, storageLocation.getName() + STORAGE_CONTAINER_NAME_SEPARATOR);
        String siteSubSiteSubSubSiteNames = getStorageLocationDao().getSiteSubSiteSubSubSiteNames(storageLocation.getSubSubSiteId());
        if (!StringUtils.isNullOrEmpty(siteSubSiteSubSubSiteNames)) {
            storageLocDnml.insert(0, siteSubSiteSubSubSiteNames + STORAGE_CONTAINER_NAME_SEPARATOR);
        }
        return storageLocDnml.toString();
    }

    private String deriveStorageUnitDNML(StorageUnit currentStorageUnit) {
        StringBuilder completeLocation = new StringBuilder();
        if (currentStorageUnit != null) {
            completeLocation.append(currentStorageUnit.getName());
            int countToAvoidInfiniteLoop = 0;
            while ((currentStorageUnit.getParentStorageUnitId() != null) && countToAvoidInfiniteLoop != 10) {
                currentStorageUnit = getStorageUnitDao().get(currentStorageUnit.getParentStorageUnitId());
                completeLocation.insert(0, currentStorageUnit.getName() + STORAGE_CONTAINER_NAME_SEPARATOR);
                countToAvoidInfiniteLoop++;
            }
        }
        return completeLocation.toString();
    }

    public StorageUnitDao getStorageUnitDao() {
        return storageUnitDao;
    }

    public void setStorageUnitDao(StorageUnitDao storageUnitDao) {
        this.storageUnitDao = storageUnitDao;
    }

    public StorageLocationDao getStorageLocationDao() {
        return storageLocationDao;
    }

    public void setStorageLocationDao(StorageLocationDao storageLocationDao) {
        this.storageLocationDao = storageLocationDao;
    }
}
