package com.monsanto.tcc.inventoryservice.genericparameters;

import com.monsanto.tps.primarykey.midas.MidasKeyGenerator;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.impl.SessionImpl;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Collection;

/**
 * User: Mark D. Sparks
 * Date: 8/15/11
 * Time: 4:18 PM
 */
@Repository
public class GenericParametersDaoImpl implements GenericParametersDao {
    @Resource
    private SessionFactory sessionFactory;

    @Override
    @Transactional
    public Long createGenericParameters(Collection<GenericParameters> genericParametersList) {
        MidasKeyGenerator generator = new MidasKeyGenerator();
        Session currentSession = sessionFactory.getCurrentSession();
        Long sessionId = (Long) generator.generate((SessionImpl) currentSession, null);
        int index = 0;
        for (GenericParameters genericParameters : genericParametersList) {
            genericParameters.setSessionId(sessionId);
            currentSession.save(genericParameters);
            if ((++index) % 100 == 0) {
                currentSession.flush();
                currentSession.clear();
            }
        }
        return sessionId;
    }
}
