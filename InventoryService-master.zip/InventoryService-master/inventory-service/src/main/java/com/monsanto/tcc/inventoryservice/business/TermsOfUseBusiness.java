package com.monsanto.tcc.inventoryservice.business;

import com.monsanto.tcc.inventoryservice.domain.TermsOfUseEntity;

import java.util.List;

/**
 * User: DCENGL
 */
public interface TermsOfUseBusiness {

    List<TermsOfUseEntity> getTermsOfUse(Long geneticMaterialId);

    void save(Long termsOfUseId, Long geneticMaterialId, String terms, Boolean restricted, String modifiedBy);
}
