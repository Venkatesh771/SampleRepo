/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.email.builder;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;

import java.io.StringWriter;
import java.util.Map;
import java.util.Properties;

/**
 * User: jjbens2
 * Date: Jun 4, 2010
 */
public class VelocityEmailBuilder implements EmailBuilder {

    private String velocityTemplateBasePath;

    public VelocityEmailBuilder() throws Exception {

        Properties velocityProps = new Properties();
        velocityProps.put("resource.loader", "class");
        velocityProps.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
        Velocity.init(velocityProps);
    }

    @Override
    public String getText(String emailTextIdentifier, Map<String, String> emailParameters) throws Exception {

        VelocityContext context = getPopulatedVelocityContext(emailParameters);
        Template template = Velocity.getTemplate(getVelocityTemplatePath(emailTextIdentifier));

        StringWriter mergeResult = new StringWriter();
        template.merge(context, mergeResult);

        return mergeResult.toString();
    }

    private VelocityContext getPopulatedVelocityContext(Map<String, String> emailParameters) {

        VelocityContext context = new VelocityContext();
        for( Map.Entry currentItem : emailParameters.entrySet() ) {
            context.put((String)currentItem.getKey(), (String)currentItem.getValue());
        }
        return context;
    }

    private String getVelocityTemplatePath(String fileName) {
        return getVelocityTemplateBasePath() + fileName;
    }

    public String getVelocityTemplateBasePath() {
        return velocityTemplateBasePath;
    }

    public void setVelocityTemplateBasePath(String velocityTemplateBasePath) {
        this.velocityTemplateBasePath = velocityTemplateBasePath;
    }
}
