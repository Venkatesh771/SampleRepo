package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.MaterialRequestDetail;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tcc.inventoryservice.dao.MaterialRequestDetailDao;
import com.monsanto.tps.dao.GenericDaoImpl;
import org.hibernate.Query;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jjbens2
 * Date: May 11, 2010
 * Time: 9:52:15 AM
 */
public class MaterialRequestDetailDaoImpl extends GenericDaoImpl<MaterialRequestDetail, Long> implements MaterialRequestDetailDao {

     public MaterialRequestDetailDaoImpl(Class aClass) {
        super(aClass);
    }

    public List<MaterialRequestDetail> getAllMaterialRequestDetailsForRequest(Long materialRequestId) throws QueryResultsException {
        Query query = getSession().getNamedQuery("getAllMaterialRequestDetailsForRequest");
        query.setLong("materialRequestId", materialRequestId);
        return query.list();
    }

    @Override
    public List<MaterialRequestDetail> getAllMaterialRequestDetailsMatchingTempTableById(Collection<Long> programIds, int tempSessionId) throws QueryResultsException {

        Query query = getSession().getNamedQuery("getAllMaterialRequestDetailsMatchingTempTableById");
        query.setParameterList("programIdList", programIds);
        query.setLong("tempSessionId", new Long(tempSessionId));
        return query.list();
    }

    @Override
    public Long getMaterialRequestIdForDetailId(Long materialRequestDetailId) throws QueryResultsException {
        return null;
    }
}
