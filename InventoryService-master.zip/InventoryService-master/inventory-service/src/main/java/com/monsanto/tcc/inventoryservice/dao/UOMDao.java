package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.services.domain.breeding.uom.UnitOfMeasure;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MDSPARK
 * Date: Sep 28, 2009
 * Time: 9:32:24 PM
 */
public interface UOMDao extends GenericDao<UnitOfMeasure, Long> {
    public List<UnitOfMeasure> findByIds(List<Long> uomIdList);
    public String findByUomName(String name);

    @DynamicDaoMethod(queryName = "UOMDao.getSeedQuantityUOMs")
    public List<UnitOfMeasure> getSeedQuantityUOMs();
}
