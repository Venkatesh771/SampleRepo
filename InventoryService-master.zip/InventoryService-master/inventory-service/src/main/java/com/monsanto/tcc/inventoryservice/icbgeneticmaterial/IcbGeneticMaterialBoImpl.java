package com.monsanto.tcc.inventoryservice.icbgeneticmaterial;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import com.google.common.collect.Maps;
import com.monsanto.services.domain.germplasm.ProductDescription;
import com.monsanto.tcc.inventorycommon.service.icbgeneticmaterial.domain.ICBGeneticMaterial;
import com.monsanto.tcc.inventoryservice.annotations.Business;
import com.monsanto.tcc.inventoryservice.dao.ICBGeneticMaterialDAO;
import com.monsanto.tps.dataservices.product.services.ProductsService;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.Map;

/**
 * Created by Dan Schnettgoecke on 10/24/12.
 */

@Business("icbGeneticMaterialBo")
public class IcbGeneticMaterialBoImpl implements IcbGeneticMaterialBo {

    @Resource(name = "icbGeneticMaterialDao")
    private ICBGeneticMaterialDAO icbGeneticMaterialDao;
    @Resource(name = "productsService")
    private ProductsService productsService;

    @Override
    public Collection<ICBGeneticMaterial> getICBGeneticMaterialForField(Long fieldId, Long programId) {
        Collection<ICBGeneticMaterial> icbGeneticMaterials = icbGeneticMaterialDao.getICBGeneticMaterial(fieldId);
        if (icbGeneticMaterials != null) {
            Collection<ProductDescription> productDescriptions = productsService.getProductsForGermplasms(getGermplasmIds(icbGeneticMaterials), programId);
            setProductDescriptionsOnGeneticMaterials(icbGeneticMaterials, productDescriptions);
        }
        return icbGeneticMaterials;
    }



    private void setProductDescriptionsOnGeneticMaterials(Collection<ICBGeneticMaterial> icbGeneticMaterials, Collection<ProductDescription> productDescriptions) {
        Map<Long, ProductDescription> productDescriptionsByGermplasmId = Maps.newHashMap();
        for (ProductDescription productDescription : productDescriptions) {
            productDescriptionsByGermplasmId.put(productDescription.getGermplasmId(), productDescription);
        }
        for (ICBGeneticMaterial icbGeneticMaterial : icbGeneticMaterials) {
            icbGeneticMaterial.setProductDescription(productDescriptionsByGermplasmId.get(icbGeneticMaterial.getGermplasmId()));
        }
    }

    private Collection<Long> getGermplasmIds(Collection<ICBGeneticMaterial> icbGeneticMaterials) {
        return Collections2.transform(icbGeneticMaterials, new Function<ICBGeneticMaterial, Long>() {
            @Override
            public Long apply(ICBGeneticMaterial icbGeneticMaterial) {
                return icbGeneticMaterial.getGermplasmId();
            }
        });
    }
}