package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.GeneticMaterial;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tcc.inventoryservice.dao.GeneticMaterialDao;
import com.monsanto.tps.dao.GenericNamedEntityDaoImpl;
import org.hibernate.Query;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 15, 2009
 * Time: 1:01:56 PM
 */
public class GeneticMaterialDaoImpl extends GenericNamedEntityDaoImpl<GeneticMaterial, Long> implements GeneticMaterialDao {
    private static final String MONSANTO_PRODUCT_SRC_STR = "PRE-COMMERCIAL PRODUCT IMPORT%MIRAGE USE ONLY";
    private static final String COMPETITIVE_PRODUCT_SRC_STR = "COMPETITIVE PRODUCT IMPORT%MIRAGE USE ONLY";
    private static final String MIRAGE_ONLY_STR_PRE_2005 = "MIRAGE ONLY; NOT AVAILABLE IN MIDAS";

    public GeneticMaterialDaoImpl(String entityName) {
        super(entityName);
    }

    public GeneticMaterial getGeneticMaterialByLexPubKeyForPreCommercialProduct(String lexiconPubKey) throws QueryResultsException {
        Query query = getSession().getNamedQuery("getGeneticMaterialByLexPubKeyForPreCommercialProduct");
        query.setString("lexPubKey", lexiconPubKey);
        List results = query.list();
        return firstResult(results);
    }

    public GeneticMaterial getGeneticMaterialByProductNameForCommercialMonsantoProduct(Long prodNameId) throws QueryResultsException {
        Query query = getSession().getNamedQuery("getGeneticMaterialByProductNameForCommercialProduct");
        query.setString("sourceStr1", MONSANTO_PRODUCT_SRC_STR);
        query.setString("sourceStr2", MIRAGE_ONLY_STR_PRE_2005);
        query.setLong("prodNameId", prodNameId);
        List results = query.list();
        return firstResult(results);
    }

    public GeneticMaterial getGeneticMaterialByProductNameForCommercialCompetitorProduct(Long prodNameId) throws QueryResultsException {
        Query query = getSession().getNamedQuery("getGeneticMaterialByProductNameForCommercialProduct");
        query.setString("sourceStr1", COMPETITIVE_PRODUCT_SRC_STR);
        query.setString("sourceStr2", MIRAGE_ONLY_STR_PRE_2005);
        query.setLong("prodNameId", prodNameId);
        List results = query.list();
        return firstResult(results);
    }

    @Override
    public List<GeneticMaterial> getMirageOnlyGMForProductNamePubKey(String productNamePubKey) {
        return null;  //dynamic dao method.. see interface for annotations
    }

    @Override
    public int updateGeneticMaterialTester(Long geneticMaterialId, String testerDisplay) {
        int numberUpdated = 0;
        numberUpdated += getSession()
            .getNamedQuery("GeneticMaterial.updateTester")
            .setParameter("testerDisplay", testerDisplay)
            .setParameter("geneticMaterialId", geneticMaterialId)
            .executeUpdate();
        numberUpdated += getSession()
            .getNamedQuery("GeneticMaterial.updateParentageIsTester")
            .setParameter("testerDisplay", testerDisplay)
            .setParameter("geneticMaterialId", geneticMaterialId)
            .executeUpdate();
        numberUpdated += getSession()
            .getNamedQuery("GeneticMaterial.updateParentageIsNotTester")
            .setParameter("testerDisplay", testerDisplay)
            .setParameter("geneticMaterialId", geneticMaterialId)
            .executeUpdate();
        return numberUpdated;
    }


    @Override
    public GeneticMaterial getGeneticMaterialByGermplasmID(Long germplasmID) throws QueryResultsException {
        Query query = getSession().getNamedQuery("GeneticMaterialDao.getGeneticMaterialByGermplasmID");
        query.setLong("germplasmId", germplasmID);
        List results = query.list();
        return firstResult(results);
    }

    @Override
    public int updateGeneticMaterialTemplateText(Long geneticMaterialId, String templateText) {
        return getSession()
                .getNamedQuery("GeneticMaterial.updateGeneticMaterialTemplateText")
                .setParameter("templateText", templateText)
                .setParameter("geneticMaterialId", geneticMaterialId)
                .executeUpdate();
    }


    private GeneticMaterial firstResult(List results) throws QueryResultsException {
        if (results.size() == 0) {
            throw new QueryResultsException("Found NO results when getting Genetic Material");
        } else {
            return (GeneticMaterial) results.get(0);
        }
    }
}
