/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.importing;

import java.math.BigDecimal;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$     On:$Date$
 *
 * @author sssing5
 * @version $Revision$
 */
public class ImportBarcodeRow {
    private String INVENTORYBARCODE;
    private String STORAGECONTAINERBARCODE;
    private BigDecimal ROWINDEX;

    public String getINVENTORYBARCODE() {
        return INVENTORYBARCODE;
    }

    public void setINVENTORYBARCODE(String INVENTORYBARCODE) {
        this.INVENTORYBARCODE = INVENTORYBARCODE;
    }

    public String getSTORAGECONTAINERBARCODE() {
        return STORAGECONTAINERBARCODE;
    }

    public void setSTORAGECONTAINERBARCODE(String STORAGECONTAINERBARCODE) {
        this.STORAGECONTAINERBARCODE = STORAGECONTAINERBARCODE;
    }

    public BigDecimal getROWINDEX() {
        return ROWINDEX;
    }

    public void setROWINDEX(BigDecimal ROWINDEX) {
        this.ROWINDEX = ROWINDEX;
    }
}