package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.services.domain.breeding.Program;
import com.monsanto.services.domain.breeding.program.MidasProgram;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

import java.util.Collection;
import java.util.List;

public interface ProgramDao extends GenericDao<Program, Long> {
    @DynamicDaoMethod(queryName = "ProgramDao.getProgramByProgRefIds", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public Collection<Program> getProgramsByRefIds(@DynamicDaoParameter(name = "programRefIds") Collection<String> programRefIds);

    @DynamicDaoMethod(queryName = "ProgramDao.getProgramsByCropIds", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public Collection<Program> getProgramsByCropIds(@DynamicDaoParameter(name = "cropIds") Collection<Long> cropIds);

    @DynamicDaoMethod(queryName = "ProgramDao.getShareablePrograms", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<Program> getShareablePrograms(@DynamicDaoParameter(name = "programId") long programId);

    public boolean programsAreSharedPrograms(List<Long> programIds);

    public List<MidasProgram> getMidasPrograms(String userName);
}
