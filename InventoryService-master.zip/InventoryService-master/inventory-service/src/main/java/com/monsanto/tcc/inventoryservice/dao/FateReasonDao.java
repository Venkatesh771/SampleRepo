package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.services.domain.breeding.FateReason;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

public interface FateReasonDao  extends GenericDao<FateReason, Long> {

    @DynamicDaoMethod(queryName = "FateReasonDao.findByName",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    FateReason findByName(@DynamicDaoParameter(name = "name") String name);

    @DynamicDaoMethod(queryName = "FateReasonDao.getPublishedParentInventoryFateReason")
    FateReason getPublishedParentInventoryFateReason();
}
