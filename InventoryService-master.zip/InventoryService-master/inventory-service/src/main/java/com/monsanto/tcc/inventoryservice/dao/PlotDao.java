package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.Plot;
import com.monsanto.tps.dao.GenericDao;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Oct 20, 2009
 * Time: 7:26:27 PM
 */
public interface PlotDao extends GenericDao<Plot, Long> {
    List<Long> getParentPlotsForInventoryWhereDecisionIsNotInventory(List<Long> inventoryIdList);

    List<Long> getPlotsWithInventoryChildrenStillInPreview(List<Long> parentPlotList);

    void updatePlotDecision(List<Long> plotList, String plotDecision);

    void bulkUpdatePlotDecision(List<Long> inventoryIds, String plotDecision);

    void bulkUpdatePlotDecision(long decisionId, int tempSessionId);
}
