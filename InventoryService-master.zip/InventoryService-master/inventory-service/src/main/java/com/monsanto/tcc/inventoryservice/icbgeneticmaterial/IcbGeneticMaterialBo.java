package com.monsanto.tcc.inventoryservice.icbgeneticmaterial;

import com.monsanto.tcc.inventorycommon.service.icbgeneticmaterial.domain.ICBGeneticMaterial;

import java.util.Collection;

/**
 * Created by Dan Schnettgoecke on 10/24/12.
 */

public interface IcbGeneticMaterialBo {

    Collection<ICBGeneticMaterial> getICBGeneticMaterialForField(Long fieldId, Long programId);
}