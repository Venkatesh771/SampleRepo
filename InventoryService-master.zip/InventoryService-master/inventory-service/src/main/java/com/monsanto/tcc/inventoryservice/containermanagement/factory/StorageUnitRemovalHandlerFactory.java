package com.monsanto.tcc.inventoryservice.containermanagement.factory;

import com.monsanto.tcc.inventorycommon.transferobject.StorageType;
import com.monsanto.tcc.inventoryservice.containermanagement.remove.StorageUnitRemover;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Mar 11, 2010
 * Time: 1:15:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class StorageUnitRemovalHandlerFactory {
    private Map<StorageType, StorageUnitRemover> storageUnitTypeVsRemoverHandlers;

    public StorageUnitRemovalHandlerFactory(Map<StorageType, StorageUnitRemover> storageUnitTypeVsRemoverHandlers) {
        this.storageUnitTypeVsRemoverHandlers = storageUnitTypeVsRemoverHandlers;
    }

    public StorageUnitRemover getRemoveHandler(StorageType storageType) {
        return storageUnitTypeVsRemoverHandlers.get(storageType);
    }
}
