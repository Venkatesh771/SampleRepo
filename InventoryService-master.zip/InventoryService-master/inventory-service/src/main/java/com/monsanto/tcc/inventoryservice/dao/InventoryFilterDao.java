package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.tcc.inventorycommon.domain.Inventory;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicFilterDaoMethod;

import java.util.Collection;

/**  
 * User: mbpenbe
 * Date: Jun 16, 2009
 * Time: 9:59:05 AM
 */
public interface InventoryFilterDao extends GenericDao<Inventory, Long> {
    @DynamicFilterDaoMethod(filterName = "inventoryFilter")
    Collection<Inventory> find(Filter[] filter );

    @DynamicFilterDaoMethod(filterName = "inventoryFilterTechDev")
    Collection<Inventory> findForTechDev(Filter[] filter );

    @DynamicFilterDaoMethod(filterName = "regulatedMaterialFilter")
    Collection<Inventory> findRegulatedMaterials(Filter[] filter);
}