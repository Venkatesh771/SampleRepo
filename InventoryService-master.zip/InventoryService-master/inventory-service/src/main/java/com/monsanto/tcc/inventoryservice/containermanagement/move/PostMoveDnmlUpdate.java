/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.containermanagement.move;

import com.monsanto.tcc.inventoryservice.dao.InventoryDao;
import com.monsanto.tcc.inventoryservice.inventorycontainer.StorageContainerDnml;

import java.util.List;

import static com.monsanto.tcc.inventoryservice.containermanagement.StorageLocationCollaborator.STORAGE_CONTAINER_NAME_SEPARATOR;

/* nbwald - Nov 8, 2010 */
public class PostMoveDnmlUpdate
{
    private InventoryDao inventoryDao;

    public void update(String dnmlPrefix, List<StorageContainerDnml> containerDnmls) {
        dnmlPrefix = removeTrailingSeparator(dnmlPrefix);
        for (StorageContainerDnml containerDnml : containerDnmls) {
            inventoryDao.updateInventoryDnml(containerDnml.getStorageContainerId(), dnmlPrefix + containerDnml.getRelativeStorageUnitDisplayDnml());
        }
    }

    private String removeTrailingSeparator(String dnmlPrefix) {
        return dnmlPrefix.endsWith(STORAGE_CONTAINER_NAME_SEPARATOR) ?
                dnmlPrefix.substring(0, dnmlPrefix.length() - STORAGE_CONTAINER_NAME_SEPARATOR.length()) :
                dnmlPrefix;
    }

    public void setInventoryDao(InventoryDao inventoryDao) {
        this.inventoryDao = inventoryDao;
    }
}