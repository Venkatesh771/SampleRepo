package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.MaterialRequestStatus;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tcc.inventoryservice.dao.MaterialRequestStatusDao;
import com.monsanto.tps.dao.GenericDaoImpl;
import org.hibernate.Query;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 26, 2009
 * Time: 11:06:09 AM
 */
public class MaterialRequestStatusDaoImpl extends GenericDaoImpl<MaterialRequestStatus, Long> implements MaterialRequestStatusDao {
    public MaterialRequestStatusDaoImpl(Class aClass) {
        super(aClass);
    }

    public MaterialRequestStatus getMaterialRequestStatusByName(String statusName) throws QueryResultsException {
        Query query = getSession().getNamedQuery("getMaterialRequestStatusByName");
        query.setString("statusName", statusName);
        List results = query.list();
        if (results.size() == 0) {
            throw new QueryResultsException("Found NO results when getting Material Request Status by Name = " + statusName);
        } else if (results.size() == 1) {
            return (MaterialRequestStatus) results.get(0);
        }
        throw new QueryResultsException("Found MULTIPLE results when getting Material Request Status by Name = " + statusName);
    }

    @Override
    public List<MaterialRequestStatus> getAllActiveStatuses() {
        return null;  //dynamic dao method. see interface for query
    }
}
