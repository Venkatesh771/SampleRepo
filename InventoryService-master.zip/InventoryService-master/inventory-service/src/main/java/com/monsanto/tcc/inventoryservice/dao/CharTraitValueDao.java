package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tcc.pipeline.filesync.CharTraitValue;
import com.monsanto.tps.dao.GenericDao;

public interface CharTraitValueDao extends GenericDao<CharTraitValue, Long> {
    public CharTraitValue getKlbByGermplasmId(Long germplasmId) throws QueryResultsException;
}
