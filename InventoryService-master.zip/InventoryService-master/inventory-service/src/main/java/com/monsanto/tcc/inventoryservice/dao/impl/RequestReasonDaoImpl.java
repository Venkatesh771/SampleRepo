/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.RequestReason;
import com.monsanto.tcc.inventoryservice.dao.RequestReasonDao;
import com.monsanto.tps.dao.GenericDaoImpl;

/**
 * User: jjbens2
 * Date: May 24, 2010
 */
public class RequestReasonDaoImpl extends GenericDaoImpl<RequestReason, Long> implements RequestReasonDao {

    public RequestReasonDaoImpl(Class aClass) {
        super(aClass);
    }

    @Override
    public RequestReason getRequestReasonByName(String reasonName) {
        return (RequestReason)getSessionFactory().getCurrentSession().getNamedQuery("getRequestReasonByName")
                .setString("requestReasonName", reasonName).uniqueResult();
    }
}