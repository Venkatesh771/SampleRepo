/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.databuilder.QueryBuildingException;
import com.monsanto.tcc.inventorycommon.domain.PlotRelatedDTO;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RJKENN
 * @version $Revision$
 */
public interface PlotRelatedDataDao {
  public List<PlotRelatedDTO> getPlotRelatedDTOs(List<Long> inventoryIds) throws QueryBuildingException;
}