package com.monsanto.tcc.inventoryservice.containermanagement.create;

import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventoryservice.dao.StorageContainerDao;

import java.util.Collection;
import java.util.HashSet;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Apr 8, 2010
 * Time: 10:34:07 PM
 * To change this template use File | Settings | File Templates.
 */
public class EditStorageContainerBO {

    private StorageContainerDao storageContainerDao;

    public Collection<StorageContainer> process(Collection<StorageContainer> modifiedStorageContainers) {
        for (StorageContainer modifiedStorageContainer : modifiedStorageContainers) {
            modifyExistingStorageContainer(modifiedStorageContainer);
        }
        return modifiedStorageContainers;
    }

    private void modifyExistingStorageContainer(StorageContainer storageContainer) {
        StorageContainer existingStorageContainer = getStorageContainerDao().load(storageContainer.getStorageContainerId());
        copyModifiableAttributes(storageContainer, existingStorageContainer);
        if (storageContainer.getStorageContainersByStorageContainerId() != null) {
            Collection<StorageContainer> childContainers = existingStorageContainer.getStorageContainersByStorageContainerId();
            if (childContainers == null) {
                childContainers = new HashSet<StorageContainer>();
            }
            childContainers.addAll(storageContainer.getStorageContainersByStorageContainerId());
            existingStorageContainer.setStorageContainersByStorageContainerId(childContainers);
        }

    }

    private void copyModifiableAttributes(StorageContainer storageContainer, StorageContainer existingStorageContainer) {
        existingStorageContainer.setName(storageContainer.getName());
        existingStorageContainer.setBarcode(storageContainer.getBarcode());
        existingStorageContainer.setDescription(storageContainer.getDescription());
        existingStorageContainer.setStorageContainerType(storageContainer.getStorageContainerType());
    }

    public StorageContainerDao getStorageContainerDao() {
        return storageContainerDao;
    }

    public void setStorageContainerDao(StorageContainerDao storageContainerDao) {
        this.storageContainerDao = storageContainerDao;
    }
}
