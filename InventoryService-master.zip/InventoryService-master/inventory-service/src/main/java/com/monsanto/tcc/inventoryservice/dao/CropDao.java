package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.services.domain.breeding.Crop;
import com.monsanto.tps.dao.GenericDao;

/**
 * Created by IntelliJ IDEA.
 * User: DYSONA
 * Date: May 31, 2011
 * Time: 10:44:07 AM
 * To change this template use File | Settings | File Templates.
 */
public interface CropDao extends GenericDao<Crop, Long> {
}
