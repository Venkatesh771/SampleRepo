package com.monsanto.tcc.inventoryservice.containermanagement.create;

import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventorycommon.domain.StorageLocationCatalog;
import com.monsanto.tcc.inventoryservice.dao.StorageContainerDao;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 20, 2010
 * Time: 3:56:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class EditStorageLocationCatalogBO {

    private StorageContainerDao storageContainerDao;

    public Collection<StorageContainer> process(Collection<StorageLocationCatalog> modifiedStorageLocationCatalogs) {
        Collection<StorageContainer> storageContainers = new ArrayList<StorageContainer>();
        for (StorageLocationCatalog storageLocationCatalog : modifiedStorageLocationCatalogs) {
            if (storageLocationCatalog.getStorageLocationCatalogId() != null) {
                modifyExistingStorageContainerUnderLocationCatalog(storageLocationCatalog);
                storageContainers.add(storageLocationCatalog.getStorageContainerLocationsByStorageLocationCatalogId().iterator().next().getStorageContainerByStorageContainerId());
            }
        }
        return storageContainers;
    }

    private void modifyExistingStorageContainerUnderLocationCatalog(StorageLocationCatalog storageLocationCatalog) {
        StorageContainer storageContainer = getStorageContainerDao().load(storageLocationCatalog.getStorageLocationCatalogId());
        StorageContainer modifiedStorageContainer = storageLocationCatalog.getStorageContainerLocationsByStorageLocationCatalogId().iterator().next().getStorageContainerByStorageContainerId();
        storageContainer.setName(modifiedStorageContainer.getName());
        storageContainer.setBarcode(modifiedStorageContainer.getBarcode());
        storageContainer.setDescription(modifiedStorageContainer.getDescription());
        storageContainer.setStorageContainerType(modifiedStorageContainer.getStorageContainerType());
    }


    public StorageContainerDao getStorageContainerDao() {
        return storageContainerDao;
    }

    public void setStorageContainerDao(StorageContainerDao storageContainerDao) {
        this.storageContainerDao = storageContainerDao;
    }
}
