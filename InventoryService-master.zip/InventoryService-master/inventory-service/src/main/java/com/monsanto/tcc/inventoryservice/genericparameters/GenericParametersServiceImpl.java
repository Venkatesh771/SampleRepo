package com.monsanto.tcc.inventoryservice.genericparameters;

import com.monsanto.tcc.inventorycommon.genericparameters.client.GenericParametersRequest;
import com.monsanto.tcc.inventorycommon.genericparameters.client.GenericParametersResponse;
import com.monsanto.tcc.inventorycommon.genericparameters.service.GenericParametersService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;

/**
 * User: Mark D. Sparks
 * Date: 8/15/11
 * Time: 4:04 PM
 */
@Component(value = "genericParametersServiceImpl")
public class GenericParametersServiceImpl implements GenericParametersService {
    @Resource
    private GenericParametersBo genericParametersBo;
    @Resource
    GenericParametersTransformer genericParametersTransformer;

    public void setGenericParametersBo(GenericParametersBo genericParametersBo) {
        this.genericParametersBo = genericParametersBo;
    }

    public void setGenericParametersTransformer(GenericParametersTransformer genericParametersTransformer) {
        this.genericParametersTransformer = genericParametersTransformer;
    }

    @Override
    public GenericParametersResponse createGenericParameters(List<GenericParametersRequest> genericParametersRequestList) {
        GenericParametersResponse response = new GenericParametersResponse();
        Collection<GenericParameters> genericParametersEntities = genericParametersTransformer.transformToEntities(genericParametersRequestList);
        Long sessionId = genericParametersBo.createGenericParameters(genericParametersEntities);
        response.setSessionId(sessionId);
        return response;
    }
}
