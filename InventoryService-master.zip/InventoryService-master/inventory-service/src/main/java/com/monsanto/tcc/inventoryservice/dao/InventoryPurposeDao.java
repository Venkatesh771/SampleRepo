package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.services.domain.germplasm.InventoryPurpose;
import com.monsanto.tps.dao.GenericDao;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jul 24, 2009
 * Time: 1:24:02 PM
 */
public interface InventoryPurposeDao extends GenericDao<InventoryPurpose, Long> {
    public List<InventoryPurpose> getInventoryPurposesForCropId(Long cropId);
}
