package com.monsanto.tcc.inventoryservice.containermanagement.move;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventoryservice.containermanagement.StorageLocationCollaborator;
import com.monsanto.tcc.inventoryservice.dao.StorageContainerDao;
import com.monsanto.tcc.inventoryservice.inventorycontainer.StorageContainerDnml;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.List;

/**
 * Created by Dan Schnettgoecke on 5/17/13.
 */

public class ContainersIntoContainerMovement {

    private static final Function<StorageContainer, Long> STORAGE_CONTAINER_IDS = new Function<StorageContainer, Long>() {
        @Override
        public Long apply(StorageContainer storageContainer) {
            return storageContainer.getStorageContainerId();
        }
    };
    private static final Predicate<StorageContainer> TOP_LEVEL_CONTAINERS = new Predicate<StorageContainer>() {
        @Override
        public boolean apply(StorageContainer storageContainer) {
            return null == storageContainer.getParentContainerId();
        }
    };

    private StorageContainerDao storageContainerDao;
    private StorageLocationCollaborator storageLocationCollaborator;
    private PostMoveDnmlUpdate postMoveDnmlUpdate;

    public void move(Collection<StorageContainer> containersToMove, StorageContainer destinationContainer) {
        detachCatalogForTopLevelContainers(containersToMove);
        storageContainerDao.updateMultipleContainersParent(getStorageContainerIds(containersToMove), destinationContainer.getStorageContainerId());
        updateInventoryDnml(containersToMove, destinationContainer);
    }

    private void detachCatalogForTopLevelContainers(Collection<StorageContainer> containersToMove) {
        Collection<StorageContainer> topLevelContainers = Lists.newArrayList(Collections2.filter(containersToMove, TOP_LEVEL_CONTAINERS));
        if (!CollectionUtils.isEmpty(topLevelContainers)) {
            storageContainerDao.detachStorageContainerCatalogInBatch(topLevelContainers);
        }
    }

    private Collection<Long> getStorageContainerIds(Collection<StorageContainer> storageContainers) {
        return Lists.newArrayList(Collections2.transform(storageContainers, STORAGE_CONTAINER_IDS));
    }

    private void updateInventoryDnml(Collection<StorageContainer> moved, StorageContainer to) {
        String dnmlPrefix = storageLocationCollaborator.deriveStorageContainerDNML(to);
        List<StorageContainerDnml> containerDnmls = getContainerDnmls(moved);
        postMoveDnmlUpdate.update(dnmlPrefix, containerDnmls);
    }

    private List<StorageContainerDnml> getContainerDnmls(Collection<StorageContainer> storageContainers) {
        List<StorageContainerDnml> allContainerDnmls = Lists.newArrayList();
        for (StorageContainer storageContainer : storageContainers) {
            Collection<StorageContainerDnml> containerDnmls = storageContainerDao.deeplyFindStorageContainersWithInventories(storageContainer.getStorageContainerId());
            allContainerDnmls.addAll(null != containerDnmls ? containerDnmls : Lists.<StorageContainerDnml>newArrayList());
        }
        return allContainerDnmls;
    }

    public void setStorageContainerDao(StorageContainerDao storageContainerDao) {
        this.storageContainerDao = storageContainerDao;
    }

    public void setStorageLocationCollaborator(StorageLocationCollaborator storageLocationCollaborator) {
        this.storageLocationCollaborator = storageLocationCollaborator;
    }

    public void setPostMoveDnmlUpdate(PostMoveDnmlUpdate postMoveDnmlUpdate) {
        this.postMoveDnmlUpdate = postMoveDnmlUpdate;
    }
}
