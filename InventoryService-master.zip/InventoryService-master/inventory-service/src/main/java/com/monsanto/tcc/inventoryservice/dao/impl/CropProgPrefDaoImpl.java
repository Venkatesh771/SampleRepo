package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.CropProgPref;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tcc.inventoryservice.dao.CropProgPrefDao;
import com.monsanto.tps.dao.GenericDaoImpl;
import org.hibernate.Query;

import java.util.List;

public class CropProgPrefDaoImpl extends GenericDaoImpl<CropProgPref, Long> implements CropProgPrefDao {
    public CropProgPrefDaoImpl(Class aClass) {
        super(aClass);
    }

    public CropProgPref getCropProgPrefByProductId(Long productId) throws QueryResultsException {
        Query query = getSession().getNamedQuery("getCropProgPrefByProductId");
        query.setLong("prodId", productId);
        List results = query.list();
        if (results.size() == 0) {
            throw new QueryResultsException("Found NO results when getting CropProgPref by Product Id");
        } else if (results.size() == 1){
            return (CropProgPref) results.get(0);
        } throw new QueryResultsException("Found MULTIPLE results when getting CropProgPref by Product Id");
    }
}
