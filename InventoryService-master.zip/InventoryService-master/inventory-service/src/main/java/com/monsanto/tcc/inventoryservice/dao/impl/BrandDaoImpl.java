package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.Brand;
import com.monsanto.tcc.inventoryservice.dao.BrandDao;
import com.monsanto.tps.dao.GenericDaoImpl;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 12, 2009
 * Time: 2:22:39 PM
 */
public class BrandDaoImpl extends GenericDaoImpl<Brand, Long> implements BrandDao {
    public BrandDaoImpl(Class entityClass) {
        super(entityClass);
    }
}
