package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventorycommon.domain.StorageLocation;
import com.monsanto.tcc.inventorycommon.domain.TempSessionOcd;
import com.monsanto.tcc.inventorycommon.domain.TempSessionOcdId;
import com.monsanto.tcc.inventoryservice.dao.StorageLocationDao;
import com.monsanto.tcc.inventoryservice.inventorycontainer.StorageContainerDnml;
import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Mar 12, 2010
 * Time: 2:00:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class StorageLocationDaoImpl extends GenericDaoImpl<StorageLocation, Long> implements StorageLocationDao {
    private int requestId = 2;

    public StorageLocationDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public List<StorageLocation> getStorageLocationsBySubSubSiteId(@DynamicDaoParameter(name = "parentSubSubSiteId") Long storageLocationId) {
        return null;//Dynamic DAO see interface for annotations
    }

    @Override
    public String getNextBarcode() {
        return null;  //Dynamic DAO see interface for annotations
    }

    public String getSiteSubSiteSubSubSiteNames(Long parentSubSubSiteId) {
        Query query = getSession().getNamedQuery("StorageLocation.getSiteSubSiteSubSubSiteNames");
        query.setParameter("parentSubSubSiteId", parentSubSubSiteId);
        return (String) query.uniqueResult();
    }

    @Override
    public void deleteStorageLocations(Collection<Long> storageLocationIds) {
        if (storageLocationIds != null) {
            Query storageContainerIdsUnderStorageLocationQuery = getSession().getNamedQuery("StorageContainerDao.getStorageContainersByStorageLocationId");
            for (Long storageLocationId : storageLocationIds) {
                storageContainerIdsUnderStorageLocationQuery.setParameter("parentStorageLocationId", storageLocationId);
                List<StorageContainer> storageContainers = storageContainerIdsUnderStorageLocationQuery.list();
                delete(storageLocationId);
                deleteChildStorageContainers(storageContainers);
            }
        }
    }

    public StorageLocation getStorageLocationByBarcode(@DynamicDaoParameter(name = "storageLocationBarcode") String storageLocationBarcode) {
        return null;
    }

    private void deleteChildStorageContainers(List<StorageContainer> storageContainers) {
        if (storageContainers != null) {
            for (StorageContainer storageContainer : storageContainers) {
                getSessionFactory().getCurrentSession().delete(storageContainer);
            }
        }
    }

    @Override
    public Collection<Long> getStorageLocationsWithInventoryAssigned(Collection<Long> parentStorageLocationIds) {
        insertParentContainerIdsIntoTempTable(parentStorageLocationIds, requestId);
        getSessionFactory().getCurrentSession().flush();
        Query query = getSession().getNamedQuery("StorageLocationDao.getStorageLocationsWithInventoryAssigned");
        query.setParameter("requestId", requestId);
        Collection<BigDecimal> storageContainerIds = query.list();
        return convertToLongList(storageContainerIds);
    }

    @Override
    public List<StorageContainerDnml> deeplyFindStorageContainersWithInventories(long storageLocationId) {
        Session session = getSession();
        Query query = session.getNamedQuery("StorageLocationDao.deeplyFindStorageContainersWithInventories");
        query.setParameter("storageLocationId", storageLocationId);
        query.setResultTransformer(Transformers.aliasToBean(StorageContainerDnml.class));
        return query.list();
    }

    private Collection<Long> convertToLongList(Collection<BigDecimal> storageContainerIds) {
        List<Long> storageContainerLongIds = new ArrayList<Long>();
        if (storageContainerIds != null) {
            for (BigDecimal storageContainerId : storageContainerIds) {
                storageContainerLongIds.add(storageContainerId.longValue());
            }
        }
        return storageContainerLongIds;
    }

    private void insertParentContainerIdsIntoTempTable(Collection<Long> parentContainerIds, int sessionId) {
        Long sortOrder = 1L;
        for (Long parentContainerId : parentContainerIds) {
            TempSessionOcd ocd = new TempSessionOcd();
            TempSessionOcdId tempSessionOcdId = new TempSessionOcdId();
            tempSessionOcdId.setRequestId(new Long(sessionId));
            tempSessionOcdId.setNumber1(parentContainerId);
            tempSessionOcdId.setSortOrder(sortOrder++);
            ocd.setId(tempSessionOcdId);
            getSessionFactory().getCurrentSession().save(ocd);
        }
    }
}
