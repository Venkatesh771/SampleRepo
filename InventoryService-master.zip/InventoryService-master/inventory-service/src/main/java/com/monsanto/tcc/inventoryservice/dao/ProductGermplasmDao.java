/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.ProductGermplasmXRef;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

import java.util.List;

/**
 * Filename:    $RCSfile$
 * Label:       $Name$
 * Last Change: $Author$     On:$Date$
 *
 * @author mmatho
 * @version $Revision$
 */
public interface ProductGermplasmDao extends GenericDao<ProductGermplasmXRef, Long> {

    @DynamicDaoMethod(queryName = "ProductGermplasmDao.getProductGermplasmBYProductId", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<ProductGermplasmXRef> getProductGermplasmBYProductId(@DynamicDaoParameter(name = "id") Long productId);
}