package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tcc.inventoryservice.dao.CharTraitValueDao;
import com.monsanto.tcc.pipeline.filesync.CharTraitValue;
import com.monsanto.tps.dao.GenericDaoImpl;
import org.hibernate.Query;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jul 20, 2009
 * Time: 1:27:15 PM
 */
public class CharTraitValueDaoImpl extends GenericDaoImpl<CharTraitValue, Long> implements CharTraitValueDao{
    public CharTraitValueDaoImpl(Class aClass) {
        super(aClass);
    }

    public CharTraitValue getKlbByGermplasmId(Long germplasmId) throws QueryResultsException {
        Query query = getSession().getNamedQuery("getKlbByGermplasmId");
        query.setLong("germplasmId", germplasmId);
        List results = query.list();
        if (results.size() == 0) {
            return null;
        } else if (results.size() == 1){
            return (CharTraitValue) results.get(0);
        } throw new QueryResultsException("Found MULTIPLE results when getting Klb by Germplasm Id");

    }
}
