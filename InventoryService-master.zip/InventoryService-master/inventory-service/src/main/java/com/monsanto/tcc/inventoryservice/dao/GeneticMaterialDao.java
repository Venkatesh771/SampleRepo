package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.GeneticMaterial;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 15, 2009
 * Time: 1:01:24 PM
 */
public interface GeneticMaterialDao extends GenericDao<GeneticMaterial, Long> {
    public GeneticMaterial getGeneticMaterialByLexPubKeyForPreCommercialProduct(String lexiconPubKey) throws QueryResultsException;

    public GeneticMaterial getGeneticMaterialByProductNameForCommercialMonsantoProduct(Long prodNameId) throws QueryResultsException;

    public GeneticMaterial getGeneticMaterialByProductNameForCommercialCompetitorProduct(Long prodNameId) throws QueryResultsException;

    @DynamicDaoMethod(queryName = "GeneticMaterial.getFirstMirageOnlyGMForLexProductNamePubKey",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<GeneticMaterial> getMirageOnlyGMForProductNamePubKey(@DynamicDaoParameter(name = "lexProdNamePubKey") String productNamePubKey);


    public int updateGeneticMaterialTester(Long geneticMaterialId,String testerDisplay);

    public GeneticMaterial getGeneticMaterialByGermplasmID(Long germplasmId) throws QueryResultsException;

    public int updateGeneticMaterialTemplateText(Long geneticMaterialId, String templateText);
}
