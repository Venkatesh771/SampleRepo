package com.monsanto.tcc.inventoryservice.dao;


import com.monsanto.tcc.inventorycommon.service.icbgeneticmaterial.domain.ICBGeneticMaterial;

import java.util.Collection;


/**
 * Created by IntelliJ IDEA.
 * User: KKTIWA
 * Date: 6/7/12
 * Time: 2:33 PM
 */

public interface ICBGeneticMaterialDAO {

    Collection<ICBGeneticMaterial> getICBGeneticMaterial(long fieldId);
}