package com.monsanto.tcc.inventoryservice.containermanagement.remove;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Mar 12, 2010
 * Time: 4:35:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveStorageUnitsHelper {
    public Collection<Long> captureStorageUnitTOIds(Collection<StorageUnitTO> storageUnitsRequestedForRemoval) {
        Collection<Long> storageUnitIds = new ArrayList<Long>();
        if (storageUnitsRequestedForRemoval != null) {
            for (StorageUnitTO storageLocation : storageUnitsRequestedForRemoval) {
                storageUnitIds.add(storageLocation.getId());
            }
        }
        return storageUnitIds;
    }

    public <T> Collection<T> minusElements(Collection<T> sourceIds, Collection<T> idsToRemove) {
        Collection<T> newCollection = new ArrayList<T>();
        if (idsToRemove != null) {
            newCollection = new ArrayList<T>(sourceIds);
            newCollection.removeAll(idsToRemove);
        }
        return newCollection;
    }

}
