package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.services.domain.germplasm.InventoryPurpose;
import com.monsanto.tcc.inventoryservice.dao.InventoryPurposeDao;
import com.monsanto.tps.dao.GenericDaoImpl;
import org.hibernate.Query;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jul 24, 2009
 * Time: 1:24:54 PM
 */
public class InventoryPurposeDaoImpl extends GenericDaoImpl<InventoryPurpose, Long> implements InventoryPurposeDao {
    public InventoryPurposeDaoImpl(Class aClass) {
        super(aClass);
    }

    public List<InventoryPurpose> getInventoryPurposesForCropId(Long cropId) {
        Query query = getSession().getNamedQuery("getInventoryPurposesForCropId");
        query.setLong("cropId", cropId);
        return query.list();
    }
}
