/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.containermanagement.move;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;

public interface StorageUnitMovementStrategy
{
    boolean isApplicableTo(StorageUnitTO moved, StorageUnitTO to);
    void move(StorageUnitTO moved, StorageUnitTO to);
}