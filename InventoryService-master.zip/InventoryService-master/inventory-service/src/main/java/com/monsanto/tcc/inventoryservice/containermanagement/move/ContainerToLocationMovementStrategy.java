/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.containermanagement.move;

import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventorycommon.domain.StorageLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;
import com.monsanto.tcc.inventorycommon.transferobject.StorageType;
import com.monsanto.tcc.inventoryservice.dao.StorageContainerDao;
import com.monsanto.tcc.inventoryservice.dao.StorageLocationDao;

public class ContainerToLocationMovementStrategy
    implements StorageUnitMovementStrategy
{
    private StorageContainerDao storageContainerDao;
    private StorageLocationDao storageLocationDao;
    private ContainerToLocationMovement containerToLocationMovement;

    @Override
    public boolean isApplicableTo(StorageUnitTO moved, StorageUnitTO to) {
        return isType(moved, StorageType.STORAGE_CONTAINER) && isType(to, StorageType.STORAGE_LOCATION);
    }

    @Override
    public void move(StorageUnitTO moved, StorageUnitTO to) {
        StorageContainer movedContainer = storageContainerDao.getStorageContainerByBarcode(moved.getBarcode());
        StorageLocation toLocation = storageLocationDao.getStorageLocationByBarcode(to.getBarcode());
        containerToLocationMovement.move(movedContainer, toLocation);
    }

    private boolean isType(StorageUnitTO storageUnit, StorageType storageType) {
        return storageType.equals(storageUnit.getStorageUnitType().getType());
    }

    public void setStorageContainerDao(StorageContainerDao storageContainerDao) {
        this.storageContainerDao = storageContainerDao;
    }

    public void setStorageLocationDao(StorageLocationDao storageLocationDao) {
        this.storageLocationDao = storageLocationDao;
    }

    public void setContainerToLocationMovement(ContainerToLocationMovement containerToLocationMovement) {
        this.containerToLocationMovement = containerToLocationMovement;
    }
}