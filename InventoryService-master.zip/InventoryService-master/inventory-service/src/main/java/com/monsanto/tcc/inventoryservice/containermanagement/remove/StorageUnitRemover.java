package com.monsanto.tcc.inventoryservice.containermanagement.remove;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Mar 11, 2010
 * Time: 1:16:32 PM
 * To change this template use File | Settings | File Templates.
 */
public interface StorageUnitRemover {
    public void remove(Collection<StorageUnitTO> storageUnitsToBeRemoved);

    public Collection<StorageUnitTO> getStorageUnitsNotAssignedToAnyInventory(Collection<StorageUnitTO> storageUnitsRequestedForRemoval);
}
