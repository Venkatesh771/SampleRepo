package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.AlternateInventory;
import com.monsanto.tps.dao.GenericDao;

/**
 * Created by IntelliJ IDEA.
 * User: vkdasy
 * Date: Sep 2, 2010
 * Time: 7:13:46 PM
 */
public interface AlternateInventoryDao extends GenericDao<AlternateInventory, Long> {
}
