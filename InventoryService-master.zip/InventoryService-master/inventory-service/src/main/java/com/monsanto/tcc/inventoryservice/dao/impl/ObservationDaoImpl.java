package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.Observation;
import com.monsanto.tcc.inventoryservice.dao.ObservationDao;
import com.monsanto.tcc.inventoryservice.ttpm.testedmaterial.CrossSegregateParentage;
import org.hibernate.SessionFactory;
import org.hibernate.transform.AliasToBeanResultTransformer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Jun 25, 2010
 * Time: 10:56:57 AM
 */
public class ObservationDaoImpl implements ObservationDao {

    private SessionFactory sessionFactory;

    public List<Observation> getObservationsWithZygositySummaryForEventPresenceAnalysis(Long crossSegregateIndividualStatusId) {
        List<CrossSegregateParentage> crossSegregateParentages = loadParentRecords(crossSegregateIndividualStatusId);
        List<Long> inventoryIds = new ArrayList<Long>();
        List<Long> plotIds = new ArrayList<Long>();
        buildInventoryPlotIds(crossSegregateParentages, inventoryIds, plotIds);
        //noinspection unchecked
        return (List<Observation>) sessionFactory.getCurrentSession()
                .getNamedQuery("ObservationDao.getObservationsWithZygositySummaryForEventPresenceAnalysis")
                .setParameter("CROSS_SEGREGATE_ID", crossSegregateIndividualStatusId)
                .setParameterList("INVENTORY_IDS", inventoryIds)
                .setParameterList("PLOT_IDS", plotIds)
                .list();
    }

    private void buildInventoryPlotIds(List<CrossSegregateParentage> crossSegregateParentages, List<Long> inventoryIds, List<Long> plotIds) {
        for (CrossSegregateParentage crossSegregateParentage : crossSegregateParentages) {
            inventoryIds.addAll(crossSegregateParentage.getInventoryIds());
            plotIds.addAll(crossSegregateParentage.getPlotIds());
        }
        addDummyValueIfListIsEmpty(inventoryIds, plotIds);
    }

    private void addDummyValueIfListIsEmpty(List<Long> inventoryIds, List<Long> plotIds) {
        if (inventoryIds.isEmpty()) {
            inventoryIds.add(0L);
        }
        if (plotIds.isEmpty()) {
            plotIds.add(0L);
        }
    }

    private List<CrossSegregateParentage> loadParentRecords(Long crossSegregateIndividualStatusId) {
        //noinspection unchecked
        return (List<CrossSegregateParentage>) sessionFactory.getCurrentSession()
                .getNamedQuery("ObservationDao.getUpToSixLevelsOfParentageFromCrossSeg")
                .setParameter("CROSS_SEGREGATE_ID", crossSegregateIndividualStatusId)
                .setResultTransformer(new AliasToBeanResultTransformer(CrossSegregateParentage.class))
                .list();
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
