/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao;

import java.util.Collection;

/**
 * Created by Dan Schnettgoecke with IntelliJ IDEA.
 * Created on Oct 19, 2010 @ 9:01:56 PM.
 */

public interface GermplasmEventConstructDao {

    public void deregulateMaterials(Collection<Long> germplasmEventConstructIds);
}