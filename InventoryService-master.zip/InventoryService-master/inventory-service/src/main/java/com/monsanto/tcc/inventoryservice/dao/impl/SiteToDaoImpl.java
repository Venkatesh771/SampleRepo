/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.SiteTO;
import com.monsanto.tcc.inventoryservice.dao.SiteToDao;
import com.monsanto.tps.dao.GenericDaoImpl;
import org.hibernate.Query;

import javax.annotation.Resource;
import java.util.Collection;
import java.util.List;

/* NBWALD - Jan 24, 2011 */
public class SiteToDaoImpl extends GenericDaoImpl<SiteTO, Long> implements SiteToDao
{
    @Resource private TempSessionDao tempSessionDao;

    public SiteToDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public SiteTO findSiteByName(String siteName) {
        Query query = query("Site.findSiteByName").setString("siteName", siteName);
        return (SiteTO) query.uniqueResult();
    }

    @Override
    public List<SiteTO> findSitesByNames(Collection<String> siteNames) {
        TempSessionRequest tempSessionRequest = TempSessionRequest.SITE_NAMES;
        tempSessionDao.insertStrings(tempSessionRequest, siteNames);
        Query query = query("Site.findSitesByNames").setLong("requestId", tempSessionRequest.getRequestId());
        return query.list();
    }

    private Query query(String queryName) {
        return getSession().getNamedQuery(queryName);
    }
}