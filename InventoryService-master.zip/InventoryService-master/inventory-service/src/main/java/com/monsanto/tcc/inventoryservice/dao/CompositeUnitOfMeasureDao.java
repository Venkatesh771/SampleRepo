package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.services.domain.breeding.uom.UnitOfMeasure;
import com.monsanto.tcc.inventorycommon.domain.CompositeUnitOfMeasure;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

public interface CompositeUnitOfMeasureDao extends GenericDao<CompositeUnitOfMeasure, Long> {

    @DynamicDaoMethod(queryName = "CompositeUnitOfMeasureDao.findByUnitOfMeasureName",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    CompositeUnitOfMeasure findByUnitOfMeasureName(@DynamicDaoParameter(name = "name") String name);

    @DynamicDaoMethod(queryName = "CompositeUnitOfMeasureDao.findByUnitOfMeasure",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    CompositeUnitOfMeasure findByUnitOfMeasure(@DynamicDaoParameter(name = "unitOfMeasure") UnitOfMeasure unitOfMeasure);
}
