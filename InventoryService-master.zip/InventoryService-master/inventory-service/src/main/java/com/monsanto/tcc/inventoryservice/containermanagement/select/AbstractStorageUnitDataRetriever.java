package com.monsanto.tcc.inventoryservice.containermanagement.select;

import com.monsanto.tcc.inventoryservice.inventory.util.ManageContainersDaoProvider;
import com.monsanto.tps.architecture.transformer.DozerObjectTransformer;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 17, 2010
 * Time: 9:18:19 AM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractStorageUnitDataRetriever {
    private ManageContainersDaoProvider manageContainersDaoProvider;
    private DozerObjectTransformer objectTransformer;


    protected <E> Collection<E> buildObjects(Collection<?> sourceObjects, Class<E> destinationClass) {
        return (sourceObjects != null) ? getObjectTransformer().buildObjects(sourceObjects, destinationClass) : new ArrayList<E>();
    }

    public ManageContainersDaoProvider getManageContainersDaoProvider() {
        return manageContainersDaoProvider;
    }

    public void setManageContainersDaoProvider(ManageContainersDaoProvider manageContainersDaoProvider) {
        this.manageContainersDaoProvider = manageContainersDaoProvider;
    }

    public DozerObjectTransformer getObjectTransformer() {
        return objectTransformer;
    }

    public void setObjectTransformer(DozerObjectTransformer objectTransformer) {
        this.objectTransformer = objectTransformer;
    }

}
