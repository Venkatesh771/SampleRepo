package com.monsanto.tcc.inventoryservice;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.dialect.Dialect;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.exception.JDBCExceptionHelper;
import org.hibernate.id.Configurable;
import org.hibernate.type.Type;
import org.hibernate.util.PropertiesHelper;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 16, 2009
 * Time: 4:31:50 PM
 */
public class PrimaryKeyGenerator implements org.hibernate.id.IdentifierGenerator, Configurable {

    protected String getIdSQL = "select midas.get_nextId from dual";
    protected String schemaName = "midas";
    protected String generatorFunctionName = "get_nextId";
    protected boolean unwrapSqlFunctionResultAsTable = false;

    public void configure(Type type, Properties params, Dialect dialect) throws MappingException {
        this.setSchemaName(PropertiesHelper.getString("schemaName", params, this.getSchemaName()));
        this.setGeneratorFunctionName(PropertiesHelper.getString("generatorFunctionName", params, this.getGeneratorFunctionName()));
        this.setUnwrapSqlFunctionResultAsTable(PropertiesHelper.getBoolean("unwrapSqlFunctionResultAsTable", params, this.isUnwrapSqlFunctionResultAsTable()));
        setIdSQL();
    }

    public boolean isUnwrapSqlFunctionResultAsTable() {
        return unwrapSqlFunctionResultAsTable;
    }

    public void setUnwrapSqlFunctionResultAsTable(boolean unwrapSqlFunctionResultAsTable) {
        this.unwrapSqlFunctionResultAsTable = unwrapSqlFunctionResultAsTable;
    }

    public String getSchemaName() {
        return schemaName;
    }

    public void setSchemaName(String schemaName) {
        this.schemaName = schemaName;
        setIdSQL();
    }

    public String getGeneratorFunctionName() {
        return generatorFunctionName;
    }

    public void setGeneratorFunctionName(String generatorFunctionName) {
        this.generatorFunctionName = generatorFunctionName;
        setIdSQL();
    }

    protected void setIdSQL() {
        if( this.isUnwrapSqlFunctionResultAsTable() ) {
            getIdSQL = "SELECT column_value as line_id FROM TABLE(" + this.getSchemaName() + "." + this.getGeneratorFunctionName() + ")";
        } else {
            getIdSQL = "SELECT " + this.getSchemaName() + "." + this.getGeneratorFunctionName() + " FROM DUAL";
        }
    }

    public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
        PreparedStatement st = null;
        try {
            st = session.getBatcher().prepareSelectStatement(getIdSQL);
            try {
                ResultSet rs = st.executeQuery();
                final Serializable result;
                try {
                    rs.next();
                    result = rs.getLong(1);
                }
                finally {
                    rs.close();
                }
                return result;
            }
            finally {
                session.getBatcher().closeStatement(st);
            }
        }
        catch (SQLException sqle) {
            throw JDBCExceptionHelper.convert(
                    session.getFactory().getSQLExceptionConverter(),
                    sqle,
                    "could not get next value",
                    getIdSQL
            );
        }
    }
}
