package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.StorageLocationCatalog;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 3, 2010
 * Time: 8:58:08 AM
 * To change this template use File | Settings | File Templates.
 */
public interface StorageLocationCatalogDao extends GenericDao<StorageLocationCatalog, Long> {
    @DynamicDaoMethod(queryName = "StorageLocationCatalog.getNextBarcode", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public String getNextBarcode();
}
