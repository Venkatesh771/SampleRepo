package com.monsanto.tcc.inventoryservice.containermanagement.factory;

import com.monsanto.tcc.inventorycommon.transferobject.StorageType;
import com.monsanto.tcc.inventoryservice.containermanagement.select.AbstractStorageLocationAndContainerRetriever;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Mar 9, 2010
 * Time: 2:09:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class StorageUnitsRetrieverFactory {

    private Map<StorageType, AbstractStorageLocationAndContainerRetriever> handlerMap;

    public StorageUnitsRetrieverFactory(Map<StorageType, AbstractStorageLocationAndContainerRetriever> handlerMap) {
        this.handlerMap = handlerMap;
    }

    public AbstractStorageLocationAndContainerRetriever getHandler(StorageType storageType) {
        return handlerMap.get(storageType);
    }
}
