/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.containermanagement.export;

import com.monsanto.tcc.inventorycommon.transferobject.suinventory.ExportStorageContainer;

import java.util.List;

public interface StorageContainerExportStrategy
{
    List<ExportStorageContainer> export(long storageUnitId);
}