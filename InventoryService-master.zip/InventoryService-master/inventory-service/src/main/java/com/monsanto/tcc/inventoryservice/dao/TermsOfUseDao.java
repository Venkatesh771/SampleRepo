package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventoryservice.domain.TermsOfUseEntity;

import java.util.List;

/**
 * User: DCENGL
 */
public interface TermsOfUseDao {

    List<TermsOfUseEntity> findTermsOfUse(Long geneticMaterialId);

    TermsOfUseEntity load(Long termsOfUseId);

    void save(TermsOfUseEntity termsOfUseEntity);
}
