package com.monsanto.tcc.inventoryservice.containermanagement.select;

import com.monsanto.tcc.inventorycommon.domain.StorageLocationType;
import com.monsanto.tcc.inventorycommon.domain.StorageUnitTypeTO;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 17, 2010
 * Time: 9:51:26 AM
 * To change this template use File | Settings | File Templates.
 */
public class StorageLocationTypeRetriever extends AbstractStorageTypesRetriever {

    @Override
    protected Collection<StorageUnitTypeTO> build() {
        List<StorageLocationType> storageLocationTypeList = getManageContainersDaoProvider().getStorageLocationTypeDao().loadAll();
        return buildObjects(storageLocationTypeList, StorageUnitTypeTO.class);
    }
}
