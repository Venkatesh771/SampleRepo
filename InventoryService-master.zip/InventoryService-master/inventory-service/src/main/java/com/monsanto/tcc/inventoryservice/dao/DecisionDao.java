package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.Decision;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tps.dao.GenericDao;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Oct 21, 2009
 * Time: 12:46:55 PM
 */
public interface DecisionDao extends GenericDao<Decision, Long> {
    public Decision getInventoryDecision() throws QueryResultsException;
}
