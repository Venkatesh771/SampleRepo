package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.services.domain.shipping.Shipment;
import com.monsanto.tps.dao.GenericDao;

public interface ShipmentDao extends GenericDao<Shipment, Long> {
}
