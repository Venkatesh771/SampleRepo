package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.tcc.inventorycommon.domain.MaterialRequest;
import com.monsanto.tcc.inventoryservice.dao.MaterialRequestDao;
import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import org.hibernate.Query;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 24, 2009
 * Time: 11:11:14 AM
 */
public class MaterialRequestDaoImpl extends GenericDaoImpl<MaterialRequest, Long> implements MaterialRequestDao {
    private static final String PROGRAM_ID_LIST = "programIdList";

    public MaterialRequestDaoImpl(Class aClass) {
        super(aClass);
    }

    @Override
    public MaterialRequest saveOrUpdate(MaterialRequest entity) {
        if (entity.getRequestUniqueIdNumber() == null) {
            entity.setRequestUniqueIdNumber(this.getNextUniqueRequestIdNbr());
        }
        return super.saveOrUpdate(entity);
    }

    public Long getNextUniqueRequestIdNbr() {
        return ((BigDecimal) getSession().getNamedQuery("getNextUniqueRequestIdNbr").uniqueResult()).longValue();
    }

    @Override
    public Collection<MaterialRequest> retrieveMaterialRequestHistory(Filter[] filter) {
        return null;  //dynamic dao method. check the interface for annotations
    }

    @Override
    public Collection<Integer> getAvailableYearsInRequestHistory(@DynamicDaoParameter(name = "requestorProgIds") Collection<Long> programIds) {
        return null;  //dynamic dao method. check the interface for annotations
    }

    public List<MaterialRequest> getMaterialRequestsByProviderProgram(String providerProgRefId, List<String> materialReqIds) {
        Query query = getSession().getNamedQuery("getMaterialRequestsByProviderProgram");
        query.setString("progRefId", providerProgRefId);
        query.setParameterList("reqIds", materialReqIds);
        return query.list();
    }

    public List<MaterialRequest> getAllMaterialRequestsForProgram(Long progId) {
        Query query = getSession().getNamedQuery("getAllMaterialRequestsForProgram");
        query.setLong("progId", progId);
        return query.list();
    }

    @Override
    public List<MaterialRequest> getMaterialRequestsByProviderProgramListInStatus(Collection<Long> programIds, String materialRequestStatusName) {

        Query query = getSession().getNamedQuery("getMaterialRequestsByProviderProgramListInStatus");

        query.setParameterList(PROGRAM_ID_LIST, programIds);
        query.setString("materialRequestStatusName", materialRequestStatusName);
        return query.list();
    }

    @Override
    public List<MaterialRequest> getMaterialRequestsByProviderProgramListInProcessedStatus(Collection<Long> programIds) {
        return getMaterialRequestsByProviderProgramListInStatus(programIds, "Processed");
    }

    @Override
    public List<MaterialRequest> getMaterialRequestsForProviderProgramByDetailId(Collection<Long> materialRequestDetailIds, Collection<Long> programIds) {

        return getSession().getNamedQuery("getMaterialRequestsForProviderProgramByDetailId")
                .setParameterList("detailIds", materialRequestDetailIds)
                .setParameterList(PROGRAM_ID_LIST, programIds)
                .list();
    }

    @Override
    public List<MaterialRequest> getAllRequestsForProviderProgramsMatchedToTempSession(Collection<Long> programIds, int tempSessionId) {

        return getSessionFactory().getCurrentSession().getNamedQuery("getAllRequestsForProviderProgramsMatchedToTempSession")
                .setInteger("tempSessionId", tempSessionId)
                .setParameterList(PROGRAM_ID_LIST, programIds)
                .list();
    }
}
