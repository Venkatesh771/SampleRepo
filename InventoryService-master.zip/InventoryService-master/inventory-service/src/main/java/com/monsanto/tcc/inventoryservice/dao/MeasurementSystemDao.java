package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.MeasurementSystem;
import com.monsanto.tps.dao.GenericDao;

public interface MeasurementSystemDao extends GenericDao<MeasurementSystem, Long> {
}
