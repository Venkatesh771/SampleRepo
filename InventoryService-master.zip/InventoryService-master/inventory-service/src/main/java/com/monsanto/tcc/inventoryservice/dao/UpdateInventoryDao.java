package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.Inventory;
import com.monsanto.tps.dao.GenericDao;

/**
 * Created by Dan Schnettgoecke with IntelliJ IDEA.
 * Created on Feb 21, 2011 at 12:20:16 PM.
 */

public interface UpdateInventoryDao extends GenericDao<Inventory, Long> {
}