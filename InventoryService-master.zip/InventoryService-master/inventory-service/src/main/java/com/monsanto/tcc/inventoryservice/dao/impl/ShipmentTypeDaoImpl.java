package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventoryservice.dao.ShipmentTypeDao;
import com.monsanto.tps.aop.cache.MethodCache;
import org.hibernate.SessionFactory;

import java.math.BigDecimal;

/**
 * Created by FFAN on 8/8/14.
 */
public class ShipmentTypeDaoImpl implements ShipmentTypeDao {


    private SessionFactory sessionFactory;

    @Override
    @MethodCache
    public Long findByName(String shipmentTypeName) {
        return ((BigDecimal) sessionFactory.getCurrentSession().
                createSQLQuery("select shipment_type_id " +
                        "from INVENTORY_MGT.SHIPMENT_TYPE " +
                        "where upper(name) = :name")
                .setParameter("name", shipmentTypeName.toUpperCase())
                .uniqueResult()).longValue();
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
