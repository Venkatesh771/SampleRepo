/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.email;

import com.monsanto.tcc.inventorycommon.domain.email.EmailConfiguration;
import com.monsanto.tcc.inventorycommon.domain.email.EmailMessage;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tcc.inventorycommon.service.email.EmailSender;
import com.monsanto.tcc.inventorycommon.service.exception.MaterialExchangeException;
import com.monsanto.tcc.inventoryservice.dao.MaterialRequestDetailDao;
import com.monsanto.tcc.inventoryservice.email.builder.EmailBuilder;
import com.monsanto.tcc.inventoryservice.util.EnvironmentUtil;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * User: jjbens2
 * Date: Jun 2, 2010
 */
public class MaterialExchangeEmailManagerImpl implements MaterialExchangeEmailManager {

    private MaterialRequestDetailDao materialRequestDetailDao;
    private EmailSenderFactory emailSenderFactory;
    private EmailBindUtil emailBindUtil;
    private EmailBuilder emailBuilder;

    public MaterialExchangeEmailManagerImpl() {

    }

    @Override
    public void sendMaterialExchangeExceptionEmail(Long materialRequestDetailId) throws MaterialExchangeException {

        try {
            Map<String, String> emailParameterMap = buildEmailParameterMap(materialRequestDetailId);
            EmailMessage emailMessage = buildEmailMessage(emailParameterMap);
            this.sendEmail(emailMessage);
        } catch(Exception e) {
            throw new MaterialExchangeException(e.getMessage(), e);
        }
    }

    private void sendEmail(EmailMessage emailMessage) {

        EmailSender emailSender = emailSenderFactory.createForEnvironment();
        emailSender.sendEmails(emailMessage);
    }

    private EmailMessage buildEmailMessage(Map<String, String> emailParameterMap) throws Exception {

        EmailMessage emailMessage = new EmailMessage();
        emailMessage.setSubject(getSubjectText(emailParameterMap));
        emailMessage.setFromAddress(EmailConfiguration.getProperty("MATERIAL_EXCHANGE_FROM_EMAIL_ADDRESS"));
        emailMessage.setToAddresses(Arrays.asList(EmailConfiguration.getProperty("MATERIAL_EXCHANGE_SUPPORT_EMAIL_ADDRESS", EnvironmentUtil.lsiFunction())));
        emailMessage.setBody(emailBuilder.getText(EmailConfiguration.getProperty("MATERIAL_EXCHANGE_ALBPM_ERROR_MESSAGE"), emailParameterMap));

        return emailMessage;
    }


    private Map<String, String> buildEmailParameterMap(Long materialRequestDetailId) throws MaterialExchangeException {

        Map<String, String> emailParameterMap = new HashMap<String, String>();
        emailParameterMap.put("APPLICATION_NAME", "InventoryService");
        emailParameterMap.put("MATERIAL_REQUEST_DETAIL_ID", materialRequestDetailId.toString());
        emailParameterMap.put("MATERIAL_REQUEST_ID", getMaterialRequestId(materialRequestDetailId).toString());
        emailParameterMap.put("ENVIRONMENT", EnvironmentUtil.lsiFunction());
        emailParameterMap.put("BPM_URL", EmailConfiguration.getProperty("BPM_URL", EnvironmentUtil.lsiFunction()));

        return emailParameterMap;
    }

    private Long getMaterialRequestId(Long materialRequestDetailId) throws MaterialExchangeException {

        try {
            return materialRequestDetailDao.getMaterialRequestIdForDetailId(materialRequestDetailId);
        } catch( QueryResultsException e ) {
            throw new MaterialExchangeException(e.getMessage(), e);
        }
    }

    protected String getSubjectText(Map<String, String> emailParameterMap) {

        String subjectTemplateText = EmailConfiguration.getProperty("MATERIAL_EXCHANGE_ALBPM_ERROR_SUBJECT");
        return emailBindUtil.bindParametersToString(subjectTemplateText, emailParameterMap);
    }

    public void setMaterialRequestDetailDao(MaterialRequestDetailDao materialRequestDetailDao) {
        this.materialRequestDetailDao = materialRequestDetailDao;
    }

    public void setEmailSenderFactory(EmailSenderFactory emailSenderFactory) {
        this.emailSenderFactory = emailSenderFactory;
    }

    public void setEmailBuilder(EmailBuilder emailBuilder) {
        this.emailBuilder = emailBuilder;
    }

    public void setEmailBindUtil(EmailBindUtil emailBindUtil) {
        this.emailBindUtil = emailBindUtil;
    }
}
