package com.monsanto.tcc.inventoryservice.containermanagement.select;

import com.monsanto.tcc.inventorycommon.domain.StorageLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Mar 9, 2010
 * Time: 2:17:45 PM
 * To change this template use File | Settings | File Templates.
 */
public class LocationsBySubSubSiteRetriever extends AbstractStorageLocationAndContainerRetriever {
    @Override
    public Collection<StorageUnitTO> retrieve(Long parentSubSubSiteId) {
        Collection<StorageLocation> storageLocations = getManageContainersDaoProvider().getStorageLocationDao().getStorageLocationsBySubSubSiteId(parentSubSubSiteId);
        return buildObjects(storageLocations, StorageUnitTO.class);
    }
}
