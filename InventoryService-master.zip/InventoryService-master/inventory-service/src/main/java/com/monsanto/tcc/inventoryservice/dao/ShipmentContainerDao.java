package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.ShipmentContainer;
import com.monsanto.tps.dao.GenericDao;


public interface ShipmentContainerDao extends GenericDao<ShipmentContainer, Long> {
}
