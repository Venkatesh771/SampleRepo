package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.AlternateInventory;
import com.monsanto.tcc.inventoryservice.dao.AlternateInventoryDao;
import com.monsanto.tps.dao.GenericDaoImpl;

/**
 * Created by IntelliJ IDEA.
 * User: vkdasy
 * Date: Sep 2, 2010
 * Time: 7:15:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class AlternateInventoryDaoImpl extends GenericDaoImpl<AlternateInventory, Long> implements AlternateInventoryDao {
    public AlternateInventoryDaoImpl(Class entityClass) {
        super(entityClass);
    }
}
