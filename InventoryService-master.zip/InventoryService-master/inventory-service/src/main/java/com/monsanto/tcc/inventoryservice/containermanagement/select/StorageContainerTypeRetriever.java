package com.monsanto.tcc.inventoryservice.containermanagement.select;

import com.monsanto.tcc.inventorycommon.domain.StorageContainerType;
import com.monsanto.tcc.inventorycommon.domain.StorageUnitTypeTO;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 17, 2010
 * Time: 9:15:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class StorageContainerTypeRetriever extends AbstractStorageTypesRetriever {

    @Override
    protected Collection<StorageUnitTypeTO> build() {
        List<StorageContainerType> containerTypeList = getManageContainersDaoProvider().getStorageContainerTypeDao().loadAll();
        return buildObjects(containerTypeList, StorageUnitTypeTO.class);
    }
}
