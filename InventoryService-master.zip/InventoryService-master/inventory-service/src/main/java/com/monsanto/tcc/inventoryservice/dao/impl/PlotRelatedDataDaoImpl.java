/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.PlotRelatedDTO;
import com.monsanto.tcc.inventoryservice.dao.PlotRelatedDataDao;
import org.hibernate.SQLQuery;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;

import java.util.List;

/**
 * @author RJKENN
 */

public class PlotRelatedDataDaoImpl extends DynamicGroupBaseDao implements PlotRelatedDataDao {

    private static final String FILE_NAME = "com/monsanto/tcc/inventoryservice/inventory/filter/sql/GetInventoryPlotRelatedData.sql";
    private static final Class TRANSFORMER = PlotRelatedDTO.class;

    @Override
    public List<PlotRelatedDTO> getPlotRelatedDTOs(List<Long> inventoryIds){
        return getData(inventoryIds);
    }

    @Override
    protected String getFilename() {
        return FILE_NAME;
    }

    @Override
    protected Class getTransformerClass() {
        return TRANSFORMER;
    }

    @Override
    protected void addScalars(SQLQuery query) {
        query.addScalar("inventoryId", new LongType())
            .addScalar("femalePlotId", new LongType())
            .addScalar("femaleAbsoluteColumn", new IntegerType())
            .addScalar("femaleAbsoluteRange", new IntegerType())
            .addScalar("femaleSubRowDisplayOrder", new IntegerType())
            .addScalar("femaleSubSubRowDisplayOrder", new IntegerType())
            .addScalar("femalePlotType", new IntegerType())
            .addScalar("operationName", new StringType())
            .addScalar("maleBarcode", new StringType())
            .addScalar("malePlotId", new LongType())
            .addScalar("maleSubRowDisplayOrder", new IntegerType())
            .addScalar("maleSubSubRowDisplayOrder", new IntegerType())
            .addScalar("malePlotType", new IntegerType())
            .addScalar("malePlotInventoryId", new LongType())
            .addScalar("maleBrFieldName", new StringType())
            .addScalar("maleSeasonName", new StringType())
            .addScalar("malePedigree", new StringType())
            .addScalar("maleLineFunctionName", new StringType())
            .addScalar("maleBufferProgramRefId", new StringType())
            .addScalar("maleNonBufferProgramRefId", new StringType());
    }
}