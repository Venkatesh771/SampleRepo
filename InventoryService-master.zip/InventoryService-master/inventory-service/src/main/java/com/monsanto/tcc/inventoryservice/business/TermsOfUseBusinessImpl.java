package com.monsanto.tcc.inventoryservice.business;

import com.google.common.collect.Sets;
import com.monsanto.tcc.inventorycommon.domain.GeneticMaterial;
import com.monsanto.tcc.inventoryservice.annotations.Business;
import com.monsanto.tcc.inventoryservice.dao.GeneticMaterialDao;
import com.monsanto.tcc.inventoryservice.dao.TermsOfUseDao;
import com.monsanto.tcc.inventoryservice.domain.GeneticMaterialTermsOfUseEntity;
import com.monsanto.tcc.inventoryservice.domain.TermsOfUseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * User: DCENGL
 */
@Business
public class TermsOfUseBusinessImpl implements TermsOfUseBusiness {

    @Autowired
    private TermsOfUseDao termsOfUseDao;

    @Resource
    private GeneticMaterialDao geneticMaterialDao;


    @Override
    public List<TermsOfUseEntity> getTermsOfUse(Long geneticMaterialId) {
        return termsOfUseDao.findTermsOfUse(geneticMaterialId);
    }

    @Override
    public void save(Long termsOfUseId, Long geneticMaterialId, String terms, Boolean restricted, String modifiedBy) {
        TermsOfUseEntity termsOfUseEntity;

        if (termsOfUseId != null) {
            termsOfUseEntity = termsOfUseDao.load(termsOfUseId);
        } else {
            termsOfUseEntity = new TermsOfUseEntity();
            GeneticMaterial originalGeneticMaterial = geneticMaterialDao.get(geneticMaterialId);
            termsOfUseEntity.setOriginalGeneticMaterial(originalGeneticMaterial);

            GeneticMaterialTermsOfUseEntity geneticMaterialTermsOfUseEntity = new GeneticMaterialTermsOfUseEntity();
            geneticMaterialTermsOfUseEntity.setGeneticMaterial(originalGeneticMaterial);
            geneticMaterialTermsOfUseEntity.setTermsOfUse(termsOfUseEntity);
            geneticMaterialTermsOfUseEntity.setModifiedDate(new Date());
            geneticMaterialTermsOfUseEntity.setModifiedBy(modifiedBy);

            termsOfUseEntity.setGeneticMaterialTermsOfUseEntities(Sets.newHashSet(geneticMaterialTermsOfUseEntity));
        }

        termsOfUseEntity.setRestricted(restricted);
        termsOfUseEntity.setTerms(!StringUtils.hasText(terms) ? " " : terms);
        termsOfUseEntity.setModifiedBy(modifiedBy);
        termsOfUseEntity.setModifiedDate(new Date());

        termsOfUseDao.save(termsOfUseEntity);
    }
}
