/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao.impl;

import com.google.common.base.Preconditions;
import com.monsanto.tcc.inventorycommon.domain.TempSessionOcd;
import com.monsanto.tcc.inventorycommon.domain.TempSessionOcdId;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;

/* nbwald - Nov 12, 2010 */
public class TempSessionDao {
    public static final String INSERT_SQL = "insert into midas.temp_session_ocd (request_id, number_1) values(:sessionId, :number1)";
    private SessionFactory sessionFactory;
    private JdbcTemplate jdbcTemplate;

    public void insertLongs(TempSessionRequest tempSessionRequest, Collection<Long> values) {
        insert(tempSessionRequest, values, new Number1Setter());
    }

    public void insertStrings(TempSessionRequest tempSessionRequest, Collection<String> values) {
        insert(tempSessionRequest, values, new Text1Setter());
    }

    public void insertLongsInBatch(final int sessionId, final Collection<Long> values) {
        Preconditions.checkNotNull(values);
        final Iterator<Long> iterator = values.iterator();
        jdbcTemplate.batchUpdate(INSERT_SQL, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                ps.setInt(1, sessionId);
                ps.setLong(2, iterator.next());
            }

            @Override
            public int getBatchSize() {
                return values.size();
            }
        });
    }

    private <T> void insert(TempSessionRequest tempSessionRequest, Collection<T> values, TempSessionValueSetter<T> tempSessionSetter) {
        if (values == null) {
            return;
        }
        Session session = sessionFactory.getCurrentSession();
        long sortOrder = 0;
        for (T value : values) {
            TempSessionOcd ocd = new TempSessionOcd();
            TempSessionOcdId tempSessionOcdId = new TempSessionOcdId();
            tempSessionOcdId.setRequestId(tempSessionRequest.getRequestId());
            tempSessionSetter.setValue(tempSessionOcdId, value);
            tempSessionOcdId.setSortOrder(sortOrder++);
            ocd.setId(tempSessionOcdId);
            session.save(ocd);
        }
        session.flush();
    }

    private interface TempSessionValueSetter<T> {
        void setValue(TempSessionOcdId tempSessionOcdId, T value);
    }

    private class Text1Setter
            implements TempSessionValueSetter<String> {
        @Override
        public void setValue(TempSessionOcdId tempSessionOcdId, String value) {
            tempSessionOcdId.setText1(value);
        }
    }

    private class Number1Setter
            implements TempSessionValueSetter<Long> {
        @Override
        public void setValue(TempSessionOcdId tempSessionOcdId, Long value) {
            tempSessionOcdId.setNumber1(value);
        }
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
}