package com.monsanto.tcc.inventoryservice.dao;


/**
 * Created by FFAN on 8/8/14.
 */
public interface ShipmentTypeDao {

    Long findByName(String shipmentTypeName);
}
