package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.StorageLocation;
import com.monsanto.tcc.inventoryservice.inventorycontainer.StorageContainerDnml;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 3, 2010
 * Time: 6:41:35 AM
 * To change this template use File | Settings | File Templates.
 */
public interface StorageLocationDao extends GenericDao<StorageLocation, Long> {
    @DynamicDaoMethod(queryName = "StorageLocationDao.getStorageLocationsBySubSubSiteId", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<StorageLocation> getStorageLocationsBySubSubSiteId(@DynamicDaoParameter(name = "parentSubSubSiteId") Long storageLocationId);

    public Collection<Long> getStorageLocationsWithInventoryAssigned(Collection<Long> parentStorageLocationIds);

    @DynamicDaoMethod(queryName = "StorageLocation.getNextBarcode", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public String getNextBarcode();

    public String getSiteSubSiteSubSubSiteNames(Long parentSubSubSiteId);

    public void deleteStorageLocations(Collection<Long> storageLocationIds);

    @DynamicDaoMethod(queryName = "StorageLocationDao.getStorageLocationByBarcode", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public StorageLocation getStorageLocationByBarcode(@DynamicDaoParameter(name = "storageLocationBarcode") String storageLocationBarcode);

    List<StorageContainerDnml> deeplyFindStorageContainersWithInventories(long storageLocationId);
}
