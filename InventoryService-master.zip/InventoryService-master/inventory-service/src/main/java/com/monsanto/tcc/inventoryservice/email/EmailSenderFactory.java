package com.monsanto.tcc.inventoryservice.email;

import com.monsanto.tcc.inventorycommon.service.email.EmailSender;
import com.monsanto.tcc.inventoryservice.util.EnvironmentUtil;
import org.apache.log4j.Logger;

public class EmailSenderFactory {

    private static final String PRODUCTION_LOG_MESSAGE = "USING PROD SENDER FOR EMAILS!!!  EMAILS ARE GOING TO USERS!!!";
    private static final String NON_PRODUCTION_LOG_MESSAGE = "USING NON PROD SENDER FOR EMAILS!!!";
    private static final Logger LOGGER = Logger.getLogger(EmailSenderFactory.class);

    private EmailSender prodEmailSender;
    private EmailSender nonProdEmailSender;
    private EmailSender developerEmailSender;

    public void setProdEmailSender(EmailSender prodEmailSender) {
        this.prodEmailSender = prodEmailSender;
    }

    public void setNonProdEmailSender(EmailSender nonProdEmailSender) {
        this.nonProdEmailSender = nonProdEmailSender;
    }

    public void setDeveloperEmailSender(EmailSender developerEmailSender) {
        this.developerEmailSender = developerEmailSender;
    }

    public EmailSender createForEnvironment() {
        logIntroMessage();
        EmailSender result = determineWhichEmailSenderToUse();
        logAlertMessage(result);
        return result;
    }

    private void logIntroMessage() {
        LOGGER.info("LSI Function for email sender factory is: " +
                    EnvironmentUtil.lsiFunction() +
                    " and value of the isProduction call is: " +
                    EnvironmentUtil.isProduction());
    }

    private EmailSender determineWhichEmailSenderToUse() {
        return (!EnvironmentUtil.isProduction()) ? getNonProductionEmailSender() : prodEmailSender;
    }

    private EmailSender getNonProductionEmailSender() {
        return (EnvironmentUtil.isLocalDevMachine() || EnvironmentUtil.isDev()) ? developerEmailSender : nonProdEmailSender ;
    }

    private void logAlertMessage(EmailSender result) {
        String logMessage = (result == prodEmailSender) ? PRODUCTION_LOG_MESSAGE : NON_PRODUCTION_LOG_MESSAGE;
        LOGGER.info(logMessage);
    }

}
