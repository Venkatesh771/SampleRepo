package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.services.domain.breeding.FateReason;
import com.monsanto.tcc.inventorycommon.domain.EventConstruct;
import com.monsanto.tcc.inventorycommon.domain.Inventory;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tcc.inventorycommon.transferobject.BlendSummary;
import com.monsanto.tcc.inventorycommon.transferobject.FatedInventory;
import com.monsanto.tcc.inventorycommon.transferobject.InventoryProgramAccount;
import com.monsanto.tcc.inventoryservice.dao.impl.TempSessionRequest;
import com.monsanto.tcc.inventoryservice.importing.ImportBarcodeRow;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 16, 2009
 * Time: 9:59:05 AM
 */
public interface InventoryDao extends GenericDao<Inventory, Long> {
    public List<Inventory> getInventoryByPedigreeAndProg(String pedigree, String prog);

    public Inventory getInventoryByBarcode(String barcode) throws QueryResultsException;

    List<InventoryProgramAccount> findInventoryProgramAccountIdFromBracode(List<String> barcodes);

    public List<Inventory> getInventoriesByIds(List<Long> inventoryIds);

    public void bulkUpdateInventoryPreviewStatus(int sessionId);

    List<Inventory> findInventoryByBarcodes(Collection<String> barcodes);

    List<String> getInventoryBarcodesThatAreAlreadyAssignedToPlotsOrEntries(List<Long> inventoryIdList);

    List<ImportBarcodeRow> findInventoryLinkedToDifferentStorageContainer();

    @DynamicDaoMethod(queryName = "Inventory.getInventoryForProductNamePubKey",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<Inventory> getInventoryForProductNamePubKey(@DynamicDaoParameter(name = "lexProdNamePubKey") String oldProductNamePubKey);

    @DynamicDaoMethod(queryName = "Inventory.getHydratedInventoriesById",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public Collection<Inventory> getHydratedInventoriesById(@DynamicDaoParameter(name = "inventoryIds") Collection<Long> inventoryIds);

    @DynamicDaoMethod(queryName = "getInventoriesMatchingProgramAndPedigreeByInventoryId",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<Inventory> getInventoriesMatchingProgramAndPedigreeByInventoryId(@DynamicDaoParameter(name = "sourceInventoryId") Long inventoryId);

    @DynamicDaoMethod(queryName = "Inventory.getActiveEventConstructs",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<EventConstruct> getActiveEventConstructs(@DynamicDaoParameter(name = "inventoryId") Long inventoryId);

    @DynamicDaoMethod(queryName = "InventoryDao.getNewestInventoryFromProductId",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public Inventory getNewestInventoryFromProductId(@DynamicDaoParameter(name = "id") Long productId);

    @DynamicDaoMethod(queryName = "InventoryDao.retrieveBlendedSummaryFromInventoryBarcode",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public BlendSummary retrieveBlendedSummaryFromInventoryBarcode(@DynamicDaoParameter(name = "barcode") String barcode);


    @DynamicDaoMethod(queryName = "getPagedPendingDestructionInventoriesForPrograms",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<Inventory> getPagedPendingDestructionInventoriesForPrograms(@DynamicDaoParameter(name = "programIds") Collection<Long> programIds,
                                                                            @DynamicDaoParameter(name = "startIndex") int startIndex,
                                                                            @DynamicDaoParameter(name = "pageSize") int pageSize);

    @DynamicDaoMethod(queryName = "InventoryDao.getNextId",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public BigDecimal getNextId();

    List<String> getPotentialTesters(Long inventoryId);

    Collection<Inventory> getInventoriesByStorageContainerBarcodes(Collection<String> storageContainerBarcodes);

    Collection<Inventory> getInventoriesByStorageContainerBarcode(String storageContainerBarcode);

    void updateInventoryDnml(long storageContainerId, String newDnml);

    void clearInventoryDnml(Collection<Long> inventoryIds);

    void clearBarcodeAndSetDnml(String dnml, TempSessionRequest tempSessionRequest);

    @DynamicDaoMethod(queryName = "InventoryDao.loadInventoryRecordForEventRemoval", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    Inventory loadInventoryRecordForEventRemoval(@DynamicDaoParameter(name = "INVENTORY_ID") Long inventoryId);

    void fateAndEmptyInventory(Collection<Long> inventoryIds, FateReason fateReason);

    void clearInventoryQuantityAndUom(Collection<Long> inventoryIds);

    void updateDiscardedInventoryAndResetQuantity(String dnml, List<FatedInventory> fatedInventories);

    void updateDiscardedInventoryWithoutQuantityChange(String dnml, List<FatedInventory> fatedInventories);

    void undoDiscardedInventoryAndSetQuantity(String dnml, TempSessionRequest tempSessionRequest, Double seedQuantity);

    void undoDiscardedInventory(String dnml, TempSessionRequest tempSessionRequest);

    public List<String> getInventoriesAssociatedWithPendingShipment(TempSessionRequest tempSessionRequest);

    public void accept(List<Long> inventoryIds, TempSessionRequest tempSessionRequest, String modifiedUserName, Date modifiedDate);

    public void reject(long inventoryId, Long rejectionReasonId, String modifiedUserName, Date modifiedDate);

    public void undoReject(List<Long> inventoryIds, TempSessionRequest tempSessionRequest, String modifiedUserName, Date modifiedDate);

    public void undoRejectAndAccept(List<Long> inventoryIds, TempSessionRequest tempSessionRequest, String modifiedUserName, Date modifiedDate);

    public List<String> findInventoryInPendingPedFixByBarcode(List<String> inventoryBarcodes);

    public boolean isProgramNeedsToBeSynced(List programList);

    public void updateToBeDestroyedFlag(List<Long> inventoryIds);
}
