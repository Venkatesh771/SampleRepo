/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.containermanagement.move;

import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;
import com.monsanto.tcc.inventorycommon.transferobject.StorageType;
import com.monsanto.tcc.inventoryservice.dao.StorageContainerDao;

import java.util.Collection;

public class ContainerToContainerMovementStrategy
    implements StorageUnitMovementStrategy
{
    private StorageContainerDao storageContainerDao;
    private ContainerToContainerMovement containerToContainerMovement;
    private ContainersIntoContainerMovement containersIntoContainerMovement;

    @Override
    public boolean isApplicableTo(StorageUnitTO moved, StorageUnitTO to) {
        return isType(moved, StorageType.STORAGE_CONTAINER) && isType(to, StorageType.STORAGE_CONTAINER);
    }

    @Override
    public void move(StorageUnitTO moved, StorageUnitTO to) {
        containerToContainerMovement.move(getContainerByBarcode(moved.getBarcode()), getContainerByBarcode(to.getBarcode()));
    }

    public void batchMove(Collection<String> barcodesToMove, String destinationBarcode) {
        Collection<StorageContainer> storageContainersToMove = storageContainerDao.getStorageContainersByBarcodes(barcodesToMove);
        containersIntoContainerMovement.move(storageContainersToMove, getContainerByBarcode(destinationBarcode));
    }

    private StorageContainer getContainerByBarcode(String barcode) {
        return storageContainerDao.getStorageContainerByBarcode(barcode);
    }

    private boolean isType(StorageUnitTO storageUnit, StorageType storageType) {
        return storageType.equals(storageUnit.getStorageUnitType().getType());
    }

    public void setStorageContainerDao(StorageContainerDao storageContainerDao) {
        this.storageContainerDao = storageContainerDao;
    }

    public void setContainerToContainerMovement(ContainerToContainerMovement containerToContainerMovement) {
        this.containerToContainerMovement = containerToContainerMovement;
    }

    public void setContainersIntoContainerMovement(ContainersIntoContainerMovement containersIntoContainerMovement) {
        this.containersIntoContainerMovement = containersIntoContainerMovement;
    }
}