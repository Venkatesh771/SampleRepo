package com.monsanto.tcc.inventoryservice.containermanagement.search;

import com.google.common.collect.Lists;
import com.monsanto.Util.StringUtils;
import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventorycommon.domain.StorageLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageUnitSearchRequest;
import com.monsanto.tcc.inventorycommon.domain.StorageUnitSearchResponse;
import com.monsanto.tcc.inventorycommon.transferobject.ResponseMessage;
import com.monsanto.tcc.inventorycommon.transferobject.ResponseMessageType;
import com.monsanto.tcc.inventoryservice.containermanagement.StorageLocationCollaborator;
import com.monsanto.tcc.inventoryservice.dao.StorageContainerDao;
import com.monsanto.tcc.inventoryservice.dao.StorageLocationDao;
import com.monsanto.tcc.inventoryservice.transfer.StorageContainerSearchResponse;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Jun 10, 2010
 * Time: 11:09:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class StorageUnitSearchBO {

    private StorageContainerDao storageContainerDao;
    private StorageLocationDao storageLocationDao;
    private StorageLocationCollaborator storageLocationCollaborator;
    public static final String SEARCH_CAN_T_BE_PERFORMED_WITH_EMPTY_OR_NULL_BARCODE = "Search can't be performed with empty or null barcode";
    public static final String STORAGE_UNIT_FOUND = "Storage unit found";
    public static final String STORAGE_UNIT_NOT_FOUND_FOR_THE_GIVEN_BARCODE = "Storage unit not found for the given barcode ";


    public StorageUnitSearchResponse search(StorageUnitSearchRequest storageUnitSearchRequest) {
        StorageUnitSearchResponse response = new StorageUnitSearchResponse();
        ResponseMessage responseMessage = new ResponseMessage();
        response.setResponseMessage(responseMessage);
        if (!StringUtils.isNullOrEmpty(storageUnitSearchRequest.getBarcode())) {
            StorageContainer storageContainerByBarcode = getStorageContainerDao().getStorageContainerByBarcode(storageUnitSearchRequest.getBarcode());
            String storageUnitLocationPath = getStorageUnitPath(storageUnitSearchRequest, storageContainerByBarcode);
            prepareResponse(response, storageUnitLocationPath, storageUnitSearchRequest.getBarcode());
        } else {
            responseMessage.setResponseType(ResponseMessageType.ERROR);
            responseMessage.setMessage(SEARCH_CAN_T_BE_PERFORMED_WITH_EMPTY_OR_NULL_BARCODE);
        }

        return response;
    }

    public StorageContainerSearchResponse getStorageUnitDetails(String barcode) {
        StorageContainer storageContainer = storageContainerDao.getStorageContainerByBarcode(barcode);
        return buildResponseFromStorageContainer(barcode, storageContainer);
    }

    public List<StorageContainerSearchResponse> getStorageUnitDetails(Collection<String> barcodes) {
        List<StorageContainerSearchResponse> responses = Lists.newArrayList();
        List<String> foundBarcodes = Lists.newArrayList();
        addResponcesForBarcodes(barcodes, responses, foundBarcodes);
        addResponcesForBarcodesNotFound(barcodes, responses, foundBarcodes);
        return responses;
    }

    private void addResponcesForBarcodes(Collection<String> barcodes, List<StorageContainerSearchResponse> responses,
                                         List<String> foundBarcodes) {
        Collection<StorageContainer> storageContainers = storageContainerDao.getStorageContainersByBarcodes(barcodes);
        for(StorageContainer storageContainer : storageContainers){
            try{
                responses.add(buildResponseFromStorageContainer(storageContainer.getBarcode(), storageContainer));
                foundBarcodes.add(storageContainer.getBarcode());
            }catch (RuntimeException e){
            }
        }
    }

    private StorageContainerSearchResponse buildResponseFromStorageContainer(String barcode,
                                                                             StorageContainer storageContainer) {
        StorageContainerSearchResponse response = new StorageContainerSearchResponse();
        throwExceptionIfNull(storageContainer);
        response.setBarcode(barcode);
        response.setStorageContainerType(storageContainer.getStorageContainerType().getName());
        response.setNumberOfInventories(null != storageContainer.getInventoryContainers() ? storageContainer.getInventoryContainers().size() : 0);
        response.setNumberOfChildContainers(null != storageContainer.getStorageContainersByStorageContainerId() ? storageContainer.getStorageContainersByStorageContainerId().size() : 0);
        response.setLocation(storageLocationCollaborator.deriveStorageContainerDNML(storageContainer));
        return response;
    }

    private void addResponcesForBarcodesNotFound(Collection<String> barcodes,
                                                 List<StorageContainerSearchResponse> responses,
                                                 List<String> foundBarcodes) {
        for(String barcode : barcodes){
            if(!foundBarcodes.contains(barcode)){
                StorageContainerSearchResponse storageContainer = new StorageContainerSearchResponse();
                storageContainer.setBarcode(barcode);
                storageContainer.setNumberOfChildContainers(0);
                storageContainer.setNumberOfInventories(0);
                storageContainer.setStorageContainerType("NOT FOUND");
                storageContainer.setLocation("Storage Container Not Found");
                responses.add(storageContainer);
            }
        }
    }

    private void throwExceptionIfNull(StorageContainer storageContainer) {
        if (null == storageContainer) {
            throw new RuntimeException("No storage container exists for given barcode");
        }
    }

    private String getStorageUnitPath(StorageUnitSearchRequest storageUnitSearchRequest, StorageContainer storageContainerByBarcode) {
        String storageUnitLocationPath = null;
        if (storageContainerByBarcode != null) {
            storageUnitLocationPath = getStorageLocationCollaborator().deriveStorageContainerDNML(storageContainerByBarcode);
        } else {
            StorageLocation storageLocationByBarcode = getStorageLocationDao().getStorageLocationByBarcode(storageUnitSearchRequest.getBarcode());
            if (storageLocationByBarcode != null) {
                storageUnitLocationPath = getStorageLocationCollaborator().deriveStorageLocationPath(storageLocationByBarcode);
            }
        }
        return storageUnitLocationPath;
    }


    private void prepareResponse(StorageUnitSearchResponse response, String storageUnitLocationPath, String barcode) {
        if (!StringUtils.isNullOrEmpty(storageUnitLocationPath)) {
            response.getResponseMessage().setResponseType(ResponseMessageType.SUCCESS);
            response.getResponseMessage().setMessage(STORAGE_UNIT_FOUND);
            response.setStorageUnitPath(storageUnitLocationPath);
        } else {
            response.getResponseMessage().setResponseType(ResponseMessageType.ERROR);
            response.getResponseMessage().setMessage(STORAGE_UNIT_NOT_FOUND_FOR_THE_GIVEN_BARCODE + barcode);
        }
    }

    public StorageContainerDao getStorageContainerDao() {
        return storageContainerDao;
    }

    public void setStorageContainerDao(StorageContainerDao storageContainerDao) {
        this.storageContainerDao = storageContainerDao;
    }

    public StorageLocationDao getStorageLocationDao() {
        return storageLocationDao;
    }

    public void setStorageLocationDao(StorageLocationDao storageLocationDao) {
        this.storageLocationDao = storageLocationDao;
    }

    public StorageLocationCollaborator getStorageLocationCollaborator() {
        return storageLocationCollaborator;
    }

    public void setStorageLocationCollaborator(StorageLocationCollaborator storageLocationCollaborator) {
        this.storageLocationCollaborator = storageLocationCollaborator;
    }
}
