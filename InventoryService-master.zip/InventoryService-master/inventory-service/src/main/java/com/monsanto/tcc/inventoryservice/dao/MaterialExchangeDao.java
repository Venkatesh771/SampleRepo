package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.MaterialExchange;
import com.monsanto.tps.dao.GenericDao;

public interface MaterialExchangeDao extends GenericDao<MaterialExchange, Long> {
}