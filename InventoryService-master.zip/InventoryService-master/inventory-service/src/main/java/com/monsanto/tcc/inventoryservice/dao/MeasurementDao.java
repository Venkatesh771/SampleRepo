package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.Measurement;
import com.monsanto.tps.dao.GenericDao;

public interface MeasurementDao extends GenericDao<Measurement, Long> {
}
