/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.containermanagement.move;

import com.monsanto.tcc.inventorycommon.domain.StorageLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;
import com.monsanto.tcc.inventoryservice.containermanagement.StorageLocationCollaborator;
import com.monsanto.tcc.inventoryservice.dao.StorageLocationDao;
import com.monsanto.tcc.inventoryservice.inventorycontainer.StorageContainerDnml;

import java.util.List;

/* nbwald - Nov 2, 2010 */
public class LocationToSubSubSiteMovement
{
    private StorageLocationDao storageLocationDao;
    private StorageLocationCollaborator storageLocationCollaborator;
    private PostMoveDnmlUpdate postMoveDnmlUpdate;

    public void move(StorageLocation storageLocation, StorageUnitTO subSubSite) {
        storageLocation.setSubSubSiteId(subSubSite.getId());
        updateInventoryDnml(storageLocation);
    }

    private void updateInventoryDnml(StorageLocation storageLocation) {
        String dnmlPrefix = storageLocationCollaborator.deriveStorageLocationPath(storageLocation);
        List<StorageContainerDnml> containerDnmls = storageLocationDao.deeplyFindStorageContainersWithInventories(storageLocation.getStorageLocationId());
        postMoveDnmlUpdate.update(dnmlPrefix, containerDnmls);
    }

    public void setStorageLocationDao(StorageLocationDao storageLocationDao) {
        this.storageLocationDao = storageLocationDao;
    }

    public void setPostMoveDnmlUpdate(PostMoveDnmlUpdate postMoveDnmlUpdate) {
        this.postMoveDnmlUpdate = postMoveDnmlUpdate;
    }

    public void setStorageLocationCollaborator(StorageLocationCollaborator storageLocationCollaborator) {
        this.storageLocationCollaborator = storageLocationCollaborator;
    }
}