package com.monsanto.tcc.inventoryservice.dao;


import com.monsanto.tcc.inventorycommon.domain.Brand;
import com.monsanto.tps.dao.GenericDao;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 12, 2009
 * Time: 2:18:29 PM
 */
public interface BrandDao extends GenericDao<Brand, Long> {
}
