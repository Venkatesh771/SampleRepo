package com.monsanto.tcc.inventoryservice.containermanagement.select;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Mar 9, 2010
 * Time: 2:10:47 PM
 * To change this template use File | Settings | File Templates.
 */
public abstract class AbstractStorageLocationAndContainerRetriever extends AbstractStorageUnitDataRetriever {

    public abstract Collection<StorageUnitTO> retrieve(Long parentId);

}
