package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.services.domain.common.filter.Filter;
import com.monsanto.tcc.inventorycommon.domain.MaterialRequest;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.DynamicFilterDaoMethod;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 24, 2009
 * Time: 11:09:37 AM
 */
public interface MaterialRequestDao extends GenericDao<MaterialRequest, Long> {
    public List<MaterialRequest> getMaterialRequestsByProviderProgram(String providerProgRefId, List<String> materialReqIds);

    public List<MaterialRequest> getAllMaterialRequestsForProgram(Long progId);

    public List<MaterialRequest> getAllRequestsForProviderProgramsMatchedToTempSession(Collection<Long> programIds, int tempSessionId);

    public Long getNextUniqueRequestIdNbr();

    @DynamicFilterDaoMethod(filterName = "materialExchangeHistoryFilter")
    Collection<MaterialRequest> retrieveMaterialRequestHistory(Filter[] filter);

    @DynamicDaoMethod(queryName = "MaterialRequest.getAvailableYearsInRequestHistory", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    Collection<Integer> getAvailableYearsInRequestHistory(@DynamicDaoParameter(name = "requestorProgIds") Collection<Long> programIds);

    // utilities, can be removed if desired
    public List<MaterialRequest> getMaterialRequestsByProviderProgramListInStatus(Collection<Long> programIds, String materialRequestStatusName);

    public List<MaterialRequest> getMaterialRequestsByProviderProgramListInProcessedStatus(Collection<Long> programIds);

    public List<MaterialRequest> getMaterialRequestsForProviderProgramByDetailId(Collection<Long> materialRequestDetailIds, Collection<Long> programIds);
}
