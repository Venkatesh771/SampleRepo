package com.monsanto.tcc.inventoryservice.dao;

public interface GermplasmDao {

    void updateGermplasmCrossName(Long germplasmId, String crossName);

}
