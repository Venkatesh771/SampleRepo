/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.email;

import com.monsanto.tcc.inventorycommon.domain.email.EmailConfiguration;
import com.monsanto.tcc.inventorycommon.domain.email.EmailMessage;

import java.util.ArrayList;
import java.util.List;

/**
 * User: jjbens2
 * Date: Jun 2, 2010
 */
public class DeveloperEmailSender extends NonProdEmailSender {



    
    /**
     * Replaces the To: list with just the developer distribution list email
     * 
     * @see email-configuration.xml
     *
     * @param currentAddresses existing list of email addresses for this message
     * @return modified list of email addresses for this message
     */
    @Override
    protected List<String> buildAdjustedToList(List<String> currentAddresses) {
        List<String> adjustedToList = new ArrayList<String>();
        adjustedToList.add(EmailConfiguration.getProperty("DEVELOPER_DISTRIBUTION_LIST"));
        return adjustedToList;
    }

    @Override
    protected String buildModifiedBody(EmailMessage emailMessage) {

        StringBuilder bodyBuilder = new StringBuilder(emailMessage.getBody());
        bodyBuilder.append("\n\n");
        bodyBuilder.append("Original Email address list:\n");
        for (String address : emailMessage.getToAddresses()) {
            bodyBuilder.append(address + "\n");
        }
        return bodyBuilder.toString();
    }
}
