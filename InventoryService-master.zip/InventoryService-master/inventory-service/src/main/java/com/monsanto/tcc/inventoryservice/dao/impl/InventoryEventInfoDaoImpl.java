/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.transferobject.InventoryEventInfo;
import com.monsanto.tcc.inventoryservice.dao.InventoryEventInfoDao;
import org.hibernate.SQLQuery;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author srpras
 * @version $Revision$
 */
public class InventoryEventInfoDaoImpl extends DynamicGroupBaseDao implements InventoryEventInfoDao {

    private static final String FILE_NAME = "com/monsanto/tcc/inventoryservice/inventory/filter/sql/GetInventoryEventInfo.sql";
    private static final Class TRANSFORMER = InventoryEventInfo.class;

  @Override
    public List<InventoryEventInfo> getInventoryEventInfo(List<Long> inventoryIds){
        return getData(inventoryIds);
    }

  @Override
  protected String getFilename() {
    return FILE_NAME;
  }

  @Override
  protected Class getTransformerClass() {
    return TRANSFORMER;
  }

  @Override
  protected void addScalars(SQLQuery query) {
    query.addScalar("inventoryId", new LongType())
         .addScalar("allEventNames", new StringType())
         .addScalar("removedEventNames", new StringType())
         .addScalar("toBeRemovedEventNames", new StringType())
         .addScalar("allConstructNames", new StringType())
         .addScalar("removedConstructNames", new StringType())
         .addScalar("toBeRemovedConstructNames", new StringType());
  }

}