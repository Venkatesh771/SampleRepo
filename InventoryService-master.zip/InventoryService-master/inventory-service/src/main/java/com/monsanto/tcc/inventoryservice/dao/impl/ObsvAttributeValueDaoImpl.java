package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.ObsvAttributeValue;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tcc.inventoryservice.dao.ObsvAttributeValueDao;
import com.monsanto.tcc.pipeline.database.temptable.InsertIntoTempDbAdapter;
import com.monsanto.tps.dao.GenericNamedEntityDaoImpl;
import org.hibernate.Query;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Sep 21, 2009
 * Time: 12:55:04 PM
 */
public class ObsvAttributeValueDaoImpl extends GenericNamedEntityDaoImpl<ObsvAttributeValue, Long> implements ObsvAttributeValueDao {
    private static final String OBSV_VALUES_NAMED_QUERY = "getObsvAttributeValueJoinTempTable";
    private static final String ATTRIBUTE_REF_ID_PARAM = "attributeRefId";
    private static final String SESSION_ID_PARAM = "sessionId";

    public ObsvAttributeValueDaoImpl(String entityName) {
        super(entityName);
    }

    @Override
    public List<ObsvAttributeValue> getObsvAttributeValues(final List<String> inventoryBarcodes, final List<String> obsvAttributeRefIds) throws QueryResultsException {
        List<ObsvAttributeValue> obsvAttributeValues = new ArrayList();
        for (String attributeRefId : obsvAttributeRefIds) {
            Query query = getSessionFactory().getCurrentSession().getNamedQuery(OBSV_VALUES_NAMED_QUERY)
                    .setString(ATTRIBUTE_REF_ID_PARAM, attributeRefId)
                    .setInteger(SESSION_ID_PARAM, InsertIntoTempDbAdapter.TEMP_TABLE_REQ_ID);
            List<ObsvAttributeValue> results = query.list();
            obsvAttributeValues.addAll(results);
        }
        return obsvAttributeValues;
    }
}
