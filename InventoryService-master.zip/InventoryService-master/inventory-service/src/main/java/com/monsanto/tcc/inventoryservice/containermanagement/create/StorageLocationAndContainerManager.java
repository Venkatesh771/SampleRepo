package com.monsanto.tcc.inventoryservice.containermanagement.create;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 8, 2010
 * Time: 11:21:40 AM
 * To change this template use File | Settings | File Templates.
 */
public interface StorageLocationAndContainerManager {

    public Collection<StorageUnitTO> createOrModify(Collection<StorageUnitTO> storageUnitTransferObjects);

}
