package com.monsanto.tcc.inventoryservice.genericparameters;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

/**
 * User: Mark D. Sparks
 * Date: 8/16/11
 * Time: 8:39 AM
 */
@Entity
@GenericGenerator(name = "modifiedTimestampGenerator", strategy = "com.monsanto.tcc.inventoryservice.genericparameters.ModifiedTimestampGenerator")
@Table(name = "BO_RPT_PARAM_TEMP_STAGE", schema = "MIDAS")
public class GenericParameters implements Serializable {
    Long sessionId;
    Long number1;
    Long number2;
    String text1;
    String text2;
    Date date1;
    Date date2;
    Date modifiedTimestamp;

    @Id
    @Column(name = "SESSION_ID", nullable = false)
    public Long getSessionId() {
        return sessionId;
    }

    public void setSessionId(Long sessionId) {
        this.sessionId = sessionId;
    }

    @Id
    @Column(name = "NUMBER_1")
    public Long getNumber1() {
        return number1;
    }

    public void setNumber1(Long number1) {
        this.number1 = number1;
    }

    @Id
    @Column(name = "NUMBER_2")
    public Long getNumber2() {
        return number2;
    }

    public void setNumber2(Long number2) {
        this.number2 = number2;
    }

    @Id
    @Column(name = "TEXT_1")
    public String getText1() {
        return text1;
    }

    public void setText1(String text1) {
        this.text1 = text1;
    }

    @Id
    @Column(name = "TEXT_2")
    public String getText2() {
        return text2;
    }

    public void setText2(String text2) {
        this.text2 = text2;
    }

    @Id
    @Column(name = "DATE_1")
    public Date getDate1() {
        return date1;
    }

    public void setDate1(Date date1) {
        this.date1 = date1;
    }

    @Id
    @Column(name = "DATE_2")
    public Date getDate2() {
        return date2;
    }

    public void setDate2(Date date2) {
        this.date2 = date2;
    }

    @Column(name = "MODIFIED_TSP")
    @GeneratedValue(generator = "modifiedTimestampGenerator")
    @Id
    public Date getModifiedTimestamp() {
        return modifiedTimestamp;
    }

    public void setModifiedTimestamp(Date modifiedTimestamp) {
        this.modifiedTimestamp = modifiedTimestamp;
    }
}
