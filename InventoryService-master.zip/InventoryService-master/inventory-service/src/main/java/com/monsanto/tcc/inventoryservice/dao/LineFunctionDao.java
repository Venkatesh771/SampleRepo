package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.LineFunction;
import com.monsanto.tcc.inventoryservice.linefunctions.InventorySelectionAdvancement;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: DYSONA
 * Date: 4/23/12
 * Time: 7:45 AM
 */
public interface LineFunctionDao {

    @DynamicDaoMethod(queryName = "LineFunctionDao.getInventoryLineFunction",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    String  getInventoryLineFunction(@DynamicDaoParameter(name = "plotId")Long plotId);

    @DynamicDaoMethod(queryName = "LineFunctionDao.getInventorySelectionAdvancement",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    InventorySelectionAdvancement getInventorySelectionAdvancement(@DynamicDaoParameter(name = "inventoryId") Long inventoryId);

    @DynamicDaoMethod(queryName = "LineFunctionDao.getLineFunctions",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<LineFunction> getLineFunctions(@DynamicDaoParameter(name = "lineFunctionNames") List<String> lineFunctionNames);

    void updateLineFunction(Long inventoryId, String lineFunctionName);

}
