/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.services.domain.breeding.Program;
import com.monsanto.tcc.inventorycommon.domain.Inventory;
import com.monsanto.tcc.inventorycommon.domain.ProgramRole;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$     On:$Date$
 *
 * @author mbpenbe
 * @version $Revision$
 */
public interface ProgramRoleDao extends GenericDao<Inventory, Long> {

    @DynamicDaoMethod(queryName = "getRolesByProgram",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<ProgramRole> findRolesByProgram(@DynamicDaoParameter(name = "program") Program program);
}