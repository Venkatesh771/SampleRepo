package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventoryservice.importing.ImportBarcodeRow;
import com.monsanto.tcc.inventoryservice.inventorycontainer.StorageContainerDnml;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface StorageContainerDao extends GenericDao<StorageContainer, Long> {

    Collection<Long> getStorageContainersWithInventoryAssigned(Collection<Long> parentStorageContainerIds);

    void removeTopLevelEmptyStorageContainers(Collection<Long> topLevelStorageContainers);

    void removeStorageContainersUnderParentContainer(Collection<Long> storageContainerIdsToRemove);

    List<ImportBarcodeRow> getInvalidBarcodes();

    Map<String, StorageContainer> getBarcodeToStorageContainerMap();

    @DynamicDaoMethod(queryName = "StorageContainerDao.getStorageContainersByParentStorageContainerId",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<StorageContainer> getContainersByParentStorageContainerId(@DynamicDaoParameter(name = "parentStorageContainerId") Long parentStorageContainerId);

    @DynamicDaoMethod(queryName = "StorageContainerDao.getStorageContainersByStorageLocationId",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<StorageContainer> getStorageContainersByStorageLocationId(@DynamicDaoParameter(name = "parentStorageLocationId") Long storageLocationId);

    @DynamicDaoMethod(queryName = "StorageContainer.getNextBarcode",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    String getNextBarcode();

    @DynamicDaoMethod(queryName = "StorageContainer.getNextBarcodes",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<String> getNextBarcodes(@DynamicDaoParameter(name = "count") int count);

    @DynamicDaoMethod(queryName = "StorageContainerDao.getStorageContainerByBarcode",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    StorageContainer getStorageContainerByBarcode(@DynamicDaoParameter(name = "barcode") String barcode);

    @DynamicDaoMethod(queryName = "StorageContainerDao.getStorageContainersByBarcodes", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    Collection<StorageContainer> getStorageContainersByBarcodes(@DynamicDaoParameter(name = "barcodes") Collection<String> barcodes);

    List<StorageContainerDnml> deeplyFindStorageContainersWithInventories(long storageContainerId);

    void deleteStorageLocationCatalog(StorageContainer storageContainer);

    void updateContainersParent(long storageContainerId, long parentStorageContainerId);

    void updateMultipleContainersParent(Collection<Long> storageContainerIds, Long parentStorageContainerId);

    Collection<Long> findContainersWithInventory(Collection<Long> storageContainerIds);

    //    @DynamicDaoMethod(queryName="StorageContainer.getPendingStorageContainer", parameterMatchingStrategy=ParameterMatchingStrategy.PARAMETER_MAPPING)
//    StorageContainer getPendingStorageContainer(long programId);
    StorageContainer getPendingStorageContainer();

    void detachStorageContainerCatalog(StorageContainer storageContainer);

    void detachStorageContainerCatalogInBatch(Collection<StorageContainer> storageContainers);
}