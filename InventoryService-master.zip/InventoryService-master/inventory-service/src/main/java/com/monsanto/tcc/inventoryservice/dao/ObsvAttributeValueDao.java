package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.ObsvAttributeValue;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tps.dao.GenericDao;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Sep 21, 2009
 * Time: 12:55:25 PM
 */
public interface ObsvAttributeValueDao extends GenericDao<ObsvAttributeValue, Long> {

    public List<ObsvAttributeValue> getObsvAttributeValues(List<String> inventoryBarcodes, List<String> obsvAttributeRefIds) throws QueryResultsException;
}

