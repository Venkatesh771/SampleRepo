package com.monsanto.tcc.inventoryservice.genericparameters;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import com.monsanto.tcc.inventorycommon.genericparameters.client.GenericParametersRequest;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;

/**
 * User: Mark D. Sparks
 * Date: 8/26/11
 * Time: 2:16 PM
 */
@Component
public class GenericParametersTransformer {
    public Collection<GenericParameters> transformToEntities(List<GenericParametersRequest> genericParametersRequestList) {
        return Collections2.transform(genericParametersRequestList,
                new Function<GenericParametersRequest, GenericParameters>() {
                    @Override
                    public GenericParameters apply(GenericParametersRequest request) {
                        GenericParameters entity = new GenericParameters();
                        entity.setNumber1(request.getNumber1());
                        entity.setNumber2(request.getNumber2());
                        entity.setText1(request.getText1());
                        entity.setText2(request.getText2());
                        entity.setDate1(request.getDate1());
                        entity.setDate2(request.getDate2());
                        return entity;
                    }
                });
    }
}
