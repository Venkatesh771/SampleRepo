package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.Decision;
import com.monsanto.tcc.inventorycommon.domain.Plot;
import com.monsanto.tcc.inventoryservice.dao.PlotDao;
import com.monsanto.tps.dao.GenericNamedEntityDaoImpl;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.type.LongType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Oct 20, 2009
 * Time: 7:27:01 PM
 */
public class PlotDaoImpl extends GenericNamedEntityDaoImpl<Plot, Long> implements PlotDao {

    @Resource(name = "jdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    private static final Long TEMP_TABLE_SESSION_ID1 = 500L;
    private static final Long TEMP_TABLE_SESSION_ID2 = 501L;
    private static final String SESSION_ID = "SESSION_ID";
    private static final String DECISION_NAME = "DECISION_NAME";
    private static final LongType LONG_TYPE = new LongType();

    @SuppressWarnings({"ConstantNamingConvention"})
    private static final String GET_PARENT_PLOTS_FOR_INVENTORY_WHERE_DECISION_IS_NOT_INVENTORY = "GetParentPlotsForInventoryWhereDecisionIsNotInventory";
    @SuppressWarnings({"ConstantNamingConvention"})
    private static final String GET_PLOTS_WITH_INVENTORY_CHILDREN_STILL_IN_PREVIEW = "GetPlotsWithInventoryChildrenStillInPreview";
    private static final String GET_PLOT_DECISION = "GetPlotDecision";

    public PlotDaoImpl(String entityName) {
        super(entityName);
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public List<Long> getParentPlotsForInventoryWhereDecisionIsNotInventory(List<Long> inventoryIdList) {
        persistInventoryIdsIntoTempTable(inventoryIdList, TEMP_TABLE_SESSION_ID1);
        //noinspection unchecked
        SQLQuery sqlQuery = (SQLQuery) getSession().getNamedQuery(GET_PARENT_PLOTS_FOR_INVENTORY_WHERE_DECISION_IS_NOT_INVENTORY);
        return (List<Long>) sqlQuery
                .addScalar("PLOT_ID", LONG_TYPE)
                .setParameter(SESSION_ID, TEMP_TABLE_SESSION_ID1)
                .list();
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public List<Long> getPlotsWithInventoryChildrenStillInPreview(List<Long> parentPlotList) {
        persistPlotIdsIntoTempTable(parentPlotList, TEMP_TABLE_SESSION_ID2);
        //noinspection unchecked
        SQLQuery sqlQuery = (SQLQuery) getSession().getNamedQuery(GET_PLOTS_WITH_INVENTORY_CHILDREN_STILL_IN_PREVIEW);
        return (List<Long>) sqlQuery
                .addScalar("PLOT_ID", LONG_TYPE)
                .setParameter(SESSION_ID, TEMP_TABLE_SESSION_ID2)
                .list();
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public void updatePlotDecision(List<Long> plotList, String plotDecision) {
        Decision decision = getDecision(plotDecision);
        for (Long plotId : plotList) {
            jdbcTemplate.update("UPDATE MIDAS.Plot set decision_id = " + decision.getDecisionId() + " WHERE plot_id = " + plotId);
        }
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public void bulkUpdatePlotDecision(List<Long> inventoryIds, String plotDecision) {
        Decision decision = getDecision(plotDecision);
        persistInventoryIdsIntoTempTable(inventoryIds, TEMP_TABLE_SESSION_ID1);
        updateDecision(decision.getDecisionId(), TEMP_TABLE_SESSION_ID1.intValue());
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public void bulkUpdatePlotDecision(long decisionId, int tempSessionId) {
        updateDecision(decisionId, tempSessionId);
    }

    private void updateDecision(long decisionId, int tempSessionId) {
        updateDecision(decisionId, tempSessionId, "bulkUpdatePlotDecisionJoiningTempTable");
        updateDecision(decisionId, tempSessionId, "bulkUpdatePlotDecisionOnFirstAdvancementJoiningTempTable");
        updateDecision(decisionId, tempSessionId, "bulkUpdateSelectionAdvancementDecisionJoiningTempTable");
    }

    private Decision getDecision(String plotDecision) {
        return (Decision) getSession().getNamedQuery(GET_PLOT_DECISION)
                .setParameter(DECISION_NAME, plotDecision)
                .uniqueResult();
    }

    private void updateDecision(long decisionId, int tempSessionId, String queryName) {
        Query query = getSession().getNamedQuery(queryName);
        query.setLong("decisionId", decisionId);
        query.setInteger("sessionId", tempSessionId);
        query.executeUpdate();
    }

    private void persistPlotIdsIntoTempTable(List<Long> parentPlotList, Long tempTableSessionId) {
        for (Long plotId : parentPlotList) {
            jdbcTemplate.execute("INSERT INTO MIDAS.TEMP_SESSION_OCD (REQUEST_ID, NUMBER_1) VALUES (" + tempTableSessionId + ", " + plotId + ")");
        }
    }

    private void persistInventoryIdsIntoTempTable(List<Long> inventoryIdList, long tempTableSessionId) {
        for (Long inventoryId : inventoryIdList) {
            jdbcTemplate.execute("INSERT INTO MIDAS.TEMP_SESSION_OCD (REQUEST_ID, NUMBER_1) VALUES (" + tempTableSessionId + ", " + inventoryId + ")");
        }
    }
}
