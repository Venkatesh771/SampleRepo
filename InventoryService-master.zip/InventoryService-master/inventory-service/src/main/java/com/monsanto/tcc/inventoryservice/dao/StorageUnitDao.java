package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.StorageUnit;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

public interface StorageUnitDao extends GenericDao<StorageUnit, Long> {

    @DynamicDaoMethod(queryName = "StorageUnitDao.getStorageUnitByBarcode",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    StorageUnit getStorageUnitByBarcode(@DynamicDaoParameter(name = "barcode") String barcode);

}
