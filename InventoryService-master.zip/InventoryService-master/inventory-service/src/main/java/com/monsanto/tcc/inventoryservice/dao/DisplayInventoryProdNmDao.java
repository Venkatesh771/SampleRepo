package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.DisplayInventoryProdNm;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 18, 2009
 * Time: 4:10:17 PM
 */
public interface DisplayInventoryProdNmDao extends GenericDao<DisplayInventoryProdNm, Long> {
    @DynamicDaoMethod(queryName = "getLinkagesForProductNameId", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<DisplayInventoryProdNm> getLinkagesByProductNameId(@DynamicDaoParameter(name = "prodNameId") Long productNameId);

    @DynamicDaoMethod(queryName = "DisplayInventoryProdNm.getDispInvProdNamesForProductNamePubKey", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<DisplayInventoryProdNm> getDispInvProdNamesForProductNamePubKey(@DynamicDaoParameter(name = "lexProdNmPubKey") String lexProdNmPubKey);

    @DynamicDaoMethod(queryName = "getCommercialLinkagesForProductNameId", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public List<DisplayInventoryProdNm> getCommercialLinkagesByProductNameId(@DynamicDaoParameter(name = "prodNameIds") List<Long> productNameIds);
}
