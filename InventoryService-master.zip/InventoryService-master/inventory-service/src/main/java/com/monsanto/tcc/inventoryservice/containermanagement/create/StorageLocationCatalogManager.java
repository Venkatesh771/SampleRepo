package com.monsanto.tcc.inventoryservice.containermanagement.create;

import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventorycommon.domain.StorageContainerLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageContainerType;
import com.monsanto.tcc.inventorycommon.domain.StorageLocationCatalog;
import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;
import com.monsanto.tcc.inventoryservice.inventory.util.ManageContainersDaoProvider;
import com.monsanto.tcc.inventoryservice.service.handler.StorageLocationCatalogTranslator;
import com.monsanto.tps.architecture.transformer.DozerObjectTransformer;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 8, 2010
 * Time: 10:49:21 AM
 * To change this template use File | Settings | File Templates.
 */
public class StorageLocationCatalogManager implements StorageLocationAndContainerManager {

    private StorageLocationCatalogTranslator storageLocationCatalogTranslator;
    private ManageContainersDaoProvider manageContainersDaoProvider;
    private EditStorageLocationCatalogBO editStorageLocationCatalogBO;
    private CreateStorageLocationCatalogBO createStorageLocationCatalogBO;
    private DozerObjectTransformer objectTransformer;

    @Override
    public Collection<StorageUnitTO> createOrModify(Collection<StorageUnitTO> storageUnitTransferObjects) {
        Collection<StorageUnitTO> storageUnitTOs = new ArrayList<StorageUnitTO>();
        Collection<StorageLocationCatalog> storageLocationCatalogs = getStorageLocationCatalogTranslator().getStorageLocationCatalogs(storageUnitTransferObjects);
        populateName(storageLocationCatalogs);
        Collection<StorageContainer> modifiedStorageContainers = getEditStorageLocationCatalogBO().process(getModifiedStorageLocationCatalogs(storageLocationCatalogs));
        Collection<StorageContainer> newStorageContainers = getCreateStorageLocationCatalogBO().process(getNewStorageLocationCatalogs(storageLocationCatalogs));
        storageUnitTOs.addAll(buildObjects(modifiedStorageContainers, StorageUnitTO.class));
        storageUnitTOs.addAll(buildObjects(newStorageContainers, StorageUnitTO.class));
        return storageUnitTOs;
    }

    private Collection<StorageLocationCatalog> getModifiedStorageLocationCatalogs(Collection<StorageLocationCatalog> storageLocationCatalogs) {
        Collection<StorageLocationCatalog> modifiedStorageLocationCatalogCollection = new ArrayList<StorageLocationCatalog>();
        for (StorageLocationCatalog storageLocationCatalog : storageLocationCatalogs) {
            if (storageLocationCatalog.getStorageLocationCatalogId() != null) {
                modifiedStorageLocationCatalogCollection.add(storageLocationCatalog);
            }
        }
        return modifiedStorageLocationCatalogCollection;
    }


    private Collection<StorageLocationCatalog> getNewStorageLocationCatalogs(Collection<StorageLocationCatalog> storageLocationCatalogs) {
        Collection<StorageLocationCatalog> newStorageLocationCatalogCollection = new ArrayList<StorageLocationCatalog>();
        for (StorageLocationCatalog storageLocationCatalog : storageLocationCatalogs) {
            if (storageLocationCatalog.getStorageLocationCatalogId() == null) {
                newStorageLocationCatalogCollection.add(storageLocationCatalog);
            }
        }
        return newStorageLocationCatalogCollection;
    }


    private void populateName(Collection<StorageLocationCatalog> storageLocationCatalogs) {
        for (StorageLocationCatalog storageLocationCatalog : storageLocationCatalogs) {
            String storageLocationCatalogName = getStorageLocationCatalogName(storageLocationCatalog);
            storageLocationCatalog.setName(storageLocationCatalogName);
        }
    }

    public StorageLocationCatalogTranslator getStorageLocationCatalogTranslator() {
        return storageLocationCatalogTranslator;
    }

    public void setStorageLocationCatalogTranslator(StorageLocationCatalogTranslator storageLocationCatalogTranslator) {
        this.storageLocationCatalogTranslator = storageLocationCatalogTranslator;
    }

    public ManageContainersDaoProvider getManageContainersDaoProvider() {
        return manageContainersDaoProvider;
    }

    public void setManageContainersDaoProvider(ManageContainersDaoProvider manageContainersDaoProvider) {
        this.manageContainersDaoProvider = manageContainersDaoProvider;
    }

    private String getStorageLocationCatalogName(StorageLocationCatalog storageLocationCatalog) {
        StorageContainerLocation storageContainerLocation = storageLocationCatalog.getStorageContainerLocationsByStorageLocationCatalogId().iterator().next();
        Long storageContainerTypeId = storageContainerLocation.getStorageContainerByStorageContainerId().getStorageContainerType().getStorageContainerTypeId();
        StorageContainerType storageContainerType = getManageContainersDaoProvider().getStorageContainerTypeDao().load(storageContainerTypeId);
        return storageLocationCatalog.getName() + "-" + storageContainerType.getName();
    }

    public EditStorageLocationCatalogBO getEditStorageLocationCatalogBO() {
        return editStorageLocationCatalogBO;
    }

    public void setEditStorageLocationCatalogBO(EditStorageLocationCatalogBO existingStorageLocationCatalogBO) {
        this.editStorageLocationCatalogBO = existingStorageLocationCatalogBO;
    }

    public CreateStorageLocationCatalogBO getCreateStorageLocationCatalogBO() {
        return createStorageLocationCatalogBO;
    }

    public void setCreateStorageLocationCatalogBO(CreateStorageLocationCatalogBO createStorageLocationCatalogBO) {
        this.createStorageLocationCatalogBO = createStorageLocationCatalogBO;
    }

    protected <E> Collection<E> buildObjects(Collection<?> sourceObjects, Class<E> destinationClass) {
        return (sourceObjects != null) ? getObjectTransformer().buildObjects(sourceObjects, destinationClass) : new ArrayList<E>();
    }

    public DozerObjectTransformer getObjectTransformer() {
        return objectTransformer;
    }

    public void setObjectTransformer(DozerObjectTransformer objectTransformer) {
        this.objectTransformer = objectTransformer;
    }

}
