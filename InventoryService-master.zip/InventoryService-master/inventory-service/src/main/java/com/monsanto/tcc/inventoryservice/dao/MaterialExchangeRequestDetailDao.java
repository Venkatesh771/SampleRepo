package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.MaterialExchangeRequestDetail;
import com.monsanto.tcc.inventorycommon.domain.MaterialRequestDetail;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

public interface MaterialExchangeRequestDetailDao extends GenericDao<MaterialExchangeRequestDetail, Long> {

    @DynamicDaoMethod(queryName = "MaterialExchangeRequestDetailDao.findByMaterialRequestDetail",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    MaterialExchangeRequestDetail findByMaterialRequestDetail(@DynamicDaoParameter(name = "materialRequestDetail") MaterialRequestDetail materialRequestDetail);

    @DynamicDaoMethod(queryName = "MaterialExchangeRequestDetailDao.findByMaterialRequestDetailId",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    MaterialExchangeRequestDetail findByMaterialRequestDetailId(@DynamicDaoParameter(name = "materialRequestDetailId") long materialRequestDetailId);
}