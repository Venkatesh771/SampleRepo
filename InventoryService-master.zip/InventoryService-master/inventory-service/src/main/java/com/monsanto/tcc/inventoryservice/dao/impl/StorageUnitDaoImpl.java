package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.StorageUnit;
import com.monsanto.tcc.inventoryservice.dao.StorageUnitDao;
import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;

public class StorageUnitDaoImpl extends GenericDaoImpl<StorageUnit, Long> implements StorageUnitDao {

    public StorageUnitDaoImpl(Class clazz) {
        super(clazz);
    }

    @Override
    public StorageUnit getStorageUnitByBarcode(@DynamicDaoParameter(name = "barcode") String barcode) {
        return null; // This is created dynamically! See interface for annotations.
    }
}
