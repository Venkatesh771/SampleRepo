package com.monsanto.tcc.inventoryservice.containermanagement.remove;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;
import com.monsanto.tcc.inventorycommon.transferobject.StorageType;
import com.monsanto.tcc.inventoryservice.inventory.util.ManageContainersDaoProvider;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Mar 11, 2010
 * Time: 1:33:35 PM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveStorageContainerHandler implements StorageUnitRemover {
    private ManageContainersDaoProvider manageContainersDaoProvider;
    private RemoveStorageUnitsHelper removeStorageUnitsHelper;

    @Override
    public void remove(Collection<StorageUnitTO> storageUnitsRequestedForRemoval) {
        Map<StorageType, Collection<StorageUnitTO>> parentTypesVsUnits = categorizeUnitsBasedOnParentType(storageUnitsRequestedForRemoval);
        Collection<Long> topLevelStorageContainerIds = getRemoveStorageUnitsHelper().captureStorageUnitTOIds(parentTypesVsUnits.get(StorageType.STORAGE_LOCATION));
        getManageContainersDaoProvider().getStorageContainerDao().removeTopLevelEmptyStorageContainers(topLevelStorageContainerIds);
        Collection<Long> containersIdsContainedUnderParentContainers = getRemoveStorageUnitsHelper().captureStorageUnitTOIds(parentTypesVsUnits.get(StorageType.STORAGE_CONTAINER));
        getManageContainersDaoProvider().getStorageContainerDao().removeStorageContainersUnderParentContainer(containersIdsContainedUnderParentContainers);
    }

    @Override
    public Collection<StorageUnitTO> getStorageUnitsNotAssignedToAnyInventory(Collection<StorageUnitTO> storageUnitsRequestedForRemoval) {
        Collection<Long> storageLocationIds = getRemoveStorageUnitsHelper().captureStorageUnitTOIds(storageUnitsRequestedForRemoval);
        Collection<Long> storageLocationIdsHavingInventories = getManageContainersDaoProvider().getStorageContainerDao().getStorageContainersWithInventoryAssigned(storageLocationIds);
        Collection<StorageUnitTO> storageUnitTOsValidForRemoval = new ArrayList<StorageUnitTO>();
        for (StorageUnitTO storageUnitTO : storageUnitsRequestedForRemoval) {
            if (!storageLocationIdsHavingInventories.contains(storageUnitTO.getId())) {
                storageUnitTOsValidForRemoval.add(storageUnitTO);
            }
        }
        return storageUnitTOsValidForRemoval;
    }

    private Map<StorageType, Collection<StorageUnitTO>> categorizeUnitsBasedOnParentType(Collection<StorageUnitTO> storageUnitsRequestedForRemoval) {
        Map<StorageType, Collection<StorageUnitTO>> storageTypeVsUnits = new HashMap<StorageType, Collection<StorageUnitTO>>();
        for (StorageUnitTO storageUnitTO : storageUnitsRequestedForRemoval) {
            Collection<StorageUnitTO> storageUnits = storageTypeVsUnits.get(storageUnitTO.getParentStorageUnitType().getType());
            if (storageUnits == null) {
                storageUnits = new ArrayList<StorageUnitTO>();
                storageTypeVsUnits.put(storageUnitTO.getParentStorageUnitType().getType(), storageUnits);
            }
            storageUnits.add(storageUnitTO);
        }
        return storageTypeVsUnits;
    }

    public ManageContainersDaoProvider getManageContainersDaoProvider() {
        return manageContainersDaoProvider;
    }

    public void setManageContainersDaoProvider(ManageContainersDaoProvider manageContainersDaoProvider) {
        this.manageContainersDaoProvider = manageContainersDaoProvider;
    }

    public RemoveStorageUnitsHelper getRemoveStorageUnitsHelper() {
        return removeStorageUnitsHelper;
    }

    public void setRemoveStorageUnitsHelper(RemoveStorageUnitsHelper removeStorageUnitsHelper) {
        this.removeStorageUnitsHelper = removeStorageUnitsHelper;
    }
}
