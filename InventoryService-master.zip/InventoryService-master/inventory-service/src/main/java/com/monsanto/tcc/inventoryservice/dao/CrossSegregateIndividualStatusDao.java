package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.CrossSegregateIndividualStatus;
import com.monsanto.tcc.inventorycommon.domain.RemovableEventSop;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Mar 30, 2010
 * Time: 3:32:09 PM
 */
public interface CrossSegregateIndividualStatusDao extends GenericDao<CrossSegregateIndividualStatus, Long> {

    @DynamicDaoMethod(queryName = "CrossSegregateIndividualStatusDao.getActiveCrossSegregateIndividualsByCrop", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<CrossSegregateIndividualStatus> getActiveCrossSegregateIndividualsByCrop(@DynamicDaoParameter(name = "cropId") Long cropId);

    @DynamicDaoMethod(queryName = "CrossSegregateIndividualStatusDao.getRemovableEventSopForCrossSegregate", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    RemovableEventSop getRemovableEventSopForCrossSegregate(@DynamicDaoParameter(name = "CROSS_SEGREGATE_ID") Long crossSegregateIndividualStatusId);

    @DynamicDaoMethod(queryName = "CrossSegregateIndividualStatusDao.loadCrossSegregateIndividualForEventRemoval", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    CrossSegregateIndividualStatus loadCrossSegregateIndividualForEventRemoval(@DynamicDaoParameter(name = "CROSS_SEGREGATE_ID") Long crossSegregateIndividualStatusId);
}