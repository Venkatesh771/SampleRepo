package com.monsanto.tcc.inventoryservice.containermanagement.select;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTypeTO;

import java.util.Collection;

public abstract class AbstractStorageTypesRetriever extends AbstractStorageUnitDataRetriever {

    public Collection<StorageUnitTypeTO> retrieve() {
        return build();
    }

    protected abstract Collection<StorageUnitTypeTO> build();

}
