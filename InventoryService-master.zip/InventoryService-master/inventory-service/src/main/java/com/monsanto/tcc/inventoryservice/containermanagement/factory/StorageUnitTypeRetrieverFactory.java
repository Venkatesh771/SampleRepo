package com.monsanto.tcc.inventoryservice.containermanagement.factory;

import com.monsanto.tcc.inventorycommon.transferobject.StorageType;
import com.monsanto.tcc.inventoryservice.containermanagement.select.AbstractStorageTypesRetriever;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 17, 2010
 * Time: 10:01:08 AM
 * To change this template use File | Settings | File Templates.
 */
public class StorageUnitTypeRetrieverFactory {

    private Map<StorageType, AbstractStorageTypesRetriever> handlerMap;

    public StorageUnitTypeRetrieverFactory(Map<StorageType, AbstractStorageTypesRetriever> handlerMap) {
        this.handlerMap = handlerMap;
    }

    public AbstractStorageTypesRetriever getHandler(StorageType storageType) {
        return handlerMap.get(storageType);
    }

}
