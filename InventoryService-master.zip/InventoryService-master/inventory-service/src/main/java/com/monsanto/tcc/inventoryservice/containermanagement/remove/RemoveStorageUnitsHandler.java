package com.monsanto.tcc.inventoryservice.containermanagement.remove;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;
import com.monsanto.tcc.inventorycommon.transferobject.ResponseMessage;
import com.monsanto.tcc.inventorycommon.transferobject.ResponseMessageType;
import com.monsanto.tcc.inventorycommon.transferobject.StorageType;
import com.monsanto.tcc.inventoryservice.containermanagement.factory.StorageUnitRemovalHandlerFactory;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Mar 11, 2010
 * Time: 10:53:23 AM
 * To change this template use File | Settings | File Templates.
 */
public class RemoveStorageUnitsHandler {
    private StorageUnitRemovalHandlerFactory storageUnitRemovalHandlerFactory;

    public Collection<ResponseMessage> deleteStorageUnits(Collection<StorageUnitTO> storageUnitsRequestedForRemoval) {
        Map<StorageType, List<StorageUnitTO>> storageTypeVsUnitsRequestedForDeletion = categorizeStorageLocationIdsToDelete(storageUnitsRequestedForRemoval);
        List<StorageUnitTO> storageUnitsInvalidForDeletion = new ArrayList<StorageUnitTO>();
        for (Map.Entry currentItem : storageTypeVsUnitsRequestedForDeletion.entrySet()) {
          StorageType storageType = (StorageType)currentItem.getKey();
            List<StorageUnitTO> storageUnits = (List<StorageUnitTO>) currentItem.getValue();
            Collection<StorageUnitTO> unitsValidForRemoval = getStorageUnitRemovalHandlerFactory().getRemoveHandler(storageType).getStorageUnitsNotAssignedToAnyInventory(storageUnits);
            if (!unitsValidForRemoval.isEmpty()) {
                getStorageUnitRemovalHandlerFactory().getRemoveHandler(storageType).remove(unitsValidForRemoval);
            }
            storageUnits.removeAll(unitsValidForRemoval);
            storageUnitsInvalidForDeletion.addAll(storageUnits);
        }
        return buildResponseMessagesForStorageUnitsNotDeleted(storageUnitsInvalidForDeletion);
    }

    private Collection<ResponseMessage> buildResponseMessagesForStorageUnitsNotDeleted(List<StorageUnitTO> storageUnitsInvalidForDeletion) {
        Collection<ResponseMessage> responseMessages = new ArrayList<ResponseMessage>();
        if (!storageUnitsInvalidForDeletion.isEmpty()) {
            List<String> storageUnitNames = new ArrayList<String>();
            for (StorageUnitTO storageUnitTO : storageUnitsInvalidForDeletion) {
                storageUnitNames.add(storageUnitTO.getName());
            }
            ResponseMessage responseMessage = new ResponseMessage(ResponseMessageType.ERROR, StringUtils.join(storageUnitNames, ","));
            responseMessages.add(responseMessage);
        }
        return responseMessages;
    }

    private Map<StorageType, List<StorageUnitTO>> categorizeStorageLocationIdsToDelete(Collection<StorageUnitTO> storageUnitsToBeDeleted) {
        Map<StorageType, List<StorageUnitTO>> storageTypeVsUnits = new HashMap<StorageType, List<StorageUnitTO>>();
        if (storageUnitsToBeDeleted != null) {
            for (StorageUnitTO storageUnitTO : storageUnitsToBeDeleted) {
                List<StorageUnitTO> storageUnits = storageTypeVsUnits.get(storageUnitTO.getStorageUnitType().getType());
                if (storageUnits == null) {
                    storageUnits = new ArrayList<StorageUnitTO>();
                    storageTypeVsUnits.put(storageUnitTO.getStorageUnitType().getType(), storageUnits);
                }
                storageUnits.add(storageUnitTO);
            }
        }
        return storageTypeVsUnits;
    }

    public StorageUnitRemovalHandlerFactory getStorageUnitRemovalHandlerFactory() {
        return storageUnitRemovalHandlerFactory;
    }

    public void setStorageUnitRemovalHandlerFactory(StorageUnitRemovalHandlerFactory storageUnitRemovalHandlerFactory) {
        this.storageUnitRemovalHandlerFactory = storageUnitRemovalHandlerFactory;
    }
}
