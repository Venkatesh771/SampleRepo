/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventoryservice.annotations.Business;

/**
 * @author Somsubhra Ghosh (ssghos1)
 * @date 12/9/11
 * @responsibility Data Retreival Strategy for Old Greenhouse Events
 */
@Business("greenhouseEventQualityCalcDao")
public class GreenhouseEventQualityCalcDao extends AbstractQualityEventCalculatorDao {

    public static final String GET_QUALITY_EVENTS_FOR_GREENHOUSE_SQL =
            "classpath://com/monsanto/tcc/inventoryservice/inventory/sql/GetQualityEventsForGreenhouse.sql";

    @Override
    protected String getCalculateQualityEventsQuery() throws Exception {
        return getSqlString(GET_QUALITY_EVENTS_FOR_GREENHOUSE_SQL);
    }
}