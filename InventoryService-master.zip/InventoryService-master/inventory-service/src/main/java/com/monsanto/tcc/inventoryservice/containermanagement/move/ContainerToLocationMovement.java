/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.containermanagement.move;

import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventorycommon.domain.StorageContainerLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageLocationCatalog;
import com.monsanto.tcc.inventoryservice.containermanagement.StorageLocationCollaborator;
import com.monsanto.tcc.inventoryservice.containermanagement.create.CreateStorageLocationCatalogBO;
import com.monsanto.tcc.inventoryservice.dao.StorageContainerDao;
import com.monsanto.tcc.inventoryservice.inventorycontainer.StorageContainerDnml;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

/* nbwald - Nov 2, 2010 */
public class ContainerToLocationMovement
{
    private StorageContainerDao storageContainerDao;
    private PostMoveDnmlUpdate postMoveDnmlUpdate;
    private StorageLocationCollaborator storageLocationCollaborator;
    private CreateStorageLocationCatalogBO createStorageLocationCatalogBO;

    public void move(StorageContainer moved, StorageLocation to) {
        if(isTopLevelContainer(moved)) {
            updateContainersCatalogToPointToNewLocation(moved, to);
        }
        else {
            clearParent(moved);
            attachContainerToLocation(moved, to);
        }
        updateInventoryDnml(moved, to);
    }

    private boolean isTopLevelContainer(StorageContainer storageContainer) {
        return storageContainer.getParentContainerId() == null;
    }

    private void updateContainersCatalogToPointToNewLocation(StorageContainer moved, StorageLocation to) {
        Collection<StorageContainerLocation> containerLocations = moved.getStorageContainerLocationsByStorageContainerId();
        for (StorageContainerLocation containerLocation : containerLocations) {
            StorageLocationCatalog catalog = containerLocation.getStorageLocationCatalogByStorageLocationCatalogId();
            catalog.setStorageLocation(to);
        }
    }

    private void clearParent(StorageContainer moved) {
        moved.setParentContainerId(null);
        moved.setParentStorageContainer(null);
    }

    private void attachContainerToLocation(StorageContainer moved, StorageLocation to) {
        StorageLocationCatalog catalog = createCatalogBasedOnContainer(moved);
        StorageContainerLocation containerLocation = new StorageContainerLocation();
        Collection<StorageContainerLocation> containerLocations = new HashSet<StorageContainerLocation>();
        containerLocations.add(containerLocation);
        containerLocation.setStorageContainerByStorageContainerId(moved);
        containerLocation.setStorageLocationCatalogByStorageLocationCatalogId(catalog);
        catalog.setStorageLocation(to);
        catalog.setStorageLocationId(to.getStorageLocationId());
        catalog.setStorageContainerLocationsByStorageLocationCatalogId(containerLocations);
        moved.getStorageContainerLocationsByStorageContainerId().clear();
        moved.getStorageContainerLocationsByStorageContainerId().addAll(containerLocations);
        createStorageLocationCatalogBO.process(Arrays.asList(catalog));
    }

    private void updateInventoryDnml(StorageContainer moved, StorageLocation to) {
        String dnmlPrefix = storageLocationCollaborator.deriveStorageLocationPath(to);
        List<StorageContainerDnml> containerDnmls = storageContainerDao.deeplyFindStorageContainersWithInventories(moved.getStorageContainerId());
        postMoveDnmlUpdate.update(dnmlPrefix, containerDnmls);
    }

    private StorageLocationCatalog createCatalogBasedOnContainer(StorageContainer moved) {
        StorageLocationCatalog catalog = new StorageLocationCatalog();
        catalog.setName(moved.getName() + "-" + moved.getStorageContainerType().getName());
        catalog.setBarcode(moved.getBarcode());
        catalog.setDescription(moved.getDescription());
        return catalog;
    }

    public void setStorageContainerDao(StorageContainerDao storageContainerDao) {
        this.storageContainerDao = storageContainerDao;
    }

    public void setPostMoveDnmlUpdate(PostMoveDnmlUpdate postMoveDnmlUpdate) {
        this.postMoveDnmlUpdate = postMoveDnmlUpdate;
    }

    public void setStorageLocationCollaborator(StorageLocationCollaborator storageLocationCollaborator) {
        this.storageLocationCollaborator = storageLocationCollaborator;
    }

    public void setCreateStorageLocationCatalogBO(CreateStorageLocationCatalogBO createStorageLocationCatalogBO) {
        this.createStorageLocationCatalogBO = createStorageLocationCatalogBO;
    }
}