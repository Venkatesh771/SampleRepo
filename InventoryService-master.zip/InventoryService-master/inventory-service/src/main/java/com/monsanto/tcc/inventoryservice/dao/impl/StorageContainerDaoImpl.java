package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventorycommon.domain.StorageContainerLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageLocationCatalog;
import com.monsanto.tcc.inventorycommon.domain.TempSessionOcd;
import com.monsanto.tcc.inventorycommon.domain.TempSessionOcdId;
import com.monsanto.tcc.inventoryservice.dao.StorageContainerDao;
import com.monsanto.tcc.inventoryservice.importing.ImportBarcodeRow;
import com.monsanto.tcc.inventoryservice.inventorycontainer.StorageContainerDnml;
import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import org.hibernate.FlushMode;
import org.hibernate.Query;
import org.hibernate.classic.Session;
import org.hibernate.transform.Transformers;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StorageContainerDaoImpl extends GenericDaoImpl<StorageContainer, Long> implements StorageContainerDao {
    private static volatile Object lock = new Object();
    private static final String REQUEST_ID = "requestId";
    private static StorageContainer THE_ONE_AND_ONLY_PENDING_STORAGE_CONTAINER = null;

    public StorageContainerDaoImpl() {
        super(StorageContainer.class);
    }

    public StorageContainerDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public List<StorageContainer> getContainersByParentStorageContainerId(@DynamicDaoParameter(name = "parentStorageContainerId") Long parentStorageContainerId) {
        return null;
    }

    @Override
    public List<StorageContainer> getStorageContainersByStorageLocationId(@DynamicDaoParameter(name = "parentStorageLocationId") Long storageLocationId) {
        return null;
    }

    @Override
    public String getNextBarcode() {
        return null;
    }

    @Override
    public List<String> getNextBarcodes(int count) {
        return null;
    }

    @Override
    public StorageContainer getStorageContainerByBarcode(@DynamicDaoParameter(name = "barcode") String barcode) {
        return null;
    }

    @Override
    public Collection<StorageContainer> getStorageContainersByBarcodes(@DynamicDaoParameter(name = "barcodes") Collection<String> barcodes) {
        return null;
    }

    @Override
    public StorageContainer getPendingStorageContainer() {
        if (THE_ONE_AND_ONLY_PENDING_STORAGE_CONTAINER == null) {
            synchronized (StorageContainerDaoImpl.lock) {
                if (THE_ONE_AND_ONLY_PENDING_STORAGE_CONTAINER == null) {
                    Query query = getSession().getNamedQuery("StorageContainerDao.getPendingStorageContainer");
                    THE_ONE_AND_ONLY_PENDING_STORAGE_CONTAINER = (StorageContainer) query.setMaxResults(1).uniqueResult();
                }
            }
        }
        return THE_ONE_AND_ONLY_PENDING_STORAGE_CONTAINER;
    }

    @Override
    public Collection<Long> getStorageContainersWithInventoryAssigned(Collection<Long> parentStorageContainerIds) {
        int requestId = 2;
        insertIdsIntoTempTable(parentStorageContainerIds, requestId);
        getSessionFactory().getCurrentSession().flush();
        Query query = getSession().getNamedQuery("StorageContainerDao.getStorageContainerWithInventoryAssigned");
        query.setParameter(REQUEST_ID, requestId);
        Collection<BigDecimal> storageContainerIds = query.list();
        return convertToLongList(storageContainerIds);
    }

    @Override
    public void removeTopLevelEmptyStorageContainers(Collection<Long> topLevelStorageContainers) {
        if (topLevelStorageContainers != null) {
            for (Long topLevelStorageContainerId : topLevelStorageContainers) {
                StorageContainer storageContainer = load(topLevelStorageContainerId);
                deleteStorageLocationCatalog(storageContainer);
                delete(storageContainer);
            }
        }
    }

    @Override
    public void deleteStorageLocationCatalog(StorageContainer storageContainer) {
        deleteOrDetachStorageLocationCatalog(storageContainer, false);
    }

    private void deleteOrDetachStorageLocationCatalog(StorageContainer storageContainer, boolean detach) {
        Session session = getSessionFactory().getCurrentSession();
        Collection<StorageContainerLocation> containerLocations = storageContainer.getStorageContainerLocationsByStorageContainerId();
        for (StorageContainerLocation containerLocation : containerLocations) {
            StorageLocationCatalog storageLocationCatalog = containerLocation.getStorageLocationCatalogByStorageLocationCatalogId();
            StorageLocation storageLocation = storageLocationCatalog.getStorageLocation();
            storageLocation.getStorageLocationCatalogsByStorageLocationId().remove(storageLocationCatalog);
            if (detach) {
                containerLocation.setStorageContainerByStorageContainerId(null);
            }
            session.delete(storageLocationCatalog);
        }
        storageContainer.getStorageContainerLocationsByStorageContainerId().clear();
    }

    @Override
    public void detachStorageContainerCatalog(StorageContainer storageContainer) {
        deleteOrDetachStorageLocationCatalog(storageContainer, true);
    }

    @Override
    public void detachStorageContainerCatalogInBatch(Collection<StorageContainer> storageContainers) {
        for (StorageContainer storageContainer : storageContainers) {
            deleteOrDetachStorageLocationCatalog(storageContainer, true);
        }
    }

    @Override
    public void updateContainersParent(long storageContainerId, long parentStorageContainerId) {
        Query query = getSession().getNamedQuery("StorageContainer.updateContainersParent");
        query.setParameter("storageContainerId", storageContainerId);
        query.setParameter("parentContainerId", parentStorageContainerId);
        query.executeUpdate();
    }

    @Override
    public void updateMultipleContainersParent(Collection<Long> storageContainerIds, Long parentStorageContainerId) {
        long requestId = 2389438;
        insertIdsIntoTempTable(storageContainerIds, (int) requestId);
        Query query = getSession().getNamedQuery("StorageContainer.updateMultipleContainersParent");
        query.setParameter("requestId", requestId);
        query.setParameter("parentContainerId", parentStorageContainerId);
        query.executeUpdate();
    }

    @Override
    public void removeStorageContainersUnderParentContainer(Collection<Long> storageContainerIdsToRemove) {
        if (storageContainerIdsToRemove != null) {
            for (Long storageContainerId : storageContainerIdsToRemove) {
                StorageContainer chilStorageContainer = load(storageContainerId);
                if (chilStorageContainer.getParentContainerId() != null) {
                    StorageContainer parentStorageContainer = load(chilStorageContainer.getParentContainerId());
                    parentStorageContainer.getStorageContainersByStorageContainerId().remove(chilStorageContainer);
                }
            }
        }
    }

    @Override
    public List<ImportBarcodeRow> getInvalidBarcodes() {
        Query query = getSession().getNamedQuery("StorageContainer.getInvalidBarcodes");
        query.setParameter(REQUEST_ID, TempSessionTableHelper.STORAGE_UNIT_IMPORT_REQUEST_ID);
        query.setResultTransformer(Transformers.aliasToBean(ImportBarcodeRow.class));
        return query.list();
    }

    @Override
    public Map<String, StorageContainer> getBarcodeToStorageContainerMap() {
        Query query = getSession().getNamedQuery("StorageContainer.findStorageContainersByBarcodesInTemp");
        query.setParameter(REQUEST_ID, TempSessionTableHelper.STORAGE_UNIT_IMPORT_REQUEST_ID);
        query.setFlushMode(FlushMode.COMMIT);
        List<StorageContainer> results = query.list();
        Map<String, StorageContainer> barcodeToStorageContainerMap = new HashMap<String, StorageContainer>();
        if (!CollectionUtils.isEmpty(results)) {
            for (StorageContainer result : results) {
                barcodeToStorageContainerMap.put(result.getBarcode(), result);
            }
        }
        return barcodeToStorageContainerMap;
    }

    @Override
    public List<StorageContainerDnml> deeplyFindStorageContainersWithInventories(long storageContainerId) {
        Query query = getSession().getNamedQuery("StorageContainerDnml.deeplyFindStorageContainersWithInventories");
        query.setParameter("storageContainerId", storageContainerId);
        query.setResultTransformer(Transformers.aliasToBean(StorageContainerDnml.class));
        return query.list();
    }

    @Override
    public Collection<Long> findContainersWithInventory(Collection<Long> storageContainerIds) {
        int requestId = 7;
        insertIdsIntoTempTable(storageContainerIds, requestId);
        getSessionFactory().getCurrentSession().flush();
        Query query = getSession().getNamedQuery("StorageContainer.findContainersWithInventory");
        query.setParameter(REQUEST_ID, requestId);
        return query.list();
    }

    private Collection<Long> convertToLongList(Collection<BigDecimal> storageContainerIds) {
        List<Long> storageContainerLongIds = new ArrayList<Long>();
        if (storageContainerIds != null) {
            for (BigDecimal storageContainerId : storageContainerIds) {
                storageContainerLongIds.add(storageContainerId.longValue());
            }
        }
        return storageContainerLongIds;
    }

    private void insertIdsIntoTempTable(Collection<Long> ids, int sessionId) {
        Long sortOrder = 1L;
        for (Long id : ids) {
            TempSessionOcd ocd = new TempSessionOcd();
            TempSessionOcdId tempSessionOcdId = new TempSessionOcdId();
            tempSessionOcdId.setRequestId(new Long(sessionId));
            tempSessionOcdId.setNumber1(id);
            tempSessionOcdId.setSortOrder(sortOrder++);
            ocd.setId(tempSessionOcdId);
            getSessionFactory().getCurrentSession().save(ocd);
        }
    }
}
