package com.monsanto.tcc.inventoryservice.domain;


import com.monsanto.tcc.inventorycommon.domain.GeneticMaterial;

import java.util.Date;
import java.util.Set;

/**
 * User: DCENGL
 */
public class TermsOfUseEntity {

    private Long id;
    private String terms;
    private Boolean restricted;
    private GeneticMaterial originalGeneticMaterial;
    private Date modifiedDate;
    private String modifiedBy;
    private Set<GeneticMaterialTermsOfUseEntity> geneticMaterialTermsOfUseEntities;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTerms() {
        return terms;
    }

    public void setTerms(String terms) {
        this.terms = terms;
    }

    public Boolean getRestricted() {
        return restricted;
    }

    public void setRestricted(Boolean restricted) {
        this.restricted = restricted;
    }

    public GeneticMaterial getOriginalGeneticMaterial() {
        return originalGeneticMaterial;
    }

    public void setOriginalGeneticMaterial(GeneticMaterial originalGeneticMaterial) {
        this.originalGeneticMaterial = originalGeneticMaterial;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Set<GeneticMaterialTermsOfUseEntity> getGeneticMaterialTermsOfUseEntities() {
        return geneticMaterialTermsOfUseEntities;
    }

    public void setGeneticMaterialTermsOfUseEntities(Set<GeneticMaterialTermsOfUseEntity> geneticMaterialTermsOfUseEntities) {
        this.geneticMaterialTermsOfUseEntities = geneticMaterialTermsOfUseEntities;
    }
}
