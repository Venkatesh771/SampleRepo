package com.monsanto.tcc.inventoryservice.email;

import com.monsanto.tcc.artemis.util.supportemailsystem.SupportEmailSystem;
import com.monsanto.tcc.inventorycommon.domain.email.EmailMessage;
import com.monsanto.tcc.inventorycommon.service.email.EmailSystemBroker;
import com.monsanto.tcc.pipeline.util.IOUtil;
import org.apache.log4j.Logger;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.Properties;

public class EmailSystemBrokerImpl implements EmailSystemBroker {

    private static final String LOG_MESSAGE = "Unable to send email due to messaging system failure";
    private static final String STREAM_PATH = "SupportEmailSystem.properties";

    private final Logger logger = Logger.getLogger(EmailSystemBrokerImpl.class);

    @Override
    public void sendEmailMessages(EmailMessage... emailMessageList) {
        try {
            if (emailMessageList != null) {
                sendEmails(emailMessageList);
            }
        } catch (Exception exception) {
            logger.error(LOG_MESSAGE, exception);
        }
    }

    private void sendEmails(EmailMessage[] emailMessageList) throws IOException, MessagingException {
        SupportEmailSystem supportEmailSystem = initializeEmailSystem();
        for (EmailMessage emailMessage : emailMessageList) {
            supportEmailSystem.send(emailMessage.getFromAddress(), emailMessage.getToAddresses(), emailMessage.getSubject(), emailMessage.getBody());
            logger.info(emailMessage);
        }
    }

    protected SupportEmailSystem initializeEmailSystem() throws IOException {
        SupportEmailSystem.register(getEmailProperties());
        return SupportEmailSystem.createInstance();
    }

    private Properties getEmailProperties() throws IOException {
        Properties emailProperties = new Properties();
        emailProperties.load(IOUtil.createInputStream(STREAM_PATH));
        return emailProperties;
    }

}
