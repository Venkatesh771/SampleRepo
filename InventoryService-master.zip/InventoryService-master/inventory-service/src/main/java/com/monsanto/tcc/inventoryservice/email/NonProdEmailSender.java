/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.email;

import com.monsanto.tcc.inventorycommon.domain.email.EmailConfiguration;
import com.monsanto.tcc.inventorycommon.domain.email.EmailMessage;
import com.monsanto.tcc.inventorycommon.service.email.EmailSender;
import com.monsanto.tcc.inventorycommon.service.email.EmailSystemBroker;
import com.monsanto.tcc.inventoryservice.util.EnvironmentUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * User: jjbens2
 * Date: Jun 2, 2010
 */
public class NonProdEmailSender implements EmailSender {

    protected EmailSystemBroker emailSystemBroker;

    @Override
    public void sendEmails(EmailMessage... emailMessageList) {
        if (emailMessageList != null) {
            for (EmailMessage emailMessage : emailMessageList) {
                emailMessage.setBody(buildModifiedBody(emailMessage));
                emailMessage.setSubject(buildNonProdSubject(emailMessage));
                emailMessage.setToAddresses(buildAdjustedToList(emailMessage.getToAddresses()));
            }
            emailSystemBroker.sendEmailMessages(emailMessageList);
        }
    }

    @Override
    public void sendDeveloperExceptionEmail(EmailMessage... emailMessages) {
        emailSystemBroker.sendEmailMessages(emailMessages);
    }

    /**
     * Adds the developer distribution list to the To: list.
     *
     * @param currentAddresses existing list of email addresses for this message
     * @return modified list of email addresses for this message
     */
    protected List<String> buildAdjustedToList(List<String> currentAddresses) {
        List<String> adjustedToList = new ArrayList<String>(currentAddresses);
        adjustedToList.add(EmailConfiguration.getProperty("DEVELOPER_DISTRIBUTION_LIST"));
        return adjustedToList;
    }

    protected String buildModifiedBody(EmailMessage emailMessage) {
        return emailMessage.getBody();
    }

    protected String buildNonProdSubject(EmailMessage emailMessage) {
        StringBuilder subjectBuilder = new StringBuilder("[" + EnvironmentUtil.lsiFunction() + "]" + " - " + emailMessage.getSubject());
        return subjectBuilder.toString();
    }

    public void setEmailSystemBroker(EmailSystemBroker emailSystemBroker) {
        this.emailSystemBroker = emailSystemBroker;
    }
}
