package com.monsanto.tcc.inventoryservice.containermanagement.create;

import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;
import com.monsanto.tcc.inventoryservice.inventory.util.ManageContainersDaoProvider;
import com.monsanto.tcc.inventoryservice.service.handler.StorageContainerTranslator;
import com.monsanto.tps.architecture.transformer.DozerObjectTransformer;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 8, 2010
 * Time: 10:48:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class StorageContainerManager implements StorageLocationAndContainerManager {
    private StorageContainerTranslator storageContainerTranslator;
    private ManageContainersDaoProvider manageContainersDaoProvider;
    private CreateStorageContainerBO createStorageContainerBO;
    private EditStorageContainerBO editStorageContainerBO;
    private DozerObjectTransformer objectTransformer;


    @Override
    public Collection<StorageUnitTO> createOrModify(Collection<StorageUnitTO> storageUnitTransferObjects) {
        Collection<StorageUnitTO> storageUnitTOs = new ArrayList<StorageUnitTO>();
        Collection<StorageContainer> storageContainers = getStorageContainerTranslator().getStorageContainers(storageUnitTransferObjects);
        Collection<StorageContainer> modifiedStorageContainers = getEditStorageContainerBO().process(getModifiedStorageContainers(storageContainers));
        Collection<StorageContainer> newStorageContainers = getCreateStorageContainerBO().process(getNewStorageContainers(storageContainers));
        storageUnitTOs.addAll(buildObjects(newStorageContainers, StorageUnitTO.class));
        storageUnitTOs.addAll(buildObjects(modifiedStorageContainers, StorageUnitTO.class));
        return storageUnitTOs;
    }

    public Collection<StorageContainer> getModifiedStorageContainers(Collection<StorageContainer> storageContainers) {
        Collection<StorageContainer> modifiedStorageContainers = new ArrayList<StorageContainer>();
        for (StorageContainer storageContainer : storageContainers) {
            if (storageContainer.getStorageContainerId() != null) {
                modifiedStorageContainers.add(storageContainer);
            }
        }
        return modifiedStorageContainers;
    }

    public Collection<StorageContainer> getNewStorageContainers(Collection<StorageContainer> storageContainers) {
        Collection<StorageContainer> newStorageContainers = new ArrayList<StorageContainer>();
        for (StorageContainer storageContainer : storageContainers) {
            if (storageContainer.getStorageContainerId() == null) {
                newStorageContainers.add(storageContainer);
            }
        }
        return newStorageContainers;
    }


    public StorageContainerTranslator getStorageContainerTranslator() {
        return storageContainerTranslator;
    }

    public void setStorageContainerTranslator(StorageContainerTranslator storageContainerTranslator) {
        this.storageContainerTranslator = storageContainerTranslator;
    }

    public CreateStorageContainerBO getCreateStorageContainerBO() {
        return createStorageContainerBO;
    }

    public void setCreateStorageContainerBO(CreateStorageContainerBO createStorageContainerBO) {
        this.createStorageContainerBO = createStorageContainerBO;
    }

    public EditStorageContainerBO getEditStorageContainerBO() {
        return editStorageContainerBO;
    }

    public void setEditStorageContainerBO(EditStorageContainerBO editStorageContainerBO) {
        this.editStorageContainerBO = editStorageContainerBO;
    }

    protected <E> Collection<E> buildObjects(Collection<?> sourceObjects, Class<E> destinationClass) {
        return (sourceObjects != null) ? getObjectTransformer().buildObjects(sourceObjects, destinationClass) : new ArrayList<E>();
    }

    public DozerObjectTransformer getObjectTransformer() {
        return objectTransformer;
    }

    public void setObjectTransformer(DozerObjectTransformer objectTransformer) {
        this.objectTransformer = objectTransformer;
    }
}
