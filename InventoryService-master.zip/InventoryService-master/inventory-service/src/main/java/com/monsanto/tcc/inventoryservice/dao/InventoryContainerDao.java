package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.InventoryContainer;
import com.monsanto.tcc.inventoryservice.dao.impl.TempSessionRequest;
import com.monsanto.tps.dao.GenericDao;

import java.util.Collection;
import java.util.List;

public interface InventoryContainerDao extends GenericDao<InventoryContainer, Long> {

    public Collection<InventoryContainer> getInventoryContainersByInventoryIds(Collection<Long> inventoryIds);

    Collection<InventoryContainer> getInventoryContainersByInventoryIds(TempSessionRequest tempSessionRequest);

    Collection<InventoryContainer> getStorageInventoryContainersByInventoryIds(TempSessionRequest tempSessionRequest);

    Collection<InventoryContainer> getStorageInventoryContainersByInventoryIds(Collection<Long> inventoryIds);

    int deleteInventoryContainers(long storage_container_id1, Collection<Long> inventoryCollection) throws Exception;

    List<Long> getNextInventoryContainerIds(int count);

    int copyContainerTreatments(long sourceInventoryContainerId, long targetInventoryContainerId);

    int copyContainerTreatments(Collection<Long> sourceInventoryContainerIds, long targetInventoryContainerId);

    /**
     * @param pendingStorageContainerId The Pending storage container id to associate the newly created inventories to.
     * @param inventoryIds              The inventory ids to create new inventory containers for.
     * @param createdByUserId           The user id to associate the user who created the inventory containers.
     * @return an array containing one entry per each element in the batch.  In the case of oracle, each element with
     *         have a value of -2.
     */
    int[] createInventoryContainersInBatch(Long pendingStorageContainerId, Collection<Long> inventoryIds, String createdByUserId);

    Collection<Long> findInventoryIdsWithoutContainers(int sessionId);
}
