/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.importing;

import com.monsanto.services.domain.breeding.FateReason;
import com.monsanto.tcc.inventorycommon.domain.InventoryContainer;

import java.util.Date;
import java.util.Set;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$     On:$Date$
 *
 * @author sssing5
 * @version $Revision$
 */
public class ImportInventory {
    private Long id;
    private Long brProgId;
    private String barcode;
    private Boolean isActive;
    private Boolean isPreview;
    private String asort1;
    private String asort2;
    private String asort3;
    private String asort4;
    private String asort5;
    private Double nsort1;
    private Double nsort2;
    private Double nsort3;
    private Double nsort4;
    private Double nsort5;
    private String invComments;
    private String goiTxt;
    private Double quantity;
    private Long quantityUomId;
    private Double originQty;
    private Long originQuantityUomId;
    private Date originDate;
    private String seedTreatment;
    private String storageUnitDisplayDnml;
    private FateReason fateReason;
    private Date fateReasonDate;
    private Set<InventoryContainer> inventoryContainers;
    private String storageUnitBarcode;
    private Date modifiedDate;
    private String modifiedUserName;
    private Date seedProcessingDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBrProgId() {
        return brProgId;
    }

    public void setBrProgId(Long brProgId) {
        this.brProgId = brProgId;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public Boolean getActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }

    public Boolean getPreview() {
        return isPreview;
    }

    public void setPreview(Boolean preview) {
        isPreview = preview;
    }

    public String getAsort1() {
        return asort1;
    }

    public void setAsort1(String asort1) {
        this.asort1 = asort1;
    }

    public String getAsort2() {
        return asort2;
    }

    public void setAsort2(String asort2) {
        this.asort2 = asort2;
    }

    public String getAsort3() {
        return asort3;
    }

    public void setAsort3(String asort3) {
        this.asort3 = asort3;
    }

    public String getAsort4() {
        return asort4;
    }

    public void setAsort4(String asort4) {
        this.asort4 = asort4;
    }

    public String getAsort5() {
        return asort5;
    }

    public void setAsort5(String asort5) {
        this.asort5 = asort5;
    }

    public Double getNsort1() {
        return nsort1;
    }

    public void setNsort1(Double nsort1) {
        this.nsort1 = nsort1;
    }

    public Double getNsort2() {
        return nsort2;
    }

    public void setNsort2(Double nsort2) {
        this.nsort2 = nsort2;
    }

    public Double getNsort3() {
        return nsort3;
    }

    public void setNsort3(Double nsort3) {
        this.nsort3 = nsort3;
    }

    public Double getNsort4() {
        return nsort4;
    }

    public void setNsort4(Double nsort4) {
        this.nsort4 = nsort4;
    }

    public Double getNsort5() {
        return nsort5;
    }

    public void setNsort5(Double nsort5) {
        this.nsort5 = nsort5;
    }

    public String getInvComments() {
        return invComments;
    }

    public void setInvComments(String invComments) {
        this.invComments = invComments;
    }

    public String getGoiTxt() {
        return goiTxt;
    }

    public void setGoiTxt(String goiTxt) {
        this.goiTxt = goiTxt;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public Long getQuantityUomId() {
        return quantityUomId;
    }

    public void setQuantityUomId(Long quantityUomId) {
        this.quantityUomId = quantityUomId;
    }

    public Double getOriginQty() {
        return originQty;
    }

    public void setOriginQty(Double originQty) {
        this.originQty = originQty;
    }

    public Long getOriginQuantityUomId() {
        return originQuantityUomId;
    }

    public void setOriginQuantityUomId(Long originQuantityUomId) {
        this.originQuantityUomId = originQuantityUomId;
    }

    public Date getOriginDate() {
        return originDate;
    }

    public void setOriginDate(Date originDate) {
        this.originDate = originDate;
    }

    public String getSeedTreatment() {
        return seedTreatment;
    }

    public void setSeedTreatment(String seedTreatment) {
        this.seedTreatment = seedTreatment;
    }

    public String getStorageUnitDisplayDnml() {
        return storageUnitDisplayDnml;
    }

    public void setStorageUnitDisplayDnml(String storageUnitDisplayDnml) {
        this.storageUnitDisplayDnml = storageUnitDisplayDnml;
    }

    public FateReason getFateReason() {
        return fateReason;
    }

    public void setFateReason(FateReason fateReason) {
        this.fateReason = fateReason;
    }

    public Date getFateReasonDate() {
        return fateReasonDate;
    }

    public void setFateReasonDate(Date fateReasonDate) {
        this.fateReasonDate = fateReasonDate;
    }

    public Set<InventoryContainer> getInventoryContainers() {
        return inventoryContainers;
    }

    public void setInventoryContainers(Set<InventoryContainer> inventoryContainers) {
        this.inventoryContainers = inventoryContainers;
    }

    @Deprecated
    public String getStorageUnitBarcode() {
        return storageUnitBarcode;
    }

    @Deprecated
    public void setStorageUnitBarcode(String storageUnitBarcode) {
        this.storageUnitBarcode = storageUnitBarcode;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getModifiedUserName() {
        return modifiedUserName;
    }

    public void setModifiedUserName(String modifiedUserName) {
        this.modifiedUserName = modifiedUserName;
    }

    public Date getSeedProcessingDate() {
        return seedProcessingDate;
    }

    public void setSeedProcessingDate(Date seedProcessingDate) {
        this.seedProcessingDate = seedProcessingDate;
    }

}