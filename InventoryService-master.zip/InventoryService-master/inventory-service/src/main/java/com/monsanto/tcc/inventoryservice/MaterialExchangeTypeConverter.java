package com.monsanto.tcc.inventoryservice;

import com.monsanto.services.domain.germplasm.GeneticMaterial;
import com.monsanto.services.domain.germplasm.Germplasm;
import com.monsanto.services.domain.germplasm.Inventory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Aug 11, 2009
 * Time: 10:04:25 AM
 */
public class MaterialExchangeTypeConverter {

    public List<Germplasm> convertInvCommonGermplasmList(List<com.monsanto.tcc.inventorycommon.domain.Germplasm> invCommonGermplasmList) {
        List<Germplasm> germplasmList = new ArrayList<Germplasm>();
        for (com.monsanto.tcc.inventorycommon.domain.Germplasm invCommonGermplasm : invCommonGermplasmList) {
            Germplasm germplasm = convertInvCommonGermplasm(invCommonGermplasm);
            germplasmList.add(germplasm);
        }
        return germplasmList;
    }

    public List<Germplasm> convertGermplasmIdListToServicesAllGermplasmList(List<Long> germplasmIdList) {
        List<Germplasm> germplasmList = new ArrayList<Germplasm>();
        for (Long germplasmId : germplasmIdList) {
            Germplasm germplasm = new Germplasm();
            germplasm.setGermplasmId(germplasmId);
            germplasmList.add(germplasm);
        }
        return germplasmList;
    }

    public Germplasm convertInvCommonGermplasm(com.monsanto.tcc.inventorycommon.domain.Germplasm invCommonGermplasm) {
        Germplasm germplasm = new Germplasm();
        germplasm.setCodeYear(invCommonGermplasm.getCodeYear());
        germplasm.setConstruct(invCommonGermplasm.getConstructDisplay());
        germplasm.setCreationDate(invCommonGermplasm.getCreationDate());
        germplasm.setCropId(invCommonGermplasm.getCropId());
        germplasm.setCytoplasmDonor(invCommonGermplasm.getCytoplasmDonor());
        germplasm.setDeletedStatus(getBooleanFromChar(invCommonGermplasm.getIsDeleted()));
        germplasm.setEvent(invCommonGermplasm.getEventDisplay());
        germplasm.setFinishedOrFinishedChildStatus(getBooleanFromString(invCommonGermplasm.getIsFinishedOrFinishedChild()));
        germplasm.setGenusSpeciesId(invCommonGermplasm.getGenusSpeciesId());
        germplasm.setGermplasmId(invCommonGermplasm.getGermplasmId());
        germplasm.setGermplasmId(invCommonGermplasm.getGermplasmId());
        germplasm.setHoldensRefIndex(invCommonGermplasm.getHoldensRefIndex());
        germplasm.setLineCode(invCommonGermplasm.getLineCode());
        if (invCommonGermplasm.getLineFunction() != null) {
            germplasm.setLineFunctionId(invCommonGermplasm.getLineFunction().getLineFunctionId());
        }
        if (invCommonGermplasm.getLineType() != null) {
            germplasm.setLineTypeId(invCommonGermplasm.getLineType().getLineTypeId());
        }

        germplasm.setMarisDbOrTemplate(invCommonGermplasm.getMarisDbOrTemplate());
        germplasm.setMarisPedIdOrTemplateId(invCommonGermplasm.getMarisPedIdOrTemplateId());
        germplasm.setOldPedigree(invCommonGermplasm.getOldPedigree());
        germplasm.setOrigin(invCommonGermplasm.getOrigin());
        germplasm.setOwnerProgramId(invCommonGermplasm.getBrProgId());
        germplasm.setPedigree(invCommonGermplasm.getPedigreeName());
        germplasm.setPollinationInstruction(invCommonGermplasm.getPollinationInstruction());
        germplasm.setRegulatoryDisplayName(invCommonGermplasm.getRegulatoryNameDisplay());
        germplasm.setRemRefNumber(invCommonGermplasm.getRemRefNumber());
        germplasm.setRestriction(invCommonGermplasm.getRestriction());
        germplasm.setTransformationGenoType(invCommonGermplasm.getTransformationGenotype());
        germplasm.setTransgenic(getBooleanFromString(invCommonGermplasm.getIsTransgenic()));
        germplasm.setVirgoId(invCommonGermplasm.getVirgoId());
        return germplasm;
    }

    private Boolean getBooleanFromString(String boolString) {
        return "T".equals(boolString);
    }

    private Boolean getBooleanFromChar(char boolChar) {
        return boolChar == 'T';
    }

    public List<GeneticMaterial> convertInvCommonGeneticMaterialList(List<com.monsanto.tcc.inventorycommon.domain.GeneticMaterial> invCommonGeneticMaterialList) {
        List<GeneticMaterial> geneticMaterials = new ArrayList<GeneticMaterial>();
        for (com.monsanto.tcc.inventorycommon.domain.GeneticMaterial invCommonGeneticMaterial : invCommonGeneticMaterialList) {
            GeneticMaterial geneticMaterial = convertInvCommonGeneticMaterial(invCommonGeneticMaterial);
            geneticMaterials.add(geneticMaterial);
        }
        return geneticMaterials;
    }

    public GeneticMaterial convertInvCommonGeneticMaterial(com.monsanto.tcc.inventorycommon.domain.GeneticMaterial invCommonGeneticMaterial) {
        GeneticMaterial geneticMaterial = new GeneticMaterial();
        geneticMaterial.setAutogen(invCommonGeneticMaterial.getAutogen());
        geneticMaterial.setGenCount(invCommonGeneticMaterial.getGenCount());
        geneticMaterial.setGeneration(invCommonGeneticMaterial.getGeneration());
        geneticMaterial.setGeneticMaterialId(invCommonGeneticMaterial.getGeneticMaterialId());
        if (invCommonGeneticMaterial.getGermplasm() != null) {
            geneticMaterial.setGermplasmId(invCommonGeneticMaterial.getGermplasm().getGermplasmId());
        }
        geneticMaterial.setLineage(invCommonGeneticMaterial.getLineage());
        geneticMaterial.setRubiconDecisionDisplay(invCommonGeneticMaterial.getRubProjDisplay());
        geneticMaterial.setRubiconKeeperDisplay(invCommonGeneticMaterial.getRubKeeperDisplay());
        geneticMaterial.setSource(invCommonGeneticMaterial.getSourceStr());
        geneticMaterial.setSrcAbsoluteColumn(invCommonGeneticMaterial.getSrcAbsCol());
        geneticMaterial.setSrcAbsoluteRange(invCommonGeneticMaterial.getSrcAbsRng());
        geneticMaterial.setSrcCrop(invCommonGeneticMaterial.getSrcCrop());
        geneticMaterial.setSrcEntryNumber(invCommonGeneticMaterial.getSrcEntryNumber());
        geneticMaterial.setSrcExtBarcode(invCommonGeneticMaterial.getSrcExtBid());
        geneticMaterial.setSrcGrowerProgram(invCommonGeneticMaterial.getSrcGrowProg());
        geneticMaterial.setSrcHarvestMonth(invCommonGeneticMaterial.getSrcHarvMonth());
        geneticMaterial.setSrcHarvestYear(invCommonGeneticMaterial.getSrcHarvYear());
        geneticMaterial.setSrcLocation(invCommonGeneticMaterial.getSrcLoc());
        geneticMaterial.setSrcLotNumber(invCommonGeneticMaterial.getSrcLotNumber());
        geneticMaterial.setSrcMaleColumn(invCommonGeneticMaterial.getSrcMaleCol());
        geneticMaterial.setSrcMalePlotBarcode(invCommonGeneticMaterial.getSrcMalePlotBid());
        geneticMaterial.setSrcMaleProgram(invCommonGeneticMaterial.getSrcMaleProg());
        geneticMaterial.setSrcMaleRange(invCommonGeneticMaterial.getSrcMaleRng());
        geneticMaterial.setSrcMaleSequenceNumber(invCommonGeneticMaterial.getSrcMaleSeqNumber());
        geneticMaterial.setSrcMaleSubRowNumber(invCommonGeneticMaterial.getSrcMaleSrNumber());
        geneticMaterial.setSrcOperation(invCommonGeneticMaterial.getSrcOperation());
        geneticMaterial.setSrcOriginatorCountry(invCommonGeneticMaterial.getSrcOrigCountry());
        geneticMaterial.setSrcOriginatorProgram(invCommonGeneticMaterial.getSrcOrigProg());
        geneticMaterial.setSrcOrigStation(invCommonGeneticMaterial.getSrcOrigStation());
        geneticMaterial.setSrcPlantMonth(invCommonGeneticMaterial.getSrcPlantMonth());
        geneticMaterial.setSrcPlantYear(invCommonGeneticMaterial.getSrcPlantYear());
        geneticMaterial.setSrcPlotBarcode(invCommonGeneticMaterial.getSrcPlotBid());
        geneticMaterial.setSrcPlotNumber(invCommonGeneticMaterial.getSrcPlotNumber());
        geneticMaterial.setSrcPollinationDate(invCommonGeneticMaterial.getSrcPollinationDate());
        geneticMaterial.setSrcProtocolName(invCommonGeneticMaterial.getSrcProtocolName());
        geneticMaterial.setSrcRepNumber(invCommonGeneticMaterial.getSrcRepNumber());
        geneticMaterial.setSrcSampleNumber(invCommonGeneticMaterial.getSrcSampleNumber());
        geneticMaterial.setSrcSeason(invCommonGeneticMaterial.getSrcSeason());
        geneticMaterial.setSrcSequenceNumber(invCommonGeneticMaterial.getSrcSeqNumber());
        geneticMaterial.setSrcSet(invCommonGeneticMaterial.getSrcSet());
        geneticMaterial.setSrcSubRowNumber(invCommonGeneticMaterial.getSrcSubRowNumber());
        geneticMaterial.setSrcSubSubRowNumber(invCommonGeneticMaterial.getSrcSubSubRowNumber());
        geneticMaterial.setSrcTrackId(invCommonGeneticMaterial.getSrcTrkId());
        geneticMaterial.setTester(invCommonGeneticMaterial.getTesterDisplay());
        geneticMaterial.setTransformationGeneration(invCommonGeneticMaterial.getTransformationGeneration());
        geneticMaterial.setTemplateText(invCommonGeneticMaterial.getTemplateText());
        return geneticMaterial;
    }

    public List<Inventory> convertInvCommonInventoryList(List<com.monsanto.tcc.inventorycommon.domain.Inventory> invCommonInventoryList) {
        List<Inventory> inventoryList = new ArrayList<Inventory>();
        for (com.monsanto.tcc.inventorycommon.domain.Inventory invCommonInventory : invCommonInventoryList) {
            Inventory inventory = convertInvCommonInventory(invCommonInventory);
            inventoryList.add(inventory);
        }
        return inventoryList;
    }

    public Inventory convertInvCommonInventory(com.monsanto.tcc.inventorycommon.domain.Inventory invCommonInventory) {
        Inventory inventory = new Inventory();
        inventory.setActiveStatus(Boolean.TRUE.equals(invCommonInventory.getIsActive()));
        inventory.setArchivedMaterial(Boolean.TRUE.equals(invCommonInventory.getArchivedMaterial()));
        inventory.setBarcode(invCommonInventory.getBarcode());
        inventory.setBulkReason(invCommonInventory.getBulkReason());
        inventory.setCheckIndicator(getBooleanFromString(invCommonInventory.getCheckIndicator()));
        inventory.setComments(invCommonInventory.getInvComments());
        inventory.setCreationDate(invCommonInventory.getCreationDate());
        if (invCommonInventory.getGeneticMaterial() != null) {
            inventory.setGeneticMaterialId(invCommonInventory.getGeneticMaterial().getGeneticMaterialId());
        }
        inventory.setGoiText(invCommonInventory.getGoiTxt());
        inventory.setLocation(invCommonInventory.getLocation());
        inventory.setNbrSubInventoryToCreate(invCommonInventory.getNbrSubinventoryToCreate());

        inventory.setPreviewStatus(invCommonInventory.getIsPreview());
        inventory.setProgramId(invCommonInventory.getBrProgId());

        if (null != invCommonInventory.getQuantityUom()) {
            inventory.setQuantityUomId(invCommonInventory.getQuantityUom().getId());
        }
        inventory.setSeedProcessingDate(invCommonInventory.getSeedProcessingDate());
        inventory.setSeedTreatment(invCommonInventory.getSeedTreatment());
        inventory.setToBeDestoryed(Boolean.TRUE.equals(invCommonInventory.getToBeDestroyed()));
        if (invCommonInventory.getVegetativeStructure() != null) {
            inventory.setVegetativeStructureId(invCommonInventory.getVegetativeStructure().getVegetativeStructureId());
        }
        inventory.setVirgoId(invCommonInventory.getVirgoId());
        setAlphaSort(invCommonInventory, inventory);
        setQuantity(invCommonInventory, inventory);
        setDesctructionData(invCommonInventory, inventory);
        setFateData(invCommonInventory, inventory);
        setInventoryData(invCommonInventory, inventory);
        setNumericSort(invCommonInventory, inventory);
        setOriginData(invCommonInventory, inventory);
        setPlacedData(invCommonInventory, inventory);
        setReadyForTransformationData(invCommonInventory, inventory);
        setStorageUnitData(invCommonInventory, inventory);
        //        inventory.setQuantityUOM(invCommonInventory.getQuantity);
        //        inventory.setParentBarcode(invCommonInventory.getParentInventories());   TODO:  get correct parent inventory barcode
        return inventory;
    }

     private void setStorageUnitData(com.monsanto.tcc.inventorycommon.domain.Inventory invCommonInventory,
                                     Inventory inventory) {
          if (invCommonInventory.getStorageUnit() != null) {
              inventory.setStorageUnitBarcode(invCommonInventory.getStorageUnit().getBarcode());
              inventory.setStorageUnitName(invCommonInventory.getStorageUnit().getName());
          }
          inventory.setStorageUnitDisplay(invCommonInventory.getStorageUnitDisplayDnml());
     }

     private void setReadyForTransformationData(com.monsanto.tcc.inventorycommon.domain.Inventory invCommonInventory,
                                                Inventory inventory) {
          inventory.setReadyForTransformationDate(invCommonInventory.getReadyForTransformationDate());
          inventory.setReadyForTransofrmationUserId(invCommonInventory.getReadyForTransformationUsrid());
     }

     private void setPlacedData(com.monsanto.tcc.inventorycommon.domain.Inventory invCommonInventory,
                                Inventory inventory) {
          inventory.setPlaced(Boolean.TRUE.equals(invCommonInventory.getIsPlaced()));
          inventory.setPlacedInArchivedBook(Boolean.TRUE.equals(invCommonInventory.getIsPlacedInArchivedBook()));
     }

     private void setOriginData(com.monsanto.tcc.inventorycommon.domain.Inventory invCommonInventory,
                                Inventory inventory) {
          inventory.setOriginDate(invCommonInventory.getOriginDate());
          inventory.setOriginQty(invCommonInventory.getOriginQty());
          inventory.setOriginQtyUnitOfMeasureId(invCommonInventory.getOriginQuantityUomId());
     }

     private void setNumericSort(com.monsanto.tcc.inventorycommon.domain.Inventory invCommonInventory,
                                 Inventory inventory) {
          inventory.setNumericSort1(invCommonInventory.getNsort1());
          inventory.setNumericSort2(invCommonInventory.getNsort2());
          inventory.setNumericSort3(invCommonInventory.getNsort3());
          inventory.setNumericSort4(invCommonInventory.getNsort4());
          inventory.setNumericSort5(invCommonInventory.getNsort5());
     }

     private void setInventoryData(com.monsanto.tcc.inventorycommon.domain.Inventory invCommonInventory,
                                   Inventory inventory) {
          inventory.setInventoryId(invCommonInventory.getId());
          if (invCommonInventory.getInventoryPurpose() != null) {
              inventory.setInventoryPurposeId(invCommonInventory.getInventoryPurpose().getInventoryPurposeId());
          }
          if (invCommonInventory.getInventoryStatus() != null) {
              inventory.setInventoryStatusId(invCommonInventory.getInventoryStatus().getInventoryStatusID());
          }
          if (invCommonInventory.getInventoryType() != null) {
              inventory.setInventoryTypeId(invCommonInventory.getInventoryType().getInventoryTypeId());
          }
     }

     private void setFateData(com.monsanto.tcc.inventorycommon.domain.Inventory invCommonInventory,
                              Inventory inventory) {
          inventory.setFateDate(invCommonInventory.getFateReasonDate());
          if (invCommonInventory.getFateReason() != null) {
              inventory.setFateReasonId(invCommonInventory.getFateReason().getFateReasonId());
          }
     }

     private void setDesctructionData(com.monsanto.tcc.inventorycommon.domain.Inventory invCommonInventory,
                                      Inventory inventory) {
          inventory.setDestructionDate(invCommonInventory.getDestructionDate());
          inventory.setDestructionMethodId(invCommonInventory.getDestructionMethodId());
          inventory.setDestructionVerifiedUserId(invCommonInventory.getDestructionVerifiedUserId());
     }

     private void setQuantity(com.monsanto.tcc.inventorycommon.domain.Inventory invCommonInventory,
                              Inventory inventory) {
          if (invCommonInventory.getCurrentQty() != null) {
              inventory.setCurrentQuantity(invCommonInventory.getCurrentQty().intValue());
          }
          inventory.setCurrentQuantityUomId(invCommonInventory.getCurrentQtyUomId());
          inventory.setSubInventoryQuantity(invCommonInventory.getSubinventoryQuantity());
          inventory.setSeedQuantity(invCommonInventory.getQuantity());
     }

     private void setAlphaSort(com.monsanto.tcc.inventorycommon.domain.Inventory invCommonInventory,
                               Inventory inventory) {
          inventory.setAlphaSort1(invCommonInventory.getAsort1());
          inventory.setAlphaSort2(invCommonInventory.getAsort2());
          inventory.setAlphaSort3(invCommonInventory.getAsort3());
          inventory.setAlphaSort4(invCommonInventory.getAsort4());
          inventory.setAlphaSort5(invCommonInventory.getAsort5());
     }
}
