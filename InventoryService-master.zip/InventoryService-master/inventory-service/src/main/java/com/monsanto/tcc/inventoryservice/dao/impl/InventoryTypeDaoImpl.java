package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.services.domain.breeding.InventoryType;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tcc.inventoryservice.dao.InventoryTypeDao;
import com.monsanto.tps.dao.GenericDaoImpl;
import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Query;

import java.util.List;

public class InventoryTypeDaoImpl extends GenericDaoImpl<InventoryType, Long> implements InventoryTypeDao {
    public InventoryTypeDaoImpl(Class aClass) {
        super(aClass);
    }

    public InventoryType getActiveHybridInventoryTypeForCropId(Long cropId) throws QueryResultsException {
        Query query = getSession().getNamedQuery("getActiveHybridInventoryTypeForCropId");
        query.setLong("cropId", cropId);
        List results = query.list();
        if (CollectionUtils.isEmpty(results)) {
            throw new QueryResultsException("Found NO results when getting Inventory Type by Crop Id");
        } else if (results.size() == 1) {
            return (InventoryType) results.get(0);
        }
        throw new QueryResultsException("Found MULTIPLE results when getting Inventory Type by Crop Id");
    }

    public List<InventoryType> getInventoryTypesByCropId(Long cropId) throws QueryResultsException {
        Query query = getSession().getNamedQuery("getInventoryTypesByCropId");
        query.setLong("cropId", cropId);
        List results = query.list();
        if (CollectionUtils.isEmpty(results)) {
            throw new QueryResultsException("Found NO results when getting Inventory Type by Crop Id");
        }
        return (List<InventoryType>) results;
    }
}
