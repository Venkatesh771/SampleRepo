package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.inventorycommon.domain.TempSessionOcd;
import com.monsanto.tcc.inventorycommon.domain.TempSessionOcdId;
import org.hibernate.Session;

import java.util.Collection;

public class TempSessionTableHelper {

    public static final Long STORAGE_UNIT_IMPORT_REQUEST_ID = 54984L;

    private static final int DEFAULT_BATCH_SIZE = 50;

    private Long counter;

    public TempSessionTableHelper() {
        counter = 0L;
    }

    public void insertIdsIntoTempTable(Session currentSession, Collection<Long> ids, int sessionId) {
        Long index = 0L;
        for (Long id : ids) {
            TempSessionOcd ocd = new TempSessionOcd();
            TempSessionOcdId tempSessionOcdId = new TempSessionOcdId();
            tempSessionOcdId.setRequestId((long) sessionId);
            tempSessionOcdId.setNumber1(id);
            tempSessionOcdId.setSortOrder(index++);
            ocd.setId(tempSessionOcdId);
            currentSession.save(ocd);
            if (index % DEFAULT_BATCH_SIZE == 0) {
                flushAndClear(currentSession);
            }
        }
        flushAndClear(currentSession);
    }

    public void insertBarcodesIntoTempTable(Session currentSession, Collection<String> barcodes, Long sessionId) {
        Long index = 0L;
        for (String barcode : barcodes) {
            TempSessionOcd ocd = new TempSessionOcd();
            TempSessionOcdId tempSessionOcdId = new TempSessionOcdId();
            tempSessionOcdId.setRequestId(sessionId);
            tempSessionOcdId.setText1(barcode);
            tempSessionOcdId.setSortOrder(index++);
            ocd.setId(tempSessionOcdId);
            currentSession.save(ocd);
        }
    }

    public void insertLexiconProductReferencesIntoTempTable(Session currentSession, Collection<String> productReferences, Long sessionId) throws WrappingException {
        for (String productReference : productReferences) {

            TempSessionOcd ocd = new TempSessionOcd();
            TempSessionOcdId tempSessionOcdId = new TempSessionOcdId();
            tempSessionOcdId.setRequestId(sessionId);
            tempSessionOcdId.setText1(productReference);
            tempSessionOcdId.setText2("");
            tempSessionOcdId.setSortOrder(counter++);
            ocd.setId(tempSessionOcdId);
            currentSession.save(ocd);
        }
    }

    public void insertPreCommercialProductReferencesIntoTempTable(Session currentSession, Collection<String> productReferences, Long sessionId) throws WrappingException {
        for (String productReference : productReferences) {

            TempSessionOcd ocd = new TempSessionOcd();
            TempSessionOcdId tempSessionOcdId = new TempSessionOcdId();
            tempSessionOcdId.setRequestId(sessionId);
            tempSessionOcdId.setText1("");
            tempSessionOcdId.setText2(productReference);
            tempSessionOcdId.setSortOrder(counter++);
            ocd.setId(tempSessionOcdId);
            currentSession.save(ocd);
        }
    }

    public void insertStorageUnitImportRow(Session currentSession, String inventoryBarcode, String storageContainerBarcode, int row) {
        TempSessionOcd ocd = new TempSessionOcd();
        TempSessionOcdId tempSessionOcdId = new TempSessionOcdId();
        tempSessionOcdId.setRequestId(STORAGE_UNIT_IMPORT_REQUEST_ID);
        tempSessionOcdId.setText1(inventoryBarcode);
        tempSessionOcdId.setText2(storageContainerBarcode);
        tempSessionOcdId.setNumber1((long) row);
        tempSessionOcdId.setSortOrder(counter++);
        ocd.setId(tempSessionOcdId);
        currentSession.save(ocd);
    }

    public void flushAndClear(Session currentSession) {
        currentSession.flush();
        currentSession.clear();
    }

}
