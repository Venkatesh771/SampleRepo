package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.UnitOfMeasureGroup;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

public interface UnitOfMeasureGroupDao extends GenericDao<UnitOfMeasureGroup, Long> {

    @DynamicDaoMethod(queryName = "UnitOfMeasureGroupDao.findByName",
                      parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    UnitOfMeasureGroup findByName(@DynamicDaoParameter(name = "name") String name);
}
