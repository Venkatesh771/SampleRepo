package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.services.domain.breeding.uom.UnitOfMeasure;
import com.monsanto.tcc.inventoryservice.dao.UOMDao;
import com.monsanto.tps.dao.GenericDaoImpl;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: MDSPARK
 * Date: Sep 28, 2009
 * Time: 9:33:49 PM
 */
public class UOMDaoImpl extends GenericDaoImpl<UnitOfMeasure, Long> implements UOMDao {
    private static final String QUERY_NAME = "UnitOfMeasure.findByUomIds";
    private static final String UOM_ID_LIST_PARAM = "uomIdList";

    public UOMDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public List<UnitOfMeasure> findByIds(final List<Long> uomIdList) {
        return getSessionFactory().getCurrentSession().getNamedQuery(QUERY_NAME).setParameterList(UOM_ID_LIST_PARAM, uomIdList).list();
    }

    public String findByUomName(String name){
        return getSessionFactory().getCurrentSession().createSQLQuery("select uom_id from midas.uom where name = :name").setParameter("name",name).uniqueResult().toString();
    }

    public List<UnitOfMeasure> getSeedQuantityUOMs() {
        return null;
    }
}
