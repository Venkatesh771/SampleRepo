/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.containermanagement.export;

import com.monsanto.tcc.inventorycommon.transferobject.StorageType;
import com.monsanto.tcc.inventorycommon.transferobject.suinventory.ExportStorageContainer;
import com.monsanto.tcc.inventoryservice.dao.impl.ExportStorageContainerDao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* nbwald - Dec 21, 2010 */
public class StorageContainerExportStrategyFactory {

    private ExportStorageContainerDao exportStorageContainerDao;
    private final Map<StorageType, StorageContainerExportStrategy> exportStrategyByStorageType = new HashMap<StorageType, StorageContainerExportStrategy>();

    public StorageContainerExportStrategyFactory() {
        exportStrategyByStorageType.put(StorageType.SITE, new BySiteExport());
        exportStrategyByStorageType.put(StorageType.SUB_SITE, new BySubSiteExport());
        exportStrategyByStorageType.put(StorageType.SUB_SUB_SITE, new BySubSubSiteExport());
        exportStrategyByStorageType.put(StorageType.STORAGE_LOCATION, new ByStorageLocationExport());
        exportStrategyByStorageType.put(StorageType.STORAGE_CONTAINER, new ByStorageContainerExport());
        exportStrategyByStorageType.put(StorageType.DISCARD_STORAGE_CONTAINER, new ByStorageContainerExport());
        exportStrategyByStorageType.put(StorageType.DISCARD_STORAGE_LOCATION, new ByStorageLocationExport());
    }

    public StorageContainerExportStrategy getExportStrategy(StorageType storageType) {
        StorageContainerExportStrategy exportStrategy = exportStrategyByStorageType.get(storageType);
        if (exportStrategy == null) {
            throw new IllegalArgumentException("Cannot export storage type " + storageType);
        }
        return exportStrategy;
    }

    private class BySiteExport
            implements StorageContainerExportStrategy {
        @Override
        public List<ExportStorageContainer> export(long storageUnitId) {
            return exportStorageContainerDao.getExportStorageContainersBySiteId(storageUnitId);
        }
    }

    private class BySubSiteExport
            implements StorageContainerExportStrategy {
        @Override
        public List<ExportStorageContainer> export(long storageUnitId) {
            return exportStorageContainerDao.getExportStorageContainersBySubSiteId(storageUnitId);
        }
    }

    private class BySubSubSiteExport
            implements StorageContainerExportStrategy {
        @Override
        public List<ExportStorageContainer> export(long storageUnitId) {
            return exportStorageContainerDao.getExportStorageContainersBySubSubSiteId(storageUnitId);
        }
    }

    private class ByStorageLocationExport
            implements StorageContainerExportStrategy {
        @Override
        public List<ExportStorageContainer> export(long storageUnitId) {
            return exportStorageContainerDao.getExportStorageContainersByStorageLocationId(storageUnitId);
        }
    }

    private class ByStorageContainerExport
            implements StorageContainerExportStrategy {
        @Override
        public List<ExportStorageContainer> export(long storageUnitId) {
            return exportStorageContainerDao.getExportStorageContainersByStorageContainerId(storageUnitId);
        }
    }

    public void setExportStorageContainerDao(ExportStorageContainerDao exportStorageContainerDao) {
        this.exportStorageContainerDao = exportStorageContainerDao;
    }
}