package com.monsanto.tcc.inventoryservice.dao.impl;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.monsanto.services.domain.breeding.FateReason;
import com.monsanto.tcc.inventorycommon.domain.EventConstruct;
import com.monsanto.tcc.inventorycommon.domain.Inventory;
import com.monsanto.tcc.inventorycommon.domain.TempSessionOcd;
import com.monsanto.tcc.inventorycommon.domain.TempSessionOcdId;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tcc.inventorycommon.transferobject.BlendSummary;
import com.monsanto.tcc.inventorycommon.transferobject.FatedInventory;
import com.monsanto.tcc.inventorycommon.transferobject.InventoryProgramAccount;
import com.monsanto.tcc.inventoryservice.dao.InventoryDao;
import com.monsanto.tcc.inventoryservice.importing.ImportBarcodeRow;
import com.monsanto.tps.dao.GenericNamedEntityDaoImpl;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import org.hibernate.Query;
import org.hibernate.classic.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.LongType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.BatchSqlUpdate;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;

import static com.google.common.collect.Sets.newHashSet;

public class InventoryDaoImpl extends GenericNamedEntityDaoImpl<Inventory, Long> implements InventoryDao {

    @Resource(name = "jdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    private static final String INVENTORY_BY_BARCODE_TEMP_TABLE_QUERY = "Inventory.findByBarcodesJoinTempTable";
    private static final String GET_INVENTORY_BARCODES_ALREADY_ASSIGNED_TO_PLOTS = "GetInventoryBarcodesAlreadyAssignedToPlots";
    private static final String GET_INVENTORY_BARCODES_ALREADY_ASSIGNED_TO_ENTRIES = "GetInventoryBarcodesAlreadyAssignedToEntries";
    public static final String PROJECT_CREATION_QUERY = "ProjectCreationDao.findInventoryInPendingPedFixByBarcode";
    private static final String SESSION_ID_PARAM = "sessionId";
    private static final String SESSION_ID = "SESSION_ID";
    private static final int MAX_SESSION_ID = 99999999;
    private static final String REQUEST_ID = "requestId";
    private static final String INVENTORY_STATUS_REF_ID_PARAM = "inventoryStatusRefId";
    private static final String REJECTED_STATUS_REF_ID = "J";
    private static final String REJECTION_REASON_ID_PARAM = "rejectionReasonId";
    private static final String INVENTORY_ID_PARAM = "inventoryId";
    private static final String DISCARD_INVENTORY_RESET_QTY_QUERY = "update Midas.Inventory set storage_unit_display_dnml = :dnml, storage_unit_barcode = null, fate_reason_id= :fateReasonId , fate_reason_date= :fateReasonDate , quantity = 0 where inventory_id=:inventoryId";
    private static final String DISCARD_INVENTORY = "update Midas.Inventory set storage_unit_display_dnml = :dnml, storage_unit_barcode = null, fate_reason_id= :fateReasonId , fate_reason_date= :fateReasonDate where inventory_id=:inventoryId";
    private static final String MODIFIED_USER_NAME = "modifiedUserName";
    private static final String MODIFIED_DATE = "modifiedDate";

    public InventoryDaoImpl(String entityName) {
        super(entityName);
    }

    @SuppressWarnings({"unchecked"})
    public List<Inventory> getInventoryByPedigreeAndProg(String pedigree, String prog) {
        Query query = getNamedQuery("getInventoryByPedigreeAndProg");
        query.setString("pedigree", pedigree);
        query.setString("prog", prog);
        return query.list();
    }

    public Inventory getInventoryByBarcode(String barcode) throws QueryResultsException {
        Query query = getNamedQuery("getInventoryByBarcode");
        query.setString("barcode", barcode);
        List results = query.list();
        if (results.isEmpty()) {
            throw new QueryResultsException("Found NO results when getting Inventory By Barcode");
        } else if (results.size() == 1) {
            return (Inventory) results.get(0);
        }
        throw new QueryResultsException("Found MULTIPLE results when getting Inventory By Barcode");
    }

    @Override
    public List<InventoryProgramAccount> findInventoryProgramAccountIdFromBracode(List<String> barcodes) {
        int sessionId = getSessionId();
        insertStringsInTempTable(barcodes, sessionId);
        Session session = getCurrentSession();
        Query namedQuery = session.getNamedQuery("findInventoryProgramAccountIdFromBracode");
        Query query = namedQuery.setInteger(SESSION_ID_PARAM, sessionId);
        return query.list();
    }

    @Override
    public void bulkUpdateInventoryPreviewStatus(int sessionId) {
        Query query = getNamedQuery("bulkUpdateInventoriesToPreviewFalseJoiningTempTable");
        query.setInteger("sessionId", sessionId);
        query.executeUpdate();
    }

    @Override
    @SuppressWarnings({"unchecked"})
    public List<Inventory> findInventoryByBarcodes(Collection<String> barcodes) {
        int sessionId = getSessionId();
        insertStringsInTempTable(barcodes, sessionId);
        Session session = getCurrentSession();
        Query namedQuery = session.getNamedQuery(INVENTORY_BY_BARCODE_TEMP_TABLE_QUERY);
        Query query = namedQuery.setInteger(SESSION_ID_PARAM, sessionId);
        return query.list();
    }

    @SuppressWarnings({"unchecked"})
    @Transactional(propagation = Propagation.MANDATORY)
    public List<String> getInventoryBarcodesThatAreAlreadyAssignedToPlotsOrEntries(List<Long> inventoryIdList) {
        long sessionId = getSessionId();
        persistInventoryIdsIntoTempTable(inventoryIdList, sessionId);

        List<String> inventoryBarcodesAlreadyAssignedToPlots = getBarcodes(sessionId, GET_INVENTORY_BARCODES_ALREADY_ASSIGNED_TO_PLOTS);
        List<String> inventoryBarcodesAlreadyAssignedToEntries = getBarcodes(sessionId, GET_INVENTORY_BARCODES_ALREADY_ASSIGNED_TO_ENTRIES);

        return mergeResults(inventoryBarcodesAlreadyAssignedToPlots, inventoryBarcodesAlreadyAssignedToEntries);
    }

    @Override
    public List<ImportBarcodeRow> findInventoryLinkedToDifferentStorageContainer() {
        Query query = getSession().getNamedQuery("Inventory.findInventoryLinkedToDifferentStorageContainer");
        query.setParameter(REQUEST_ID, TempSessionTableHelper.STORAGE_UNIT_IMPORT_REQUEST_ID);
        query.setResultTransformer(Transformers.aliasToBean(ImportBarcodeRow.class));
        return query.list();
    }

    @Override
    public List<Inventory> getInventoryForProductNamePubKey(@DynamicDaoParameter(name = "lexProdNamePubKey") String oldProductNamePubKey) {
        return null;  //dynamic dao. see annotations in the interface
    }

    @Override
    public Collection<Inventory> getHydratedInventoriesById(@DynamicDaoParameter(name = "inventoryIds") Collection<Long> inventoryIds) {
        return null;  //dynamic dao. see annotations in the interface
    }

    @Override
    public List<Inventory> getInventoriesMatchingProgramAndPedigreeByInventoryId(@DynamicDaoParameter(name = "sourceInventoryId") Long inventoryId) {
        return null;  //dynamic dao. see annotations in the interface
    }

    @Override
    public List<EventConstruct> getActiveEventConstructs(@DynamicDaoParameter(name = "inventoryId") Long inventoryId) {
        return null; //Dynamic dao method
    }

    @Override
    public Inventory getNewestInventoryFromProductId(@DynamicDaoParameter(name = "id") Long geneticMaterialId) {
        return null; //Dynamic dao method
    }

    @Override
    public BlendSummary retrieveBlendedSummaryFromInventoryBarcode(@DynamicDaoParameter(name = "barcode") String barcode) {
        return null; //Dynamic dao method
    }


    @Override
    public List<Inventory> getPagedPendingDestructionInventoriesForPrograms(@DynamicDaoParameter(name = "programIds") Collection<Long> programIds,
                                                                            @DynamicDaoParameter(name = "startIndex") int startIndex,
                                                                            @DynamicDaoParameter(name = "pageSize") int pageSize) {
        return null;
    } // Dynamic dao method

    @Override
    public Inventory loadInventoryRecordForEventRemoval(@DynamicDaoParameter(name = "INVENTORY_ID") Long inventoryId) {
        return null; //Dynamic dao method
    }

    public BigDecimal getNextId() {
        return null; //Dynamic dao method
    }

    @Override
    public List<String> getPotentialTesters(Long inventoryId) {
        Set<String> uniquePedigrees = newHashSet();
        uniquePedigrees.addAll(getSessionFactory().getCurrentSession()
              .getNamedQuery("getPotentialTesters").setParameter("inventoryId", inventoryId).list());
        return new ArrayList(uniquePedigrees);
    }


    @Override
    public Collection<Inventory> getInventoriesByStorageContainerBarcodes(Collection<String> storageContainerBarcodes) {
        int sessionId = getSessionId();
        insertStringsInTempTable(storageContainerBarcodes, sessionId);
        Query query = getNamedQuery("Inventory.getInventoriesByStorageContainerBarcodes");
        query.setInteger(SESSION_ID_PARAM, sessionId);
        return query.list();
    }

    @Override
    public Collection<Inventory> getInventoriesByStorageContainerBarcode(String storageContainerBarcode) {
        Query query = getNamedQuery("Inventory.getInventoriesByStorageContainerBarcode");
        query.setString("storageContainerBarcode", storageContainerBarcode);
        return query.list();
    }

    @SuppressWarnings({"unchecked"})
    public List<Inventory> getInventoriesByIds(List<Long> inventoryIds) {
        if ((inventoryIds == null) || (inventoryIds.isEmpty())) {
            return new ArrayList<Inventory>();
        }

        int sessionId = getSessionId();
        insertInventoryIdsInTempTable(inventoryIds, sessionId);
        Query query = getNamedQuery("getInventoriesByIds");
        query.setInteger(SESSION_ID_PARAM, sessionId);
        return query.list();
    }

    @Override
    public void fateAndEmptyInventory(Collection<Long> inventoryIds, FateReason fateReason) {
        long requestId = 621721;
        insertInventoryIdsInTempTable(inventoryIds, requestId);
        Query query = getNamedQuery("Inventory.fateAndEmptyInventory");
        query.setParameter(REQUEST_ID, requestId);
        query.setParameter("fateReasonDate", new Date());
        query.setParameter("fateReasonId", fateReason.getFateReasonId());
        query.executeUpdate();
    }

    @Override
    public void clearInventoryQuantityAndUom(Collection<Long> inventoryIds) {
        long requestId = 621721;
        insertInventoryIdsInTempTable(inventoryIds, requestId);
        Query query = getNamedQuery("Inventory.clearInventoryQuantityAndUom");
        query.setParameter(REQUEST_ID, requestId);
        query.executeUpdate();
    }

    @Override
    public void updateInventoryDnml(long storageContainerId, String newDnml) {
        Query query = getSession().getNamedQuery("Inventory.updateInventoryDnml");
        query.setParameter("storageContainerId", storageContainerId);
        query.setParameter("newDnml", newDnml);
        query.executeUpdate();
    }

    public void clearInventoryDnml(Collection<Long> inventoryIds) {
        long requestId = 48393;
        insertInventoryIdsInTempTable(new ArrayList<Long>(inventoryIds), requestId);
        Query query = getSession().getNamedQuery("Inventory.clearInventoryDnml");
        query.setParameter(REQUEST_ID, requestId);
        query.executeUpdate();
    }

    @Override
    public void clearBarcodeAndSetDnml(String dnml, TempSessionRequest tempSessionRequest) {
        Query query = getSession().getNamedQuery("Inventory.clearBarcodeAndSetDnml");
        query.setParameter("dnml", dnml);
        query.setParameter(REQUEST_ID, tempSessionRequest.getRequestId());
        query.executeUpdate();
    }


    @Override
    public void updateDiscardedInventoryAndResetQuantity(String dnml, List<FatedInventory> fatedInventories) {
        BatchSqlUpdate batchSqlUpdate = createDiscardBatchSqlUpdate(DISCARD_INVENTORY_RESET_QTY_QUERY);
        for (FatedInventory fatedInventory : fatedInventories) {
            batchSqlUpdate.update(dnml, fatedInventory.getFateReason().getFateReasonId(), fatedInventory.getFateDate(), fatedInventory.getInventoryId());
        }
        batchSqlUpdate.flush();
    }

    private BatchSqlUpdate createDiscardBatchSqlUpdate(String query) {
        BatchSqlUpdate batchSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(), query);
        batchSqlUpdate.declareParameter(new SqlParameter("dnml", Types.VARCHAR));
        batchSqlUpdate.declareParameter(new SqlParameter("fateReasonId", Types.BIGINT));
        batchSqlUpdate.declareParameter(new SqlParameter("fateReasonDate", Types.DATE));
        batchSqlUpdate.declareParameter(new SqlParameter("inventoryId", Types.BIGINT));
        return batchSqlUpdate;
    }

    public void updateDiscardedInventory(String dnml, List<FatedInventory> fatedInventories, String query) {
        BatchSqlUpdate batchSqlUpdate = createDiscardBatchSqlUpdate(query);
        for (FatedInventory fatedInventory : fatedInventories) {
            batchSqlUpdate.update(dnml, fatedInventory.getFateReason().getFateReasonId(), fatedInventory.getFateDate(), fatedInventory.getInventoryId());
        }
        batchSqlUpdate.flush();
    }

    public void updateDiscardedInventoryWithoutQuantityChange(String dnml, List<FatedInventory> fatedInventories) {
        updateDiscardedInventory(dnml, fatedInventories, DISCARD_INVENTORY);
    }

    public void undoDiscardedInventoryAndSetQuantity(String dnml, TempSessionRequest tempSessionRequest, Double seedQuantity) {
        Query query = getSession().getNamedQuery("Inventory.undoDiscardedInventoryAndSetQuantity");
        query.setParameter("dnml", dnml);
        query.setParameter("seedQuantity", seedQuantity);
        query.setParameter(REQUEST_ID, tempSessionRequest.getRequestId());
        query.executeUpdate();
    }

    public void undoDiscardedInventory(String dnml, TempSessionRequest tempSessionRequest) {
        Query query = getSession().getNamedQuery("Inventory.undoDiscardedInventory");
        query.setParameter("dnml", dnml);
        query.setParameter(REQUEST_ID, tempSessionRequest.getRequestId());
        query.executeUpdate();
    }


    @Override
    public List<String> getInventoriesAssociatedWithPendingShipment(TempSessionRequest tempSessionRequest) {
        Query query = getSession().getNamedQuery("InventoryDao.getInventoriesAssociatedWithPendingShipment");
        query.setParameter(REQUEST_ID, tempSessionRequest.getRequestId());
        return query.list();
    }

    public void accept(List<Long> inventoryIds, TempSessionRequest tempSessionRequest, String modifiedUserName, Date modifiedDate) {
        Query query = getSession().getNamedQuery("Inventory.accept");
        query.setParameter(REQUEST_ID, tempSessionRequest.getRequestId());
        insertModifiedUserAndDateInQuery(query, modifiedUserName, modifiedDate);
        query.executeUpdate();
    }

    public void reject(long inventoryId, Long rejectionReasonId, String modifiedUserName, Date modifiedDate) {
        Query query = getSession().getNamedQuery("Inventory.rejectInventoryWithReasonId");
        query.setString(INVENTORY_STATUS_REF_ID_PARAM, REJECTED_STATUS_REF_ID);
        query.setLong(INVENTORY_ID_PARAM, inventoryId);
        query.setParameter(REJECTION_REASON_ID_PARAM, rejectionReasonId, new LongType());
        insertModifiedUserAndDateInQuery(query, modifiedUserName, modifiedDate);
        query.executeUpdate();
    }

    public void undoReject(List<Long> inventoryIds, TempSessionRequest tempSessionRequest, String modifiedUserName, Date modifiedDate) {
        Query query = getSession().getNamedQuery("Inventory.undoReject");
        query.setParameter(REQUEST_ID, tempSessionRequest.getRequestId());
        insertModifiedUserAndDateInQuery(query, modifiedUserName, modifiedDate);
        query.executeUpdate();
    }

    public void undoRejectAndAccept(List<Long> inventoryIds, TempSessionRequest tempSessionRequest, String modifiedUserName, Date modifiedDate) {
        Query query = getSession().getNamedQuery("Inventory.undoRejectAndAccept");
        query.setParameter(REQUEST_ID, tempSessionRequest.getRequestId());
        insertModifiedUserAndDateInQuery(query, modifiedUserName, modifiedDate);
        query.executeUpdate();
    }

    @Override
    public List<String> findInventoryInPendingPedFixByBarcode(List<String> inventoryBarcodes) {
        List<String> results = Lists.newArrayList();
        Iterable<List<String>> barcodePartitions = Iterables.partition(inventoryBarcodes, 1000);
        for (List<String> barcodePartition : barcodePartitions) {
            Query namedQuery = getSessionFactory().getCurrentSession().getNamedQuery(PROJECT_CREATION_QUERY);
            namedQuery.setParameterList("inventoryBarcodes", barcodePartition);
            results.addAll(namedQuery.list());
        }
        return results;
    }

    @Override
    public boolean isProgramNeedsToBeSynced(List programList) {
        Query query = getNamedQuery("Inventory.doesProgramNeedsToBeSynced");
        query.setParameterList("programId", programList);
        if (((BigDecimal)query.uniqueResult()).intValue()!=0) {
            return true;
        }
        return false;
    }

    @Override
    public void updateToBeDestroyedFlag(List<Long> inventoryIds) {
      Query query = getSession().getNamedQuery("Inventory.updateToBeDestroyedFlag");
      int sessionId = getSessionId();
      persistInventoryIdsIntoTempTable(inventoryIds, sessionId);
      query.setParameter(SESSION_ID_PARAM, sessionId);
      query.executeUpdate();
    }

    private void insertModifiedUserAndDateInQuery(Query query, String modifiedUserName, Date modifiedDate) {
        query.setParameter(MODIFIED_DATE, modifiedDate);
        query.setParameter(MODIFIED_USER_NAME, modifiedUserName);
    }

    private List getBarcodes(long sessionId, String queryName) {
        Query namedQuery = getCurrentSession().getNamedQuery(queryName);
        namedQuery.setParameter(SESSION_ID, sessionId);
        return namedQuery.list();
    }

    private List<String> mergeResults(List<String> inventoryBarcodesAlreadyAssignedToPlots, List<String> inventoryBarcodesAlreadyAssignedToEntries) {
        for (String inventoryBarcode : inventoryBarcodesAlreadyAssignedToEntries) {
            if (!inventoryBarcodesAlreadyAssignedToPlots.contains(inventoryBarcode)) {
                inventoryBarcodesAlreadyAssignedToPlots.add(inventoryBarcode);
            }
        }
        return inventoryBarcodesAlreadyAssignedToPlots;
    }

    private void persistInventoryIdsIntoTempTable(List<Long> inventoryIdList, long tempTableSessionId) {
        for (Long inventoryId : inventoryIdList) {
            jdbcTemplate.execute("INSERT INTO MIDAS.TEMP_SESSION_OCD (REQUEST_ID, NUMBER_1) VALUES (" + tempTableSessionId + ", " + inventoryId + ")");
        }
    }

    private int getSessionId() {
        return (int) (Math.random() * MAX_SESSION_ID);
    }

    private void insertStringsInTempTable(Collection<String> values, int sessionId) {
        Long sortOrder = 1L;
        for (String value : values) {
            TempSessionOcd ocd = new TempSessionOcd();
            TempSessionOcdId tempSessionOcdId = new TempSessionOcdId();
            tempSessionOcdId.setRequestId((long) sessionId);
            tempSessionOcdId.setText1(value);
            tempSessionOcdId.setSortOrder(sortOrder++);
            ocd.setId(tempSessionOcdId);
            getCurrentSession().save(ocd);
        }
    }

    private void insertInventoryIdsInTempTable(Collection<Long> inventoryIds, long sessionId) {
        Long sortOrder = 1L;
        for (Long inventoryId : inventoryIds) {
            TempSessionOcd ocd = new TempSessionOcd();
            TempSessionOcdId tempSessionOcdId = new TempSessionOcdId();
            tempSessionOcdId.setRequestId(sessionId);
            tempSessionOcdId.setNumber1(inventoryId);
            tempSessionOcdId.setSortOrder(sortOrder++);
            ocd.setId(tempSessionOcdId);
            getCurrentSession().save(ocd);
        }
    }

    private Query getNamedQuery(String queryName) {
        return getSession().getNamedQuery(queryName);
    }

    private Session getCurrentSession() {
        return getSessionFactory().getCurrentSession();
    }
}
