package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.ProductName;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tcc.inventorycommon.transferobject.BlendProductNameFilter;
import com.monsanto.tcc.inventorycommon.transferobject.BlendProductNameTransferObject;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 17, 2009
 * Time: 10:03:00 AM
 */
public interface ProductNameDao extends GenericDao<ProductName, Long> {
    public ProductName getProductNameByLexProductPubKey(String lexPubKey) throws QueryResultsException;

    public ProductName getProductNameByLexProductNamePubKey(String lexPubKey) throws QueryResultsException;

    List<BlendProductNameTransferObject> getPreCommercialProductNameByBrandName(BlendProductNameFilter filter);

    @DynamicDaoMethod(queryName = "getAllPreCommercialProductNameByBrandName")
    List<BlendProductNameTransferObject> getAllPreCommercialProductNameByBrandName();

    List<Long> getProductNameIdsWithSameCombination(Long brandId, Long countryId, String name);
}
