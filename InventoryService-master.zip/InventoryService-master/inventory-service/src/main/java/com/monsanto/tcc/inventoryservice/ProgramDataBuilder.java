package com.monsanto.tcc.inventoryservice;

import com.monsanto.services.domain.breeding.Program;
import com.monsanto.services.domain.breeding.ProgramSummary;
import com.monsanto.tcc.inventorycommon.domain.ProgramGermplasmManagerRole;
import com.monsanto.tcc.inventorycommon.domain.SiteTO;
import com.monsanto.tcc.inventorycommon.transferobject.ProgramSite;
import com.monsanto.tcc.inventoryservice.dao.ProgramSiteXRefDao;
import com.monsanto.tcc.inventoryservice.materialexchange.Contacts;
import com.monsanto.tcc.inventoryservice.program.ProgramData;
import org.hibernate.Query;
import org.hibernate.SessionFactory;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Aug 5, 2009
 * Time: 3:03:57 PM
 */
public class ProgramDataBuilder {
    private SessionFactory sessionFactory;
    private ProgramSiteXRefDao programSiteXRefDao;
    private Contacts contacts;

    public ProgramData buildProgramsData(Long cropId) {
        Query query = sessionFactory.getCurrentSession().getNamedQuery("getProgramsByCropsWithGermplasmManagerRoleSummary");
        query.setLong("cropId", cropId);
        List<ProgramGermplasmManagerRole> list = query.list();
        return buildProgramData(list);
    }

    private ProgramData buildProgramData(List<ProgramGermplasmManagerRole> list) {
        ProgramData programData = new ProgramData();
        for (ProgramGermplasmManagerRole programGermplasmManagerRole : list) {
            Program program = buildProgram(programGermplasmManagerRole);
            programData.add(program);
            List<SiteTO> sites = programSiteXRefDao.getAllSitesByProgRefId(program.getProgramRefId());
            addProgramSites(programData, program, sites);
            ProgramSummary programSummary = new ProgramSummary();
            programSummary.setBrProgId(programGermplasmManagerRole.getBr_prog_id());
            programSummary.setHasGerplasmManagerRole(getBoolean(programGermplasmManagerRole.getHAS_GERMPLASM_MANAGER_ROLE()));
            programData.add(programSummary);
        }
        programData.buildProgramContacts(contacts.find(programData.getPrograms()));
        return programData;
    }

    private void addProgramSites(ProgramData programData, Program program, List<SiteTO> sites) {
        if(sites.isEmpty()) {
            programData.add(programSite(program, null));
        }
        for (SiteTO site : sites) {
            programData.add(programSite(program, site));
        }
    }

    private ProgramSite programSite(Program program, SiteTO site) {
        ProgramSite programSite = new ProgramSite();
        programSite.setProgram(program);
        programSite.setSite(site);
        return programSite;
    }

    private Program buildProgram(ProgramGermplasmManagerRole programGermplasmManagerRole) {
        Program program = new Program();
        program.setMailStop(programGermplasmManagerRole.getMail_stop());
        program.setRefActive(programGermplasmManagerRole.getRef_active());
        program.setProgramRefId(programGermplasmManagerRole.getBr_prog_ref_id());
        program.setProgramId(programGermplasmManagerRole.getBr_prog_id());
        program.setName(programGermplasmManagerRole.getName());
        program.setCropId(programGermplasmManagerRole.getCrop_id());
        program.setMidasProgram(programGermplasmManagerRole.getMidas_program());
        program.setAcctId(programGermplasmManagerRole.getAcct_id());
        return program;
    }

    private boolean getBoolean(Long has_germplasm_manager_role) {
        return has_germplasm_manager_role == 1;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void setProgramSiteXRefDao(ProgramSiteXRefDao programSiteXRefDao) {
        this.programSiteXRefDao = programSiteXRefDao;
    }

    public void setContacts(Contacts contacts) {
        this.contacts = contacts;
    }
}
