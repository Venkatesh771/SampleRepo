package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.MaterialRequestDetail;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: jjbens2
 * Date: May 11, 2010
 * Time: 10:18:47 AM
 */
public interface MaterialRequestDetailDao extends GenericDao<MaterialRequestDetail, Long> {

    public List<MaterialRequestDetail> getAllMaterialRequestDetailsForRequest(Long materialRequestId) throws QueryResultsException;

    public List<MaterialRequestDetail> getAllMaterialRequestDetailsMatchingTempTableById(Collection<Long> programIds, int tempSessionId) throws QueryResultsException;

    @DynamicDaoMethod(queryName = "getMaterialRequestIdForDetailId", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public Long getMaterialRequestIdForDetailId(@DynamicDaoParameter(name = "materialRequestDetailId") Long materialRequestDetailId) throws QueryResultsException;
}
