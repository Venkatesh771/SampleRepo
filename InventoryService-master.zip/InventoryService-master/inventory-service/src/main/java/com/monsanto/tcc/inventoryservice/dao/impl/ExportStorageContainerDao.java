/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.transferobject.suinventory.ExportStorageContainer;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.transform.Transformers;

import java.util.List;

/* nbwald - Dec 20, 2010 */
public class ExportStorageContainerDao {

    private SessionFactory sessionFactory;

    public List<ExportStorageContainer> getExportStorageContainersBySiteId(long siteId) {
        return getExportStorageContainersBySUId("ExportStorageContainer.getExportStorageContainersBySiteId", siteId);
    }

    public List<ExportStorageContainer> getExportStorageContainersBySubSiteId(long subSiteId) {
        return getExportStorageContainersBySUId("ExportStorageContainer.getExportStorageContainersBySubSiteId", subSiteId);
    }

    public List<ExportStorageContainer> getExportStorageContainersBySubSubSiteId(Long subSubSiteId) {
        return getExportStorageContainersBySUId("ExportStorageContainer.getExportStorageContainersBySubSubSiteId", subSubSiteId);
    }

    public List<ExportStorageContainer> getExportStorageContainersByStorageLocationId(Long storageLocationId) {
        return getExportStorageContainersBySUId("ExportStorageContainer.getExportStorageContainersByStorageLocationId", storageLocationId);
    }

    public List<ExportStorageContainer> getExportStorageContainersByStorageContainerId(Long storageContainerId) {
        Query query = getQuery("ExportStorageContainer.getExportStorageContainersByStorageContainerId");
        query.setParameter("parentStorageContainerIdPath",  "%!" + storageContainerId + "!%");
        query.setParameter("leafStorageContainerIdPath",  "%!" + storageContainerId);
        return query.list();
    }

    private List<ExportStorageContainer> getExportStorageContainersBySUId(String queryName, long storageUnitId) {
        Query query = getQuery(queryName);
        query.setParameter("storageUnitId", storageUnitId);
        return query.list();
    }

    private Query getQuery(String queryName) {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.getNamedQuery(queryName);
        query.setResultTransformer(Transformers.aliasToBean(ExportStorageContainer.class));
        return query;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}