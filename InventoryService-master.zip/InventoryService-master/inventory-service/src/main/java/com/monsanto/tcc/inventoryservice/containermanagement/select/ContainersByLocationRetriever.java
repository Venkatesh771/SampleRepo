package com.monsanto.tcc.inventoryservice.containermanagement.select;

import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;

import java.util.Collection;

public class ContainersByLocationRetriever extends AbstractStorageLocationAndContainerRetriever {
    private HasInventoryStorageContainerDecorator hasInventoryStorageContainerDecorator;

    @Override
    public Collection<StorageUnitTO> retrieve(Long parentLocationId) {
        Collection<StorageContainer> storageContainers = getManageContainersDaoProvider().getStorageContainerDao().getStorageContainersByStorageLocationId(parentLocationId);
        hasInventoryStorageContainerDecorator.decorate(storageContainers);
        return buildObjects(storageContainers, StorageUnitTO.class);
    }

    public void setHasInventoryStorageContainerDecorator(HasInventoryStorageContainerDecorator hasInventoryStorageContainerDecorator) {
        this.hasInventoryStorageContainerDecorator = hasInventoryStorageContainerDecorator;
    }
}
