package com.monsanto.tcc.inventoryservice.genericparameters;

import java.util.Collection;

/**
 * User: Mark D. Sparks
 * Date: 8/15/11
 * Time: 4:15 PM
 */
public interface GenericParametersBo {
    Long createGenericParameters(Collection<GenericParameters> genericParametersList);
}
