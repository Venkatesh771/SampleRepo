package com.monsanto.tcc.inventoryservice.containermanagement.create;

import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventorycommon.domain.StorageContainerLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageLocationCatalog;
import com.monsanto.tcc.inventoryservice.dao.StorageLocationCatalogDao;
import com.monsanto.tcc.inventoryservice.dao.StorageLocationDao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: ssnall
 * Date: Mar 20, 2010
 * Time: 4:07:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class CreateStorageLocationCatalogBO {

    private StorageLocationDao storageLocationDao;
    private StorageLocationCatalogDao storageLocationCatalogDao;

    public Collection<StorageContainer> process(Collection<StorageLocationCatalog> newStorageLocationCatalogs) {
        Collection<StorageContainer> storageContainers = new ArrayList<StorageContainer>();
        Map<StorageLocation, Collection<StorageLocationCatalog>> storageLocationCatalogsByParentMap = buildStorageLocationCatalogsByParentMap(newStorageLocationCatalogs);
        for (Map.Entry currentItem : storageLocationCatalogsByParentMap.entrySet()) {
            StorageLocation storageLocation = (StorageLocation) currentItem.getKey();
            Collection<StorageLocationCatalog> storageLocationCatalogCollection = (Collection<StorageLocationCatalog>) currentItem.getValue();
            Long maxPositionIndex = getMaxPositionIndex(storageLocation.getStorageLocationCatalogsByStorageLocationId());
            for (StorageLocationCatalog storageLocationCatalog : storageLocationCatalogCollection) {
                maxPositionIndex++;
                setRequiredAttributes(storageLocationCatalog, storageLocation, maxPositionIndex);
                getStorageLocationCatalogDao().saveOrUpdate(storageLocationCatalog);
                Collection<StorageContainerLocation> containerLocationCollection = storageLocationCatalog.getStorageContainerLocationsByStorageLocationCatalogId();
                storageContainers.add(containerLocationCollection.iterator().next().getStorageContainerByStorageContainerId());
            }
        }
        return storageContainers;
    }

    private Map<StorageLocation, Collection<StorageLocationCatalog>> buildStorageLocationCatalogsByParentMap(Collection<StorageLocationCatalog> newStorageLocationCatalogs) {
        Map<StorageLocation, Collection<StorageLocationCatalog>> storageLocationCatalogsByParentMap = new HashMap<StorageLocation, Collection<StorageLocationCatalog>>();
        for (StorageLocationCatalog newStorageLocationCatalog : newStorageLocationCatalogs) {
            StorageLocation storageLocation = getStorageLocation(newStorageLocationCatalog);
            Collection<StorageLocationCatalog> storageLocationCatalogCollection = storageLocationCatalogsByParentMap.get(storageLocation);
            if (storageLocationCatalogCollection == null) {
                storageLocationCatalogCollection = new ArrayList<StorageLocationCatalog>();
                storageLocationCatalogsByParentMap.put(storageLocation, storageLocationCatalogCollection);
            }
            storageLocationCatalogsByParentMap.get(storageLocation).add(newStorageLocationCatalog);
        }

        return storageLocationCatalogsByParentMap;
    }

    private void setRequiredAttributes(StorageLocationCatalog storageLocationCatalog, StorageLocation storageLocation, Long positionIndex) {
        storageLocationCatalog.setStorageLocation(storageLocation);
        storageLocationCatalog.setPositionIndex(positionIndex);
    }

    private Long getMaxPositionIndex(Collection<StorageLocationCatalog> storageLocationCatalogCollection) {
        Long maxPositionIndex = 0L;
        for (StorageLocationCatalog storageLocationCatalog : storageLocationCatalogCollection) {
            if (maxPositionIndex < storageLocationCatalog.getPositionIndex()) {
                maxPositionIndex = storageLocationCatalog.getPositionIndex();
            }
        }
        return maxPositionIndex;
    }

    private StorageLocation getStorageLocation(StorageLocationCatalog storageLocationCatalog) {
        return getStorageLocationDao().load(storageLocationCatalog.getStorageLocationId());
    }


    public StorageLocationDao getStorageLocationDao() {
        return storageLocationDao;
    }

    public void setStorageLocationDao(StorageLocationDao storageLocationDao) {
        this.storageLocationDao = storageLocationDao;
    }

    public StorageLocationCatalogDao getStorageLocationCatalogDao() {
        return storageLocationCatalogDao;
    }

    public void setStorageLocationCatalogDao(StorageLocationCatalogDao storageLocationCatalogDao) {
        this.storageLocationCatalogDao = storageLocationCatalogDao;
    }
}
