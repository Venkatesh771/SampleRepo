package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.DestructionMethod;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

import java.util.List;

public interface DestructionMethodDao extends GenericDao<DestructionMethod, Long> {

    @DynamicDaoMethod(queryName = "getByRefId", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public DestructionMethod getByRefId(@DynamicDaoParameter(name = "refId") String refId);

    @DynamicDaoMethod(queryName = "getActiveMethods")
    public List<DestructionMethod> getActiveMethods();
}
