package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.services.domain.breeding.Program;
import com.monsanto.services.domain.breeding.program.MidasProgram;
import com.monsanto.tcc.inventoryservice.dao.ProgramDao;
import com.monsanto.tps.dao.GenericNamedEntityDaoImpl;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.List;

public class ProgramDaoImpl extends GenericNamedEntityDaoImpl<Program, Long> implements ProgramDao {

    public ProgramDaoImpl(String entityName) {
        super(entityName);
    }

    @Override
    public Collection<Program> getProgramsByRefIds(@DynamicDaoParameter(name = "programRefIds") Collection<String> programRefIds) {
        return null;
    }

    @Override
    public Collection<Program> getProgramsByCropIds(@DynamicDaoParameter(name = "cropIds") Collection<Long> cropIds) {
        return null;
    }

    @Override
    public List<Program> getShareablePrograms(@DynamicDaoParameter(name = "programId") long programId) {
        return null;
    }

    @Override
    public boolean programsAreSharedPrograms(List<Long> programIds) {
        Query query = getSession().getNamedQuery("ProgramDao.CheckIfShareableProgramByProgramIds");
        query.setParameterList("programId", programIds);
        return !CollectionUtils.isEmpty(query.list());
    }

    @Override
    public List<MidasProgram> getMidasPrograms(String userName) {
        Query query = getSession().getNamedQuery("ProgramDao.getMidasProgramByUser");
        query.setResultTransformer(Transformers.aliasToBean(MidasProgram.class));
        query.setParameter("userName", userName);
        return query.list();
    }
}
