package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.LineFunction;
import com.monsanto.tcc.inventoryservice.dao.LineFunctionDao;
import com.monsanto.tcc.inventoryservice.linefunctions.InventorySelectionAdvancement;
import com.monsanto.tps.dao.GenericNamedEntityDaoImpl;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import org.hibernate.Query;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: DYSONA
 * Date: 4/23/12
 * Time: 8:14 AM
 */
public class LineFunctionDaoImpl extends GenericNamedEntityDaoImpl<LineFunction, Long>  implements LineFunctionDao {


    public LineFunctionDaoImpl(String entityName) {
        super(entityName);
    }

    @Override
    public String getInventoryLineFunction(@DynamicDaoParameter(name = "plotId") Long plotId) {
        return null;  //Dynamic Dao Method
    }

//    @Override
//    public Map<Long, String> getInventoryLineFunction(List<Long> plotIds) {
//        Map<Long, String> plotToLineFunctionNameMap = new HashMap<Long, String>();
//        Query query = getSession().getNamedQuery("LineFunctionDao.getInventoryLineFunction");
//        query.setParameter("plotIds", plotIds);
//        List<Object[]> result = query.list();
//        if(!CollectionUtils.isEmpty(result)) {
//            for (Object[] resultRow : result) {
//                plotToLineFunctionNameMap.put((Long)resultRow[0], (String) resultRow[1]);
//            }
//        }
//        return plotToLineFunctionNameMap;
//    }

    @Override
    public InventorySelectionAdvancement getInventorySelectionAdvancement(Long inventoryId) {
        return null;  //Dynamic Dao Method
    }

    @Override
    public List<LineFunction> getLineFunctions(List<String> lineFunctionNames) {
        return null;  //Dynamic Dao Method
    }

    @Override
    public void updateLineFunction(Long inventoryId, String lineFunctionName) {
        Query query = getSession().getNamedQuery("LineFunctionDao.updateLineFunction");
        query.setParameter("lineFunctionName", lineFunctionName);
        query.setParameter("inventoryId", inventoryId);
        query.executeUpdate();
    }
}
