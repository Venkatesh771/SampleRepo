/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.containermanagement.export;

import com.monsanto.tcc.inventorycommon.transferobject.StorageType;
import com.monsanto.tcc.inventorycommon.transferobject.suinventory.ExportStorageContainer;

import java.util.List;

/* nbwald - Dec 20, 2010 */
public class StorageContainerExport {
    private StorageContainerExportStrategyFactory strategyFactory;

    public List<ExportStorageContainer> export(long storageUnitId, StorageType storageType) {
        StorageContainerExportStrategy exportStrategy = strategyFactory.getExportStrategy(storageType);
        return exportStrategy.export(storageUnitId);
    }

    public void setStorageContainerExportStrategyFactory(StorageContainerExportStrategyFactory strategyFactory) {
        this.strategyFactory = strategyFactory;
    }
}