package com.monsanto.tcc.inventoryservice.genericparameters;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;

import java.io.Serializable;
import java.util.Date;

/**
 * User: Mark D. Sparks
 * Date: 8/24/11
 * Time: 10:59 AM
 */
public class ModifiedTimestampGenerator implements IdentifierGenerator {
    @Override
    public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
        return new Date(System.currentTimeMillis());
    }
}
