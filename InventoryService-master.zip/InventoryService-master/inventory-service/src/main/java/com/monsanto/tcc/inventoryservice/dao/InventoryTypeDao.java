package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.services.domain.breeding.InventoryType;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tps.dao.GenericDao;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 18, 2009
 * Time: 3:21:02 PM
 */
public interface InventoryTypeDao extends GenericDao<InventoryType, Long> {
    public InventoryType getActiveHybridInventoryTypeForCropId(Long cropId) throws QueryResultsException;
    public List<InventoryType> getInventoryTypesByCropId(Long cropId) throws QueryResultsException;
}
