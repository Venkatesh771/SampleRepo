/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.containermanagement.move;

import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;
import com.monsanto.tcc.inventorycommon.transferobject.ResponseMessage;
import com.monsanto.tcc.inventorycommon.transferobject.ResponseMessageType;

import java.util.List;

/* nbwald - Nov 2, 2010 */
public class StorageUnitMovement
{
    private List<StorageUnitMovementStrategy> storageUnitMovementStrategies;

    public ResponseMessage move(StorageUnitTO moved, StorageUnitTO to) {
        for (StorageUnitMovementStrategy movementStrategy : storageUnitMovementStrategies) {
            if(movementStrategy.isApplicableTo(moved, to)) {
                movementStrategy.move(moved, to);
                return new ResponseMessage();
            }
        }
        return new ResponseMessage(ResponseMessageType.ERROR, "Invalid move scenario: move " + moved.getId() + " to " + to.getId());
    }

    public void setStorageUnitMovementStrategies(List<StorageUnitMovementStrategy> storageUnitMovementStrategies) {
        this.storageUnitMovementStrategies = storageUnitMovementStrategies;
    }
}