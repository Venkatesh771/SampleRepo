package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.services.domain.protocol.MidasUser;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: Mar 30, 2010
 * Time: 5:06:56 PM
 * To change this template use File | Settings | File Templates.
 */
public interface MidasUserDao extends GenericDao<MidasUser, Long> {
    @DynamicDaoMethod(queryName = "MidasUserDao.getMidasUserWithLoginId", parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    public MidasUser getMidasUserWithLoginId(@DynamicDaoParameter(name = "loginId") String loginId);
}
