package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.CropProgPref;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tps.dao.GenericDao;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 18, 2009
 * Time: 10:35:00 AM
 */
public interface CropProgPrefDao extends GenericDao<CropProgPref, Long> {
    public CropProgPref getCropProgPrefByProductId(Long productId) throws QueryResultsException;
}
