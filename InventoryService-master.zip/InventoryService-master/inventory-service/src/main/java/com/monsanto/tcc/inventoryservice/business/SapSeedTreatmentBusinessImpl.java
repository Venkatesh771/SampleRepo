package com.monsanto.tcc.inventoryservice.business;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.databuilder.QueryBuildingException;
import com.monsanto.tcc.inventorycommon.transferobject.SapSeedTreatment;
import com.monsanto.tcc.inventorycommon.transferobject.SapSeedTreatmentInput;
import com.monsanto.tcc.inventorycommon.transferobject.SapSeedTreatmentResponse;
import com.monsanto.tcc.inventoryservice.annotations.Business;
import com.monsanto.tcc.inventoryservice.dao.SeedTreatmentDao;
import com.monsanto.tps.architecture.transformer.DozerObjectTransformer;
import com.monsanto.tps.regulatory.traitquality.sap.BatchInformationService;
import com.monsanto.tps.regulatory.traitquality.sap.batch.BatchTreatmentRequest;
import com.monsanto.tps.regulatory.traitquality.sap.batch.BatchTreatmentResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;

@Business
public class SapSeedTreatmentBusinessImpl implements SapSeedTreatmentBusiness {
    private Log logger = LogFactory.getLog(SapSeedTreatmentBusinessImpl.class);

    @Resource
    private BatchInformationService sapBatchInformationService;
    @Resource
    private DozerObjectTransformer objectTransformer;
    @Resource
    private SeedTreatmentDao seedTreatmentDao;

    @Override
    public SapSeedTreatmentResponse getSapSeedTreatments(List<Long> inventoryIds) throws QueryBuildingException, WrappingException {
        BatchTreatmentResponse batchTreatmentResponse = null;

        List<SapSeedTreatmentInput> inputs = seedTreatmentDao.getSeedTreatmentInfo(inventoryIds);
        if (!CollectionUtils.isEmpty(inputs)) {
            List<BatchTreatmentRequest> batchTreatmentRequests = (List<BatchTreatmentRequest>) objectTransformer.buildObjects(inputs, BatchTreatmentRequest.class);
            batchTreatmentResponse = callTQService(batchTreatmentRequests);
            logErrors(batchTreatmentResponse);
        }
        return buildResponse(batchTreatmentResponse);
    }

    private BatchTreatmentResponse callTQService(List<BatchTreatmentRequest> batchTreatmentRequests) {
        try{
            return sapBatchInformationService.findTreatmentsForBatches(batchTreatmentRequests);
        }catch(Exception e){
            logger.error("Error calling TQ BatchInformationService: ", e);
            return null;
        }
    }

    private SapSeedTreatmentResponse buildResponse(BatchTreatmentResponse batchTreatmentResponse) {
        SapSeedTreatmentResponse sapSeedTreatmentResponse = new SapSeedTreatmentResponse();
        if (batchTreatmentResponse != null) {
            List<SapSeedTreatment> sapSeedTreatments = (List<SapSeedTreatment>) objectTransformer.buildObjects(batchTreatmentResponse.getTreatments(), SapSeedTreatment.class);
            sapSeedTreatmentResponse.setSapSeedTreatments(sapSeedTreatments);
        }
        return sapSeedTreatmentResponse;
    }

    private void logErrors(BatchTreatmentResponse batchTreatmentResponse) {
        if (batchTreatmentResponse != null && batchTreatmentResponse.hasErrors()) {
            logger.error("Error retrieving SAP treatment data :");
            for (String error : batchTreatmentResponse.getErrors()) {
                logger.error(error);
            }
        }
    }
}