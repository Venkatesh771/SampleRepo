package com.monsanto.tcc.inventoryservice.containermanagement.create;

import com.monsanto.tcc.inventorycommon.domain.StorageLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;
import com.monsanto.tcc.inventoryservice.dao.StorageLocationDao;
import com.monsanto.tcc.inventoryservice.inventory.util.ManageContainersDaoProvider;
import com.monsanto.tcc.inventoryservice.service.handler.StorageLocationTranslator;
import com.monsanto.tps.architecture.transformer.DozerObjectTransformer;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 8, 2010
 * Time: 10:59:05 AM
 * To change this template use File | Settings | File Templates.
 */
public class StorageLocationManager implements StorageLocationAndContainerManager {

    private StorageLocationTranslator storageLocationTranslator;
    private ManageContainersDaoProvider manageContainersDaoProvider;
    private DozerObjectTransformer objectTransformer;

    @Override
    public Collection<StorageUnitTO> createOrModify(Collection<StorageUnitTO> storageUnitTransferObjects) {
        Collection<StorageUnitTO> storageUnitTOs = new ArrayList<StorageUnitTO>();
        Collection<StorageLocation> newStorageLocations = new ArrayList<StorageLocation>();
        Collection<StorageLocation> storageLocations = getStorageLocationTranslator().getStorageLocations(storageUnitTransferObjects);
        for (StorageLocation storageLocation : storageLocations) {
            if (storageLocation.getStorageLocationId() != null) {
                StorageLocation existingStorageLocation = getStorageLocationDao().load(storageLocation.getStorageLocationId());
                copyModifiedAttributes(storageLocation, existingStorageLocation);
            } else {
                getStorageLocationDao().saveOrUpdate(storageLocation);
                newStorageLocations.add(storageLocation);
            }
        }
        storageUnitTOs.addAll(buildObjects(newStorageLocations, StorageUnitTO.class));
        return storageUnitTOs;
    }

    private StorageLocationDao getStorageLocationDao() {
        return getManageContainersDaoProvider().getStorageLocationDao();
    }

    private void copyModifiedAttributes(StorageLocation storageLocation, StorageLocation existingStorageLocation) {
        existingStorageLocation.setName(storageLocation.getName());
        existingStorageLocation.setBarcode(storageLocation.getBarcode());
        existingStorageLocation.setDescription(storageLocation.getDescription());
        existingStorageLocation.setStorageLocationType(storageLocation.getStorageLocationType());
        existingStorageLocation.setSubSubSiteId(storageLocation.getSubSubSiteId());
    }

    public StorageLocationTranslator getStorageLocationTranslator() {
        return storageLocationTranslator;
    }

    public void setStorageLocationTranslator(StorageLocationTranslator storageLocationTranslator) {
        this.storageLocationTranslator = storageLocationTranslator;
    }

    public ManageContainersDaoProvider getManageContainersDaoProvider() {
        return manageContainersDaoProvider;
    }

    public void setManageContainersDaoProvider(ManageContainersDaoProvider manageContainersDaoProvider) {
        this.manageContainersDaoProvider = manageContainersDaoProvider;
    }

    protected <E> Collection<E> buildObjects(Collection<?> sourceObjects, Class<E> destinationClass) {
        return (sourceObjects != null) ? getObjectTransformer().buildObjects(sourceObjects, destinationClass) : new ArrayList<E>();
    }

    public DozerObjectTransformer getObjectTransformer() {
        return objectTransformer;
    }

    public void setObjectTransformer(DozerObjectTransformer objectTransformer) {
        this.objectTransformer = objectTransformer;
    }

}
