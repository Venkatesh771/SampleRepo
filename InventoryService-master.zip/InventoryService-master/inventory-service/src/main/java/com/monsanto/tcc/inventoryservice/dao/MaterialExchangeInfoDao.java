/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.MaterialExchangeInfo;
import com.monsanto.tps.dao.GenericDao;

/* NBWALD - Feb 7, 2011 */
public interface MaterialExchangeInfoDao extends GenericDao<MaterialExchangeInfo, Long> {
}