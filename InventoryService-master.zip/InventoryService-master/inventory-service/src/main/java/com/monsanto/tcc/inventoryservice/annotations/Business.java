package com.monsanto.tcc.inventoryservice.annotations;

import org.springframework.stereotype.Component;

@Component
public @interface Business {
    String value() default "";
}
