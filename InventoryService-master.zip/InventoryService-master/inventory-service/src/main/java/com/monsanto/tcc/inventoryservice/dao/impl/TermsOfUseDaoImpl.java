package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventoryservice.dao.TermsOfUseDao;
import com.monsanto.tcc.inventoryservice.domain.TermsOfUseEntity;
import org.hibernate.SessionFactory;

import java.util.List;

/**
 * User: DCENGL
 */
public class TermsOfUseDaoImpl implements TermsOfUseDao {

    public static final String FIND_TERMS = "select gmtu.termsOfUse from GeneticMaterialTermsOfUse gmtu where gmtu.geneticMaterial.geneticMaterialId = :geneticMaterialId order by gmtu.termsOfUse.terms";
    private SessionFactory sessionFactory;

    @Override
    public List<TermsOfUseEntity> findTermsOfUse(Long geneticMaterialId) {
        return sessionFactory.getCurrentSession().createQuery(FIND_TERMS).setLong("geneticMaterialId", geneticMaterialId ).list();
    }

    @Override
    public TermsOfUseEntity load(Long termsOfUseId) {
        return (TermsOfUseEntity) sessionFactory.getCurrentSession().load("TermsOfUse", termsOfUseId);
    }

    @Override
    public void save(TermsOfUseEntity termsOfUseEntity) {
        sessionFactory.getCurrentSession().saveOrUpdate("TermsOfUse", termsOfUseEntity);
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
