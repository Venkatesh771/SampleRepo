/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao.impl;

import com.google.common.base.Joiner;
import com.monsanto.services.domain.germplasm.Inventory;
import com.monsanto.tcc.inventorycommon.transferobject.InactiveInventory;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.transform.Transformers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* nbwald - Dec 8, 2010 */
public class InactiveInventoryDao {
    private SessionFactory sessionFactory;
    public static final Joiner JOINER = Joiner.on(",").skipNulls();

    public List<InactiveInventory> findByInventoryPrograms(List<Long> inventoryProgramIds) {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.getNamedQuery("InactiveInventory.findByInventoryPrograms");
        query.setParameterList("inventoryProgramIds", inventoryProgramIds);
        query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
        List<Map<String, Object>> rows = query.list();
        return createInactiveInventories(rows);
    }

    private List<InactiveInventory> createInactiveInventories(List<Map<String, Object>> rows) {
        Map<Long, InactiveInventory> inactiveInventoryByInventoryId = new LinkedHashMap<Long, InactiveInventory>();
        for (Map<String, Object> row : rows) {
            Long inventoryId = getInventoryId(row);
            if (inactiveInventoryByInventoryId.containsKey(inventoryId)) {
                InactiveInventory inactiveInventory = inactiveInventoryByInventoryId.get(inventoryId);
                appendToParentInventoryBarcodeCsv(inactiveInventory, getParentInventoryBarcode(row));
            } else {
                inactiveInventoryByInventoryId.put(inventoryId, createInactiveInventory(row));
            }
        }
        return new ArrayList<InactiveInventory>(inactiveInventoryByInventoryId.values());
    }

    private void appendToParentInventoryBarcodeCsv(InactiveInventory inactiveInventory, String parentInventoryBarcode) {
        String appendedParentInventoryBarcodeCsv = addValueToCsv(inactiveInventory.getParentInventoryBarcode(), parentInventoryBarcode);
        inactiveInventory.setParentInventoryBarcode(appendedParentInventoryBarcodeCsv);
    }

    private String addValueToCsv(String oldCsv, String newValue) {
        return JOINER.join(Arrays.asList(oldCsv, newValue));
    }

    private InactiveInventory createInactiveInventory(Map<String, Object> row) {
        InactiveInventory inactiveInventory = new InactiveInventory();
        inactiveInventory.setInventory(createInventory(row));
        inactiveInventory.setGermplasmId(readLong(row, "GERMPLASM_ID"));
        inactiveInventory.setGermplasmOwnerProgRefId(readString(row, "GP_OWNER_BR_PROG_REF_ID"));
        inactiveInventory.setInventoryOwnerProgRefId(readString(row, "INV_OWNER_BR_PROG_REF_ID"));
        inactiveInventory.setInventoryPurpose(readString(row, "INVENTORY_PURPOSE_NAME"));
        inactiveInventory.setInventoryType(readString(row, "INVENTORY_TYPE_NAME"));
        inactiveInventory.setPedigree(readString(row, "PEDIGREE_NAME"));
        inactiveInventory.setGeneticMaterialSource(readString(row, "SOURCE_STR"));
        inactiveInventory.setParentInventoryBarcode(getParentInventoryBarcode(row));
        return inactiveInventory;
    }

    private Inventory createInventory(Map<String, Object> row) {
        Inventory inventory = new Inventory();
        inventory.setInventoryId(getInventoryId(row));
        inventory.setComments(readString(row, "INV_COMMENTS"));
        inventory.setSeedQuantity(readDouble(row, "QUANTITY"));
        inventory.setQuantityUOM(readString(row, "QUANTITY_UOM"));
        inventory.setQuantityUomId(readLong(row, "QUANTITY_UOM_ID"));
        inventory.setGeneticMaterialId(readLong(row, "GENETIC_MATERIAL_ID"));
        inventory.setBarcode(readString(row, "BARCODE"));
        inventory.setProgramId(readLong(row, "BR_PROG_ID"));
        return inventory;
    }

    private Long getInventoryId(Map<String, Object> row) {
        return readLong(row, "INVENTORY_ID");
    }

    private String getParentInventoryBarcode(Map<String, Object> row) {
        return readString(row, "PARENT_INVENTORY_BARCODE");
    }

    private String readString(Map<String, Object> row, String columnName) {
        return (String) row.get(columnName);
    }

    private Long readLong(Map<String, Object> row, String columnName) {
        BigDecimal value = readBigDecimal(row, columnName);
        return value == null ? null : value.longValue();
    }

    private Double readDouble(Map<String, Object> row, String columnName) {
        BigDecimal value = readBigDecimal(row, columnName);
        return value == null ? null : value.doubleValue();
    }

    private BigDecimal readBigDecimal(Map<String, Object> row, String columnName) {
        return (BigDecimal) row.get(columnName);
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
