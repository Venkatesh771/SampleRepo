package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.ProductName;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tcc.inventorycommon.transferobject.BlendProductNameFilter;
import com.monsanto.tcc.inventorycommon.transferobject.BlendProductNameTransferObject;
import com.monsanto.tcc.inventoryservice.dao.ProductNameDao;
import com.monsanto.tps.dao.GenericDaoImpl;
import org.hibernate.Query;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 17, 2009
 * Time: 10:03:28 AM
 */
public class ProductNameDaoImpl extends GenericDaoImpl<ProductName, Long> implements ProductNameDao {

    private static final Integer MAX_ROWS = 20;

    public ProductNameDaoImpl(Class aClass) {
        super(aClass);
    }

    public ProductName getProductNameByLexProductPubKey(String lexPubKey) throws QueryResultsException {
        Query query = getSession().getNamedQuery("getProductNameByLexProductPubKey");
        query.setString("lexPubKey", lexPubKey);
        List results = query.list();
        return firstResult(results);
    }

    public ProductName getProductNameByLexProductNamePubKey(String lexPubKey) throws QueryResultsException {
        Query query = getSession().getNamedQuery("getProductNameByLexProductNamePubKey");
        query.setString("lexPubKey", lexPubKey);
        List results = query.list();
        return firstResult(results);
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public List<BlendProductNameTransferObject> getPreCommercialProductNameByBrandName(BlendProductNameFilter filter) {
        Query query = getSession().getNamedQuery("getPreCommercialProductNameByBrandNameAndCrop");
        query.setLong("cropId", filter.getCropId());
        query.setString("productName", filter.getProductFilter());
        query.setMaxResults(MAX_ROWS);
        return query.list();
    }

    public List<BlendProductNameTransferObject> getAllPreCommercialProductNameByBrandName(){
        return null;
    }

    @Override
    public List<Long> getProductNameIdsWithSameCombination(Long brandId, Long countryId, String name) {
        Query query = getSession().getNamedQuery("getProductNameIdsWithSameCombination");
        query.setLong("brandId", brandId);
        query.setLong("countryId", countryId);
        query.setString("name", name);
        return query.list();
    }

    private ProductName firstResult(List results) throws QueryResultsException {
        if (results.size() == 0) {
            throw new QueryResultsException("Found NO results when getting Product Name by Lexicon Public Key");
        } else if (results.size() == 1) {
            return (ProductName) results.get(0);
        }
        throw new QueryResultsException("Found MULTIPLE results when getting Product Name by Lexicon Public Key");
    }
}
