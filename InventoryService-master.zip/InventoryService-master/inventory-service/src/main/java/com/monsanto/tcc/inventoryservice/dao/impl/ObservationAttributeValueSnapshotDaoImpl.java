package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.ObservationAttributeValueSnapshot;
import com.monsanto.tcc.inventoryservice.dao.ObservationAttributeValueSnapshotDao;
import org.hibernate.SessionFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Dan Schnettgoecke with IntelliJ IDEA.
 * Created on Jan 6, 2011 at 9:35:06 AM.
 */

public class ObservationAttributeValueSnapshotDaoImpl implements ObservationAttributeValueSnapshotDao {

    private SessionFactory sessionFactory;

    private static final int BATCH_SIZE = 50;

    @Transactional(propagation = Propagation.MANDATORY)
    public void saveSnapshots(List<ObservationAttributeValueSnapshot> snapshots) {
        int batchCounter = 0;
        for (ObservationAttributeValueSnapshot snapshot : snapshots) {
            sessionFactory.getCurrentSession().save(snapshot);
            batchCounter++;
            if (batchCounter % BATCH_SIZE == 0) {
                flushAndClearSession();
            }
        }
        flushAndClearSession();
    }

    private void flushAndClearSession() {
        sessionFactory.getCurrentSession().flush();
        sessionFactory.getCurrentSession().clear();
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}