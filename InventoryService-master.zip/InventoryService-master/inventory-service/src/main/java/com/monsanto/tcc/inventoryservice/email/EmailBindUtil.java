/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.email;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: EMGOODE
 * Date: Oct 19, 2009
 * Time: 10:04:32 AM
 * To change this template use File | Settings | File Templates.
 */
public class EmailBindUtil {
    private static final String START_PROPERTY_KEY = "${";
    private static final String STOP_PROPERTY_KEY = "}";

    public String bindParametersToString(String rawString, Map<String, String> parameterMap) {
        if (rawString.contains(START_PROPERTY_KEY) && rawString.contains(STOP_PROPERTY_KEY)) {
            return bindParameters(rawString, parameterMap);
        }
        return rawString;
    }

    private String bindParameters(String rawString, Map<String, String> parameterMap) {
        while (rawString.contains(START_PROPERTY_KEY) && rawString.contains(STOP_PROPERTY_KEY)) {
            String bindTextBlock = rawString.substring(rawString.indexOf(START_PROPERTY_KEY), rawString.indexOf(STOP_PROPERTY_KEY)+1);
            String defaultBindValue = null;
            int endIndex = bindTextBlock.indexOf(",") + 1;
            if( 0 == endIndex ) {
                endIndex = bindTextBlock.length();
            } else {
                defaultBindValue = bindTextBlock.substring(endIndex, bindTextBlock.length() - 1);
            }
            String bindVariable = bindTextBlock.substring(0, endIndex);

            String value = getValueByBind(bindVariable, parameterMap, defaultBindValue);

            rawString = findAndReplace(rawString, bindTextBlock, value + "");
        }
        return new StringBuffer(rawString).toString();
    }

    private String getValueByBind(String bindVariable, Map<String, String> parameterMap, String defaultValue) {
        String bindKey = bindVariable.substring(2, bindVariable.length() -1);
        if( parameterMap.containsKey(bindKey)) {
            return parameterMap.get(bindKey);
        } else {
            return defaultValue.trim();
        }

    }

    private String findAndReplace(String rawString, String bindVariable, String value) {
        String regularExpression = "\\Q" + bindVariable + "\\E";
        return rawString.replaceAll(regularExpression, value);
    }

}