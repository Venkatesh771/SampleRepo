package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.databuilder.QueryBuildingException;
import com.monsanto.tcc.inventorycommon.transferobject.SapSeedTreatmentInput;

import java.util.List;

public interface SeedTreatmentDao {
    List<SapSeedTreatmentInput> getSeedTreatmentInfo(List<Long> inventoryIds) throws QueryBuildingException, WrappingException;
}
