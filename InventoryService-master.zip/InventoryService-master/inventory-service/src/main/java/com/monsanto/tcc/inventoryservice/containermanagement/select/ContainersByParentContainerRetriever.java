package com.monsanto.tcc.inventoryservice.containermanagement.select;

import com.monsanto.tcc.inventorycommon.domain.StorageContainer;
import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;

import java.util.Collection;

public class ContainersByParentContainerRetriever extends AbstractStorageLocationAndContainerRetriever {
    private HasInventoryStorageContainerDecorator hasInventoryStorageContainerDecorator;

    @Override
    public Collection<StorageUnitTO> retrieve(Long parentContainerId) {
        Collection<StorageContainer> childStorageContainers = getManageContainersDaoProvider().getStorageContainerDao().getContainersByParentStorageContainerId(parentContainerId);
        hasInventoryStorageContainerDecorator.decorate(childStorageContainers);
        return buildObjects(childStorageContainers, StorageUnitTO.class);
    }

    public void setHasInventoryStorageContainerDecorator(HasInventoryStorageContainerDecorator hasInventoryStorageContainerDecorator) {
        this.hasInventoryStorageContainerDecorator = hasInventoryStorageContainerDecorator;
    }
}
