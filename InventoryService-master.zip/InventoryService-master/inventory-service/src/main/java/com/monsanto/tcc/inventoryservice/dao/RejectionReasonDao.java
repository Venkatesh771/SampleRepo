/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.RejectionReason;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

import java.util.List;

/**
 * User: jjbens2
 * Date: May 27, 2010
 */
public interface RejectionReasonDao extends GenericDao<RejectionReason, Long> {

    @DynamicDaoMethod(queryName = "RejectionReasonDao.getRejectionReasonByName",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    RejectionReason getRejectionReasonByName(@DynamicDaoParameter(name = "reasonName") String reasonName);

    @DynamicDaoMethod(queryName = "RejectionReasonDao.getRejectionReasonByType",
            parameterMatchingStrategy = ParameterMatchingStrategy.PARAMETER_MAPPING)
    List<RejectionReason> getRejectionReasonsByType(@DynamicDaoParameter(name = "reasonTypeName") String reasonTypeName);
}
