package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.domain.Decision;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tcc.inventoryservice.dao.DecisionDao;
import com.monsanto.tps.dao.GenericDaoImpl;
import org.hibernate.Query;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Oct 21, 2009
 * Time: 12:48:23 PM
 */
public class DecisionDaoImpl  extends GenericDaoImpl<Decision, Long> implements DecisionDao {
    public DecisionDaoImpl(Class aClass) {
        super(aClass);
    }

    public Decision getInventoryDecision() throws QueryResultsException {
        Query query = getSession().getNamedQuery("getInventoryDecision");
        List results = query.list();
        if (results.size() == 0) {
            throw new QueryResultsException("Found NO results when getting Inventory Decision");
        } else if (results.size() == 1){
            return (Decision) results.get(0);
        } throw new QueryResultsException("Found MULTIPLE results when getting Inventory Decision");
    }
}
