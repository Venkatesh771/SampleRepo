package com.monsanto.tcc.inventoryservice.business;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.tcc.databuilder.QueryBuildingException;
import com.monsanto.tcc.inventorycommon.transferobject.SapSeedTreatmentResponse;

import java.util.List;

public interface SapSeedTreatmentBusiness {
    public SapSeedTreatmentResponse getSapSeedTreatments(List<Long> inventoryIds) throws QueryBuildingException, WrappingException;
}
