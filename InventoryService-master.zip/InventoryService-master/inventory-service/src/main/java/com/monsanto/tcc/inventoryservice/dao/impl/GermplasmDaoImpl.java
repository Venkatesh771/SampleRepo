package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventoryservice.dao.GermplasmDao;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;


public class GermplasmDaoImpl implements GermplasmDao {
    private SessionFactory sessionFactory;

    @Override
    public void updateGermplasmCrossName(Long germplasmId, String crossName) {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.getNamedQuery("GermplasmDao.updateGermplasmCrossName");
        query.setParameter("crossName", crossName);
        query.setParameter("germplasmId", germplasmId);
        query.executeUpdate();
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
