package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.MaterialRequestStatus;
import com.monsanto.tcc.inventorycommon.exception.QueryResultsException;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: sssing5
 * Date: Jun 26, 2009
 * Time: 11:05:56 AM
 */
public interface MaterialRequestStatusDao extends GenericDao<MaterialRequestStatus, Long> {
    public MaterialRequestStatus getMaterialRequestStatusByName(String statusName) throws QueryResultsException;

    @DynamicDaoMethod(queryName = "MaterialRequestStatus.getActiveRequestStatuses")
    public List<MaterialRequestStatus> getAllActiveStatuses();
}
