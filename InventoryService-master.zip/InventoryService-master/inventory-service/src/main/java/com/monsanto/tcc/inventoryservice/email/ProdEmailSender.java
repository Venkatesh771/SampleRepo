/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.email;

import com.monsanto.tcc.inventorycommon.domain.email.EmailMessage;
import com.monsanto.tcc.inventorycommon.service.email.EmailSender;
import com.monsanto.tcc.inventorycommon.service.email.EmailSystemBroker;

/**
 * User: jjbens2
 * Date: Jun 2, 2010
 */
public class ProdEmailSender implements EmailSender {

    private EmailSystemBroker emailSystemBroker;

    @Override
    public void sendEmails(EmailMessage... emailMessageList) {
        emailSystemBroker.sendEmailMessages(emailMessageList);
    }

    @Override
    public void sendDeveloperExceptionEmail(EmailMessage... emailMessage) {
        emailSystemBroker.sendEmailMessages(emailMessage);
    }

    public void setEmailSystemBroker(EmailSystemBroker emailSystemBroker) {
        this.emailSystemBroker = emailSystemBroker;
    }
}
