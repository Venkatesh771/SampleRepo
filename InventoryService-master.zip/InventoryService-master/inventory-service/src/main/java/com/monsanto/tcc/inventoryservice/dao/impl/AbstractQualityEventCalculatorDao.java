package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dataservices.PersistentStoreStatement;
import com.monsanto.tcc.database.DatabaseResource;
import com.monsanto.tcc.databuilder.dbadapter.BaseDbAdapter;
import com.monsanto.tcc.inventorycommon.transferobject.AssayType;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: $
 * Last Change: $Author: daguar $
 * Date: $Date: Sep 18, 2009 2:31:56 PM $
 */
public abstract class AbstractQualityEventCalculatorDao extends BaseDbAdapter {

    private PersistentStoreStatement statement = null;
    private PersistentStoreResultSet rs = null;
    private PersistentStoreConnection connection = null;

    private Long r0GrowoutWorkflowId = null;
    private Double expectedOriginQuantity = null;
    private String expectedUnitOfMeasure = null;

    private Logger log4j = Logger.getLogger( AbstractQualityEventCalculatorDao.class );

    public AbstractQualityEventCalculatorDao() {}

    private void initMemberVariables( Long r0GrowoutWorkflowId, Double expectedOriginQuantity, String expectedUnitOfMeasure ) {
        this.r0GrowoutWorkflowId = r0GrowoutWorkflowId;
        this.expectedOriginQuantity = expectedOriginQuantity;
        this.expectedUnitOfMeasure = expectedUnitOfMeasure;
        if ( log4j.isDebugEnabled() ) {
            log4j.debug( "r0GrowoutWorkflowId = " + r0GrowoutWorkflowId  );
            log4j.debug( "expectedOriginQuantity = " + expectedOriginQuantity );
            log4j.debug( "expectedUnitOfMeasure = " + expectedUnitOfMeasure );
        }
    }

    public Map<Long, List<AssayType>> calculateEvents( PersistentStoreConnection conn, Long r0GrowoutWorkflowId, Double expectedOriginQuantity,
                                String expectedUnitOfMeasure ) throws Exception {

        this.connection = conn;
        try {
            initMemberVariables( r0GrowoutWorkflowId, expectedOriginQuantity, expectedUnitOfMeasure );
            return processQuery();
        }catch(Exception e ) {
            log4j.error( "Error processing calculate quality events query.", e );
            throw e;
        }finally {
            closeResources();
        }
    }

    private Map<Long, List<AssayType>> processQuery() throws Exception {
        statement = initializeStatementForQuery();
        rs = statement.executeQuery();
        return populateResults();
    }

    private Map<Long, List<AssayType>> populateResults() throws WrappingException {
        Map<Long, List<AssayType>> resultsMap = new HashMap<Long, List<AssayType>>();
        PersistentStoreResultSetFwdIterator it = rs.getForwardIterator();
        while ( it.next() ) {
            populateSingleRecord( resultsMap, it );
        }
        if ( log4j.isDebugEnabled() ) {
            log4j.debug("QualityEventCalculatorDAO finished. Map entries = " + resultsMap.size() );
        }
        return resultsMap;
    }

    private void populateSingleRecord( Map<Long, List<AssayType>> resultsMap, PersistentStoreResultSetFwdIterator it ) throws WrappingException {
        Long key = it.getLong("key");
        List<AssayType> typesInMap = fetchAssaysByKeyFor(resultsMap, key);
        addAssayTypeToListForKey(it, typesInMap);
        resultsMap.put( key, typesInMap );
    }

    private void addAssayTypeToListForKey(PersistentStoreResultSetFwdIterator it, List<AssayType> typesInMap) throws WrappingException {
        AssayType type = new AssayType( it.getString("obsv_attribute_ref_id"), it.getString("oav_value") );
        typesInMap.add( type );
    }

    private List<AssayType> fetchAssaysByKeyFor(Map<Long, List<AssayType>> resultsMap, Long plotId) {
        List<AssayType> typesInMap = resultsMap.get( plotId );
        return initializeListForNewKey(typesInMap);
    }

    private List<AssayType> initializeListForNewKey(List<AssayType> typesInMap) {
        if ( typesInMap == null ) {
            typesInMap = new ArrayList<AssayType>();
        }
        return typesInMap;
    }

    private PersistentStoreStatement initializeStatementForQuery() throws Exception {
        statement = connection.prepareStatement( getCalculateQualityEventsQuery() );
        statement.setParam( 1, r0GrowoutWorkflowId );
        statement.setParam( 2, expectedOriginQuantity );
        statement.setParam( 3, expectedUnitOfMeasure );
        return statement;
    }

    protected abstract String getCalculateQualityEventsQuery() throws Exception;

    private void closeResources() {
        DatabaseResource.close( rs );
        DatabaseResource.close( statement );
        setResourcesToNull();
    }

    private void setResourcesToNull() {
        rs = null;
        statement = null;
    }

}



