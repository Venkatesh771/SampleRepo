package com.monsanto.tcc.inventoryservice.dao.impl;

import com.google.common.collect.Lists;
import com.monsanto.dataservices.PersistentStoreConnection;
import com.monsanto.dbdataservices.PersistentStoreCachedDBConnection;
import com.monsanto.tcc.databuilder.dbadapter.StringFromFileBuilder;
import com.monsanto.tcc.inventorycommon.domain.InventoryContainer;
import com.monsanto.tcc.inventoryservice.dao.InventoryContainerDao;
import com.monsanto.tps.dao.GenericDaoImpl;
import com.monsanto.tps.primarykey.midas.BulkKeyGenerator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.BatchSqlUpdate;

import javax.annotation.Resource;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class InventoryContainerDaoImpl extends GenericDaoImpl<InventoryContainer, Long> implements InventoryContainerDao {

    @Resource(name = "jdbcTemplate")
    private JdbcTemplate jdbcTemplate;
    @Resource(name = "stringFromFileBuilder")
    private StringFromFileBuilder stringFromFileBuilder;
    @Resource(name = "bulkKeyGenerator")
    private BulkKeyGenerator bulkKeyGenerator;

    private static final Log logger = LogFactory.getLog(InventoryContainerDaoImpl.class);
    private static final String INSERT_NUMBER = "insert into midas.temp_session_ocd (request_id, number_1, sort_order) values (:REQUEST_ID, :NUMBER_1, :SORT_ORDER)";
    private static final String INSERT_INVENTORY_CONTAINER_FILE_PATH = "com/monsanto/tcc/inventoryservice/dao/impl/InsertInventoryContainer.sql";
    private static final String FIND_INV_IDS_WITHOUT_CONTAINERS_SQL_PATH = "com/monsanto/tcc/inventoryservice/dao/impl/FindInventoryIdsWithoutInventoryContainers.sql";

    public InventoryContainerDaoImpl(Class entityClass) {
        super(entityClass);
    }

    @Override
    public Collection<InventoryContainer> getInventoryContainersByInventoryIds(Collection<Long> inventoryIds) {
        long requestId = 2;
        insertIntoTempTable(inventoryIds, requestId);
        return getInventoryContainersByNamedQueryWithTempTable(requestId, "InventoryContainerDao.getInventoryContainersByInventoryIds");
    }

    @Override
    public Collection<InventoryContainer> getInventoryContainersByInventoryIds(TempSessionRequest tempSessionRequest) {
        return getInventoryContainersByNamedQueryWithTempTable(tempSessionRequest.getRequestId(), "InventoryContainerDao.getInventoryContainersByInventoryIds");
    }

    @Override
    public Collection<InventoryContainer> getStorageInventoryContainersByInventoryIds(Collection<Long> inventoryIds) {
        deleteByRequestId(TempSessionRequest.INVENTORY_CONTAINERS_BY_INVENTORY_ID.getRequestId());
        insertIntoTempTable(inventoryIds, TempSessionRequest.INVENTORY_CONTAINERS_BY_INVENTORY_ID.getRequestId());
        return getStorageInventoryContainersByInventoryIds(TempSessionRequest.INVENTORY_CONTAINERS_BY_INVENTORY_ID);
    }

    @Override
    public Collection<InventoryContainer> getStorageInventoryContainersByInventoryIds(TempSessionRequest tempSessionRequest) {
        return getInventoryContainersByNamedQueryWithTempTable(tempSessionRequest.getRequestId(), "InventoryContainerDao.getStorageInventoryContainersByInventoryIds");
    }

    private Collection<InventoryContainer> getInventoryContainersByNamedQueryWithTempTable(Long requestId, String queryName) {
        Query query = getSession().getNamedQuery(queryName);
        query.setParameter("requestId", requestId);
        return (Collection<InventoryContainer>) query.list();
    }

    @Override
    public int deleteInventoryContainers(long storageContainerId, Collection<Long> inventoryIds) throws Exception {
        long requestId = 3;
        insertIntoTempTable(inventoryIds, requestId);
        Query query = getSession().getNamedQuery("InventoryContainerDao.deleteByStorageContainerIdAndInventoryIds");
        query.setParameter("storageContainerId", storageContainerId);
        query.setParameter("requestId", requestId);
        int rowsDeleted = 0;
        rowsDeleted = query.executeUpdate();
        logger.info("deleteInventoryContainers(" + storageContainerId + ", ...) deleted " + rowsDeleted + " rows.");
        return rowsDeleted;
    }

    @Override
    public List<Long> getNextInventoryContainerIds(int count) {
        Query query = getSession().getNamedQuery("InventoryContainer.getNextInventoryContainerIds");
        query.setParameter("count", count);
        return query.list();
    }

    @Override
    public int copyContainerTreatments(long sourceInventoryContainerId, long targetInventoryContainerId) {
        return copyContainerTreatments(Lists.newArrayList(sourceInventoryContainerId), targetInventoryContainerId);
    }

    @Override
    public int copyContainerTreatments(Collection<Long> sourceInventoryContainerIds, long targetInventoryContainerId) {

        if (sourceInventoryContainerIds != null && !sourceInventoryContainerIds.isEmpty()) {
            getSession().flush();
            int rowCount = getSession().getNamedQuery("InventoryContainerDao.copyMultipleSourceContainerTreatments")
                    .setLong("targetInventoryContainerId", targetInventoryContainerId)
                    .setParameterList("sourceInventoryContainerIds", sourceInventoryContainerIds)
                    .executeUpdate();
            logger.info("copyContainerTreatments(" + targetInventoryContainerId + ") copied " + rowCount + " treatments.");
            return rowCount;
        }
        logger.info("copyContainerTreatments(" + targetInventoryContainerId + ") had no source containers.");
        return 0;
    }

    @Override
    public int[] createInventoryContainersInBatch(Long pendingStorageContainerId, final Collection<Long> inventoryIds, final String createdByUserId) {
        String sql = stringFromFileBuilder.buildStringFromFile(INSERT_INVENTORY_CONTAINER_FILE_PATH);
        final Long storageContainerId = pendingStorageContainerId;
        final Timestamp modifiedDate = new Timestamp(System.currentTimeMillis());
        final Iterator<Long> inventoryIdsIterator = inventoryIds.iterator();
        return jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                ps.setLong(1, inventoryIdsIterator.next());
                ps.setLong(2, storageContainerId);
                ps.setString(3, createdByUserId);
                ps.setTimestamp(4, modifiedDate);
                ps.setLong(5, bulkKeyGenerator.generate());
            }

            @Override
            public int getBatchSize() {
                return inventoryIds.size();
            }
        });
    }

    @Override
    public Collection<Long> findInventoryIdsWithoutContainers(int sessionId) {
        String sql = stringFromFileBuilder.buildStringFromFile(FIND_INV_IDS_WITHOUT_CONTAINERS_SQL_PATH);
        return jdbcTemplate.queryForList(sql, Long.class, sessionId);
    }

    private void insertIntoTempTable(Collection<Long> inventoryIds, long requestId) {
        int sortOrder = 1;
        BatchSqlUpdate batchSqlUpdate = buildTempTableNumberBatchUpdate();
        for (Long number : inventoryIds) {
            batchSqlUpdate.update(requestId, number, sortOrder++);
        }
        batchSqlUpdate.flush();
    }

    private BatchSqlUpdate buildTempTableNumberBatchUpdate() {
        BatchSqlUpdate batchSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(), INSERT_NUMBER);
        batchSqlUpdate.declareParameter(new SqlParameter("REQUEST_ID", Types.INTEGER));
        batchSqlUpdate.declareParameter(new SqlParameter("NUMBER_1", Types.BIGINT));
        batchSqlUpdate.declareParameter(new SqlParameter("SORT_ORDER", Types.INTEGER));
        return batchSqlUpdate;
    }

    private int deleteByRequestId(long requestId) {
        Query query = getSessionFactory().getCurrentSession().getNamedQuery("TempSessionOcd.deleteByRequestId");
        query.setParameter("requestId", requestId);
        return query.executeUpdate();
    }

    private PersistentStoreConnection getConnection() {
        try {
            return new PersistentStoreCachedDBConnection(jdbcTemplate.getDataSource().getConnection());
        } catch (Exception e) {
            throw new CannotGetJdbcConnectionException(e.getMessage(), new SQLException(e));
        }
    }
}