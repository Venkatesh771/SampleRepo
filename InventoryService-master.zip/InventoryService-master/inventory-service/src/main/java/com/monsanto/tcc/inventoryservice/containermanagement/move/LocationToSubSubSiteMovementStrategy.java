/*
 Copyright:  Copyright � 2010 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.tcc.inventoryservice.containermanagement.move;

import com.monsanto.tcc.inventorycommon.domain.StorageLocation;
import com.monsanto.tcc.inventorycommon.domain.StorageUnitTO;
import com.monsanto.tcc.inventorycommon.transferobject.StorageType;
import com.monsanto.tcc.inventoryservice.dao.StorageLocationDao;

public class LocationToSubSubSiteMovementStrategy
    implements StorageUnitMovementStrategy
{
    private StorageLocationDao storageLocationDao;
    private LocationToSubSubSiteMovement locationToSubSubSiteMovement;

    @Override
    public boolean isApplicableTo(StorageUnitTO moved, StorageUnitTO to) {
        return isType(moved, StorageType.STORAGE_LOCATION) && isType(to, StorageType.SUB_SUB_SITE);
    }

    @Override
    public void move(StorageUnitTO moved, StorageUnitTO to) {
        StorageLocation movedLocation = storageLocationDao.getStorageLocationByBarcode(moved.getBarcode());
        locationToSubSubSiteMovement.move(movedLocation, to);
    }

    private boolean isType(StorageUnitTO storageUnit, StorageType storageType) {
        return storageType.equals(storageUnit.getStorageUnitType().getType());
    }

    public void setStorageLocationDao(StorageLocationDao storageLocationDao) {
        this.storageLocationDao = storageLocationDao;
    }

    public void setLocationToSubSubSiteMovement(LocationToSubSubSiteMovement locationToSubSubSiteMovement) {
        this.locationToSubSubSiteMovement = locationToSubSubSiteMovement;
    }
}