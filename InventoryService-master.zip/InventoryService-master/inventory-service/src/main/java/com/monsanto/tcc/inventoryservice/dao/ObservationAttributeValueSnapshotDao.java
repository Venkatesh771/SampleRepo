package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.ObservationAttributeValueSnapshot;

import java.util.List;

/**
 * Created by Dan Schnettgoecke with IntelliJ IDEA.
 * Created on Dec 15, 2010 at 12:42:33 PM.
 */

public interface ObservationAttributeValueSnapshotDao {

    public void saveSnapshots(List<ObservationAttributeValueSnapshot> snapshots);
}