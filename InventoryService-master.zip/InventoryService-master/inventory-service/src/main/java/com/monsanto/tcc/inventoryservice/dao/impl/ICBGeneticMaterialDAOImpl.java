package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.inventorycommon.service.icbgeneticmaterial.domain.ICBGeneticMaterial;
import com.monsanto.tcc.inventoryservice.dao.ICBGeneticMaterialDAO;
import org.hibernate.CacheMode;
import org.hibernate.SessionFactory;
import org.hibernate.transform.AliasToBeanResultTransformer;

import javax.annotation.Resource;
import java.util.Collection;

import static org.springframework.util.CollectionUtils.isEmpty;

/**
 * Created by IntelliJ IDEA. User: KKTIWA Date: 6/7/12 Time: 3:13 PM
 */

public class ICBGeneticMaterialDAOImpl implements ICBGeneticMaterialDAO {

    @Resource(name = "sessionFactory")
    private SessionFactory sessionFactory;

    private static final int FETCH_SIZE = 200;

    @Override
    public Collection<ICBGeneticMaterial> getICBGeneticMaterial(long fieldId) {
        Collection<ICBGeneticMaterial> icbGeneticMaterialList = getICBGeneticMaterialData(fieldId, "ICBGeneticMaterialDAO.getICBGeneticMaterialByRowRequest");
        return !isEmpty(icbGeneticMaterialList) ? icbGeneticMaterialList : getICBGeneticMaterialData(fieldId, "ICBGeneticMaterialDAO.getICBGeneticMaterial");
    }

    private Collection<ICBGeneticMaterial> getICBGeneticMaterialData(long fieldId, String queryId) {
        //noinspection unchecked
        return sessionFactory.getCurrentSession().getNamedQuery(queryId)
            .setLong("fieldId", fieldId)
            .setFetchSize(FETCH_SIZE)
            .setCacheMode(CacheMode.IGNORE)
            .setResultTransformer(new AliasToBeanResultTransformer(ICBGeneticMaterial.class))
            .list();
    }
}