package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.ParentInventory;
import com.monsanto.tps.dao.GenericDao;

/**
 * Created by IntelliJ IDEA.
 * User: rrpatn
 * Date: May 25, 2010
 * Time: 4:08:01 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ParentInventoryDao extends GenericDao<ParentInventory, Long> {
}
