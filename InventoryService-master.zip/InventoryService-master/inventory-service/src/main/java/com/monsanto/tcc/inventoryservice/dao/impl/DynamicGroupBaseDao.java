package com.monsanto.tcc.inventoryservice.dao.impl;

import com.monsanto.tcc.databuilder.dbadapter.QueryFileStringBuilder;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.BatchSqlUpdate;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import javax.annotation.Resource;
import java.sql.Types;
import java.util.Collection;
import java.util.List;

public abstract class DynamicGroupBaseDao extends HibernateDaoSupport {

    @Resource(name = "jdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    private static final String INSERT_NUMBER = "insert into midas.temp_session_ocd (request_id, number_1, sort_order) values (:REQUEST_ID, :NUMBER_1, :SORT_ORDER)";
    private static final long MAX_REQUEST_ID = 99999999;

    protected abstract String getFilename();

    protected abstract Class getTransformerClass();

    protected abstract void addScalars(SQLQuery query);

    public List getData(List<Long> inputList) {
        if (inputList != null) {
            int requestId = (int) (Math.random() * MAX_REQUEST_ID);
            insertIntoTempTable(inputList, requestId);
            return getDataFromDatabase(requestId);
        }
        return null;
    }

    private void insertIntoTempTable(Collection<Long> inventoryIds, long requestId) {
        int sortOrder = 1;
        BatchSqlUpdate batchSqlUpdate = buildTempTableNumberBatchUpdate();
        for (Long number : inventoryIds) {
            batchSqlUpdate.update(requestId, number, sortOrder++);
        }
        batchSqlUpdate.flush();
    }

    private BatchSqlUpdate buildTempTableNumberBatchUpdate() {
        BatchSqlUpdate batchSqlUpdate = new BatchSqlUpdate(jdbcTemplate.getDataSource(), INSERT_NUMBER);
        batchSqlUpdate.declareParameter(new SqlParameter("REQUEST_ID", Types.INTEGER));
        batchSqlUpdate.declareParameter(new SqlParameter("NUMBER_1", Types.BIGINT));
        batchSqlUpdate.declareParameter(new SqlParameter("SORT_ORDER", Types.INTEGER));
        return batchSqlUpdate;
    }

    private List getDataFromDatabase(long requestId) {
        Query query = buildQuery(requestId);
        return query.list();
    }

    private SQLQuery buildQuery(long requestId)  {
        SQLQuery query = (SQLQuery) getSessionFactory().getCurrentSession().createSQLQuery(getSqlString(getFilename()))
            .setLong("requestId", requestId)
            .setResultTransformer(Transformers.aliasToBean(getTransformerClass()));
        addScalars(query);
        return query;
    }

    public static String getSqlString(String fileName){
        try {
            return new QueryFileStringBuilder().getQueryString(fileName);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to build query at " + fileName, e);
        }
    }
}