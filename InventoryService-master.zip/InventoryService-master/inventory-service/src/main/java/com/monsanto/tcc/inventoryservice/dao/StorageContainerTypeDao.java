package com.monsanto.tcc.inventoryservice.dao;

import com.monsanto.tcc.inventorycommon.domain.StorageContainerType;
import com.monsanto.tps.dao.GenericDao;
import com.monsanto.tps.dao.annotation.DynamicDaoMethod;
import com.monsanto.tps.dao.annotation.DynamicDaoParameter;
import com.monsanto.tps.dao.annotation.ParameterMatchingStrategy;

/**
 * Created by IntelliJ IDEA.
 * User: SSNALL
 * Date: Mar 3, 2010
 * Time: 9:27:21 AM
 * To change this template use File | Settings | File Templates.
 */
public interface StorageContainerTypeDao extends GenericDao<StorageContainerType, Long> {
    
    @DynamicDaoMethod(queryName="StorageContainerType.getByName", parameterMatchingStrategy=ParameterMatchingStrategy.PARAMETER_MAPPING)
    StorageContainerType getByName(@DynamicDaoParameter(name="name") String name);
}

